/**
 *  Copyright Notice:
 *  Copyright 2021-2022 DMTF. All rights reserved.
 *  License: BSD 3-Clause License. For full text see link: https://github.com/DMTF/libspdm/blob/main/LICENSE.md
 **/

#define PLATFORM "LIBSPDM"
#define DATE "Thu 21/01/2023"

const char *compiler_flags = "compiler: information not available from libspdm";
