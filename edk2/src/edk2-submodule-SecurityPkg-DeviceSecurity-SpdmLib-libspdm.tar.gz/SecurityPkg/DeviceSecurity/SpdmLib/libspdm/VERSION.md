libspdm version 3.6.0 (pending and unreleased)
