syst_cgen.pl - a SYS-T message collateral generator

Usage:
perl ./syst_cgen.pl --help

Example:
An example project using the collateral generator
is located in <SDK-ROOT>/library/examples/client.
