// Copyright © 2026 Cloud Hypervisor Contributors
//
// SPDX-License-Identifier: Apache-2.0

use std::collections::BTreeSet;
use std::result;
use std::sync::{Arc, Barrier};

use log::{debug, warn};
use serde::{Deserialize, Serialize};
use thiserror::Error as ThisError;
use vm_device::BusDevice;
use vm_device::interrupt::InterruptSourceGroup;
use vm_memory::bitmap::AtomicBitmap;
use vm_memory::{
    Bytes, GuestAddress, GuestAddressSpace, GuestMemoryAtomic, GuestMemoryError, GuestMemoryMmap,
};
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};

use crate::iommu::{Error as IommuError, HwInfo, Invalidation, PhysicalIommu, TableEntry};
use crate::{read_le_u32, read_le_u64, write_le_u32, write_le_u64};

type GuestMemoryMmapAtomic = GuestMemoryAtomic<GuestMemoryMmap<AtomicBitmap>>;

// All constants below are based on the reference specification that
// can be found at https://developer.arm.com/documentation/ihi0070/latest/
pub const SMMU_V3_MMIO_SIZE: u64 = 0x2_0000;
// Registers are exposed through two 64KiB pages.
pub const SMMU_V3_MMIO_PAGE_SIZE: u64 = 0x1_0000;

const CMDQ_ENTRY_SIZE: u64 = 16;

// Page 0 registers
const IDR0: u64 = 0x0000;
const IDR1: u64 = 0x0004;
const IDR2: u64 = 0x0008;
const IDR3: u64 = 0x000c;
const IDR4: u64 = 0x0010;
const IDR5: u64 = 0x0014;
const IIDR: u64 = 0x0018;
const AIDR: u64 = 0x001c;
const CR0: u64 = 0x0020;
const CR0ACK: u64 = 0x0024;
const CR1: u64 = 0x0028;
const CR2: u64 = 0x002c;
const STATUSR: u64 = 0x0040;
const GBPA: u64 = 0x0044;
const IRQ_CTRL: u64 = 0x0050;
const IRQ_CTRLACK: u64 = 0x0054;
const GERROR: u64 = 0x0060;
const GERRORN: u64 = 0x0064;
const GERROR_IRQ_CFG0: u64 = 0x0068;
const GERROR_IRQ_CFG0_HI: u64 = 0x006c;
const GERROR_IRQ_CFG1: u64 = 0x0070;
const GERROR_IRQ_CFG2: u64 = 0x0074;
const STRTAB_BASE: u64 = 0x0080;
const STRTAB_BASE_HI: u64 = 0x0084;
const STRTAB_BASE_CFG: u64 = 0x0088;
const CMDQ_BASE: u64 = 0x0090;
const CMDQ_BASE_HI: u64 = 0x0094;
const CMDQ_PROD: u64 = 0x0098;
const CMDQ_CONS: u64 = 0x009c;
const EVENTQ_BASE: u64 = 0x00a0;
const EVENTQ_BASE_HI: u64 = 0x00a4;
const EVENTQ_IRQ_CFG0: u64 = 0x00b0;
const EVENTQ_IRQ_CFG0_HI: u64 = 0x00b4;
const EVENTQ_IRQ_CFG1: u64 = 0x00b8;
const EVENTQ_IRQ_CFG2: u64 = 0x00bc;

// Page 1 registers
const PAGE1_BASE: u64 = 0x1_0000;
const EVENTQ_PROD: u64 = PAGE1_BASE + 0x00a8;
const EVENTQ_CONS: u64 = PAGE1_BASE + 0x00ac;

// IDR0 fields
const IDR0_S1P: u32 = 1 << 1;
const IDR0_TTF_AARCH64: u32 = 0b10 << 2;
pub const IDR0_COHACC: u32 = 1 << 4;
const IDR0_ASID16: u32 = 1 << 12;
const IDR0_CD2L: u32 = 1 << 19;
const IDR0_ATS: u32 = 1 << 10;
const IDR0_TTENDIAN_LE: u32 = 0b10 << 21;
const IDR0_STALL_MODEL_NONE: u32 = 0b01 << 24;
const IDR0_STLEVEL_2LVL: u32 = 0b01 << 27;
// Emulation model supported features
//   S1P:         Stage 1 is programmed by the guest, stage 2 is not exposed.
//   TTENDIAN:    Translation table walks are little endian only.
//   STALL_MODEL: Faults terminate the transaction and are never stalled.
//   STLEVEL:     Stream table walks can have two levels.
const IDR0_MODEL_FEATURES: u32 =
    IDR0_S1P | IDR0_TTENDIAN_LE | IDR0_STALL_MODEL_NONE | IDR0_STLEVEL_2LVL;
// Host features mask
//   COHACC: Access to tables, structures and queues are coherent.
//   TTF:    Walk stage 1 tables in the AArch64 format.
//   ASID16: ASIDs read from Context Descriptor are 16 bits.
//   CD2L:   Walk two level Context Descriptor table.
const IDR0_HOST_FEATURES_MASK: u32 = IDR0_COHACC | IDR0_TTF_AARCH64 | IDR0_ASID16 | IDR0_CD2L;

// IDR1 fields
const IDR1_SIDSIZE: u32 = 16;
const IDR1_SIDSIZE_MASK: u32 = 0x3f;
const IDR1_SSIDSIZE_SHIFT: u32 = 6;
const IDR1_SSIDSIZE_MASK: u32 = 0x1f << IDR1_SSIDSIZE_SHIFT;
const IDR1_CMDQS: u32 = Q_MAX_LOG2SIZE << 21;
const IDR1_EVENTQS: u32 = Q_MAX_LOG2SIZE << 16;
// Emulation model supported features
//   SIDSIZE: StreamIDs are 16 bits.
//   CMDQS:   Command queue holds Q_MAX_LOG2SIZE entries.
//   EVENTQS: Event queue holds Q_MAX_LOG2SIZE entries.
const IDR1_MODEL_FEATURES: u32 = IDR1_SIDSIZE | IDR1_CMDQS | IDR1_EVENTQS;

// IDR5 fields
const IDR5_OAS_MASK: u32 = 0b111;
const IDR5_OAS_48BIT: u32 = 0b101;
const IDR5_GRAN4K: u32 = 1 << 4;
const IDR5_GRAN16K: u32 = 1 << 5;
const IDR5_GRAN64K: u32 = 1 << 6;
const IDR5_GRAN_MASK: u32 = IDR5_GRAN4K | IDR5_GRAN16K | IDR5_GRAN64K;
const IDR5_MODEL_FEATURES: u32 = 0;

// CR0 fields
const CR0_SMMUEN: u32 = 1 << 0;
const CR0_PRIQEN: u32 = 1 << 1;
const CR0_EVENTQEN: u32 = 1 << 2;
const CR0_CMDQEN: u32 = 1 << 3;
const CR0_ATSCHK: u32 = 1 << 4;
const CR0_VMW: u32 = 0b111 << 6;
const CR0_WRITE_MASK: u32 =
    CR0_SMMUEN | CR0_PRIQEN | CR0_EVENTQEN | CR0_CMDQEN | CR0_ATSCHK | CR0_VMW;

// CR1 fields
const CR1_WRITE_MASK: u32 = 0x0000_0fff;

// CR2 fields
const CR2_WRITE_MASK: u32 = 0x0000_0007;

// GBPA fields
const GBPA_UPDATE: u32 = 1 << 31;
const GBPA_ABORT: u32 = 1 << 20;

// IRQ_CTRL fields
const IRQ_CTRL_GERROR_IRQEN: u32 = 1 << 0;
const IRQ_CTRL_EVENTQ_IRQEN: u32 = 1 << 2;
const IRQ_CTRL_WRITE_MASK: u32 = 0x0000_0007;

// GERROR fields
const GERROR_CMDQ_ERR: u32 = 1 << 0;
const GERROR_EVENTQ_ABT_ERR: u32 = 1 << 2;
const GERRORN_WRITE_MASK: u32 = 0x0000_01fd;

// CMDQ_PROD fields
const CMDQ_PROD_WRITE_MASK: u32 = 0x000f_ffff;

// CMDQ_CONS fields
const CMDQ_CONS_ERR_SHIFT: u32 = 24;
const CMDQ_CONS_ERR_MASK: u32 = 0x7f << CMDQ_CONS_ERR_SHIFT;
const CMDQ_CONS_WRITE_MASK: u32 = 0x7f0f_ffff;
const CERROR_ILL: u32 = 1;
const CERROR_ABT: u32 = 2;

// Event queue
const EVENTQ_ENTRY_SIZE: u64 = 32;
const EVENTQ_PROD_OVFLG: u32 = 1 << 31;
const EVENTQ_CONS_OVACKFLG: u32 = 1 << 31;
const EVENTQ_PROD_WRITE_MASK: u32 = 0x800f_ffff;
const EVENTQ_CONS_WRITE_MASK: u32 = 0x800f_ffff;

// Queue base field masks
const Q_BASE_LOG2SIZE_MASK: u64 = 0x1f;
const Q_BASE_ADDR_MASK: u64 = 0x000f_ffff_ffff_ffe0;
const Q_BASE_RWA: u64 = 1 << 62;
const Q_BASE_WRITE_MASK: u64 = Q_BASE_RWA | Q_BASE_ADDR_MASK | Q_BASE_LOG2SIZE_MASK;
/// Largest queue both IDR1.CMDQS and IDR1.EVENTQS advertise.
const Q_MAX_LOG2SIZE: u32 = 19;

// Stream table layout
const STRTAB_BASE_ADDR_MASK: u64 = 0x000f_ffff_ffff_ffc0;
const STRTAB_BASE_RA: u64 = 1 << 62;
const STRTAB_BASE_WRITE_MASK: u64 = STRTAB_BASE_RA | STRTAB_BASE_ADDR_MASK;
const STRTAB_BASE_CFG_WRITE_MASK: u32 = 0x0003_07ff;
const STRTAB_CFG_FMT_SHIFT: u32 = 16;
const STRTAB_CFG_FMT_MASK: u32 = 0b11;
const STRTAB_CFG_SPLIT_SHIFT: u32 = 6;
const STRTAB_CFG_SPLIT_MASK: u32 = 0x1f;
const STRTAB_CFG_SPLIT_DEFAULT: u32 = 6;
const STRTAB_CFG_LOG2SIZE_MASK: u32 = 0x3f;
const STRTAB_FMT_2LEVEL: u32 = 0b01;

const STE_SIZE: u64 = 64;
const STE_WORDS: usize = 8;
const L1STD_SIZE: u64 = 8;
const L1STD_SPAN_MASK: u64 = 0x1f;
const L1STD_L2PTR_MASK: u64 = 0x00ff_ffff_ffff_ffc0;

const STE_V: u64 = 1 << 0;
const STE_CONFIG_SHIFT: u64 = 1;
const STE_CONFIG_MASK: u64 = 0b111;
const STE_CONFIG_BYPASS: u8 = 0b100;
const STE_CONFIG_S1_ONLY: u8 = 0b101;
const STE_CONFIG_S2_ONLY: u8 = 0b110;
const STE_CONFIG_NESTED: u8 = 0b111;

// Command opcodes
const CMD_OPCODE_MASK: u64 = 0xff;
const CMD_PREFETCH_CONFIG: u8 = 0x01;
const CMD_PREFETCH_ADDR: u8 = 0x02;
const CMD_SSEC: u64 = 1 << 10;
const CMD_CFGI_STE: u8 = 0x03;
const CMD_CFGI_STE_RANGE: u8 = 0x04;
const CMD_CFGI_CD: u8 = 0x05;
const CMD_CFGI_CD_ALL: u8 = 0x06;
const CMD_TLBI_NH_ALL: u8 = 0x10;
const CMD_TLBI_NH_ASID: u8 = 0x11;
const CMD_TLBI_NH_VA: u8 = 0x12;
const CMD_TLBI_NH_VAA: u8 = 0x13;
const CMD_TLBI_NSNH_ALL: u8 = 0x30;
const CMD_ATC_INV: u8 = 0x40;
const CMD_SYNC: u8 = 0x46;

// CMD_SYNC fields
const CMD_SYNC_CS_SHIFT: u64 = 12;
const CMD_SYNC_CS_MASK: u64 = 0b11 << CMD_SYNC_CS_SHIFT;
const CMD_SYNC_CS_IRQ: u64 = 0b01 << CMD_SYNC_CS_SHIFT;
const CMD_SYNC_CS_RESERVED: u64 = 0b11 << CMD_SYNC_CS_SHIFT;

fn align_down(value: u64, bits: u32) -> u64 {
    match 1u64.checked_shl(bits) {
        Some(alignment) => value & !(alignment - 1),
        None => 0,
    }
}

#[derive(Clone, Copy, Debug)]
struct Command {
    opcode: u8,
    word0: u64,
    word1: u64,
}

impl Command {
    fn stream_id(&self) -> u32 {
        (self.word0 >> 32) as u32
    }
}

#[derive(Debug, ThisError)]
pub enum Error {
    #[error("Event queue is not enabled")]
    EventQueueDisabled,
    #[error("Event queue is full")]
    EventQueueFull,
    #[error("Event queue abort error is not acknowledged")]
    EventQueueAbortPending,
    #[error("Guest memory access failed")]
    GuestMemory(#[source] GuestMemoryError),
    #[error("Failed to fetch the command at {0:#x}")]
    CommandFetch(u64, #[source] GuestMemoryError),
    #[error("Failed to fetch the STE for SID {0:#x}")]
    SteFetch(u32, #[source] GuestMemoryError),
    #[error("Illegal command {0:#x}")]
    IllegalCommand(u8),
    #[error("Secure command {0:#x} on the non-secure queue")]
    SecureCommand(u8),
    #[error("The backend rejected command {0:#x}")]
    Backend(u8, #[source] IommuError),
    #[error("The backend rejected the configuration of SID {0:#x}")]
    BackendStream(u32, #[source] IommuError),
    #[error("The backend failed to report the host information")]
    BackendHwInfo(#[source] IommuError),
    #[error("The backend reported information for another IOMMU")]
    BackendHwInfoMismatch,
    #[error("Host IOMMU reported no translation granule")]
    MissingHostGranules,
    #[error("Unsupported access width {0}")]
    AccessWidth(usize),
    #[error("Unknown register offset {0:#x}")]
    UnknownOffset(u64),
}

impl Error {
    fn cerror(&self) -> u32 {
        match self {
            Error::CommandFetch(..) => CERROR_ABT,
            _ => CERROR_ILL,
        }
    }
}

/// SMMUv3 event record
#[derive(Clone, Copy, Debug)]
pub struct EventRecord(pub [u64; 4]);

const _: () = assert!(size_of::<EventRecord>() as u64 == EVENTQ_ENTRY_SIZE);

#[derive(Clone, Copy, Debug)]
struct SteConfig {
    config: u8,
    words: [u64; STE_WORDS],
}

/// Layout describing a CMDQ or EVENTQ
struct QueueLayout {
    base: u64,
    log2size: u32,
}

impl QueueLayout {
    fn new(base: u64) -> Self {
        let log2size = (base & Q_BASE_LOG2SIZE_MASK) as u32;

        QueueLayout {
            base: base & Q_BASE_ADDR_MASK,
            log2size: log2size.min(Q_MAX_LOG2SIZE),
        }
    }

    fn entries(&self) -> u32 {
        1 << self.log2size
    }

    fn entry_address(&self, pointer: u32, entry_size: u64) -> u64 {
        let index = u64::from(pointer & (self.entries() - 1));
        self.base + index * entry_size
    }

    fn wrapped_index(&self, pointer: u32) -> u32 {
        pointer & ((1 << (self.log2size + 1)) - 1)
    }

    fn next_pointer(&self, pointer: u32) -> u32 {
        let entries = self.entries();
        let index = pointer & (entries - 1);
        let wrap = pointer & entries;
        let status = pointer & !((entries << 1) - 1);

        if index + 1 == entries {
            status | (wrap ^ entries)
        } else {
            status | wrap | (index + 1)
        }
    }

    fn is_empty(&self, producer: u32, consumer: u32) -> bool {
        self.wrapped_index(producer) == self.wrapped_index(consumer)
    }

    fn is_full(&self, producer: u32, consumer: u32) -> bool {
        let entries = self.entries();

        producer & (entries - 1) == consumer & (entries - 1)
            && producer & entries != consumer & entries
    }
}

pub struct Smmuv3Interrupts {
    pub event: Arc<dyn InterruptSourceGroup>,
    pub gerror: Arc<dyn InterruptSourceGroup>,
    pub sync: Arc<dyn InterruptSourceGroup>,
}

#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Smmuv3State {
    idr0: u32,
    idr1: u32,
    idr5: u32,
    cr0: u32,
    cr0ack: u32,
    cr1: u32,
    cr2: u32,
    gbpa: u32,
    irq_ctrl: u32,
    irq_ctrlack: u32,
    gerror: u32,
    gerrorn: u32,
    strtab_base: u64,
    strtab_base_cfg: u32,
    cmdq_base: u64,
    cmdq_prod: u32,
    cmdq_cons: u32,
    eventq_base: u64,
    eventq_prod: u32,
    eventq_cons: u32,
    stream_ids: BTreeSet<u32>,
}

/// ARM SMMUv3 device
pub struct Smmuv3 {
    id: String,

    idr0: u32,
    idr1: u32,
    idr5: u32,

    cr0: u32,
    cr0ack: u32,
    cr1: u32,
    cr2: u32,
    gbpa: u32,
    irq_ctrl: u32,
    irq_ctrlack: u32,
    gerror: u32,
    gerrorn: u32,

    strtab_base: u64,
    strtab_base_cfg: u32,

    cmdq_base: u64,
    cmdq_prod: u32,
    cmdq_cons: u32,

    eventq_base: u64,
    eventq_prod: u32,
    eventq_cons: u32,

    stream_ids: BTreeSet<u32>,
    restored: bool,

    mem: GuestMemoryMmapAtomic,
    interrupts: Smmuv3Interrupts,
    backend: Arc<dyn PhysicalIommu>,
}

impl Smmuv3 {
    pub fn new(
        id: String,
        mem: GuestMemoryMmapAtomic,
        interrupts: Smmuv3Interrupts,
        backend: Arc<dyn PhysicalIommu>,
        state: Option<Smmuv3State>,
    ) -> Self {
        let restored = state.is_some();
        let state = state.unwrap_or(Smmuv3State {
            idr0: IDR0_MODEL_FEATURES,
            idr1: IDR1_MODEL_FEATURES,
            idr5: IDR5_MODEL_FEATURES,
            ..Default::default()
        });

        Smmuv3 {
            id,
            idr0: state.idr0,
            idr1: state.idr1,
            idr5: state.idr5,
            cr0: state.cr0,
            cr0ack: state.cr0ack,
            cr1: state.cr1,
            cr2: state.cr2,
            gbpa: state.gbpa,
            irq_ctrl: state.irq_ctrl,
            irq_ctrlack: state.irq_ctrlack,
            gerror: state.gerror,
            gerrorn: state.gerrorn,
            strtab_base: state.strtab_base,
            strtab_base_cfg: state.strtab_base_cfg,
            cmdq_base: state.cmdq_base,
            cmdq_prod: state.cmdq_prod,
            cmdq_cons: state.cmdq_cons,
            eventq_base: state.eventq_base,
            eventq_prod: state.eventq_prod,
            eventq_cons: state.eventq_cons,
            stream_ids: state.stream_ids,
            restored,
            mem,
            interrupts,
            backend,
        }
    }

    pub fn id(&self) -> &str {
        &self.id
    }

    fn state(&self) -> Smmuv3State {
        Smmuv3State {
            idr0: self.idr0,
            idr1: self.idr1,
            idr5: self.idr5,
            cr0: self.cr0,
            cr0ack: self.cr0ack,
            cr1: self.cr1,
            cr2: self.cr2,
            gbpa: self.gbpa,
            irq_ctrl: self.irq_ctrl,
            irq_ctrlack: self.irq_ctrlack,
            gerror: self.gerror,
            gerrorn: self.gerrorn,
            strtab_base: self.strtab_base,
            strtab_base_cfg: self.strtab_base_cfg,
            cmdq_base: self.cmdq_base,
            cmdq_prod: self.cmdq_prod,
            cmdq_cons: self.cmdq_cons,
            eventq_base: self.eventq_base,
            eventq_prod: self.eventq_prod,
            eventq_cons: self.eventq_cons,
            stream_ids: self.stream_ids.clone(),
        }
    }

    /// Refine ID registers exposed to the guest based on host information
    pub fn initialize(&mut self) -> Result<(), Error> {
        if self.restored {
            return Ok(());
        }

        let hw_info = self.backend.hw_info().map_err(Error::BackendHwInfo)?;

        #[allow(irrefutable_let_patterns)]
        let HwInfo::Smmuv3 { idr, ats_supported } = hw_info else {
            return Err(Error::BackendHwInfoMismatch);
        };

        self.set_host_id_regs(&idr, ats_supported)
    }

    fn set_host_id_regs(&mut self, idr: &[u32; 6], ats_supported: bool) -> Result<(), Error> {
        let (h0, h1, h5) = (idr[0], idr[1], idr[5]);

        self.idr0 = IDR0_MODEL_FEATURES | (h0 & IDR0_HOST_FEATURES_MASK);
        if ats_supported {
            self.idr0 |= IDR0_ATS;
        }

        self.idr1 = IDR1_MODEL_FEATURES | (h1 & IDR1_SSIDSIZE_MASK);

        let oas = IDR5_OAS_48BIT.min(h5 & IDR5_OAS_MASK);
        let granules = h5 & IDR5_GRAN_MASK;
        if granules == 0 {
            return Err(Error::MissingHostGranules);
        }
        self.idr5 = oas | granules;

        Ok(())
    }

    fn read_reg(&self, offset: u64, len: usize) -> Result<u64, Error> {
        if len != 4 && len != 8 {
            return Err(Error::AccessWidth(len));
        }

        let value = match offset {
            IDR0 => self.idr0 as u64,
            IDR1 => self.idr1 as u64,
            IDR2 | IDR3 | IDR4 => 0,
            IDR5 => self.idr5 as u64,
            IIDR => 0,
            // SMMUv3.0
            AIDR => 0,
            CR0 => self.cr0 as u64,
            CR0ACK => self.cr0ack as u64,
            CR1 => self.cr1 as u64,
            CR2 => self.cr2 as u64,
            STATUSR => 0,
            GBPA => self.gbpa as u64,
            IRQ_CTRL => self.irq_ctrl as u64,
            IRQ_CTRLACK => self.irq_ctrlack as u64,
            GERROR => self.gerror as u64,
            GERRORN => self.gerrorn as u64,
            GERROR_IRQ_CFG0 | GERROR_IRQ_CFG0_HI | GERROR_IRQ_CFG1 | GERROR_IRQ_CFG2 => 0,
            STRTAB_BASE => self.strtab_base,
            STRTAB_BASE_HI => self.strtab_base >> 32,
            STRTAB_BASE_CFG => self.strtab_base_cfg as u64,
            CMDQ_BASE => self.cmdq_base,
            CMDQ_BASE_HI => self.cmdq_base >> 32,
            CMDQ_PROD => self.cmdq_prod as u64,
            CMDQ_CONS => self.cmdq_cons as u64,
            EVENTQ_BASE => self.eventq_base,
            EVENTQ_BASE_HI => self.eventq_base >> 32,
            EVENTQ_IRQ_CFG0 | EVENTQ_IRQ_CFG0_HI | EVENTQ_IRQ_CFG1 | EVENTQ_IRQ_CFG2 => 0,
            EVENTQ_PROD => self.eventq_prod as u64,
            EVENTQ_CONS => self.eventq_cons as u64,
            _ => return Err(Error::UnknownOffset(offset)),
        };

        Ok(value)
    }

    fn write_reg(&mut self, offset: u64, val: u64, len: usize) -> Result<(), Error> {
        fn merge_low(cur: u64, val: u64, len: usize) -> u64 {
            if len == 8 {
                return val;
            }
            (cur & 0xffff_ffff_0000_0000) | (val & 0xffff_ffff)
        }

        fn merge_high(cur: u64, val: u64, len: usize) -> u64 {
            if len == 8 {
                return val;
            }
            (cur & 0x0000_0000_ffff_ffff) | (val << 32)
        }

        if len != 4 && len != 8 {
            return Err(Error::AccessWidth(len));
        }

        match offset {
            CR0 => {
                let previous = self.cr0;
                self.cr0 = (val as u32) & CR0_WRITE_MASK;
                self.cr0ack = self.cr0;

                if previous & CR0_CMDQEN == 0 {
                    self.consume_cmdq()?;
                }

                if (previous ^ self.cr0) & CR0_SMMUEN != 0 {
                    self.configure_all_streams()?;
                }
            }
            CR1 => self.cr1 = (val as u32) & CR1_WRITE_MASK,
            CR2 => {
                if self.cr0 & CR0_SMMUEN == 0 {
                    self.cr2 = (val as u32) & CR2_WRITE_MASK;
                }
            }
            GBPA => {
                self.gbpa = (val as u32) & !GBPA_UPDATE;

                if self.cr0 & CR0_SMMUEN == 0 {
                    self.configure_all_streams()?;
                }
            }
            IRQ_CTRL => {
                self.irq_ctrl = (val as u32) & IRQ_CTRL_WRITE_MASK;
                self.irq_ctrlack = self.irq_ctrl;
            }
            GERRORN => {
                let pending = (self.gerror ^ self.gerrorn) & GERROR_CMDQ_ERR != 0;
                self.gerrorn = (val as u32) & GERRORN_WRITE_MASK;

                if pending && (self.gerror ^ self.gerrorn) & GERROR_CMDQ_ERR == 0 {
                    self.cmdq_cons &= !CMDQ_CONS_ERR_MASK;
                    self.consume_cmdq()?;
                }
            }
            GERROR_IRQ_CFG0 | GERROR_IRQ_CFG0_HI | GERROR_IRQ_CFG1 | GERROR_IRQ_CFG2 => {}
            STRTAB_BASE => {
                self.strtab_base = merge_low(self.strtab_base, val, len) & STRTAB_BASE_WRITE_MASK;
            }
            STRTAB_BASE_HI => {
                self.strtab_base = merge_high(self.strtab_base, val, len) & STRTAB_BASE_WRITE_MASK;
            }
            STRTAB_BASE_CFG => self.strtab_base_cfg = (val as u32) & STRTAB_BASE_CFG_WRITE_MASK,
            CMDQ_BASE => self.cmdq_base = merge_low(self.cmdq_base, val, len) & Q_BASE_WRITE_MASK,
            CMDQ_BASE_HI => {
                self.cmdq_base = merge_high(self.cmdq_base, val, len) & Q_BASE_WRITE_MASK;
            }
            CMDQ_PROD => {
                self.cmdq_prod = (val as u32) & CMDQ_PROD_WRITE_MASK;
                self.consume_cmdq()?;
            }
            CMDQ_CONS => self.cmdq_cons = (val as u32) & CMDQ_CONS_WRITE_MASK,
            EVENTQ_BASE => {
                self.eventq_base = merge_low(self.eventq_base, val, len) & Q_BASE_WRITE_MASK;
            }
            EVENTQ_BASE_HI => {
                self.eventq_base = merge_high(self.eventq_base, val, len) & Q_BASE_WRITE_MASK;
            }
            EVENTQ_IRQ_CFG0 | EVENTQ_IRQ_CFG0_HI | EVENTQ_IRQ_CFG1 | EVENTQ_IRQ_CFG2 => {}
            EVENTQ_PROD => self.eventq_prod = (val as u32) & EVENTQ_PROD_WRITE_MASK,
            EVENTQ_CONS => self.eventq_cons = (val as u32) & EVENTQ_CONS_WRITE_MASK,
            _ => return Err(Error::UnknownOffset(offset)),
        }

        Ok(())
    }

    fn consume_cmdq(&mut self) -> Result<(), Error> {
        if self.cr0 & CR0_CMDQEN == 0 {
            return Ok(());
        }

        if (self.gerror ^ self.gerrorn) & GERROR_CMDQ_ERR != 0 {
            return Ok(());
        }

        let queue = QueueLayout::new(self.cmdq_base);

        let mem = self.mem.clone();
        let guard = mem.memory();

        let read_command = |addr: u64| -> Result<Command, Error> {
            let word0 = guard
                .read_obj::<u64>(GuestAddress(addr))
                .map_err(|e| Error::CommandFetch(addr, e))?;
            let word1 = guard
                .read_obj::<u64>(GuestAddress(addr + 8))
                .map_err(|e| Error::CommandFetch(addr, e))?;

            Ok(Command {
                opcode: (word0 & CMD_OPCODE_MASK) as u8,
                word0,
                word1,
            })
        };

        for _ in 0..queue.entries() {
            if queue.is_empty(self.cmdq_prod, self.cmdq_cons) {
                break;
            }

            let addr = queue.entry_address(self.cmdq_cons, CMDQ_ENTRY_SIZE);
            let cmd = match read_command(addr) {
                Ok(cmd) => cmd,
                Err(e) => {
                    self.set_cmdq_error(e.cerror());
                    return Err(e);
                }
            };

            if let Err(e) = self.dispatch_command(&cmd) {
                self.set_cmdq_error(e.cerror());
                return Err(e);
            }

            self.cmdq_cons = queue.next_pointer(self.cmdq_cons);
        }

        Ok(())
    }

    fn fetch_ste(&self, sid: u32) -> Result<Option<SteConfig>, Error> {
        let Some(ste_addr) = self.ste_address(sid)? else {
            return Ok(None);
        };

        let mem = self.mem.clone();
        let guard = mem.memory();

        let mut words = [0u64; STE_WORDS];
        for (i, word) in words.iter_mut().enumerate() {
            *word = guard
                .read_obj::<u64>(GuestAddress(ste_addr + (i as u64) * 8))
                .map_err(|e| Error::SteFetch(sid, e))?;
        }

        if words[0] & STE_V == 0 {
            return Ok(None);
        }

        let config = ((words[0] >> STE_CONFIG_SHIFT) & STE_CONFIG_MASK) as u8;
        Ok(Some(SteConfig { config, words }))
    }

    fn ste_address(&self, sid: u32) -> Result<Option<u64>, Error> {
        let cfg = self.strtab_base_cfg;
        let base = self.strtab_base & STRTAB_BASE_ADDR_MASK;

        let log2size = cfg & STRTAB_CFG_LOG2SIZE_MASK;
        let effective_log2size = log2size.min(self.idr1 & IDR1_SIDSIZE_MASK);

        if u64::from(sid) >= (1u64 << effective_log2size) {
            return Ok(None);
        }

        let fmt = (cfg >> STRTAB_CFG_FMT_SHIFT) & STRTAB_CFG_FMT_MASK;
        if fmt != STRTAB_FMT_2LEVEL {
            let base = align_down(base, log2size + 6);
            return Ok(Some(base + u64::from(sid) * STE_SIZE));
        }

        let split = match (cfg >> STRTAB_CFG_SPLIT_SHIFT) & STRTAB_CFG_SPLIT_MASK {
            8 => 8,
            10 => 10,
            _ => STRTAB_CFG_SPLIT_DEFAULT,
        };

        let base = align_down(base, (log2size.saturating_sub(split) + 3).max(6));

        let l1_index = u64::from(sid >> split);
        let l2_index = u64::from(sid & ((1 << split) - 1));

        let mem = self.mem.clone();
        let l1_desc = mem
            .memory()
            .read_obj::<u64>(GuestAddress(base + l1_index * L1STD_SIZE))
            .map_err(|e| Error::SteFetch(sid, e))?;

        let span = (l1_desc & L1STD_SPAN_MASK) as u32;
        if span == 0 || span > split + 1 {
            return Ok(None);
        }

        let l2_entries = 1u64 << (span - 1);
        if l2_index >= l2_entries {
            return Ok(None);
        }

        let l2_ptr = align_down(l1_desc & L1STD_L2PTR_MASK, span + 5);

        Ok(Some(l2_ptr + l2_index * STE_SIZE))
    }

    fn handle_cfgi_ste(&mut self, sid: u32) -> Result<(), Error> {
        self.stream_ids.insert(sid);
        self.configure_stream(sid)
    }

    fn configure_stream(&mut self, sid: u32) -> Result<(), Error> {
        if self.cr0 & CR0_SMMUEN == 0 {
            return if self.gbpa & GBPA_ABORT != 0 {
                self.backend.set_blocking(sid)
            } else {
                self.backend.set_passthrough(sid)
            }
            .map_err(|e| Error::BackendStream(sid, e));
        }

        match self.fetch_ste(sid)? {
            Some(SteConfig {
                config: STE_CONFIG_BYPASS,
                ..
            }) => self.backend.set_passthrough(sid),
            Some(SteConfig {
                config: STE_CONFIG_S1_ONLY | STE_CONFIG_S2_ONLY | STE_CONFIG_NESTED,
                words,
            }) => self
                .backend
                .install_table_entry(sid, TableEntry::Smmuv3Ste(words)),
            _ => self.backend.set_blocking(sid),
        }
        .map_err(|e| Error::BackendStream(sid, e))
    }

    fn configure_all_streams(&mut self) -> Result<(), Error> {
        for sid in self.stream_ids.clone() {
            self.configure_stream(sid)?;
        }

        Ok(())
    }

    fn dispatch_command(&mut self, cmd: &Command) -> Result<(), Error> {
        if cmd.word0 & CMD_SSEC != 0
            && matches!(
                cmd.opcode,
                CMD_CFGI_STE
                    | CMD_CFGI_STE_RANGE
                    | CMD_CFGI_CD
                    | CMD_CFGI_CD_ALL
                    | CMD_PREFETCH_CONFIG
                    | CMD_PREFETCH_ADDR
            )
        {
            return Err(Error::SecureCommand(cmd.opcode));
        }

        match cmd.opcode {
            CMD_CFGI_STE => self.handle_cfgi_ste(cmd.stream_id()),
            CMD_CFGI_STE_RANGE => {
                debug!(
                    "SMMUv3 CFGI_STE_RANGE (SID {:#x}): no cached STE state",
                    cmd.stream_id()
                );
                Ok(())
            }
            CMD_ATC_INV if self.idr0 & IDR0_ATS == 0 => Err(Error::IllegalCommand(cmd.opcode)),
            CMD_ATC_INV if self.cr0 & CR0_SMMUEN == 0 => Ok(()),
            CMD_CFGI_CD | CMD_CFGI_CD_ALL | CMD_TLBI_NH_ALL | CMD_TLBI_NH_ASID | CMD_TLBI_NH_VA
            | CMD_TLBI_NH_VAA | CMD_TLBI_NSNH_ALL | CMD_ATC_INV => self
                .backend
                .invalidate(Invalidation::Smmuv3Cmd([cmd.word0, cmd.word1]))
                .map_err(|e| Error::Backend(cmd.opcode, e)),
            CMD_SYNC => self.complete_sync(cmd),
            CMD_PREFETCH_CONFIG | CMD_PREFETCH_ADDR => Ok(()),
            other => Err(Error::IllegalCommand(other)),
        }
    }

    fn complete_sync(&mut self, cmd: &Command) -> Result<(), Error> {
        match cmd.word0 & CMD_SYNC_CS_MASK {
            CMD_SYNC_CS_RESERVED => return Err(Error::IllegalCommand(cmd.opcode)),
            CMD_SYNC_CS_IRQ => {
                if let Err(e) = self.interrupts.sync.trigger(0) {
                    warn!("SMMUv3 failed to raise CMD_SYNC interrupt: {e}");
                }
            }
            _ => {}
        }

        Ok(())
    }

    fn set_cmdq_error(&mut self, cerror: u32) {
        self.cmdq_cons = (self.cmdq_cons & !CMDQ_CONS_ERR_MASK) | (cerror << CMDQ_CONS_ERR_SHIFT);
        self.raise_gerror(GERROR_CMDQ_ERR);
    }

    fn raise_gerror(&mut self, mask: u32) {
        if (self.gerror ^ self.gerrorn) & mask != 0 {
            return;
        }
        self.gerror ^= mask;

        if self.irq_ctrl & IRQ_CTRL_GERROR_IRQEN == 0 {
            return;
        }
        if let Err(e) = self.interrupts.gerror.trigger(0) {
            warn!("SMMUv3 failed to raise GERROR interrupt: {e}");
        }
    }

    /// Signal an overflow on the EVENTQ
    pub fn set_event_overflow(&mut self) {
        let acknowledged = (self.eventq_prod & EVENTQ_PROD_OVFLG != 0)
            == (self.eventq_cons & EVENTQ_CONS_OVACKFLG != 0);

        if !acknowledged {
            return;
        }

        self.eventq_prod ^= EVENTQ_PROD_OVFLG;
    }

    /// Push an event to the EVENTQ
    pub fn push_event(&mut self, record: &EventRecord) -> Result<(), Error> {
        if self.cr0 & CR0_EVENTQEN == 0 {
            return Err(Error::EventQueueDisabled);
        }

        if (self.gerror ^ self.gerrorn) & GERROR_EVENTQ_ABT_ERR != 0 {
            return Err(Error::EventQueueAbortPending);
        }

        let queue = QueueLayout::new(self.eventq_base);

        if queue.is_full(self.eventq_prod, self.eventq_cons) {
            self.set_event_overflow();
            return Err(Error::EventQueueFull);
        }

        let addr = queue.entry_address(self.eventq_prod, EVENTQ_ENTRY_SIZE);

        let mem = self.mem.clone();
        let guard = mem.memory();
        for (i, word) in record.0.iter().enumerate() {
            if let Err(e) = guard.write_obj::<u64>(*word, GuestAddress(addr + (i as u64) * 8)) {
                self.raise_gerror(GERROR_EVENTQ_ABT_ERR);
                return Err(Error::GuestMemory(e));
            }
        }

        self.eventq_prod = queue.next_pointer(self.eventq_prod);

        if self.irq_ctrl & IRQ_CTRL_EVENTQ_IRQEN != 0
            && let Err(e) = self.interrupts.event.trigger(0)
        {
            warn!("SMMUv3 failed to raise event interrupt: {e}");
        }

        Ok(())
    }
}

impl BusDevice for Smmuv3 {
    fn read(&mut self, _base: u64, offset: u64, data: &mut [u8]) {
        match self.read_reg(offset, data.len()) {
            Ok(val) if data.len() == 8 => write_le_u64(data, val),
            Ok(val) => write_le_u32(data, val as u32),
            Err(e) => {
                debug!("SMMUv3 read at {offset:#x}: {e}");
                data.fill(0);
            }
        }
    }

    fn write(&mut self, _base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        let val = match data.len() {
            8 => read_le_u64(data),
            4 => read_le_u32(data) as u64,
            _ => 0,
        };

        if let Err(e) = self.write_reg(offset, val, data.len()) {
            debug!("SMMUv3 write at {offset:#x}: {e}");
        }

        None
    }
}

impl Pausable for Smmuv3 {}

impl Snapshottable for Smmuv3 {
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        Snapshot::new_from_state(&self.state())
    }
}

impl Transportable for Smmuv3 {}
impl Migratable for Smmuv3 {}

#[cfg(test)]
mod tests {
    use std::io;
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicBool, Ordering};

    use vm_device::interrupt::{InterruptIndex, InterruptSourceConfig};
    use vmm_sys_util::eventfd::EventFd;

    use super::*;
    use crate::iommu::Error as IommuError;

    struct NoopInterrupts;

    impl InterruptSourceGroup for NoopInterrupts {
        fn trigger(&self, _index: InterruptIndex) -> io::Result<()> {
            Ok(())
        }

        fn notifier(&self, _index: InterruptIndex) -> Option<EventFd> {
            None
        }

        fn update(
            &self,
            _index: InterruptIndex,
            _config: InterruptSourceConfig,
            _masked: bool,
            _set_gsi: bool,
        ) -> io::Result<()> {
            Ok(())
        }

        fn set_gsi(&self) -> io::Result<()> {
            Ok(())
        }
    }

    struct NoopBackend;

    impl PhysicalIommu for NoopBackend {
        fn hw_info(&self) -> Result<HwInfo, IommuError> {
            Ok(HwInfo::Smmuv3 {
                idr: [0; 6],
                ats_supported: false,
            })
        }

        fn install_table_entry(
            &self,
            _device_id: u32,
            _entry: TableEntry,
        ) -> Result<(), IommuError> {
            Ok(())
        }

        fn set_passthrough(&self, _device_id: u32) -> Result<(), IommuError> {
            Ok(())
        }

        fn set_blocking(&self, _device_id: u32) -> Result<(), IommuError> {
            Ok(())
        }

        fn invalidate(&self, _invalidation: Invalidation) -> Result<(), IommuError> {
            Ok(())
        }
    }

    fn test_smmuv3() -> Smmuv3 {
        let mem = GuestMemoryAtomic::new(
            GuestMemoryMmap::from_ranges(&[(GuestAddress(0), 0x1_0000)]).unwrap(),
        );
        let group = || Arc::new(NoopInterrupts) as Arc<dyn InterruptSourceGroup>;

        Smmuv3::new(
            "smmuv3".to_string(),
            mem,
            Smmuv3Interrupts {
                event: group(),
                gerror: group(),
                sync: group(),
            },
            Arc::new(NoopBackend),
            None,
        )
    }

    struct FailingBackend {
        failing: Arc<AtomicBool>,
    }

    impl FailingBackend {
        fn result(&self) -> Result<(), IommuError> {
            if self.failing.load(Ordering::Relaxed) {
                Err(IommuError::Backend(io::Error::other("backend down")))
            } else {
                Ok(())
            }
        }
    }

    impl PhysicalIommu for FailingBackend {
        fn hw_info(&self) -> Result<HwInfo, IommuError> {
            self.result().map(|()| HwInfo::Smmuv3 {
                idr: [0; 6],
                ats_supported: false,
            })
        }

        fn install_table_entry(
            &self,
            _device_id: u32,
            _entry: TableEntry,
        ) -> Result<(), IommuError> {
            self.result()
        }

        fn set_passthrough(&self, _device_id: u32) -> Result<(), IommuError> {
            self.result()
        }

        fn set_blocking(&self, _device_id: u32) -> Result<(), IommuError> {
            self.result()
        }

        fn invalidate(&self, _invalidation: Invalidation) -> Result<(), IommuError> {
            self.result()
        }
    }

    struct HostInfoBackend {
        idr: Mutex<[u32; 6]>,
        ats_supported: Mutex<bool>,
    }

    impl HostInfoBackend {
        fn new(idr: [u32; 6], ats_supported: bool) -> Arc<Self> {
            Arc::new(HostInfoBackend {
                idr: Mutex::new(idr),
                ats_supported: Mutex::new(ats_supported),
            })
        }
    }

    impl PhysicalIommu for HostInfoBackend {
        fn hw_info(&self) -> Result<HwInfo, IommuError> {
            Ok(HwInfo::Smmuv3 {
                idr: *self.idr.lock().unwrap(),
                ats_supported: *self.ats_supported.lock().unwrap(),
            })
        }

        fn install_table_entry(
            &self,
            _device_id: u32,
            _entry: TableEntry,
        ) -> Result<(), IommuError> {
            Ok(())
        }

        fn set_passthrough(&self, _device_id: u32) -> Result<(), IommuError> {
            Ok(())
        }

        fn set_blocking(&self, _device_id: u32) -> Result<(), IommuError> {
            Ok(())
        }

        fn invalidate(&self, _invalidation: Invalidation) -> Result<(), IommuError> {
            Ok(())
        }
    }

    fn smmuv3_with_host_info(backend: &Arc<HostInfoBackend>) -> Smmuv3 {
        let mem = GuestMemoryAtomic::new(
            GuestMemoryMmap::from_ranges(&[(GuestAddress(0), 0x1_0000)]).unwrap(),
        );
        let group = || Arc::new(NoopInterrupts) as Arc<dyn InterruptSourceGroup>;

        Smmuv3::new(
            "smmuv3".to_string(),
            mem,
            Smmuv3Interrupts {
                event: group(),
                gerror: group(),
                sync: group(),
            },
            Arc::clone(backend) as Arc<dyn PhysicalIommu>,
            None,
        )
    }

    const TEST_CMDQ_BASE: u64 = 0x1000;

    fn smmuv3_with_one_command(failing: &Arc<AtomicBool>) -> Smmuv3 {
        smmuv3_with_command(failing, u64::from(CMD_TLBI_NH_ALL))
    }

    fn smmuv3_with_command(failing: &Arc<AtomicBool>, word0: u64) -> Smmuv3 {
        let mem = GuestMemoryAtomic::new(
            GuestMemoryMmap::from_ranges(&[(GuestAddress(0), 0x1_0000)]).unwrap(),
        );
        mem.memory()
            .write_obj::<u64>(word0, GuestAddress(TEST_CMDQ_BASE))
            .unwrap();
        mem.memory()
            .write_obj::<u64>(0, GuestAddress(TEST_CMDQ_BASE + 8))
            .unwrap();

        let group = || Arc::new(NoopInterrupts) as Arc<dyn InterruptSourceGroup>;
        let mut smmuv3 = Smmuv3::new(
            "smmuv3".to_string(),
            mem,
            Smmuv3Interrupts {
                event: group(),
                gerror: group(),
                sync: group(),
            },
            Arc::new(FailingBackend {
                failing: Arc::clone(failing),
            }),
            None,
        );

        smmuv3.write_reg(CR0, u64::from(CR0_CMDQEN), 4).unwrap();
        smmuv3.write_reg(CMDQ_BASE, TEST_CMDQ_BASE | 4, 8).unwrap();
        smmuv3
    }

    fn cmdq_error(smmuv3: &Smmuv3) -> u32 {
        (smmuv3.cmdq_cons & CMDQ_CONS_ERR_MASK) >> CMDQ_CONS_ERR_SHIFT
    }

    #[test]
    fn test_prefetch_command_is_a_nop() {
        let failing = Arc::new(AtomicBool::new(false));
        let mut smmuv3 = smmuv3_with_command(&failing, u64::from(CMD_PREFETCH_CONFIG));

        smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap();

        assert_eq!(cmdq_error(&smmuv3), 0);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 1);
    }

    #[test]
    fn test_unknown_command_is_illegal() {
        let failing = Arc::new(AtomicBool::new(false));
        let mut smmuv3 = smmuv3_with_command(&failing, 0x7f);

        let err = smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap_err();

        assert!(matches!(err, Error::IllegalCommand(0x7f)));
        assert_eq!(cmdq_error(&smmuv3), CERROR_ILL);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 0);
    }

    #[test]
    fn test_secure_config_command_is_illegal() {
        let failing = Arc::new(AtomicBool::new(false));
        let mut smmuv3 = smmuv3_with_command(&failing, u64::from(CMD_CFGI_STE) | CMD_SSEC);

        let err = smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap_err();

        assert!(matches!(err, Error::SecureCommand(CMD_CFGI_STE)));
        assert_eq!(cmdq_error(&smmuv3), CERROR_ILL);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 0);
    }

    #[test]
    fn test_secure_bit_is_ignored_on_other_commands() {
        let failing = Arc::new(AtomicBool::new(false));
        let mut smmuv3 = smmuv3_with_command(&failing, u64::from(CMD_TLBI_NH_ALL) | CMD_SSEC);

        smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap();

        assert_eq!(cmdq_error(&smmuv3), 0);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 1);
    }

    #[test]
    fn test_backend_failure_reports_an_illegal_command() {
        let failing = Arc::new(AtomicBool::new(true));
        let mut smmuv3 = smmuv3_with_one_command(&failing);

        let err = smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap_err();

        assert!(matches!(err, Error::Backend(CMD_TLBI_NH_ALL, _)));
        assert_eq!(cmdq_error(&smmuv3), CERROR_ILL);
        assert_ne!(smmuv3.gerror & GERROR_CMDQ_ERR, 0);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 0);
    }

    #[test]
    fn test_unrelated_gerror_ack_keeps_the_cmdq_error() {
        let failing = Arc::new(AtomicBool::new(true));
        let mut smmuv3 = smmuv3_with_one_command(&failing);

        smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap_err();
        assert_eq!(cmdq_error(&smmuv3), CERROR_ILL);

        failing.store(false, Ordering::Relaxed);
        smmuv3
            .write_reg(GERRORN, u64::from(smmuv3.gerror ^ GERROR_CMDQ_ERR), 4)
            .unwrap();

        assert_eq!(cmdq_error(&smmuv3), CERROR_ILL);
        assert_eq!(smmuv3.cmdq_cons & 0xf, 0);
    }

    #[test]
    fn test_acknowledging_cmdq_error_restarts_processing() {
        let failing = Arc::new(AtomicBool::new(true));
        let mut smmuv3 = smmuv3_with_one_command(&failing);

        smmuv3.write_reg(CMDQ_PROD, 1, 4).unwrap_err();
        assert_eq!(smmuv3.cmdq_cons & 0xf, 0);

        failing.store(false, Ordering::Relaxed);
        smmuv3
            .write_reg(GERRORN, u64::from(smmuv3.gerror), 4)
            .unwrap();

        assert_eq!(smmuv3.cmdq_cons & 0xf, 1);
        assert_eq!(cmdq_error(&smmuv3), 0);
    }

    fn test_queue() -> QueueLayout {
        QueueLayout::new(2)
    }

    #[test]
    fn test_queue_next_pointer_wraps() {
        let queue = test_queue();

        assert_eq!(queue.next_pointer(0b000), 0b001);
        assert_eq!(queue.next_pointer(0b011), 0b100); // last index => index 0, wrap set
        assert_eq!(queue.next_pointer(0b111), 0b000); // last index => index 0, wrap cleared
    }

    #[test]
    fn test_queue_next_pointer_preserves_other_bits() {
        let queue = test_queue();

        assert_eq!(
            queue.next_pointer(EVENTQ_PROD_OVFLG),
            EVENTQ_PROD_OVFLG | 0b001
        );
        assert_eq!(
            queue.next_pointer(EVENTQ_PROD_OVFLG | 0b011),
            EVENTQ_PROD_OVFLG | 0b100
        );
        assert_eq!(
            queue.next_pointer(EVENTQ_PROD_OVFLG | 0b111),
            EVENTQ_PROD_OVFLG
        );

        let err = CERROR_ABT << CMDQ_CONS_ERR_SHIFT;
        assert_eq!(queue.next_pointer(err), err | 0b001);
    }

    #[test]
    fn test_queue_empty_and_full() {
        let queue = test_queue();

        assert!(queue.is_empty(0b000, 0b000));
        assert!(!queue.is_full(0b000, 0b000));

        assert!(!queue.is_empty(0b100, 0b000));

        assert!(queue.is_full(0b100, 0b000));
        assert!(queue.is_full(0b010, 0b110));

        assert!(!queue.is_full(0b011, 0b000));
        assert!(!queue.is_full(0b010, 0b010));
    }

    #[test]
    fn test_queue_caps_oversized() {
        let max = QueueLayout::new(u64::from(Q_MAX_LOG2SIZE));
        assert_eq!(max.log2size, Q_MAX_LOG2SIZE);

        let oversized = QueueLayout::new(Q_BASE_LOG2SIZE_MASK);
        assert_eq!(oversized.log2size, Q_MAX_LOG2SIZE);
    }

    #[test]
    fn test_set_host_id_regs_ats_and_ssidsize() {
        let mut idr = [0u32; 6];
        idr[0] = IDR0_COHACC | IDR0_ASID16 | IDR0_CD2L | IDR0_STLEVEL_2LVL;
        idr[1] = 20 << IDR1_SSIDSIZE_SHIFT;
        idr[5] = IDR5_OAS_48BIT | IDR5_GRAN4K | IDR5_GRAN64K;

        let backend = HostInfoBackend::new(idr, true);
        let mut smmuv3 = smmuv3_with_host_info(&backend);
        smmuv3.initialize().unwrap();
        assert_ne!(
            smmuv3.idr0 & IDR0_ATS,
            0,
            "ATS must be advertised when supported"
        );
        assert_eq!(smmuv3.idr1 & IDR1_SSIDSIZE_MASK, 20 << IDR1_SSIDSIZE_SHIFT);
        assert_eq!(smmuv3.idr1 & IDR1_CMDQS, IDR1_CMDQS);
        assert_eq!(smmuv3.idr1 & IDR1_EVENTQS, IDR1_EVENTQS);
        assert_eq!(smmuv3.idr1 & 0x3f, IDR1_SIDSIZE);

        *backend.ats_supported.lock().unwrap() = false;
        smmuv3.initialize().unwrap();
        assert_eq!(smmuv3.idr0 & IDR0_ATS, 0);

        backend.idr.lock().unwrap()[1] = 0;
        smmuv3.initialize().unwrap();
        assert_eq!(smmuv3.idr1 & IDR1_SSIDSIZE_MASK, 0);
    }

    #[test]
    fn test_set_host_id_regs_drops_features_the_host_lacks() {
        let mut idr = [0u32; 6];
        idr[5] = IDR5_GRAN4K;
        let backend = HostInfoBackend::new(idr, false);
        let mut smmuv3 = smmuv3_with_host_info(&backend);

        smmuv3.initialize().unwrap();

        assert_eq!(smmuv3.idr0 & IDR0_HOST_FEATURES_MASK, 0);
        assert_eq!(smmuv3.idr0, IDR0_MODEL_FEATURES);
    }

    #[test]
    fn test_new_advertises_conservative_defaults() {
        let smmuv3 = test_smmuv3();
        assert_eq!(smmuv3.idr0, IDR0_MODEL_FEATURES);
        assert_eq!(smmuv3.idr1, IDR1_MODEL_FEATURES);
        assert_eq!(smmuv3.idr5, IDR5_MODEL_FEATURES);
    }

    #[test]
    fn test_default_id_regs_omit_ats_and_ssidsize() {
        assert_eq!(IDR0_MODEL_FEATURES & IDR0_ATS, 0);
        assert_eq!(IDR1_MODEL_FEATURES & IDR1_SSIDSIZE_MASK, 0);
    }

    #[test]
    fn test_partial_writes_merge_into_64bit_registers() {
        let mut smmuv3 = test_smmuv3();

        smmuv3.write_reg(CMDQ_BASE, 0xdead_beef, 4).unwrap();
        assert_eq!(
            smmuv3.read_reg(CMDQ_BASE, 8).unwrap(),
            0x0000_0000_dead_beef
        );
        smmuv3.write_reg(CMDQ_BASE_HI, 0xcafe, 4).unwrap();
        assert_eq!(
            smmuv3.read_reg(CMDQ_BASE, 8).unwrap(),
            0x0000_cafe_dead_beef
        );
        assert_eq!(smmuv3.read_reg(CMDQ_BASE_HI, 8).unwrap(), 0xcafe);

        smmuv3.write_reg(CMDQ_BASE, 0xffff_0000_1111, 8).unwrap();
        assert_eq!(smmuv3.read_reg(CMDQ_BASE, 8).unwrap(), 0xffff_0000_1111);
    }
}
