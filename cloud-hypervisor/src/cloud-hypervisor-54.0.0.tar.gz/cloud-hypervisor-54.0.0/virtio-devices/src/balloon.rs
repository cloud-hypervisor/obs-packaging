// Copyright (c) 2020 Ant Financial
//
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use std::io::{self, Write};
use std::ops::Deref;
use std::os::unix::io::AsRawFd;
use std::sync::atomic::AtomicBool;
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, Barrier, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use std::{cmp, mem, result};

use anyhow::anyhow;
use event_monitor::event;
use log::{error, info, warn};
use seccompiler::SeccompAction;
use serde::{Deserialize, Serialize};
use smallvec::SmallVec;
use thiserror::Error;
use virtio_queue::{Queue, QueueT};
use vm_allocator::page_size::{align_page_size_down, get_page_size};
use vm_memory::{
    Address, ByteValued, Bytes, GuestAddress, GuestAddressSpace, GuestMemoryAtomic,
    GuestMemoryBackend, GuestMemoryError, GuestMemoryRegion,
};
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vm_virtio::AccessPlatform;
use vm_virtio::checked_descriptor::DescriptorChainExt;
use vmm_sys_util::eventfd::{EFD_NONBLOCK, EventFd};
use zerocopy::little_endian::{U16 as Le16, U64 as Le64};
use zerocopy::{FromBytes, Immutable, IntoBytes, KnownLayout};

use crate::device::ActivationContext;
use crate::seccomp_filters::Thread;
use crate::{
    ActivateResult, EPOLL_HELPER_EVENT_LAST, EpollHelper, EpollHelperError, EpollHelperHandler,
    GuestMemoryMmap, VIRTIO_F_ACCESS_PLATFORM, VIRTIO_F_VERSION_1, VirtioCommon, VirtioDevice,
    VirtioDeviceType, VirtioInterrupt, VirtioInterruptType,
};

const QUEUE_SIZE: u16 = 128;
const REPORTING_QUEUE_SIZE: u16 = 32;
const STATS_QUEUE_SIZE: u16 = 32;
const MIN_NUM_QUEUES: usize = 2;
const INFLATE_QUEUE: u16 = 0;
const DEFLATE_QUEUE: u16 = 1;

// Inflate virtio queue event.
const INFLATE_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 1;
// Deflate virtio queue event.
const DEFLATE_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 2;
// Reporting virtio queue event.
const REPORTING_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 3;
// Statistics virtio queue event.
const STATS_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 4;
// Statistics request event.
const STATS_REQUEST_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 5;

// Size of a PFN in the balloon interface.
const VIRTIO_BALLOON_PFN_SHIFT: u64 = 12;
const VIRTIO_BALLOON_PAGE_SIZE: usize = 1 << VIRTIO_BALLOON_PFN_SHIFT;

// Batch the number of PFNs handled in one pass
const VIRTIO_BALLOON_PFNS_PER_BATCH: usize = 256;

// Enable statistics virtqueue.
const VIRTIO_BALLOON_F_STATS_VQ: u64 = 1;
// Deflate balloon on OOM
const VIRTIO_BALLOON_F_DEFLATE_ON_OOM: u64 = 2;
// Enable an additional virtqueue to let the guest notify the host about free
// pages.
const VIRTIO_BALLOON_F_REPORTING: u64 = 5;

const VIRTIO_BALLOON_S_SWAP_IN: u16 = 0;
const VIRTIO_BALLOON_S_SWAP_OUT: u16 = 1;
const VIRTIO_BALLOON_S_MAJFLT: u16 = 2;
const VIRTIO_BALLOON_S_MINFLT: u16 = 3;
const VIRTIO_BALLOON_S_MEMFREE: u16 = 4;
const VIRTIO_BALLOON_S_MEMTOT: u16 = 5;
const VIRTIO_BALLOON_S_AVAIL: u16 = 6;
const VIRTIO_BALLOON_S_CACHES: u16 = 7;
const VIRTIO_BALLOON_S_HTLB_PGALLOC: u16 = 8;
const VIRTIO_BALLOON_S_HTLB_PGFAIL: u16 = 9;
// Linux extensions that are not part of virtio 1.4.
const VIRTIO_BALLOON_S_OOM_KILL: u16 = 10;
const VIRTIO_BALLOON_S_ALLOC_STALL: u16 = 11;
const VIRTIO_BALLOON_S_ASYNC_SCAN: u16 = 12;
const VIRTIO_BALLOON_S_DIRECT_SCAN: u16 = 13;
const VIRTIO_BALLOON_S_ASYNC_RECLAIM: u16 = 14;
const VIRTIO_BALLOON_S_DIRECT_RECLAIM: u16 = 15;

// Bound allocations from untrusted descriptor chains. This accommodates far
// more than the 16 statistics currently defined by Linux.
const VIRTIO_BALLOON_MAX_STATS_BYTES: usize = 4096;

#[derive(Copy, Clone, FromBytes, Immutable, IntoBytes, KnownLayout)]
#[repr(C, packed)]
struct BalloonStat {
    tag: Le16,
    val: Le64,
}

#[serde_with::skip_serializing_none]
#[derive(Clone, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct BalloonStats {
    pub swap_in: Option<u64>,
    pub swap_out: Option<u64>,
    pub major_faults: Option<u64>,
    pub minor_faults: Option<u64>,
    pub free_memory: Option<u64>,
    pub total_memory: Option<u64>,
    pub available_memory: Option<u64>,
    pub disk_caches: Option<u64>,
    pub hugetlb_allocations: Option<u64>,
    pub hugetlb_failures: Option<u64>,
    pub oom_kills: Option<u64>,
    pub alloc_stalls: Option<u64>,
    pub async_scans: Option<u64>,
    pub direct_scans: Option<u64>,
    pub async_reclaims: Option<u64>,
    pub direct_reclaims: Option<u64>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct BalloonStatsSnapshot {
    pub stats: BalloonStats,
    pub last_update: u64,
}

#[derive(Error, Debug)]
pub enum BalloonStatsError {
    #[error("Invalid balloon statistics descriptor at {0:#x}")]
    InvalidDescriptor(u64),
    #[error("Balloon statistics buffer is too large: {0} bytes")]
    BufferTooLarge(usize),
    #[error("Invalid balloon statistics buffer length: {0} bytes")]
    InvalidBufferLength(usize),
    #[error("Failed to read balloon statistics")]
    GuestMemory(#[source] GuestMemoryError),
}

type BalloonStatsResult = result::Result<BalloonStats, BalloonStatsError>;
type BalloonStatsCache = Arc<Mutex<Option<BalloonStatsSnapshot>>>;

fn parse_balloon_stats(data: &[u8]) -> BalloonStatsResult {
    let entries = <[BalloonStat]>::ref_from_bytes(data)
        .map_err(|_| BalloonStatsError::InvalidBufferLength(data.len()))?;

    let mut stats = BalloonStats::default();
    for entry in entries {
        let field = match entry.tag.get() {
            VIRTIO_BALLOON_S_SWAP_IN => &mut stats.swap_in,
            VIRTIO_BALLOON_S_SWAP_OUT => &mut stats.swap_out,
            VIRTIO_BALLOON_S_MAJFLT => &mut stats.major_faults,
            VIRTIO_BALLOON_S_MINFLT => &mut stats.minor_faults,
            VIRTIO_BALLOON_S_MEMFREE => &mut stats.free_memory,
            VIRTIO_BALLOON_S_MEMTOT => &mut stats.total_memory,
            VIRTIO_BALLOON_S_AVAIL => &mut stats.available_memory,
            VIRTIO_BALLOON_S_CACHES => &mut stats.disk_caches,
            VIRTIO_BALLOON_S_HTLB_PGALLOC => &mut stats.hugetlb_allocations,
            VIRTIO_BALLOON_S_HTLB_PGFAIL => &mut stats.hugetlb_failures,
            VIRTIO_BALLOON_S_OOM_KILL => &mut stats.oom_kills,
            VIRTIO_BALLOON_S_ALLOC_STALL => &mut stats.alloc_stalls,
            VIRTIO_BALLOON_S_ASYNC_SCAN => &mut stats.async_scans,
            VIRTIO_BALLOON_S_DIRECT_SCAN => &mut stats.direct_scans,
            VIRTIO_BALLOON_S_ASYNC_RECLAIM => &mut stats.async_reclaims,
            VIRTIO_BALLOON_S_DIRECT_RECLAIM => &mut stats.direct_reclaims,
            _ => continue,
        };
        *field = Some(entry.val.get());
    }

    Ok(stats)
}

#[derive(Error, Debug)]
pub enum Error {
    #[error("Guest gave us bad memory addresses.")]
    GuestMemory(#[source] GuestMemoryError),
    #[error("Fallocate fail.")]
    FallocateFail(#[source] io::Error),
    #[error("Madvise fail.")]
    MadviseFail(#[source] io::Error),
    #[error("Invalid queue index: {0}")]
    InvalidQueueIndex(u16),
    #[error("Failed to signal")]
    FailedSignal(#[source] io::Error),
    #[error("Failed adding used index")]
    QueueAddUsed(#[source] virtio_queue::Error),
    #[error("Balloon statistics feature was not negotiated")]
    StatsNotNegotiated,
    #[error("Balloon statistics worker is unavailable")]
    StatsWorkerUnavailable,
    #[error("Failed to signal balloon statistics request")]
    StatsRequestSignal(#[source] io::Error),
}

// Got from include/uapi/linux/virtio_balloon.h
#[repr(C)]
#[derive(Copy, Clone, Debug, Default, Serialize, Deserialize)]
pub struct VirtioBalloonConfig {
    // Number of pages host wants Guest to give up.
    num_pages: u32,
    // Number of pages we've actually got in balloon.
    actual: u32,
}

#[derive(Clone, Debug)]
struct PartiallyBalloonedPage {
    addr: u64,
    bitmap: Vec<u64>,
    page_size: u64,
}

impl PartiallyBalloonedPage {
    fn new() -> Self {
        let page_size = get_page_size();
        let len = (page_size >> VIRTIO_BALLOON_PFN_SHIFT).div_ceil(64);
        // Initial each padding bit as 1 in bitmap.
        let mut bitmap = vec![0_u64; len as usize];
        let pad_num = len * 64 - (page_size >> VIRTIO_BALLOON_PFN_SHIFT);
        bitmap[(len - 1) as usize] = !((1 << (64 - pad_num)) - 1);
        Self {
            addr: 0,
            bitmap,
            page_size,
        }
    }

    fn pfn_match(&self, addr: u64) -> bool {
        self.addr == addr & !(self.page_size - 1)
    }

    fn bitmap_full(&self) -> bool {
        self.bitmap.iter().all(|b| *b == u64::MAX)
    }

    fn set_bit(&mut self, addr: u64) {
        let addr_offset = (addr % self.page_size) >> VIRTIO_BALLOON_PFN_SHIFT;
        self.bitmap[(addr_offset / 64) as usize] |= 1 << (addr_offset % 64);
    }

    fn reset(&mut self) {
        let len = (self.page_size >> VIRTIO_BALLOON_PFN_SHIFT).div_ceil(64);
        self.addr = 0;
        self.bitmap = vec![0; len as usize];
        let pad_num = len * 64 - (self.page_size >> VIRTIO_BALLOON_PFN_SHIFT);
        self.bitmap[(len - 1) as usize] = !((1 << (64 - pad_num)) - 1);
    }
}

const CONFIG_ACTUAL_OFFSET: u64 = 4;
const CONFIG_ACTUAL_SIZE: usize = 4;

// SAFETY: it only has data and has no implicit padding.
unsafe impl ByteValued for VirtioBalloonConfig {}

enum BalloonStatsState {
    WaitingForInitialDescriptor,
    Idle { descriptor_index: u16 },
    Pending,
}

struct BalloonStatsHandler {
    queue_evt: EventFd,
    queue_index: usize,
    request_evt: EventFd,
    request_receiver: Receiver<()>,
    stats_cache: BalloonStatsCache,
    state: BalloonStatsState,
}

struct BalloonEpollHandler {
    mem: GuestMemoryAtomic<GuestMemoryMmap>,
    queues: Vec<Queue>,
    interrupt_cb: Arc<dyn VirtioInterrupt>,
    inflate_queue_evt: EventFd,
    deflate_queue_evt: EventFd,
    stats_handler: Option<BalloonStatsHandler>,
    reporting_queue_evt: Option<EventFd>,
    reporting_queue_index: Option<usize>,
    kill_evt: EventFd,
    pause_evt: EventFd,
    pbp: Option<PartiallyBalloonedPage>,
    access_platform: Option<Arc<dyn AccessPlatform>>,
}

impl BalloonEpollHandler {
    fn signal(&self, int_type: VirtioInterruptType) -> result::Result<(), Error> {
        self.interrupt_cb.trigger(int_type).map_err(|e| {
            error!("Failed to signal used queue: {e:?}");
            Error::FailedSignal(e)
        })
    }

    fn advise_memory_range(
        memory: &GuestMemoryMmap,
        range_base: GuestAddress,
        range_len: usize,
        advice: libc::c_int,
    ) -> result::Result<(), Error> {
        let slice = memory
            .get_slice(range_base, range_len)
            .map_err(Error::GuestMemory)?;
        assert!(slice.len() >= range_len);
        let res =
            // SAFETY: FFI call with valid arguments, guaranteed by VolatileSlice
            unsafe {
                libc::madvise(slice.ptr_guard_mut().as_ptr().cast(),
                range_len as libc::size_t, advice) };
        if res != 0 {
            return Err(Error::MadviseFail(io::Error::last_os_error()));
        }
        Ok(())
    }

    fn release_memory_range(
        memory: &GuestMemoryMmap,
        range_base: GuestAddress,
        range_len: usize,
    ) -> result::Result<(), Error> {
        let region = memory.find_region(range_base).ok_or(Error::GuestMemory(
            GuestMemoryError::InvalidGuestAddress(range_base),
        ))?;

        // No underflow possible because range_base was found in the region by `find_region`.
        let offset = range_base.0 - region.start_addr().0;
        let region_limit = region.len() - offset;
        let len = cmp::min(range_len as u64, region_limit);
        if len < range_len as u64 {
            warn!(
                "Clamping reported range at GPA 0x{:x} from {} to {} bytes \
                 to fit inside its memory region",
                range_base.0, range_len, len
            );
        }
        if len == 0 {
            return Ok(());
        }

        // Only punch holes for MAP_SHARED file-backed memory regions. For
        // anonymous or MAP_PRIVATE memory, MADV_DONTNEED discards pages without
        // modifying the backing file.
        if region.flags() & libc::MAP_SHARED == libc::MAP_SHARED
            && let Some(f_off) = region.file_offset()
        {
            // SAFETY: FFI call with valid arguments
            let res = unsafe {
                libc::fallocate64(
                    f_off.file().as_raw_fd(),
                    libc::FALLOC_FL_PUNCH_HOLE | libc::FALLOC_FL_KEEP_SIZE,
                    (offset + f_off.start()) as libc::off64_t,
                    len as libc::off64_t,
                )
            };

            if res != 0 {
                Err(Error::FallocateFail(io::Error::last_os_error()))
            } else {
                Ok(())
            }
        } else {
            Self::advise_memory_range(memory, range_base, len as usize, libc::MADV_DONTNEED)
        }
    }

    fn release_memory_range_partial_page(
        pbp: &mut Option<PartiallyBalloonedPage>,
        memory: &GuestMemoryMmap,
        range_base: GuestAddress,
    ) -> result::Result<(), Error> {
        let page_size: u64 = get_page_size();
        if pbp.is_none() {
            *pbp = Some(PartiallyBalloonedPage::new());
        }

        if !pbp.as_ref().unwrap().pfn_match(range_base.0) {
            // We are trying to free memory region in a different pfn with current pbp. Flush pbp.
            pbp.as_mut().unwrap().reset();
            pbp.as_mut().unwrap().addr = align_page_size_down(range_base.0);
        }

        pbp.as_mut().unwrap().set_bit(range_base.0);
        if pbp.as_ref().unwrap().bitmap_full() {
            Self::release_memory_range(
                memory,
                vm_memory::GuestAddress(pbp.as_ref().unwrap().addr),
                page_size as usize,
            )?;

            pbp.as_mut().unwrap().reset();
        }

        Ok(())
    }

    fn process_inflate_addresses(
        &mut self,
        memory: &GuestMemoryMmap,
        addresses: &mut SmallVec<[GuestAddress; VIRTIO_BALLOON_PFNS_PER_BATCH]>,
    ) {
        // The balloon always deals with 4 KiB pages. Use partial page handling
        // if the host page size differs from that.
        if get_page_size() as usize != VIRTIO_BALLOON_PAGE_SIZE {
            for &address in addresses.iter() {
                if let Err(e) =
                    Self::release_memory_range_partial_page(&mut self.pbp, memory, address)
                {
                    warn!("Failed to release memory at address {:#x}: {e}", address.0);
                }
            }
            return;
        }

        addresses.sort_unstable();
        addresses.dedup();
        let same_region = |prev: &GuestAddress, next: &GuestAddress| {
            let prev_region = memory.find_region(*prev).map(GuestMemoryRegion::start_addr);
            let next_region = memory.find_region(*next).map(GuestMemoryRegion::start_addr);
            prev_region == next_region
        };

        for region_addresses in addresses.chunk_by(same_region) {
            let mut range_base = region_addresses[0];
            let mut range_len = VIRTIO_BALLOON_PAGE_SIZE;
            let mut previous_address = region_addresses[0];

            for &address in &region_addresses[1..] {
                if previous_address.checked_add(VIRTIO_BALLOON_PAGE_SIZE as u64) == Some(address) {
                    range_len += VIRTIO_BALLOON_PAGE_SIZE;
                } else {
                    if let Err(e) = Self::release_memory_range(memory, range_base, range_len) {
                        warn!("Failed to release ballooned memory range: {e}");
                    }
                    range_base = address;
                    range_len = VIRTIO_BALLOON_PAGE_SIZE;
                }
                previous_address = address;
            }

            if let Err(e) = Self::release_memory_range(memory, range_base, range_len) {
                warn!("Failed to release ballooned memory range: {e}");
            }
        }
    }

    fn process_queue(&mut self, queue_index: u16) -> result::Result<(), Error> {
        let mut used_descs = false;
        while let Some(mut desc_chain) =
            self.queues[queue_index as usize].pop_descriptor_chain(self.mem.memory())
        {
            let data_chunk_size = size_of::<u32>();

            let results: SmallVec<[_; 4]> = desc_chain
                .checked_iter(self.access_platform.as_deref())
                .collect();
            for result in results {
                let desc = match result {
                    Ok(d) => d,
                    Err(_) => break,
                };
                if desc.is_write_only() {
                    warn!("Skipping device-writable descriptor on inflate/deflate queue");
                    continue;
                }
                if !(desc.len() as usize).is_multiple_of(data_chunk_size) {
                    warn!(
                        "Skipping descriptor with length {} not a multiple of {data_chunk_size}",
                        desc.len()
                    );
                    continue;
                }

                let mut inflate_addresses: SmallVec<[GuestAddress; VIRTIO_BALLOON_PFNS_PER_BATCH]> =
                    SmallVec::new();
                let mut offset = 0u64;
                while offset < desc.len() as u64 {
                    let Some(addr) = desc.addr().checked_add(offset) else {
                        warn!("Address overflow in balloon descriptor");
                        break;
                    };
                    let pfn: u32 = match desc_chain.memory().read_obj(addr) {
                        Ok(v) => v,
                        Err(e) => {
                            warn!("Failed to read PFN from descriptor: {e}");
                            break;
                        }
                    };
                    offset += data_chunk_size as u64;

                    match queue_index {
                        INFLATE_QUEUE => {
                            inflate_addresses
                                .push(GuestAddress(u64::from(pfn) << VIRTIO_BALLOON_PFN_SHIFT));
                            if inflate_addresses.len() == VIRTIO_BALLOON_PFNS_PER_BATCH {
                                self.process_inflate_addresses(
                                    desc_chain.memory(),
                                    &mut inflate_addresses,
                                );
                                inflate_addresses.clear();
                            }
                        }
                        DEFLATE_QUEUE => {} // Nothing to do on deflate
                        _ => return Err(Error::InvalidQueueIndex(queue_index)),
                    }
                }

                if queue_index == INFLATE_QUEUE {
                    self.process_inflate_addresses(desc_chain.memory(), &mut inflate_addresses);
                }
            }

            self.queues[queue_index as usize]
                .add_used(desc_chain.memory(), desc_chain.head_index(), 0)
                .map_err(Error::QueueAddUsed)?;
            used_descs = true;
        }

        if used_descs {
            self.signal(VirtioInterruptType::Queue(queue_index))
        } else {
            Ok(())
        }
    }

    fn parse_stats_descriptor<M>(
        desc_chain: &mut virtio_queue::DescriptorChain<M>,
        access_platform: Option<&dyn AccessPlatform>,
    ) -> BalloonStatsResult
    where
        M: Deref<Target = GuestMemoryMmap>,
    {
        let results: SmallVec<[_; 4]> = desc_chain.checked_iter(access_platform).collect();
        let mut data = Vec::new();

        for result in results {
            let desc =
                result.map_err(|addr| BalloonStatsError::InvalidDescriptor(addr.raw_value()))?;
            if desc.is_write_only() {
                return Err(BalloonStatsError::InvalidDescriptor(
                    desc.addr().raw_value(),
                ));
            }

            let old_len = data.len();
            let new_len = data
                .len()
                .checked_add(desc.len() as usize)
                .ok_or(BalloonStatsError::BufferTooLarge(usize::MAX))?;
            if new_len > VIRTIO_BALLOON_MAX_STATS_BYTES {
                return Err(BalloonStatsError::BufferTooLarge(new_len));
            }
            data.resize(new_len, 0);
            desc_chain
                .memory()
                .read_slice(&mut data[old_len..], desc.addr())
                .map_err(BalloonStatsError::GuestMemory)?;
        }

        parse_balloon_stats(&data)
    }

    fn process_stats_queue(&mut self) -> result::Result<(), Error> {
        let queue_index = {
            let stats_handler = self.stats_handler.as_ref().unwrap();
            if matches!(stats_handler.state, BalloonStatsState::Idle { .. }) {
                return Ok(());
            }
            stats_handler.queue_index
        };
        let Some(mut desc_chain) = self.queues[queue_index].pop_descriptor_chain(self.mem.memory())
        else {
            return Ok(());
        };
        let descriptor_index = desc_chain.head_index();
        let stats = Self::parse_stats_descriptor(&mut desc_chain, self.access_platform.as_deref());

        let stats_handler = self.stats_handler.as_mut().unwrap();
        match stats {
            Ok(stats) => {
                let last_update = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .map_or(0, |duration| {
                        u64::try_from(duration.as_millis()).unwrap_or(u64::MAX)
                    });
                *stats_handler.stats_cache.lock().unwrap() =
                    Some(BalloonStatsSnapshot { stats, last_update });
            }
            Err(error) => warn!("Ignoring invalid balloon statistics: {error}"),
        }

        match mem::replace(
            &mut stats_handler.state,
            BalloonStatsState::Idle { descriptor_index },
        ) {
            BalloonStatsState::WaitingForInitialDescriptor | BalloonStatsState::Pending => {}
            BalloonStatsState::Idle { .. } => unreachable!(),
        }
        Ok(())
    }

    fn process_stats_request(&mut self) -> result::Result<(), Error> {
        let (queue_index, descriptor_index) = {
            let stats_handler = self.stats_handler.as_mut().unwrap();
            match &mut stats_handler.state {
                BalloonStatsState::WaitingForInitialDescriptor => return Ok(()),
                BalloonStatsState::Idle { descriptor_index } => {
                    (stats_handler.queue_index, *descriptor_index)
                }
                BalloonStatsState::Pending => return Ok(()),
            }
        };

        self.queues[queue_index]
            .add_used(self.mem.memory().deref(), descriptor_index, 0)
            .map_err(Error::QueueAddUsed)?;
        self.stats_handler.as_mut().unwrap().state = BalloonStatsState::Pending;
        self.signal(VirtioInterruptType::Queue(queue_index as u16))?;

        Ok(())
    }

    fn process_reporting_queue(&mut self, queue_index: usize) -> result::Result<(), Error> {
        let mut used_descs = false;
        while let Some(mut desc_chain) =
            self.queues[queue_index].pop_descriptor_chain(self.mem.memory())
        {
            let mut descs_len = 0;
            let results: SmallVec<[_; 4]> = desc_chain
                .checked_iter(self.access_platform.as_deref())
                .collect();
            for result in results {
                let desc = match result {
                    Ok(d) => d,
                    Err(_) => break,
                };
                descs_len += desc.len();
                if let Err(e) = Self::release_memory_range(
                    desc_chain.memory(),
                    desc.addr(),
                    desc.len() as usize,
                ) {
                    warn!("Failed to release reported memory range: {e}");
                }
            }

            self.queues[queue_index]
                .add_used(desc_chain.memory(), desc_chain.head_index(), descs_len)
                .map_err(Error::QueueAddUsed)?;
            used_descs = true;
        }

        if used_descs {
            self.signal(VirtioInterruptType::Queue(queue_index as u16))
        } else {
            Ok(())
        }
    }

    fn run(
        &mut self,
        paused: &AtomicBool,
        paused_sync: &Barrier,
    ) -> result::Result<(), EpollHelperError> {
        let mut helper = EpollHelper::new(&self.kill_evt, &self.pause_evt)?;
        helper.add_event(self.inflate_queue_evt.as_raw_fd(), INFLATE_QUEUE_EVENT)?;
        helper.add_event(self.deflate_queue_evt.as_raw_fd(), DEFLATE_QUEUE_EVENT)?;
        if let Some(stats_handler) = &self.stats_handler {
            helper.add_event(stats_handler.queue_evt.as_raw_fd(), STATS_QUEUE_EVENT)?;
            helper.add_event(stats_handler.request_evt.as_raw_fd(), STATS_REQUEST_EVENT)?;
        }
        if let Some(reporting_queue_evt) = self.reporting_queue_evt.as_ref() {
            helper.add_event(reporting_queue_evt.as_raw_fd(), REPORTING_QUEUE_EVENT)?;
        }

        // A descriptor retained by the source is available again after restore,
        // but its original queue kick is not. Recover it before waiting on epoll.
        if self.stats_handler.is_some() {
            self.process_stats_queue()
                .map_err(|e| EpollHelperError::HandleEvent(anyhow!(e)))?;
        }
        helper.run(paused, paused_sync, self)?;

        Ok(())
    }
}

impl EpollHelperHandler for BalloonEpollHandler {
    fn handle_event(
        &mut self,
        _helper: &mut EpollHelper,
        event: &epoll::Event,
    ) -> result::Result<(), EpollHelperError> {
        let ev_type = event.data as u16;
        match ev_type {
            INFLATE_QUEUE_EVENT => {
                self.inflate_queue_evt.read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to get inflate queue event: {e:?}"
                    ))
                })?;
                self.process_queue(INFLATE_QUEUE).map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to signal used inflate queue: {e:?}"
                    ))
                })?;
            }
            DEFLATE_QUEUE_EVENT => {
                self.deflate_queue_evt.read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to get deflate queue event: {e:?}"
                    ))
                })?;
                self.process_queue(DEFLATE_QUEUE).map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to signal used deflate queue: {e:?}"
                    ))
                })?;
            }
            STATS_QUEUE_EVENT => {
                let stats_handler = self.stats_handler.as_ref().ok_or_else(|| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Invalid stats queue event as no eventfd registered"
                    ))
                })?;
                stats_handler.queue_evt.read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get stats queue event: {e:?}"))
                })?;
                self.process_stats_queue().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to process stats queue: {e:?}"))
                })?;
            }
            STATS_REQUEST_EVENT => {
                let stats_handler = self.stats_handler.as_ref().ok_or_else(|| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Invalid stats request event as no eventfd registered"
                    ))
                })?;
                stats_handler.request_evt.read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to get stats request event: {e:?}"
                    ))
                })?;

                while self
                    .stats_handler
                    .as_mut()
                    .unwrap()
                    .request_receiver
                    .try_recv()
                    .is_ok()
                {}
                self.process_stats_request().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!(
                        "Failed to request balloon statistics: {e:?}"
                    ))
                })?;
            }
            REPORTING_QUEUE_EVENT => {
                if let Some(reporting_queue_evt) = self.reporting_queue_evt.as_ref() {
                    reporting_queue_evt.read().map_err(|e| {
                        EpollHelperError::HandleEvent(anyhow!(
                            "Failed to get reporting queue event: {e:?}"
                        ))
                    })?;
                    let qi = self.reporting_queue_index.unwrap();
                    self.process_reporting_queue(qi).map_err(|e| {
                        EpollHelperError::HandleEvent(anyhow!(
                            "Failed to signal used reporting queue: {e:?}"
                        ))
                    })?;
                } else {
                    return Err(EpollHelperError::HandleEvent(anyhow!(
                        "Invalid reporting queue event as no eventfd registered"
                    )));
                }
            }
            _ => {
                return Err(EpollHelperError::HandleEvent(anyhow!(
                    "Unknown event for virtio-balloon"
                )));
            }
        }

        Ok(())
    }
}

#[derive(Serialize, Deserialize)]
pub struct BalloonState {
    pub avail_features: u64,
    pub acked_features: u64,
    pub config: VirtioBalloonConfig,
}

// Virtio device for managing guest memory through a balloon.
pub struct Balloon {
    common: VirtioCommon,
    id: String,
    config: VirtioBalloonConfig,
    seccomp_action: SeccompAction,
    exit_evt: EventFd,
    stats_request_evt: EventFd,
    stats_request_sender: Option<Sender<()>>,
    stats_cache: BalloonStatsCache,
}

impl Balloon {
    // Create a new virtio-balloon.
    #[expect(clippy::too_many_arguments)]
    pub fn new(
        id: String,
        size: u64,
        deflate_on_oom: bool,
        free_page_reporting: bool,
        access_platform_enabled: bool,
        seccomp_action: SeccompAction,
        exit_evt: EventFd,
        state: Option<BalloonState>,
    ) -> io::Result<Self> {
        let mut queue_sizes = vec![QUEUE_SIZE; MIN_NUM_QUEUES];

        let (avail_features, acked_features, config, paused) = if let Some(state) = state {
            info!("Restoring virtio-balloon {id}");
            (
                state.avail_features,
                state.acked_features,
                state.config,
                true,
            )
        } else {
            let mut avail_features = 1u64 << VIRTIO_F_VERSION_1 | 1u64 << VIRTIO_BALLOON_F_STATS_VQ;
            if deflate_on_oom {
                avail_features |= 1u64 << VIRTIO_BALLOON_F_DEFLATE_ON_OOM;
            }
            if free_page_reporting {
                avail_features |= 1u64 << VIRTIO_BALLOON_F_REPORTING;
            }
            if access_platform_enabled {
                avail_features |= 1u64 << VIRTIO_F_ACCESS_PLATFORM;
            }

            let config = VirtioBalloonConfig {
                num_pages: (size >> VIRTIO_BALLOON_PFN_SHIFT) as u32,
                ..Default::default()
            };

            (avail_features, 0, config, false)
        };

        // Stats queue must come before reporting queue to match virtio spec
        // queue index ordering (the guest transport compresses out disabled
        // queues).
        if avail_features & (1u64 << VIRTIO_BALLOON_F_STATS_VQ) != 0 {
            queue_sizes.push(STATS_QUEUE_SIZE);
        }
        if avail_features & (1u64 << VIRTIO_BALLOON_F_REPORTING) != 0 {
            queue_sizes.push(REPORTING_QUEUE_SIZE);
        }

        let stats_request_evt = EventFd::new(EFD_NONBLOCK)?;

        Ok(Balloon {
            common: VirtioCommon {
                device_type: VirtioDeviceType::Balloon as u32,
                avail_features,
                acked_features,
                paused_sync: Some(Arc::new(Barrier::new(2))),
                queue_sizes,
                min_queues: MIN_NUM_QUEUES as u16,
                paused: Arc::new(AtomicBool::new(paused)),
                ..Default::default()
            },
            id,
            config,
            seccomp_action,
            exit_evt,
            stats_request_evt,
            stats_request_sender: None,
            stats_cache: Arc::new(Mutex::new(None)),
        })
    }

    pub fn resize(&mut self, size: u64) -> Result<(), Error> {
        self.config.num_pages = (size >> VIRTIO_BALLOON_PFN_SHIFT) as u32;

        self.common
            .trigger_interrupt(VirtioInterruptType::Config)
            .map_err(Error::FailedSignal)
    }

    // Get the actual size of the virtio-balloon.
    pub fn get_actual(&self) -> u64 {
        (self.config.actual as u64) << VIRTIO_BALLOON_PFN_SHIFT
    }

    fn request_stats_refresh(&self) -> Result<(), Error> {
        let request_sender = self
            .stats_request_sender
            .as_ref()
            .ok_or(Error::StatsWorkerUnavailable)?;
        request_sender
            .send(())
            .map_err(|_| Error::StatsWorkerUnavailable)?;
        self.stats_request_evt
            .write(1)
            .map_err(Error::StatsRequestSignal)
    }

    // Return the latest statistics and request an asynchronous refresh.
    pub fn stats(&self) -> Result<BalloonStatsSnapshot, Error> {
        if !self.common.feature_acked(VIRTIO_BALLOON_F_STATS_VQ) {
            return Err(Error::StatsNotNegotiated);
        }
        let stats = self.stats_cache.lock().unwrap().clone();

        if let Err(error) = self.request_stats_refresh() {
            if stats.is_none() {
                return Err(error);
            }
            warn!("Failed to refresh balloon statistics: {error}");
        }

        Ok(stats.unwrap_or_default())
    }

    fn state(&self) -> BalloonState {
        BalloonState {
            avail_features: self.common.avail_features,
            acked_features: self.common.acked_features,
            config: self.config,
        }
    }

    #[cfg(fuzzing)]
    pub fn wait_for_epoll_threads(&mut self) {
        self.common.wait_for_epoll_threads();
    }
}

impl VirtioDevice for Balloon {
    fn device_type(&self) -> u32 {
        self.common.device_type
    }

    fn queue_max_sizes(&self) -> &[u16] {
        &self.common.queue_sizes
    }

    fn features(&self) -> u64 {
        self.common.avail_features
    }

    fn ack_features(&mut self, value: u64) {
        self.common.ack_features(value);
    }

    fn read_config(&self, offset: u64, data: &mut [u8]) {
        self.read_config_from_slice(self.config.as_slice(), offset, data);
    }

    fn write_config(&mut self, offset: u64, data: &[u8]) {
        // The "actual" field is the only mutable field
        if offset != CONFIG_ACTUAL_OFFSET || data.len() != CONFIG_ACTUAL_SIZE {
            error!(
                "Attempt to write to read-only field: offset {:x} length {}",
                offset,
                data.len()
            );
            return;
        }

        let config = self.config.as_mut_slice();
        let config_len = config.len() as u64;
        let data_len = data.len() as u64;
        if offset + data_len > config_len {
            error!(
                "Out-of-bound access to configuration: config_len = {} offset = {:x} length = {} for {}",
                config_len,
                offset,
                data_len,
                self.device_type()
            );
            return;
        }

        if let Some(end) = offset.checked_add(config.len() as u64) {
            let mut offset_config =
                &mut config[offset as usize..cmp::min(end, config_len) as usize];
            offset_config.write_all(data).unwrap();
        }
    }

    fn activate(&mut self, context: ActivationContext) -> ActivateResult {
        let ActivationContext {
            mem,
            interrupt_cb,
            mut queues,
            device_status,
        } = context;
        self.common.activate(&queues, Arc::clone(&interrupt_cb))?;
        *self.stats_cache.lock().unwrap() = None;
        let (kill_evt, pause_evt) = self.common.dup_eventfds()?;

        let mut virtqueues = Vec::new();
        let (_, queue, queue_evt) = queues.remove(0);
        virtqueues.push(queue);
        let inflate_queue_evt = queue_evt;
        let (_, queue, queue_evt) = queues.remove(0);
        virtqueues.push(queue);
        let deflate_queue_evt = queue_evt;

        let stats_handler =
            if self.common.feature_acked(VIRTIO_BALLOON_F_STATS_VQ) && !queues.is_empty() {
                let qi = virtqueues.len();
                let (_, queue, queue_evt) = queues.remove(0);
                virtqueues.push(queue);

                let _ = self.stats_request_evt.read();
                let (request_sender, request_receiver) = mpsc::channel();
                self.stats_request_sender = Some(request_sender);
                let request_evt = self
                    .stats_request_evt
                    .try_clone()
                    .map_err(crate::ActivateError::CloneEventFd)?;

                Some(BalloonStatsHandler {
                    queue_evt,
                    queue_index: qi,
                    request_evt,
                    request_receiver,
                    stats_cache: Arc::clone(&self.stats_cache),
                    state: BalloonStatsState::WaitingForInitialDescriptor,
                })
            } else {
                self.stats_request_sender = None;
                None
            };

        let (reporting_queue_evt, reporting_queue_index) =
            if self.common.feature_acked(VIRTIO_BALLOON_F_REPORTING) && !queues.is_empty() {
                let qi = virtqueues.len();
                let (_, queue, queue_evt) = queues.remove(0);
                virtqueues.push(queue);
                (Some(queue_evt), Some(qi))
            } else {
                (None, None)
            };

        let mut handler = BalloonEpollHandler {
            mem,
            queues: virtqueues,
            interrupt_cb: Arc::clone(&interrupt_cb),
            inflate_queue_evt,
            deflate_queue_evt,
            stats_handler,
            reporting_queue_evt,
            reporting_queue_index,
            kill_evt,
            pause_evt,
            pbp: None,
            access_platform: self.common.access_platform(),
        };

        let paused = Arc::clone(&self.common.paused);
        let paused_sync = self.common.paused_sync.clone();

        if let Err(e) = self.common.spawn_worker(
            &self.id,
            &self.seccomp_action,
            Thread::VirtioBalloon,
            &self.exit_evt,
            Arc::clone(&device_status),
            Arc::clone(&interrupt_cb),
            move || handler.run(&paused, paused_sync.as_ref().unwrap()),
        ) {
            self.stats_request_sender = None;
            return Err(e);
        }

        event!("virtio-device", "activated", "id", &self.id);
        Ok(())
    }

    fn set_access_platform(&mut self, access_platform: Arc<dyn AccessPlatform>) {
        self.common.set_access_platform(access_platform);
    }

    fn access_platform(&self) -> Option<Arc<dyn AccessPlatform>> {
        self.common.access_platform()
    }

    fn reset(&mut self) {
        self.stats_request_sender = None;
        self.common.reset();
        *self.stats_cache.lock().unwrap() = None;
        event!("virtio-device", "reset", "id", &self.id);
    }
}

impl Pausable for Balloon {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        self.common.pause()
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        self.common.resume()
    }
}

impl Snapshottable for Balloon {
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        Snapshot::new_from_state(&self.state())
    }
}
impl Transportable for Balloon {}
impl Migratable for Balloon {}

#[cfg(test)]
mod tests {
    use vm_memory::bitmap::AtomicBitmap;
    use vm_virtio::queue::testing::VirtQueue;

    use super::*;

    type TestMemory = vm_memory::GuestMemoryMmap<AtomicBitmap>;

    struct NoopInterrupt;

    impl VirtioInterrupt for NoopInterrupt {
        fn trigger(&self, _int_type: VirtioInterruptType) -> io::Result<()> {
            Ok(())
        }

        fn set_notifier(
            &self,
            _int_type: u32,
            _notifier: Option<EventFd>,
            _vm: &dyn hypervisor::Vm,
        ) -> io::Result<()> {
            Ok(())
        }
    }

    fn create_stats_handler(
        memory: &TestMemory,
        queue: Queue,
        state: BalloonStatsState,
    ) -> BalloonEpollHandler {
        let (_, request_receiver) = mpsc::channel();

        BalloonEpollHandler {
            mem: GuestMemoryAtomic::new(memory.clone()),
            queues: vec![queue],
            interrupt_cb: Arc::new(NoopInterrupt),
            inflate_queue_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
            deflate_queue_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
            stats_handler: Some(BalloonStatsHandler {
                queue_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
                queue_index: 0,
                request_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
                request_receiver,
                stats_cache: Arc::new(Mutex::new(None)),
                state,
            }),
            reporting_queue_evt: None,
            reporting_queue_index: None,
            kill_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
            pause_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
            pbp: None,
            access_platform: None,
        }
    }

    fn stat(tag: u16, value: u64) -> Vec<u8> {
        BalloonStat {
            tag: Le16::new(tag),
            val: Le64::new(value),
        }
        .as_bytes()
        .to_vec()
    }

    fn test_release_private_page(read_only: bool) {
        use std::fs::{self, OpenOptions};
        use std::io::Write;

        use vm_memory::{FileOffset, GuestAddress, MmapRegion};
        use vmm_sys_util::tempfile::TempFile;

        use crate::GuestRegionMmap;

        let backing_file = TempFile::new().unwrap();
        backing_file.as_file().write_all(&[0x5a; 4096]).unwrap();
        let original = fs::read(backing_file.as_path()).unwrap();

        let file = OpenOptions::new()
            .read(true)
            .write(!read_only)
            .open(backing_file.as_path())
            .unwrap();
        let mmap = MmapRegion::build(
            Some(FileOffset::new(file, 0)),
            4096,
            libc::PROT_READ | libc::PROT_WRITE,
            libc::MAP_PRIVATE,
        )
        .unwrap();
        let region = GuestRegionMmap::new(mmap, GuestAddress(0)).unwrap();
        let memory = GuestMemoryMmap::from_regions(vec![region]).unwrap();
        memory.write_slice(&[0xa5], GuestAddress(0)).unwrap();
        assert_eq!(memory.read_obj::<u8>(GuestAddress(0)).unwrap(), 0xa5);

        let res = BalloonEpollHandler::release_memory_range(&memory, GuestAddress(0), 4096);
        assert!(res.is_ok(), "release_memory_range failed: {res:?}");
        assert_eq!(memory.read_obj::<u8>(GuestAddress(0)).unwrap(), 0x5a);
        assert_eq!(fs::read(backing_file.as_path()).unwrap(), original);
    }

    #[test]
    fn release_private_page_with_read_only_backing_file() {
        // Match open_backing_file() when shared=false.
        test_release_private_page(true);
    }

    #[test]
    fn release_private_page_does_not_modify_writable_backing_file() {
        // A writable descriptor does not make a MAP_PRIVATE mapping punchable.
        test_release_private_page(false);
    }

    #[test]
    fn process_inflate_addresses_releases_coalesced_ranges() {
        let page_size = get_page_size() as usize;
        if page_size != VIRTIO_BALLOON_PAGE_SIZE {
            return;
        }

        let memory_size = page_size * 4;
        let memory = TestMemory::from_ranges(&[(GuestAddress(0), memory_size)]).unwrap();
        memory
            .write_slice(&vec![0xa5; memory_size], GuestAddress(0))
            .unwrap();
        let mut handler = create_stats_handler(
            &memory,
            Queue::new(16).unwrap(),
            BalloonStatsState::WaitingForInitialDescriptor,
        );
        let mut addresses: SmallVec<[GuestAddress; VIRTIO_BALLOON_PFNS_PER_BATCH]> = [3, 1, 0, 1]
            .into_iter()
            .map(|pfn| GuestAddress(pfn << VIRTIO_BALLOON_PFN_SHIFT))
            .collect();

        handler.process_inflate_addresses(&memory, &mut addresses);

        assert_eq!(
            &addresses[..],
            &[
                GuestAddress(0),
                GuestAddress(page_size as u64),
                GuestAddress((page_size * 3) as u64),
            ]
        );
        let mut data = vec![0xff; memory_size];
        memory.read_slice(&mut data, GuestAddress(0)).unwrap();
        assert!(data[..page_size * 2].iter().all(|byte| *byte == 0));
        assert!(
            data[page_size * 2..page_size * 3]
                .iter()
                .all(|byte| *byte == 0xa5)
        );
        assert!(data[page_size * 3..].iter().all(|byte| *byte == 0));
    }

    #[test]
    fn process_inflate_queue_accepts_large_pfn_buffers() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);
        const PFNS_ADDRESS: GuestAddress = GuestAddress(0x2_0000);
        const PAGES_ADDRESS: GuestAddress = GuestAddress(0x10_0000);

        let page_size = get_page_size() as usize;
        let pfns_per_page = page_size / VIRTIO_BALLOON_PAGE_SIZE;
        // Exercise full batches and a trailing partial batch, while covering
        // whole host pages on hosts with pages larger than 4 KiB.
        for num_pfns in [512, 512 + pfns_per_page, 1024] {
            let balloon_size = num_pfns * VIRTIO_BALLOON_PAGE_SIZE;
            let memory = TestMemory::from_ranges(&[
                (GuestAddress(0), PAGES_ADDRESS.0 as usize),
                (PAGES_ADDRESS, balloon_size + page_size),
            ])
            .unwrap();
            memory
                .write_slice(&vec![0xa5; balloon_size + page_size], PAGES_ADDRESS)
                .unwrap();
            for index in 0..num_pfns {
                let pfn = (PAGES_ADDRESS.0 >> VIRTIO_BALLOON_PFN_SHIFT) as u32 + index as u32;
                memory
                    .write_obj(
                        pfn,
                        PFNS_ADDRESS.unchecked_add((index * size_of::<u32>()) as u64),
                    )
                    .unwrap();
            }
            let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
            guest_queue.dtable[0].set(PFNS_ADDRESS.0, (num_pfns * size_of::<u32>()) as u32, 0, 0);
            guest_queue.avail.ring[0].set(0);
            guest_queue.avail.idx.set(1);
            let mut handler = create_stats_handler(
                &memory,
                guest_queue.create_queue(),
                BalloonStatsState::WaitingForInitialDescriptor,
            );

            handler.process_queue(INFLATE_QUEUE).unwrap();

            assert_eq!(guest_queue.used.idx.get(), 1);
            let mut data = vec![0xff; balloon_size + page_size];
            memory.read_slice(&mut data, PAGES_ADDRESS).unwrap();
            assert!(data[..balloon_size].iter().all(|byte| *byte == 0));
            assert!(data[balloon_size..].iter().all(|byte| *byte == 0xa5));
        }
    }

    #[test]
    fn parse_standard_and_linux_stats() {
        let mut data = Vec::new();
        for (tag, value) in (0u16..=15).zip(100u64..) {
            data.extend(stat(tag, value));
        }

        let stats = parse_balloon_stats(&data).unwrap();
        assert_eq!(stats.swap_in, Some(100));
        assert_eq!(stats.swap_out, Some(101));
        assert_eq!(stats.major_faults, Some(102));
        assert_eq!(stats.minor_faults, Some(103));
        assert_eq!(stats.free_memory, Some(104));
        assert_eq!(stats.total_memory, Some(105));
        assert_eq!(stats.available_memory, Some(106));
        assert_eq!(stats.disk_caches, Some(107));
        assert_eq!(stats.hugetlb_allocations, Some(108));
        assert_eq!(stats.hugetlb_failures, Some(109));
        assert_eq!(stats.oom_kills, Some(110));
        assert_eq!(stats.alloc_stalls, Some(111));
        assert_eq!(stats.async_scans, Some(112));
        assert_eq!(stats.direct_scans, Some(113));
        assert_eq!(stats.async_reclaims, Some(114));
        assert_eq!(stats.direct_reclaims, Some(115));
    }

    #[test]
    fn parse_stats_accepts_arbitrary_order_and_unknown_tags() {
        let data = [
            stat(VIRTIO_BALLOON_S_MEMTOT, 4096),
            stat(u16::MAX, 123),
            stat(VIRTIO_BALLOON_S_SWAP_IN, 10),
        ]
        .concat();

        let stats = parse_balloon_stats(&data).unwrap();
        assert_eq!(stats.total_memory, Some(4096));
        assert_eq!(stats.swap_in, Some(10));
        assert_eq!(stats.swap_out, None);
    }

    #[test]
    fn parse_stats_rejects_partial_entry() {
        let mut data = stat(VIRTIO_BALLOON_S_MEMFREE, 1024);
        data.push(0);

        assert!(matches!(
            parse_balloon_stats(&data),
            Err(BalloonStatsError::InvalidBufferLength(11))
        ));
    }

    #[test]
    fn stats_require_negotiated_feature() {
        let balloon = Balloon::new(
            "balloon0".to_string(),
            0,
            false,
            false,
            false,
            SeccompAction::Allow,
            EventFd::new(EFD_NONBLOCK).unwrap(),
            None,
        )
        .unwrap();

        assert!(matches!(balloon.stats(), Err(Error::StatsNotNegotiated)));
    }

    #[test]
    fn stats_request_refresh_before_initial_sample() {
        let mut balloon = Balloon::new(
            "balloon0".to_string(),
            0,
            false,
            false,
            false,
            SeccompAction::Allow,
            EventFd::new(EFD_NONBLOCK).unwrap(),
            None,
        )
        .unwrap();
        balloon.common.acked_features = 1u64 << VIRTIO_BALLOON_F_STATS_VQ;
        let (request_sender, request_receiver) = mpsc::channel();
        balloon.stats_request_sender = Some(request_sender);

        assert_eq!(balloon.stats().unwrap(), BalloonStatsSnapshot::default());
        assert_eq!(request_receiver.try_recv(), Ok(()));
    }

    #[test]
    fn stats_return_cached_sample_while_requesting_refresh() {
        let mut balloon = Balloon::new(
            "balloon0".to_string(),
            0,
            false,
            false,
            false,
            SeccompAction::Allow,
            EventFd::new(EFD_NONBLOCK).unwrap(),
            None,
        )
        .unwrap();
        balloon.common.acked_features = 1u64 << VIRTIO_BALLOON_F_STATS_VQ;
        let (request_sender, request_receiver) = mpsc::channel();
        balloon.stats_request_sender = Some(request_sender);
        let cached = BalloonStatsSnapshot {
            stats: BalloonStats {
                free_memory: Some(100),
                ..Default::default()
            },
            last_update: 1,
        };
        *balloon.stats_cache.lock().unwrap() = Some(cached.clone());

        assert_eq!(balloon.stats().unwrap(), cached);
        assert_eq!(request_receiver.try_recv(), Ok(()));

        assert_eq!(balloon.stats().unwrap(), cached);
        assert_eq!(request_receiver.try_recv(), Ok(()));
    }

    #[test]
    fn stats_return_cached_sample_if_refresh_worker_is_unavailable() {
        let mut balloon = Balloon::new(
            "balloon0".to_string(),
            0,
            false,
            false,
            false,
            SeccompAction::Allow,
            EventFd::new(EFD_NONBLOCK).unwrap(),
            None,
        )
        .unwrap();
        balloon.common.acked_features = 1u64 << VIRTIO_BALLOON_F_STATS_VQ;
        let (request_sender, request_receiver) = mpsc::channel();
        drop(request_receiver);
        balloon.stats_request_sender = Some(request_sender);
        let cached = BalloonStatsSnapshot {
            stats: BalloonStats {
                free_memory: Some(100),
                ..Default::default()
            },
            last_update: 1,
        };
        *balloon.stats_cache.lock().unwrap() = Some(cached.clone());

        assert_eq!(balloon.stats().unwrap(), cached);
    }

    #[test]
    fn stats_queue_caches_initial_and_refreshed_descriptors() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);
        const STATS_ADDRESS: GuestAddress = GuestAddress(0x1_000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        let initial = stat(VIRTIO_BALLOON_S_MEMFREE, 100);
        memory.write_slice(&initial, STATS_ADDRESS).unwrap();
        guest_queue.dtable[0].set(STATS_ADDRESS.raw_value(), initial.len() as u32, 0, 0);
        guest_queue.avail.ring[0].set(0);
        guest_queue.avail.idx.set(1);

        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::WaitingForInitialDescriptor,
        );
        let before = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();
        handler.process_stats_queue().unwrap();
        let after = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();
        let initial_snapshot = handler
            .stats_handler
            .as_ref()
            .unwrap()
            .stats_cache
            .lock()
            .unwrap()
            .clone()
            .unwrap();
        assert_eq!(initial_snapshot.stats.free_memory, Some(100));
        assert!((before..=after).contains(&u128::from(initial_snapshot.last_update)));
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Idle {
                descriptor_index: 0
            }
        ));

        handler.process_stats_request().unwrap();
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Pending
        ));

        let refreshed = stat(VIRTIO_BALLOON_S_MEMFREE, 200);
        memory.write_slice(&refreshed, STATS_ADDRESS).unwrap();
        guest_queue.avail.ring[1].set(0);
        guest_queue.avail.idx.set(2);
        handler.process_stats_queue().unwrap();

        let refreshed_snapshot = handler
            .stats_handler
            .as_ref()
            .unwrap()
            .stats_cache
            .lock()
            .unwrap()
            .clone()
            .unwrap();
        assert_eq!(refreshed_snapshot.stats.free_memory, Some(200));
        assert!(refreshed_snapshot.last_update >= initial_snapshot.last_update);
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Idle {
                descriptor_index: 0
            }
        ));
    }

    #[test]
    fn stats_queue_does_not_consume_descriptor_while_idle() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);
        const STATS_ADDRESS: GuestAddress = GuestAddress(0x1_000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        guest_queue.dtable[0].set(STATS_ADDRESS.raw_value(), 10, 0, 0);
        guest_queue.avail.ring[0].set(0);
        guest_queue.avail.idx.set(1);
        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::Idle {
                descriptor_index: 1,
            },
        );

        handler.process_stats_queue().unwrap();

        assert_eq!(handler.queues[0].next_avail(), 0);
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Idle {
                descriptor_index: 1
            }
        ));
    }

    #[test]
    fn stats_request_is_ignored_while_refresh_is_pending() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::Pending,
        );

        handler.process_stats_request().unwrap();

        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Pending
        ));
    }

    #[test]
    fn stats_request_before_initial_descriptor_is_ignored() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);
        const STATS_ADDRESS: GuestAddress = GuestAddress(0x1_000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::WaitingForInitialDescriptor,
        );

        handler.process_stats_request().unwrap();
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::WaitingForInitialDescriptor
        ));

        let initial = stat(VIRTIO_BALLOON_S_MEMFREE, 100);
        memory.write_slice(&initial, STATS_ADDRESS).unwrap();
        guest_queue.dtable[0].set(STATS_ADDRESS.raw_value(), initial.len() as u32, 0, 0);
        guest_queue.avail.ring[0].set(0);
        guest_queue.avail.idx.set(1);
        handler.process_stats_queue().unwrap();
        assert!(matches!(
            &handler.stats_handler.as_ref().unwrap().state,
            BalloonStatsState::Idle {
                descriptor_index: 0
            }
        ));
        assert_eq!(
            handler
                .stats_handler
                .as_ref()
                .unwrap()
                .stats_cache
                .lock()
                .unwrap()
                .as_ref()
                .unwrap()
                .stats
                .free_memory,
            Some(100)
        );
    }

    #[test]
    fn stats_request_propagates_queue_error() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::Idle {
                descriptor_index: 16,
            },
        );
        assert!(matches!(
            handler.process_stats_request(),
            Err(Error::QueueAddUsed(_))
        ));
    }

    #[test]
    fn invalid_stats_do_not_replace_cached_sample() {
        const QUEUE_ADDRESS: GuestAddress = GuestAddress(0x1_0000);
        const INVALID_STATS_ADDRESS: GuestAddress = GuestAddress(0x3_0000);

        let memory = TestMemory::from_ranges(&[(GuestAddress(0), 0x2_0000)]).unwrap();
        let guest_queue = VirtQueue::new(QUEUE_ADDRESS, &memory, 16);
        guest_queue.dtable[0].set(INVALID_STATS_ADDRESS.raw_value(), 10, 0, 0);
        guest_queue.avail.ring[0].set(0);
        guest_queue.avail.idx.set(1);
        let mut handler = create_stats_handler(
            &memory,
            guest_queue.create_queue(),
            BalloonStatsState::Pending,
        );
        let cached = BalloonStatsSnapshot {
            stats: BalloonStats {
                free_memory: Some(100),
                ..Default::default()
            },
            last_update: 1,
        };
        *handler
            .stats_handler
            .as_ref()
            .unwrap()
            .stats_cache
            .lock()
            .unwrap() = Some(cached.clone());

        handler.process_stats_queue().unwrap();
        assert_eq!(
            *handler
                .stats_handler
                .as_ref()
                .unwrap()
                .stats_cache
                .lock()
                .unwrap(),
            Some(cached)
        );
    }
}
