// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0
//
use std::time::Instant;
use std::{io, result};

use acpi_tables::Aml;
use acpi_tables::gas::{AccessSize, AddressSpace, GAS};
use acpi_tables::rsdp::Rsdp;
#[cfg(target_arch = "aarch64")]
use acpi_tables::sdt::GenericAddress;
use acpi_tables::sdt::Sdt;
#[cfg(target_arch = "aarch64")]
use arch::DeviceType;
#[cfg(target_arch = "aarch64")]
use arch::aarch64::DeviceInfoForFdt;
use arch::{NumaNodes, layout};
use bitflags::bitflags;
#[cfg(target_arch = "aarch64")]
use devices::iommu::Smmuv3AcpiInfo;
use log::{info, warn};
use pci::PciBdf;
use thiserror::Error;
use tracer::trace_scoped;
use vm_memory::{Address, Bytes, GuestAddress, GuestMemoryRegion};
use zerocopy::{FromBytes, Immutable, IntoBytes};

use crate::cpu::CpuManager;
use crate::device_manager::DeviceManager;
use crate::memory_manager::MemoryManager;
use crate::pci_segment::PciSegment;
use crate::{GuestMemoryMmap, GuestRegionMmap};

#[derive(Debug, Error)]
pub enum Error {
    #[error("ACPI table address overflow")]
    AddressOverflow,

    #[error("Missing fw_cfg device for ACPI tables")]
    MissingFwCfg,

    #[error("Failed to write ACPI data to guest memory")]
    GuestMemory(#[source] vm_memory::GuestMemoryError),

    #[error("ACPI tables exceed their reserved memory")]
    TablesTooLarge,

    #[error("Failed to add ACPI data to fw_cfg")]
    FwCfg(#[source] io::Error),
}

pub(crate) type Result<T> = result::Result<T, Error>;

fn next_table_address(address: GuestAddress, length: u64) -> Result<GuestAddress> {
    address.checked_add(length).ok_or(Error::AddressOverflow)
}

/* Values for Type in APIC sub-headers */
#[cfg(target_arch = "x86_64")]
pub(crate) const ACPI_X2APIC_PROCESSOR: u8 = 9;
#[cfg(target_arch = "x86_64")]
pub(crate) const ACPI_APIC_IO: u8 = 1;
#[cfg(target_arch = "x86_64")]
pub(crate) const ACPI_APIC_XRUPT_OVERRIDE: u8 = 2;
#[cfg(target_arch = "aarch64")]
pub(crate) const ACPI_APIC_GENERIC_CPU_INTERFACE: u8 = 11;
#[cfg(target_arch = "aarch64")]
pub(crate) const ACPI_APIC_GENERIC_DISTRIBUTOR: u8 = 12;
#[cfg(target_arch = "aarch64")]
pub(crate) const ACPI_APIC_GIC_MSI_FRAME: u8 = 13;
#[cfg(target_arch = "aarch64")]
pub(crate) const ACPI_APIC_GENERIC_REDISTRIBUTOR: u8 = 14;
#[cfg(target_arch = "aarch64")]
pub(crate) const ACPI_APIC_GENERIC_TRANSLATOR: u8 = 15;
#[cfg(target_arch = "riscv64")]
pub(crate) const ACPI_RISC_V_IMSIC: u8 = 0x19;
#[cfg(target_arch = "riscv64")]
pub(crate) const ACPI_RISC_V_APLIC: u8 = 0x1A;

#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct PciRangeEntry {
    pub base_address: u64,
    pub segment: u16,
    pub start: u8,
    pub end: u8,
    _reserved: u32,
}

#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct MemoryAffinity {
    pub type_: u8,
    pub length: u8,
    pub proximity_domain: u32,
    _reserved1: u16,
    pub base_addr_lo: u32,
    pub base_addr_hi: u32,
    pub length_lo: u32,
    pub length_hi: u32,
    _reserved2: u32,
    pub flags: u32,
    _reserved3: u64,
}

// ACPI fixes this SRAT structure at 40 bytes.
const _: () = assert!(size_of::<MemoryAffinity>() == 40);

#[cfg(target_arch = "x86_64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct ProcessorLocalX2ApicAffinity {
    pub type_: u8,
    pub length: u8,
    _reserved1: u16,
    pub proximity_domain: u32,
    pub x2apic_id: u32,
    pub flags: u32,
    pub clock_domain: u32,
    _reserved2: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct ProcessorGiccAffinity {
    pub type_: u8,
    pub length: u8,
    pub proximity_domain: u32,
    pub acpi_processor_uid: u32,
    pub flags: u32,
    pub clock_domain: u32,
}

// ACPI 6.6 Section 5.2.16.6 - Generic Initiator Affinity Structure
// Associates devices (e.g., GPUs, NVMe, accelerators) with NUMA proximity domains
//
// Device Handle Type values per ACPI 6.6 spec:
//   0 = ACPI device handle (uses HID and UID)
//   1 = PCI device handle (uses Segment and BDF)
//
// Note: Some older Linux kernel versions may incorrectly expect
// device_handle_type=0 for PCI devices.
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct GenericInitiatorAffinity {
    pub type_: u8,
    pub length: u8,
    _reserved1: u8,
    pub device_handle_type: u8,
    pub proximity_domain: u32,
    pub device_handle: [u8; 16],
    pub flags: u32,
    _reserved2: u32,
}

// ACPI fixes this SRAT structure at 32 bytes.
const _: () = assert!(size_of::<GenericInitiatorAffinity>() == 32);

// ACPI 6.6 Section 5.2.16.6 - PCI device handle
// Bytes 0-1: PCI Segment (little-endian)
// Byte 2: Bus Number
// Byte 3: Device Number (bits 7:3) and Function Number (bits 2:0)
// Bytes 4-15: Reserved
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct PciDeviceHandle {
    segment: u16,
    bus: u8,
    device_function: u8,
    _reserved: [u8; 12],
}

// ACPI defines a PCI device handle structure as 16 bytes long.
const _: () = assert!(size_of::<PciDeviceHandle>() == 16);

impl GenericInitiatorAffinity {
    #[cfg(test)]
    fn from_acpi_device(hid: u64, uid: u32, proximity_domain: u32) -> Self {
        let mut device_handle = [0u8; 16];
        // ACPI 6.6 Section 5.2.16.6: ACPI device handle
        // Bytes 0-7: Hardware ID (HID) as 64-bit value
        // Bytes 8-11: Unique ID (UID) as 32-bit value
        device_handle[0..8].copy_from_slice(&hid.to_le_bytes());
        device_handle[8..12].copy_from_slice(&uid.to_le_bytes());
        // Bytes 12-15: Reserved
        GenericInitiatorAffinity {
            type_: 5,
            length: 32,
            _reserved1: 0,
            device_handle_type: 0, // 0 = ACPI
            proximity_domain,
            device_handle,
            flags: 1,
            _reserved2: 0,
        }
    }

    fn from_pci_bdf(bdf: PciBdf, proximity_domain: u32) -> Self {
        let handle = PciDeviceHandle {
            segment: bdf.segment(),
            bus: bdf.bus(),
            device_function: (bdf.device() << 3) | bdf.function(),
            _reserved: [0; 12],
        };

        let mut device_handle = [0u8; 16];
        device_handle.copy_from_slice(handle.as_bytes());

        GenericInitiatorAffinity {
            type_: 5,
            length: 32,
            _reserved1: 0,
            device_handle_type: 1, // 1 = PCI
            proximity_domain,
            device_handle,
            flags: 1,
            _reserved2: 0,
        }
    }
}

bitflags! {
    #[derive(Copy, Clone)]
    pub struct MemAffinityFlags: u32 {
        const NOFLAGS = 0;
        const ENABLE = 0b1;
        const HOTPLUGGABLE = 0b10;
        const NON_VOLATILE = 0b100;
    }
}

impl MemoryAffinity {
    fn from_region(
        region: &GuestRegionMmap,
        proximity_domain: u32,
        flags: MemAffinityFlags,
    ) -> Self {
        Self::from_range(
            region.start_addr().raw_value(),
            region.len(),
            proximity_domain,
            flags,
        )
    }

    fn from_range(
        base_addr: u64,
        size: u64,
        proximity_domain: u32,
        flags: MemAffinityFlags,
    ) -> Self {
        let base_addr_lo = (base_addr & 0xffff_ffff) as u32;
        let base_addr_hi = (base_addr >> 32) as u32;
        let length_lo = (size & 0xffff_ffff) as u32;
        let length_hi = (size >> 32) as u32;

        MemoryAffinity {
            type_: 1,
            length: 40,
            proximity_domain,
            base_addr_lo,
            base_addr_hi,
            length_lo,
            length_hi,
            flags: flags.bits(),
            ..Default::default()
        }
    }
}

#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct ViotVirtioPciNode {
    pub type_: u8,
    _reserved: u8,
    pub length: u16,
    pub pci_segment: u16,
    pub pci_bdf_number: u16,
    _reserved2: [u8; 8],
}

#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct ViotPciRangeNode {
    pub type_: u8,
    _reserved: u8,
    pub length: u16,
    pub endpoint_start: u32,
    pub pci_segment_start: u16,
    pub pci_segment_end: u16,
    pub pci_bdf_start: u16,
    pub pci_bdf_end: u16,
    pub output_node: u16,
    _reserved2: [u8; 6],
}

pub(crate) fn create_dsdt_table(
    device_manager: &DeviceManager,
    cpu_manager: &CpuManager,
    memory_manager: &MemoryManager,
) -> Sdt {
    trace_scoped!("create_dsdt_table");
    // DSDT
    let mut dsdt = Sdt::new(*b"DSDT", 36, 6, *b"CLOUDH", *b"CHDSDT  ", 1);

    let mut bytes = Vec::new();

    device_manager.to_aml_bytes(&mut bytes);
    cpu_manager.to_aml_bytes(&mut bytes);
    memory_manager.to_aml_bytes(&mut bytes);
    dsdt.append_slice(&bytes);

    dsdt
}

const FACP_DSDT_OFFSET: usize = 140;

fn create_facp_table(
    dsdt_offset: GuestAddress,
    device_manager: &DeviceManager,
    legacy_acpi_pm1a: bool,
) -> Sdt {
    trace_scoped!("create_facp_table");

    // Revision 6 of the ACPI FADT table is 276 bytes long
    let mut facp = Sdt::new(*b"FACP", 276, 6, *b"CLOUDH", *b"CHFACP  ", 1);

    {
        if let Some(address) = device_manager.acpi_platform_addresses().reset_reg_address {
            // RESET_REG
            facp.write(116, address);
            // RESET_VALUE
            facp.write(128, 1u8);
        }

        if let Some(address) = device_manager
            .acpi_platform_addresses()
            .sleep_control_reg_address
        {
            // SLEEP_CONTROL_REG
            facp.write(244, address);
        }

        if let Some(address) = device_manager
            .acpi_platform_addresses()
            .sleep_status_reg_address
        {
            // SLEEP_STATUS_REG
            facp.write(256, address);
        }

        if let Some(address) = device_manager.acpi_platform_addresses().pm_timer_address {
            // X_PM_TMR_BLK
            facp.write(208, address);
        }
    }

    // aarch64 specific fields
    #[cfg(target_arch = "aarch64")]
    // ARM_BOOT_ARCH: enable PSCI with HVC enable-method
    facp.write(129, 3u16);

    // Architecture common fields
    // HW_REDUCED_ACPI, RESET_REG_SUP, TMR_VAL_EXT
    let fadt_flags: u32 = (1 << 20) | (1 << 10) | (1 << 8);
    facp.write(112, fadt_flags);
    // FADT minor version
    facp.write(131, 3u8);
    // X_DSDT
    facp.write(FACP_DSDT_OFFSET, dsdt_offset.0);
    // Hypervisor Vendor Identity
    facp.write_bytes(268, b"CLOUDHYP");

    // Windows' nested-Hyper-V hvloader rejects a HW-reduced FADT whose PM1a GAS is
    // zero; point the blocks at unused ACPI I/O ports (conforming guests ignore them).
    if legacy_acpi_pm1a {
        const PM1A_EVT_PORT: u16 = 0x60c;
        facp.write(56, PM1A_EVT_PORT as u32); // PM1a_EVT_BLK (0x38)
        facp.write(88, 4u8); // PM1_EVT_LEN (0x58)
        facp.write_bytes(
            148, // X_PM1a_EVT_BLK (0x94)
            GAS::new(
                AddressSpace::SystemIo,
                32,
                0,
                AccessSize::WordAccess,
                PM1A_EVT_PORT.into(),
            )
            .as_bytes(),
        );

        const PM1A_CNT_PORT: u16 = 0x610;
        facp.write(64, PM1A_CNT_PORT as u32); // PM1a_CNT_BLK (0x40)
        facp.write(89, 2u8); // PM1_CNT_LEN (0x59)
        facp.write_bytes(
            172, // X_PM1a_CNT_BLK (0xac)
            GAS::new(
                AddressSpace::SystemIo,
                16,
                0,
                AccessSize::WordAccess,
                PM1A_CNT_PORT.into(),
            )
            .as_bytes(),
        );

        let mut allocator = device_manager.allocator().lock().unwrap();
        for (port, len) in [(PM1A_EVT_PORT, 4u64), (PM1A_CNT_PORT, 2u64)] {
            if allocator
                .allocate_io_addresses(Some(GuestAddress(port.into())), len, None)
                .is_none()
            {
                warn!("Could not reserve PM1a I/O port {port:#x} advertised in the FADT");
            }
        }
    }

    facp.update_checksum();

    facp
}

fn create_mcfg_table(pci_segments: &[PciSegment]) -> Sdt {
    let mut mcfg = Sdt::new(*b"MCFG", 36, 1, *b"CLOUDH", *b"CHMCFG  ", 1);

    // MCFG reserved 8 bytes
    mcfg.append(0u64);

    for segment in pci_segments {
        // 32-bit PCI enhanced configuration mechanism
        mcfg.append(PciRangeEntry {
            base_address: segment.mmio_config_address,
            segment: segment.id,
            start: 0,
            end: 0,
            ..Default::default()
        });
    }
    mcfg
}

fn create_tpm2_table() -> Sdt {
    let mut tpm = Sdt::new(*b"TPM2", 52, 3, *b"CLOUDH", *b"CHTPM2  ", 1);

    tpm.write(36, 0_u16); //Platform Class
    tpm.write(38, 0_u16); // Reserved Space
    tpm.write(40, 0xfed4_0040_u64); // Address of Control Area
    tpm.write(48, 7_u32); //Start Method

    tpm.update_checksum();
    tpm
}

fn create_srat_table(
    numa_nodes: &NumaNodes,
    device_manager: &DeviceManager,
    #[cfg(target_arch = "x86_64")] topology: Option<(u16, u16, u16, u16)>,
) -> Sdt {
    let mut srat = Sdt::new(*b"SRAT", 36, 3, *b"CLOUDH", *b"CHSRAT  ", 1);
    // SRAT reserved 12 bytes
    srat.append_slice(&[0u8; 12]);

    for (node_id, node) in numa_nodes.iter() {
        let proximity_domain = *node_id;

        for region in &node.memory_regions {
            srat.append(MemoryAffinity::from_region(
                region,
                proximity_domain,
                MemAffinityFlags::ENABLE,
            ));
        }

        for region in &node.hotplug_regions {
            srat.append(MemoryAffinity::from_region(
                region,
                proximity_domain,
                MemAffinityFlags::ENABLE | MemAffinityFlags::HOTPLUGGABLE,
            ));
        }

        for cpu in &node.cpus {
            #[cfg(target_arch = "x86_64")]
            let x2apic_id = arch::x86_64::get_x2apic_id(*cpu, topology);
            #[cfg(target_arch = "aarch64")]
            let x2apic_id = *cpu;

            // Flags
            // - Enabled = 1 (bit 0)
            // - Reserved bits 1-31
            let flags = 1;

            #[cfg(target_arch = "x86_64")]
            srat.append(ProcessorLocalX2ApicAffinity {
                type_: 2,
                length: 24,
                proximity_domain,
                x2apic_id,
                flags,
                clock_domain: 0,
                ..Default::default()
            });
            #[cfg(target_arch = "aarch64")]
            srat.append(ProcessorGiccAffinity {
                type_: 3,
                length: 18,
                proximity_domain,
                acpi_processor_uid: x2apic_id,
                flags,
                clock_domain: 0,
            });
        }

        // Add Generic Initiator Affinity structures for device-only NUMA nodes
        if let Some(device_id) = &node.device_id {
            // Resolve device_id to guest BDF
            if let Some(bdf) = device_manager.get_device_bdf(device_id) {
                srat.append(GenericInitiatorAffinity::from_pci_bdf(
                    bdf,
                    proximity_domain,
                ));
            } else {
                warn!("Generic Initiator: device_id '{device_id}' not found in device manager");
            }
        }
    }
    srat
}

fn create_slit_table(numa_nodes: &NumaNodes) -> Sdt {
    let mut slit = Sdt::new(*b"SLIT", 36, 1, *b"CLOUDH", *b"CHSLIT  ", 1);
    // Number of System Localities on 8 bytes.
    slit.append(numa_nodes.len() as u64);

    let existing_nodes: Vec<u32> = numa_nodes.keys().cloned().collect();
    for (node_id, node) in numa_nodes.iter() {
        let distances = &node.distances;
        for i in existing_nodes.iter() {
            let dist: u8 = if *node_id == *i {
                10
            } else if let Some(distance) = distances.get(i) {
                *distance
            // When forward distance config is missing
            // we can derive it using distance symmetry
            } else if let Some(destination) = numa_nodes.get(i) {
                destination.distances.get(node_id).copied().unwrap_or(20)
            } else {
                20
            };

            slit.append(dist);
        }
    }
    slit
}

#[cfg(target_arch = "aarch64")]
fn create_gtdt_table() -> Sdt {
    const ARCH_TIMER_NS_EL2_IRQ: u32 = 10;
    const ARCH_TIMER_VIRT_IRQ: u32 = 11;
    const ARCH_TIMER_S_EL1_IRQ: u32 = 13;
    const ARCH_TIMER_NS_EL1_IRQ: u32 = 14;
    const ACPI_GTDT_INTERRUPT_MODE_LEVEL: u32 = 0;
    const ACPI_GTDT_CAP_ALWAYS_ON: u32 = 1 << 2;

    let irqflags: u32 = ACPI_GTDT_INTERRUPT_MODE_LEVEL;
    // GTDT
    let mut gtdt = Sdt::new(*b"GTDT", 104, 2, *b"CLOUDH", *b"CHGTDT  ", 1);
    // Secure EL1 Timer GSIV
    gtdt.write(48, ARCH_TIMER_S_EL1_IRQ + 16);
    // Secure EL1 Timer Flags
    gtdt.write(52, irqflags);
    // Non-Secure EL1 Timer GSIV
    gtdt.write(56, ARCH_TIMER_NS_EL1_IRQ + 16);
    // Non-Secure EL1 Timer Flags
    gtdt.write(60, irqflags | ACPI_GTDT_CAP_ALWAYS_ON);
    // Virtual EL1 Timer GSIV
    gtdt.write(64, ARCH_TIMER_VIRT_IRQ + 16);
    // Virtual EL1 Timer Flags
    gtdt.write(68, irqflags);
    // EL2 Timer GSIV
    gtdt.write(72, ARCH_TIMER_NS_EL2_IRQ + 16);
    // EL2 Timer Flags
    gtdt.write(76, irqflags);

    gtdt.update_checksum();

    gtdt
}

#[cfg(target_arch = "aarch64")]
fn create_spcr_table(base_address: u64, gsi: u32) -> Sdt {
    // SPCR
    let mut spcr = Sdt::new(*b"SPCR", 80, 2, *b"CLOUDH", *b"CHSPCR  ", 1);
    // Interface Type
    spcr.write(36, 3u8);
    // Base Address in format ACPI Generic Address Structure
    spcr.write(40, GenericAddress::mmio_address::<u8>(base_address));
    // Interrupt Type: Bit[3] ARMH GIC interrupt
    spcr.write(52, 1u8 << 3);
    // Global System Interrupt used by the UART
    spcr.write(54, gsi.to_le());
    // Baud Rate: 3 = 9600
    spcr.write(58, 3u8);
    // Stop Bits: 1 Stop bit
    spcr.write(60, 1u8);
    // Flow Control: Bit[1] = RTS/CTS hardware flow control
    spcr.write(61, 1u8 << 1);
    // PCI Device ID: Not a PCI device
    spcr.write(64, 0xffff_u16);
    // PCI Vendor ID: Not a PCI device
    spcr.write(66, 0xffff_u16);

    spcr.update_checksum();

    spcr
}

#[cfg(target_arch = "aarch64")]
fn create_dbg2_table(base_address: u64) -> Sdt {
    let namespace = "_SB_.COM1";
    let debug_device_info_offset = 44usize;
    let debug_device_info_len: u16 = 22 /* BaseAddressRegisterOffset */ +
                       12 /* BaseAddressRegister */ +
                       4 /* AddressSize */ +
                       namespace.len() as u16 + 1 /* zero-terminated */;
    let tbl_len: u32 = debug_device_info_offset as u32 + debug_device_info_len as u32;
    let mut dbg2 = Sdt::new(*b"DBG2", tbl_len, 0, *b"CLOUDH", *b"CHDBG2  ", 1);

    /* OffsetDbgDeviceInfo */
    dbg2.write_u32(36, 44);
    /* NumberDbgDeviceInfo */
    dbg2.write_u32(40, 1);

    /* Debug Device Information structure */
    /* Offsets are calculated from the start of this structure. */
    let namespace_offset = 38u16;
    let base_address_register_offset = 22u16;
    let address_size_offset = 34u16;
    /* Revision */
    dbg2.write_u8(debug_device_info_offset, 0);
    /* Length */
    dbg2.write_u16(debug_device_info_offset + 1, debug_device_info_len);
    /* NumberofGenericAddressRegisters */
    dbg2.write_u8(debug_device_info_offset + 3, 1);
    /* NameSpaceStringLength */
    dbg2.write_u16(debug_device_info_offset + 4, namespace.len() as u16 + 1);
    /* NameSpaceStringOffset */
    dbg2.write_u16(debug_device_info_offset + 6, namespace_offset);
    /* OemDataLength */
    dbg2.write_u16(debug_device_info_offset + 8, 0);
    /* OemDataOffset */
    dbg2.write_u16(debug_device_info_offset + 10, 0);
    /* Port Type */
    dbg2.write_u16(debug_device_info_offset + 12, 0x8000);
    /* Port Subtype */
    dbg2.write_u16(debug_device_info_offset + 14, 0x0003);
    /* Reserved */
    dbg2.write_u16(debug_device_info_offset + 16, 0);
    /* BaseAddressRegisterOffset */
    dbg2.write_u16(debug_device_info_offset + 18, base_address_register_offset);
    /* AddressSizeOffset */
    dbg2.write_u16(debug_device_info_offset + 20, address_size_offset);
    /* BaseAddressRegister */
    dbg2.write(
        debug_device_info_offset + base_address_register_offset as usize,
        GenericAddress::mmio_address::<u8>(base_address),
    );
    /* AddressSize */
    dbg2.write_u32(
        debug_device_info_offset + address_size_offset as usize,
        0x1000,
    );
    /* NamespaceString, zero-terminated ASCII */
    for (k, c) in namespace.chars().enumerate() {
        dbg2.write_u8(
            debug_device_info_offset + namespace_offset as usize + k,
            c as u8,
        );
    }
    dbg2.write_u8(
        debug_device_info_offset + namespace_offset as usize + namespace.len(),
        0,
    );

    dbg2.update_checksum();

    dbg2
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortBodyBase {
    pub num_nodes: u32,
    pub offset_first_node: u32,
    _reserved: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortNodeCommon {
    pub type_: u8,
    pub length: u16,
    pub revision: u8,
    pub node_id: u32,
    pub num_id_mappings: u32,
    pub id_mappings_array_offset: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortIdMapping {
    pub input_base: u32,
    pub num_ids: u32,
    pub output_base: u32,
    pub output_reference: u32,
    pub flags: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortMemoryAccessProperties {
    pub cca: u32,
    pub ah: u8,
    _reserved: u16,
    pub maf: u8,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortItsGroupBase {
    pub common: IortNodeCommon,
    pub its_count: u32,
    // GIC ITS identifiers follow: array of `u32`
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortPciRootComplexBase {
    pub common: IortNodeCommon,
    pub mem_access_props: IortMemoryAccessProperties,
    pub ats_attribute: u32,
    pub pci_segment_number: u32,
    pub memory_address_size_limit: u8,
    pub pasid_capabilities: u16,
    _reserved: u8,
    pub flags: u32,
    // ID mappings follow: array of `struct IortIdMapping`
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortSmmuV3Base {
    pub common: IortNodeCommon,
    pub base_address: u64,
    pub flags: u32,
    _reserved: u32,
    pub vatos_address: u64,
    pub model: u32,
    pub event_gsiv: u32,
    pub pri_gsiv: u32,
    pub gerr_gsiv: u32,
    pub sync_gsiv: u32,
    pub proximity_domain: u32,
    pub deviceid_mapping_index: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortRmrBase {
    pub common: IortNodeCommon,
    pub flags: u32,
    pub num_mem_range_descriptors: u32,
    pub mem_range_desc_offset: u32,
}

#[cfg(target_arch = "aarch64")]
#[repr(C, packed)]
#[derive(Default, IntoBytes, Immutable, FromBytes)]
struct IortRmrMemRangeDescriptor {
    pub base_address: u64,
    pub length: u64,
    _reserved: u32,
}

#[cfg(target_arch = "aarch64")]
#[inline]
fn align_to_8_bytes(len: usize) -> usize {
    (8 - (len % 8)) % 8
}

#[cfg(target_arch = "aarch64")]
fn next_node_id(next_id: &mut u32) -> u32 {
    let id = *next_id;
    *next_id += 1;
    id
}

#[cfg(target_arch = "aarch64")]
struct RcIdMapping {
    input_base: u16,
    count: u16,
    smmu: Option<usize>,
}

#[cfg(target_arch = "aarch64")]
// Generate IORT table based on Spec Revision E.e:
// https://developer.arm.com/documentation/den0049/ee/?lang=en
fn create_iort_table(pci_segments: &[PciSegment], smmus: &[Smmuv3AcpiInfo]) -> Sdt {
    const ACPI_IORT_HEADER_SIZE: u32 = 36;
    const DEVICE_IDS_PER_SEGMENT: usize = 256;
    const ACPI_IORT_NODE_ITS_GROUP: u8 = 0x00;
    const ACPI_IORT_NODE_PCI_ROOT_COMPLEX: u8 = 0x02;
    const ACPI_IORT_NODE_SMMU_V3: u8 = 0x04;
    const ACPI_IORT_SMMU_V3_GENERIC: u32 = 0;
    const ACPI_IORT_NODE_RMR: u8 = 0x06;
    const ACPI_IORT_SMMU_V3_COHACC_OVERRIDE: u32 = 1 << 0;
    const ACPI_IORT_SMMU_V3_DEVICEID_VALID: u32 = 1 << 4;
    const ACPI_IORT_ATS_SUPPORTED: u32 = 1 << 0;
    const ACPI_IORT_REVISION: u8 = 6;
    const ACPI_IORT_RMR_MSI_IOVA_BASE: u64 = 0x0800_0000;
    const ACPI_IORT_RMR_MSI_IOVA_LENGTH: u64 = 0x0010_0000;

    let num_rmr = smmus
        .iter()
        .filter(|smmu| !smmu.attached_bdfs.is_empty())
        .count();

    let mut next_id = 0;

    // IORT header
    let mut iort = Sdt::new(
        *b"IORT",
        ACPI_IORT_HEADER_SIZE,
        ACPI_IORT_REVISION,
        *b"CLOUDH",
        *b"CHIORT  ",
        1,
    );
    assert_eq!(iort.len(), ACPI_IORT_HEADER_SIZE as usize);

    // The IORT table contains:
    // - IortBodyBase
    // - 1 x ITS Group Node
    // - M x SMMUv3 Node (M = number of SMMUv3s)
    // - R x RMR Node (R = number of SMMUv3s with attached devices)
    // - N x PCI Root Complex Node (N = number of pci segments)
    let num_smmu = smmus.len();
    let num_nodes = (1 + num_smmu + pci_segments.len() + num_rmr) as u32;
    // First node is the ITS Group Node located right after the IORT Body Base
    let offset_its_node = iort.len() + size_of::<IortBodyBase>();
    assert!(align_to_8_bytes(offset_its_node) == 0); // Ensure the ITS node is 8-byte aligned
    iort.append(IortBodyBase {
        num_nodes,
        offset_first_node: offset_its_node as u32,
        _reserved: 0,
    });
    assert!(iort.len() == offset_its_node);

    // ITS Group Node contains:
    // - IortItsGroupBase
    // - ITS Identifiers Array: Array of u32 ITS IDs
    //   Currently contains a single ITS with ID 0, which matches the
    //   `translation_id` field of the `GisIts`` structure in the MADT table.
    let its_id_array = [0u32; 1];
    let its_count = its_id_array.len();
    let its_group_node_size = size_of::<IortItsGroupBase>() + its_count * size_of::<u32>();
    let padding = align_to_8_bytes(iort.len() + its_group_node_size);
    iort.append(IortItsGroupBase {
        common: IortNodeCommon {
            type_: ACPI_IORT_NODE_ITS_GROUP,
            length: (its_group_node_size + padding) as u16,
            revision: 1,
            node_id: next_node_id(&mut next_id),
            num_id_mappings: 0,
            id_mappings_array_offset: 0,
        },
        its_count: its_count as u32,
    });
    iort.append(its_id_array);
    iort.append_slice(&vec![0u8; padding]); // Add padding to align to 8 bytes

    let mut smmu_node_offsets: Vec<usize> = Vec::with_capacity(smmus.len());
    for smmu in smmus {
        assert!(align_to_8_bytes(iort.len()) == 0);
        let smmu_node_offset = iort.len();
        smmu_node_offsets.push(smmu_node_offset);

        // Single ID mapping since all StreamIDs map to a single ITS group
        let num_id_mappings = 1;
        let node_size = size_of::<IortSmmuV3Base>() + num_id_mappings * size_of::<IortIdMapping>();
        let padding = align_to_8_bytes(iort.len() + node_size);
        let mut flags = 0;
        if smmu.coherent {
            flags |= ACPI_IORT_SMMU_V3_COHACC_OVERRIDE;
        }
        if smmu.deviceid_mapping_index_valid {
            flags |= ACPI_IORT_SMMU_V3_DEVICEID_VALID;
        }
        iort.append(IortSmmuV3Base {
            common: IortNodeCommon {
                type_: ACPI_IORT_NODE_SMMU_V3,
                length: (node_size + padding) as u16,
                revision: 5,
                node_id: next_node_id(&mut next_id),
                num_id_mappings: num_id_mappings as u32,
                id_mappings_array_offset: size_of::<IortSmmuV3Base>() as u32,
            },
            base_address: smmu.base,
            flags,
            _reserved: 0,
            vatos_address: 0,
            model: ACPI_IORT_SMMU_V3_GENERIC,
            event_gsiv: smmu.event_gsiv,
            pri_gsiv: smmu.pri_gsiv,
            gerr_gsiv: smmu.gerror_gsiv,
            sync_gsiv: smmu.sync_gsiv,
            proximity_domain: 0,
            deviceid_mapping_index: 0,
        });
        // Identity StreamID to DeviceID mapping, so a device gets the same ITS
        // DeviceID from its root complex mapping whether it sits behind an
        // SMMUv3 or not.
        iort.append(IortIdMapping {
            input_base: 0,
            num_ids: (DEVICE_IDS_PER_SEGMENT * pci_segments.len() - 1) as u32,
            output_base: 0,
            output_reference: offset_its_node as u32,
            flags: 0,
        });
        iort.append_slice(&vec![0u8; padding]);

        if smmu.attached_bdfs.is_empty() {
            continue;
        }
        assert!(align_to_8_bytes(iort.len()) == 0);

        let num_id_mappings = smmu.attached_bdfs.len();
        let num_mem_range_descriptors = 1usize;
        let node_size = size_of::<IortRmrBase>()
            + num_id_mappings * size_of::<IortIdMapping>()
            + num_mem_range_descriptors * size_of::<IortRmrMemRangeDescriptor>();
        let padding = align_to_8_bytes(iort.len() + node_size);
        iort.append(IortRmrBase {
            common: IortNodeCommon {
                type_: ACPI_IORT_NODE_RMR,
                length: (node_size + padding) as u16,
                revision: 3,
                node_id: next_node_id(&mut next_id),
                num_id_mappings: num_id_mappings as u32,
                id_mappings_array_offset: size_of::<IortRmrBase>() as u32,
            },
            flags: 0,
            num_mem_range_descriptors: num_mem_range_descriptors as u32,
            mem_range_desc_offset: (size_of::<IortRmrBase>()
                + num_id_mappings * size_of::<IortIdMapping>())
                as u32,
        });
        for bdf in &smmu.attached_bdfs {
            let stream_id =
                DEVICE_IDS_PER_SEGMENT as u32 * u32::from(bdf.segment()) + (u32::from(*bdf) & 0xff);
            iort.append(IortIdMapping {
                input_base: stream_id,
                num_ids: 0,
                output_base: stream_id,
                output_reference: smmu_node_offset as u32,
                flags: 0,
            });
        }
        iort.append(IortRmrMemRangeDescriptor {
            base_address: ACPI_IORT_RMR_MSI_IOVA_BASE,
            length: ACPI_IORT_RMR_MSI_IOVA_LENGTH,
            _reserved: 0,
        });
        iort.append_slice(&vec![0u8; padding]);
    }

    // Create PCI Root Complex Node for each PCI segment
    for segment in pci_segments.iter() {
        assert!(align_to_8_bytes(iort.len()) == 0); // Ensure each node is 8-byte aligned

        // Each PCI Root Complex Node contains:
        // - IortPciRootComplexBase
        // - ID mapping Array: Array of IortIdMapping
        let id_mappings: Vec<RcIdMapping> = if smmus.is_empty() {
            vec![RcIdMapping {
                input_base: 0,
                count: DEVICE_IDS_PER_SEGMENT as u16,
                smmu: None,
            }]
        } else {
            let mut id_to_smmu: [Option<usize>; DEVICE_IDS_PER_SEGMENT] =
                [None; DEVICE_IDS_PER_SEGMENT];
            for (i, smmu) in smmus.iter().enumerate() {
                for bdf in &smmu.attached_bdfs {
                    if bdf.segment() == segment.id {
                        id_to_smmu[(u32::from(*bdf) & 0xff) as usize] = Some(i);
                    }
                }
            }
            let mut mappings = Vec::new();
            let mut id = 0usize;
            for id_range in id_to_smmu.chunk_by(|a, b| a == b) {
                mappings.push(RcIdMapping {
                    input_base: id as u16,
                    count: id_range.len() as u16,
                    smmu: id_range[0],
                });
                id += id_range.len();
            }
            mappings
        };

        let ats_attribute = if smmus.iter().any(|smmu| {
            smmu.ats_supported
                && smmu
                    .attached_bdfs
                    .iter()
                    .any(|bdf| bdf.segment() == segment.id)
        }) {
            ACPI_IORT_ATS_SUPPORTED
        } else {
            0
        };

        let num_id_mappings = id_mappings.len();
        let node_size =
            size_of::<IortPciRootComplexBase>() + num_id_mappings * size_of::<IortIdMapping>();
        let padding = align_to_8_bytes(iort.len() + node_size);
        iort.append(IortPciRootComplexBase {
            common: IortNodeCommon {
                type_: ACPI_IORT_NODE_PCI_ROOT_COMPLEX,
                length: (node_size + padding) as u16,
                revision: 4,
                node_id: next_node_id(&mut next_id),
                num_id_mappings: num_id_mappings as u32,
                // ID mapping array starts right after `IortPciRootComplexBase`
                id_mappings_array_offset: size_of::<IortPciRootComplexBase>() as u32,
            },
            mem_access_props: IortMemoryAccessProperties {
                cca: 1, // Fully coherent device
                ah: 0,
                _reserved: 0,
                maf: 3, // CPM = DCAS = 1
            },
            ats_attribute,
            pci_segment_number: segment.id as u32,
            memory_address_size_limit: 64u8,
            pasid_capabilities: 0,
            _reserved: 0,
            flags: 0,
        });
        // ID Mapping for this Root Complex
        // Maps 256 device IDs (1 bus × 32 devices × 8 functions)
        assert!(segment.id < 256, "Up to 256 PCI segments are supported.");
        for mapping in &id_mappings {
            let output_reference = match mapping.smmu {
                Some(i) => smmu_node_offsets[i],
                None => offset_its_node,
            } as u32;
            iort.append(IortIdMapping {
                input_base: u32::from(mapping.input_base),
                num_ids: u32::from(mapping.count - 1),
                // Output base maps to ITS device IDs which must match the
                // device ID encoding used in KVM MSI routing setup, which
                // shares the same limitation - only 1 bus per segment and
                // up to 256 segments.
                // See: https://github.com/cloud-hypervisor/cloud-hypervisor/commit/c9374d87ac453d49185aa7b734df089444166484
                output_base: (DEVICE_IDS_PER_SEGMENT * segment.id as usize) as u32
                    + u32::from(mapping.input_base),
                output_reference,
                flags: 0,
            });
        }
        iort.append_slice(&vec![0u8; padding]); // Add padding to align to 8 bytes
    }

    iort.update_checksum();

    iort
}

fn create_viot_table(iommu_bdf: &PciBdf, devices_bdf: &[PciBdf]) -> Sdt {
    // VIOT
    let mut viot = Sdt::new(*b"VIOT", 36, 0, *b"CLOUDH", *b"CHVIOT  ", 0);
    // Node count
    viot.append((devices_bdf.len() + 1) as u16);
    // Node offset
    viot.append(48u16);
    // VIOT reserved 8 bytes
    viot.append_slice(&[0u8; 8]);

    // Virtio-iommu based on virtio-pci node
    viot.append(ViotVirtioPciNode {
        type_: 3,
        length: 16,
        pci_segment: iommu_bdf.segment(),
        pci_bdf_number: iommu_bdf.into(),
        ..Default::default()
    });

    for device_bdf in devices_bdf {
        viot.append(ViotPciRangeNode {
            type_: 1,
            length: 24,
            endpoint_start: device_bdf.into(),
            pci_segment_start: device_bdf.segment(),
            pci_segment_end: device_bdf.segment(),
            pci_bdf_start: device_bdf.into(),
            pci_bdf_end: device_bdf.into(),
            output_node: 48,
            ..Default::default()
        });
    }

    viot
}

// Generate ACPI tables based on the given DSDT address
//
// # Returns
//
// * `Rsdp` is the generated RSDP.
// * `Vec<u8>` contains the generated bytes for ACPI tables.
// * `Vec<u64>` contains a list of table pointers stored in XSDT.
fn create_acpi_tables_internal(
    dsdt_addr: GuestAddress,
    device_manager: &DeviceManager,
    cpu_manager: &CpuManager,
    memory_manager: &MemoryManager,
    numa_nodes: &NumaNodes,
    tpm_enabled: bool,
) -> Result<(Rsdp, Vec<u8>, Vec<u64>)> {
    // Generated bytes for ACPI tables
    let mut tables_bytes: Vec<u8> = Vec::new();
    // List of table pointers stored in XSDT
    let mut xsdt_table_pointers: Vec<u64> = Vec::new();

    // DSDT
    let dsdt = create_dsdt_table(device_manager, cpu_manager, memory_manager);
    tables_bytes.extend_from_slice(dsdt.as_slice());

    // FACP aka FADT
    // The legacy PM1a blocks are x86-only; there is nothing to emit on other arches.
    #[cfg(target_arch = "x86_64")]
    let legacy_acpi_pm1a = cpu_manager.nested() && cpu_manager.kvm_hyperv();
    #[cfg(not(target_arch = "x86_64"))]
    let legacy_acpi_pm1a = false;
    let facp = create_facp_table(dsdt_addr, device_manager, legacy_acpi_pm1a);
    let facp_addr = next_table_address(dsdt_addr, dsdt.len() as u64)?;
    tables_bytes.extend_from_slice(facp.as_slice());
    xsdt_table_pointers.push(facp_addr.0);

    // MADT
    #[cfg(target_arch = "aarch64")]
    let vgic = device_manager
        .get_interrupt_controller()
        .unwrap()
        .lock()
        .unwrap()
        .get_vgic()
        .unwrap();
    let madt = cpu_manager.create_madt(
        #[cfg(target_arch = "aarch64")]
        vgic,
    );
    let madt_addr = next_table_address(facp_addr, facp.len() as u64)?;
    tables_bytes.extend_from_slice(madt.as_slice());
    xsdt_table_pointers.push(madt_addr.0);
    let mut prev_tbl_len = madt.len() as u64;
    let mut prev_tbl_addr = madt_addr;

    // PPTT
    #[cfg(target_arch = "aarch64")]
    {
        let pptt = cpu_manager.create_pptt();
        let pptt_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        let mut pptt_bytes = Vec::new();

        pptt.to_aml_bytes(&mut pptt_bytes);
        tables_bytes.extend_from_slice(&pptt_bytes);
        xsdt_table_pointers.push(pptt_addr.0);
        prev_tbl_len = pptt_bytes.len() as u64;
        prev_tbl_addr = pptt_addr;
    }

    // GTDT
    #[cfg(target_arch = "aarch64")]
    {
        let gtdt = create_gtdt_table();
        let gtdt_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(gtdt.as_slice());
        xsdt_table_pointers.push(gtdt_addr.0);
        prev_tbl_len = gtdt.len() as u64;
        prev_tbl_addr = gtdt_addr;
    }

    // MCFG
    let mcfg = create_mcfg_table(device_manager.pci_segments());
    let mcfg_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
    tables_bytes.extend_from_slice(mcfg.as_slice());
    xsdt_table_pointers.push(mcfg_addr.0);
    prev_tbl_len = mcfg.len() as u64;
    prev_tbl_addr = mcfg_addr;

    // SPCR and DBG2
    #[cfg(target_arch = "aarch64")]
    {
        let is_serial_on = device_manager
            .get_device_info()
            .clone()
            .contains_key(&(DeviceType::Serial, DeviceType::Serial.to_string()));
        let serial_device_addr = layout::LEGACY_SERIAL_MAPPED_IO_START.raw_value();
        let serial_device_irq = if is_serial_on {
            device_manager
                .get_device_info()
                .clone()
                .get(&(DeviceType::Serial, DeviceType::Serial.to_string()))
                .unwrap()
                .irq()
        } else {
            // If serial is turned off, add a fake device with invalid irq.
            31
        };

        // SPCR
        let spcr = create_spcr_table(serial_device_addr, serial_device_irq);
        let spcr_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(spcr.as_slice());
        xsdt_table_pointers.push(spcr_addr.0);
        prev_tbl_len = spcr.len() as u64;
        prev_tbl_addr = spcr_addr;

        // DBG2
        let dbg2 = create_dbg2_table(serial_device_addr);
        let dbg2_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(dbg2.as_slice());
        xsdt_table_pointers.push(dbg2_addr.0);
        prev_tbl_len = dbg2.len() as u64;
        prev_tbl_addr = dbg2_addr;
    }

    if tpm_enabled {
        // TPM2 Table
        let tpm2 = create_tpm2_table();
        let tpm2_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(tpm2.as_slice());
        xsdt_table_pointers.push(tpm2_addr.0);

        prev_tbl_len = tpm2.len() as u64;
        prev_tbl_addr = tpm2_addr;
    }
    // SRAT and SLIT
    // Only created if the NUMA nodes list is not empty.
    if !numa_nodes.is_empty() {
        #[cfg(target_arch = "x86_64")]
        let topology = cpu_manager.get_vcpu_topology();
        // SRAT
        let srat = create_srat_table(
            numa_nodes,
            device_manager,
            #[cfg(target_arch = "x86_64")]
            topology,
        );
        let srat_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(srat.as_slice());
        xsdt_table_pointers.push(srat_addr.0);

        // SLIT
        let slit = create_slit_table(numa_nodes);
        let slit_addr = next_table_address(srat_addr, srat.len() as u64)?;
        tables_bytes.extend_from_slice(slit.as_slice());
        xsdt_table_pointers.push(slit_addr.0);

        prev_tbl_len = slit.len() as u64;
        prev_tbl_addr = slit_addr;
    }

    #[cfg(target_arch = "aarch64")]
    {
        let smmus = device_manager.smmuv3_acpi_infos();
        let iort = create_iort_table(device_manager.pci_segments(), &smmus);
        let iort_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(iort.as_slice());
        xsdt_table_pointers.push(iort_addr.0);
        prev_tbl_len = iort.len() as u64;
        prev_tbl_addr = iort_addr;
    }

    // VIOT
    if let Some((iommu_bdf, devices_bdf)) = device_manager.iommu_attached_devices() {
        let viot = create_viot_table(iommu_bdf, devices_bdf);

        let viot_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
        tables_bytes.extend_from_slice(viot.as_slice());
        xsdt_table_pointers.push(viot_addr.0);
        prev_tbl_len = viot.len() as u64;
        prev_tbl_addr = viot_addr;
    }

    // XSDT
    let mut xsdt = Sdt::new(*b"XSDT", 36, 1, *b"CLOUDH", *b"CHXSDT  ", 1);
    for table_pointer in &xsdt_table_pointers {
        xsdt.append(*table_pointer);
    }
    xsdt.update_checksum();
    let xsdt_addr = next_table_address(prev_tbl_addr, prev_tbl_len)?;
    tables_bytes.extend_from_slice(xsdt.as_slice());

    // RSDP
    let rsdp = Rsdp::new(*b"CLOUDH", xsdt_addr.0);

    Ok((rsdp, tables_bytes, xsdt_table_pointers))
}

#[cfg(feature = "fw_cfg")]
pub(crate) fn create_acpi_tables_for_fw_cfg(
    device_manager: &DeviceManager,
    cpu_manager: &CpuManager,
    memory_manager: &MemoryManager,
    numa_nodes: &NumaNodes,
    tpm_enabled: bool,
) -> Result<()> {
    let dsdt_offset = GuestAddress(0);
    let (rsdp, table_bytes, xsdt_table_pointers) = create_acpi_tables_internal(
        dsdt_offset,
        device_manager,
        cpu_manager,
        memory_manager,
        numa_nodes,
        tpm_enabled,
    )?;
    let mut pointer_offsets: Vec<usize> = vec![];
    let mut checksums: Vec<(usize, usize)> = vec![];

    let xsdt_addr = rsdp.xsdt_addr.get() as usize;
    let xsdt_checksum = (xsdt_addr, table_bytes.len() - xsdt_addr);

    // create pointer offsets (use location of pointers in XSDT table)
    // XSDT doesn't have a pointer to DSDT so we use FACP's pointer to DSDT
    let facp_offset = xsdt_table_pointers[0] as usize;
    pointer_offsets.push(facp_offset + FACP_DSDT_OFFSET);
    let mut current_offset = xsdt_addr + 36;
    for _ in 0..xsdt_table_pointers.len() {
        pointer_offsets.push(current_offset);
        current_offset += 8;
    }

    // create (offset, len) pairs for firmware to calculate
    // table checksums and verify ACPI tables
    let mut i = 0;
    while i < xsdt_table_pointers.len() - 1 {
        let current_table_offset = xsdt_table_pointers[i];
        let current_table_length = xsdt_table_pointers[i + 1] - current_table_offset;
        checksums.push((current_table_offset as usize, current_table_length as usize));
        i += 1;
    }
    checksums.push((
        xsdt_table_pointers[xsdt_table_pointers.len() - 1] as usize,
        0,
    ));
    checksums.push(xsdt_checksum);

    device_manager
        .fw_cfg()
        .ok_or(Error::MissingFwCfg)?
        .lock()
        .unwrap()
        .add_acpi(rsdp, table_bytes, checksums, pointer_offsets)
        .map_err(Error::FwCfg)
}

pub(crate) fn create_acpi_tables(
    guest_mem: &GuestMemoryMmap,
    device_manager: &DeviceManager,
    cpu_manager: &CpuManager,
    memory_manager: &MemoryManager,
    numa_nodes: &NumaNodes,
    tpm_enabled: bool,
) -> Result<GuestAddress> {
    trace_scoped!("create_acpi_tables");

    let start_time = Instant::now();
    let rsdp_addr = layout::RSDP_POINTER;
    let dsdt_addr = next_table_address(rsdp_addr, Rsdp::len() as u64)?;

    let (rsdp, tables_bytes, _xsdt_table_pointers) = create_acpi_tables_internal(
        dsdt_addr,
        device_manager,
        cpu_manager,
        memory_manager,
        numa_nodes,
        tpm_enabled,
    )?;

    if Rsdp::len() as u64 + tables_bytes.len() as u64 > layout::ACPI_MAX_SIZE {
        return Err(Error::TablesTooLarge);
    }

    guest_mem
        .write_slice(rsdp.as_bytes(), rsdp_addr)
        .map_err(Error::GuestMemory)?;

    guest_mem
        .write_slice(tables_bytes.as_slice(), dsdt_addr)
        .map_err(Error::GuestMemory)?;

    info!(
        "Generated ACPI tables: took {}µs size = {}",
        Instant::now().duration_since(start_time).as_micros(),
        Rsdp::len() + tables_bytes.len(),
    );

    Ok(rsdp_addr)
}

#[cfg(feature = "tdx")]
pub(crate) fn create_acpi_tables_tdx(
    device_manager: &DeviceManager,
    cpu_manager: &CpuManager,
    memory_manager: &MemoryManager,
    numa_nodes: &NumaNodes,
) -> Vec<Sdt> {
    // DSDT
    let mut tables = vec![create_dsdt_table(
        device_manager,
        cpu_manager,
        memory_manager,
    )];

    // FACP aka FADT
    let legacy_acpi_pm1a = cpu_manager.nested() && cpu_manager.kvm_hyperv();
    tables.push(create_facp_table(
        GuestAddress(0),
        device_manager,
        legacy_acpi_pm1a,
    ));

    // MADT
    tables.push(cpu_manager.create_madt());

    // MCFG
    tables.push(create_mcfg_table(device_manager.pci_segments()));

    // SRAT and SLIT
    // Only created if the NUMA nodes list is not empty.
    if !numa_nodes.is_empty() {
        #[cfg(target_arch = "x86_64")]
        let topology = cpu_manager.get_vcpu_topology();

        // SRAT
        tables.push(create_srat_table(
            numa_nodes,
            device_manager,
            #[cfg(target_arch = "x86_64")]
            topology,
        ));

        // SLIT
        tables.push(create_slit_table(numa_nodes));
    }

    // VIOT
    if let Some((iommu_bdf, devices_bdf)) = device_manager.iommu_attached_devices() {
        tables.push(create_viot_table(iommu_bdf, devices_bdf));
    }

    tables
}

#[cfg(test)]
mod tests {
    use std::slice;

    use super::*;

    #[test]
    fn test_next_table_address() {
        assert_eq!(
            next_table_address(GuestAddress(0x1000), 0x20).unwrap(),
            GuestAddress(0x1020)
        );
        assert!(matches!(
            next_table_address(GuestAddress(u64::MAX), 1),
            Err(Error::AddressOverflow)
        ));
    }

    #[test]
    fn test_generic_initiator_from_pci_bdf() {
        // Test creating Generic Initiator from PCI BDF
        // segment:bus:device:function = 0000:00:05.0
        let bdf = PciBdf::new(0, 0, 5, 0);
        let proximity_domain = 1;

        let gi = GenericInitiatorAffinity::from_pci_bdf(bdf, proximity_domain);

        // Verify structure fields
        assert_eq!(gi.type_, 5, "Type must be 5 for Generic Initiator");
        assert_eq!(gi.length, 32, "Length must be 32 bytes");
        assert_eq!(gi._reserved1, 0, "Reserved field must be 0");
        assert_eq!(
            gi.device_handle_type, 1,
            "Device handle type must be 1 for PCI per ACPI 6.6 spec"
        );
        // Copy packed fields to local variables to avoid unaligned references
        let gi_proximity_domain = gi.proximity_domain;
        let gi_flags = gi.flags;
        let gi_reserved2 = gi._reserved2;
        assert_eq!(
            gi_proximity_domain, proximity_domain,
            "Proximity domain must match input"
        );
        assert_eq!(gi_flags, 1, "Flags must be 1 (enabled)");
        assert_eq!(gi_reserved2, 0, "Reserved field must be 0");

        // Verify PCI BDF encoding in device_handle
        // ACPI 6.6 Section 5.2.16.6 format:
        // Bytes 0-1: PCI Segment (little-endian)
        // Byte 2: Bus Number
        // Byte 3: Device Number (bits 7:3) and Function Number (bits 2:0)
        // Bytes 4-15: Reserved
        //
        // 0000:00:05.0 -> device_function = (5 << 3) | 0 = 0x28.
        let expected_handle: [u8; 16] = [0, 0, 0, 0x28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        assert_eq!(
            gi.device_handle, expected_handle,
            "Device handle must encode PCI BDF correctly per ACPI 6.6 Section 5.2.16.6"
        );
    }

    #[test]
    fn test_generic_initiator_multiple_numa_nodes() {
        // Test Generic Initiators assigned to different NUMA nodes
        let bdf0 = PciBdf::new(0, 0, 4, 0);
        let bdf1 = PciBdf::new(0, 0, 5, 0);

        let gi0 = GenericInitiatorAffinity::from_pci_bdf(bdf0, 0);
        let gi1 = GenericInitiatorAffinity::from_pci_bdf(bdf1, 1);

        // Copy packed fields to local variables to avoid unaligned references
        let gi0_proximity_domain = gi0.proximity_domain;
        let gi1_proximity_domain = gi1.proximity_domain;
        assert_eq!(gi0_proximity_domain, 0);
        assert_eq!(gi1_proximity_domain, 1);

        // Verify both have correct type and length
        assert_eq!(gi0.type_, 5);
        assert_eq!(gi0.length, 32);
        assert_eq!(gi1.type_, 5);
        assert_eq!(gi1.length, 32);
    }

    #[test]
    fn test_generic_initiator_repr_c_layout() {
        // Verify the struct has correct C representation for ACPI table
        // This ensures field offsets match ACPI spec
        let gi = GenericInitiatorAffinity {
            type_: 5,
            length: 32,
            _reserved1: 0,
            device_handle_type: 1,
            proximity_domain: 1,
            device_handle: [0u8; 16],
            flags: 1,
            _reserved2: 0,
        };

        // Convert to bytes and verify layout
        // SAFETY: `gi` is a local, initialized struct. Because it is `repr(packed)`,
        // there is no internal padding, making every byte within it
        // safe to read. Casting to `u8` satisfies alignment requirements.
        let bytes = unsafe {
            slice::from_raw_parts(
                (&raw const gi).cast::<u8>(),
                size_of::<GenericInitiatorAffinity>(),
            )
        };

        // Verify field positions per ACPI 6.6 spec
        assert_eq!(bytes[0], 5, "Offset 0: Type");
        assert_eq!(bytes[1], 32, "Offset 1: Length");
        assert_eq!(bytes[2], 0, "Offset 2: Reserved");
        assert_eq!(bytes[3], 1, "Offset 3: Device Handle Type (1=PCI per spec)");
        // Proximity domain at offset 4-7 (u32 little-endian)
        assert_eq!(bytes[4], 1);
        assert_eq!(bytes[5], 0);
        assert_eq!(bytes[6], 0);
        assert_eq!(bytes[7], 0);
        // Device handle at offset 8-23 (16 bytes)
        // Flags at offset 24-27 (u32 little-endian)
        assert_eq!(bytes[24], 1);
        // Reserved at offset 28-31
    }

    #[test]
    fn test_generic_initiator_acpi_device_handle() {
        // Test ACPI device handle (device_handle_type=0) for completeness
        // This validates HID and UID encoding per ACPI 6.6 Section 5.2.16.6
        let hid: u64 = 0x0123456789ABCDEF;
        let uid: u32 = 0x12345678;
        let proximity_domain = 2;

        let gi = GenericInitiatorAffinity::from_acpi_device(hid, uid, proximity_domain);

        // Verify structure fields
        assert_eq!(gi.type_, 5, "Type must be 5 for Generic Initiator");
        assert_eq!(gi.length, 32, "Length must be 32 bytes");
        assert_eq!(gi._reserved1, 0, "Reserved field must be 0");
        assert_eq!(
            gi.device_handle_type, 0,
            "Device handle type must be 0 for ACPI per ACPI 6.6 spec"
        );
        // Copy packed fields to local variables to avoid unaligned references
        let gi_proximity_domain = gi.proximity_domain;
        let gi_flags = gi.flags;
        let gi_reserved2 = gi._reserved2;
        assert_eq!(
            gi_proximity_domain, proximity_domain,
            "Proximity domain must match input"
        );
        assert_eq!(gi_flags, 1, "Flags must be 1 (enabled)");
        assert_eq!(gi_reserved2, 0, "Reserved field must be 0");

        // Verify ACPI device handle encoding
        // Expected format per ACPI 6.6 Section 5.2.16.6:
        // Bytes 0-7: HID (64-bit, little-endian)
        // Bytes 8-11: UID (32-bit, little-endian)
        // Bytes 12-15: Reserved
        let expected_handle: [u8; 16] = [
            0xEF, 0xCD, 0xAB, 0x89, 0x67, 0x45, 0x23, 0x01, // HID
            0x78, 0x56, 0x34, 0x12, // UID
            0, 0, 0, 0, // Reserved
        ];
        assert_eq!(
            gi.device_handle, expected_handle,
            "Device handle must encode HID and UID correctly"
        );
    }
}
