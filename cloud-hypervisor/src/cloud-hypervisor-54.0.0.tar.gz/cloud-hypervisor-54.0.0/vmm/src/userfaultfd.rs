// Copyright © 2026 Cloud Hypervisor Authors
//
// SPDX-License-Identifier: Apache-2.0

// See include/uapi/linux/userfaultfd.h in the kernel code.
pub(crate) const UFFDIO_API: u64 = 0xc018_aa3f; // _IOWR(0xAA, 0x3F, struct uffdio_api)
pub(crate) const UFFDIO_REGISTER: u64 = 0xc020_aa00; // _IOWR(0xAA, 0x00, struct uffdio_register)
pub(crate) const UFFDIO_COPY: u64 = 0xc028_aa03; // _IOWR(0xAA, 0x03, struct uffdio_copy)
pub(crate) const UFFDIO_WAKE: u64 = 0x8010_aa02; // _IOR(0xAA, 0x02, struct uffdio_range)
pub(crate) const UFFDIO_CONTINUE: u64 = 0xc020_aa07; // _IOWR(0xAA, 0x07, struct uffdio_continue)
pub(crate) const UFFDIO_POISON: u64 = 0xc020_aa08; // _IOWR(0xAA, 0x08, struct uffdio_poison)

// Validate ioctl encoding against the _IO{R,W,WR}(type, nr, size) formula so
// transposed direction bits or sizes are caught at compile time.
const fn ioctl_ioc(dir: u64, typ: u64, nr: u64, size: u64) -> u64 {
    (dir << 30) | (size << 16) | (typ << 8) | nr
}
const IOC_READ: u64 = 2;
const IOC_READWRITE: u64 = 3;
const _: () = assert!(UFFDIO_API == ioctl_ioc(IOC_READWRITE, 0xAA, 0x3F, 24));
const _: () = assert!(UFFDIO_REGISTER == ioctl_ioc(IOC_READWRITE, 0xAA, 0x00, 32));
const _: () = assert!(UFFDIO_COPY == ioctl_ioc(IOC_READWRITE, 0xAA, 0x03, 40));
const _: () = assert!(UFFDIO_WAKE == ioctl_ioc(IOC_READ, 0xAA, 0x02, 16));
const _: () = assert!(UFFDIO_CONTINUE == ioctl_ioc(IOC_READWRITE, 0xAA, 0x07, 32));
const _: () = assert!(UFFDIO_POISON == ioctl_ioc(IOC_READWRITE, 0xAA, 0x08, 32));

// Seccomp compares these as Dword (u32); ensure they fit.
const _: () = assert!(UFFDIO_API <= u32::MAX as u64);
const _: () = assert!(UFFDIO_REGISTER <= u32::MAX as u64);
const _: () = assert!(UFFDIO_COPY <= u32::MAX as u64);
const _: () = assert!(UFFDIO_WAKE <= u32::MAX as u64);
const _: () = assert!(UFFDIO_CONTINUE <= u32::MAX as u64);
const _: () = assert!(UFFDIO_POISON <= u32::MAX as u64);

// /dev/userfaultfd ioctl: _IO(0xAA, 0x00)
pub(crate) const USERFAULTFD_IOC_NEW: u64 = 0x0000_AA00;
const _: () = assert!(USERFAULTFD_IOC_NEW == ioctl_ioc(0, 0xAA, 0x00, 0));
const _: () = assert!(USERFAULTFD_IOC_NEW <= u32::MAX as u64);

pub(crate) const UFFD_API: u64 = 0xAA;
pub(crate) const UFFDIO_REGISTER_MODE_MISSING: u64 = 1;
pub(crate) const UFFDIO_REGISTER_MODE_MINOR: u64 = 1 << 2;
pub(crate) const UFFD_EVENT_PAGEFAULT: u8 = 0x12;
pub(crate) const UFFD_PAGEFAULT_FLAG_MINOR: u64 = 1 << 2;
pub(crate) const UFFD_FEATURE_MISSING_HUGETLBFS: u64 = 1 << 4;
pub(crate) const UFFD_FEATURE_MISSING_SHMEM: u64 = 1 << 5;
pub(crate) const UFFD_FEATURE_MINOR_HUGETLBFS: u64 = 1 << 9;
pub(crate) const UFFD_FEATURE_MINOR_SHMEM: u64 = 1 << 10;

const _UFFDIO_COPY: u64 = 0x03;
const _UFFDIO_WAKE: u64 = 0x02;
const _UFFDIO_CONTINUE: u64 = 0x07;
pub(crate) const UFFD_API_RANGE_IOCTLS_BASIC: u64 = (1 << _UFFDIO_WAKE) | (1 << _UFFDIO_COPY);
pub(crate) const UFFD_API_RANGE_IOCTLS_MINOR: u64 =
    UFFD_API_RANGE_IOCTLS_BASIC | (1 << _UFFDIO_CONTINUE);
