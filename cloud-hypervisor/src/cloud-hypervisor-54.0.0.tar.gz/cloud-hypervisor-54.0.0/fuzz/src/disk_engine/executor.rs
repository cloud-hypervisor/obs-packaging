// Copyright © 2026 The Cloud Hypervisor Authors. All rights reserved.
//
// SPDX-License-Identifier: Apache-2.0

//! Runs op programs against an engine and checks its contract: one
//! completion per accepted op and none per rejected op, no over-long
//! transfer, a stable capacity and, with a model, the data read back.

use std::marker::PhantomData;
use std::sync::Arc;

use block::async_io::{
    AsyncIo, AsyncIoCompletion, AsyncIoOperation, GuestMemoryTarget, OwnedIoBuffer,
};
use block::disk_file::{AsyncDiskFile, AsyncFullDiskFile};
use vm_memory::{Bytes, GuestAddress, GuestMemoryMmap};

use crate::disk_engine::format::DiskFormat;
use crate::disk_engine::model::Model;
use crate::disk_engine::program::{ring_depth, Op, OpLen, OpOffset, MAX_OPS, MAX_OP_LEN};

/// Largest disk size the shadow model is kept for.
const MAX_MODEL_LEN: u64 = 8 << 20;

/// Largest size a `Resize` op may ask for.
const MAX_RESIZE_LEN: u64 = 64 << 20;

/// Bytes written into each L2 table by a `Sweep` op.
const SWEEP_LEN: usize = 512;

/// Drives an op program against one opened disk image.
pub struct Executor<F: DiskFormat> {
    disk: Box<dyn AsyncFullDiskFile>,
    clone: Option<Box<dyn AsyncDiskFile>>,
    io: Box<dyn AsyncIo>,
    mem: Arc<GuestMemoryMmap<()>>,
    size: u64,
    model: Option<Model>,
    user_data: u64,
    sweeps: bool,
    format: PhantomData<F>,
}

impl<F: DiskFormat> Executor<F> {
    /// Returns `None` if the engine cannot create an I/O engine. The model is
    /// only sound for a blank template.
    pub fn new(
        disk: Box<dyn AsyncFullDiskFile>,
        ring_depth: u32,
        with_model: bool,
    ) -> Option<Self> {
        let io = disk.create_async_io(ring_depth).ok()?;
        let size = disk.logical_size().ok()?;
        let mem = GuestMemoryMmap::from_ranges(&[(GuestAddress(0), MAX_OP_LEN)]).ok()?;
        let model = (with_model && size <= MAX_MODEL_LEN).then(|| Model::new(size as usize));

        let executor = Self {
            disk,
            clone: None,
            io,
            mem: Arc::new(mem),
            size,
            model,
            user_data: 0,
            sweeps: false,
            format: PhantomData,
        };
        executor.check_capacity_backing();

        Some(executor)
    }

    /// Lets a `Sweep` op walk its full run of metadata tables.
    pub fn set_sweeps(&mut self, sweeps: bool) {
        self.sweeps = sweeps;
    }

    /// Runs up to [`MAX_OPS`] ops.
    pub fn run(&mut self, ops: &[Op]) {
        for op in ops.iter().take(MAX_OPS) {
            self.step(op);
        }
    }

    fn step(&mut self, op: &Op) {
        match *op {
            Op::ReadVec { offset, len } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.read_vec(offset, len)
            }
            Op::WriteVec { offset, len, seed } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.write_vec(offset, len, seed)
            }
            Op::ReadMem { offset, len } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.read_mem(offset, len)
            }
            Op::WriteMem { offset, len, seed } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.write_mem(offset, len, seed)
            }
            Op::PunchHole { offset, len } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.punch_hole(offset, len)
            }
            Op::WriteZeroes { offset, len } => {
                let (offset, len) = (self.offset(offset), self.len(len));
                self.write_zeroes(offset, len)
            }
            Op::Fsync { completion } => self.fsync(completion),
            Op::Resize { size_kib } => self.resize(u64::from(size_kib) * 1024),
            Op::RecreateIo { ring_depth: depth } => {
                if let Ok(io) = self.disk.create_async_io(ring_depth(depth)) {
                    self.io = io;
                }
            }
            Op::UseClone { ring_depth: depth } => self.use_clone(ring_depth(depth)),
            Op::QueryCaps => self.query_caps(),
            Op::Sweep {
                first,
                tables,
                seed,
            } => self.sweep(first, tables, seed),
        }
    }

    /// Writes one sector into each of a run of L2 tables and reads it back.
    fn sweep(&mut self, first: u8, tables: u8, seed: u8) {
        // Only a template with more L2 tables than the cache gets a full sweep.
        let tables = if self.sweeps { tables } else { 0 };
        let offsets: Vec<u64> = Op::sweep_offsets(first, tables, self.size).collect();
        for &offset in &offsets {
            self.write_vec(offset, SWEEP_LEN, seed);
        }
        for &offset in &offsets {
            self.read_vec(offset, SWEEP_LEN);
        }
    }

    /// Resolves `offset` and aligns it down. `Wild` offsets stay unaligned.
    fn offset(&self, offset: OpOffset) -> u64 {
        let resolved = offset.resolve(self.size);
        if matches!(offset, OpOffset::Wild(_)) {
            return resolved;
        }
        resolved - resolved % F::IO_ALIGNMENT
    }

    /// Rounds `len` up to [`DiskFormat::IO_ALIGNMENT`].
    fn len(&self, len: OpLen) -> usize {
        let alignment = F::IO_ALIGNMENT as usize;
        debug_assert!(MAX_OP_LEN.is_multiple_of(alignment));
        len.get().div_ceil(alignment) * alignment
    }

    fn read_vec(&mut self, offset: u64, len: usize) {
        let user_data = self.next_user_data();
        let buffer = OwnedIoBuffer::from_vec(vec![0u8; len]);
        let op = AsyncIoOperation::read_to_vec(offset as libc::off_t, buffer, user_data);

        let Some(completion) = self.submit(op, user_data) else {
            return;
        };
        let Some(done) = self.read_transferred(&completion, offset, len) else {
            return;
        };
        let Some(buffer) = completion.buffer.as_ref() else {
            panic!("{}: read completion returned no buffer", F::NAME);
        };

        self.check_read(offset, &buffer.as_slice()[..done]);
    }

    fn write_vec(&mut self, offset: u64, len: usize, seed: u8) {
        let data = pattern(offset, len, seed);
        let user_data = self.next_user_data();
        let buffer = OwnedIoBuffer::from_vec(data.clone());
        let op = AsyncIoOperation::write_from_vec(offset as libc::off_t, buffer, user_data);

        let Some(completion) = self.submit(op, user_data) else {
            self.record_unknown(offset, len);
            return;
        };
        match self.transferred(&completion, offset, len) {
            Some(done) => self.record_write(offset, &data[..done], len - done),
            None => self.record_unknown(offset, len),
        }
    }

    fn read_mem(&mut self, offset: u64, len: usize) {
        let Some(target) = self.guest_target(len) else {
            return;
        };
        let user_data = self.next_user_data();
        let op = AsyncIoOperation::read_to_memory(offset as libc::off_t, target, user_data);

        let Some(completion) = self.submit(op, user_data) else {
            return;
        };
        let Some(done) = self.read_transferred(&completion, offset, len) else {
            return;
        };

        let mut data = vec![0u8; done];
        if self.mem.read_slice(&mut data, GuestAddress(0)).is_ok() {
            self.check_read(offset, &data);
        }
    }

    fn write_mem(&mut self, offset: u64, len: usize, seed: u8) {
        let data = pattern(offset, len, seed);
        if self.mem.write_slice(&data, GuestAddress(0)).is_err() {
            return;
        }
        let Some(target) = self.guest_target(len) else {
            return;
        };
        let user_data = self.next_user_data();
        let op = AsyncIoOperation::write_from_memory(offset as libc::off_t, target, user_data);

        let Some(completion) = self.submit(op, user_data) else {
            self.record_unknown(offset, len);
            return;
        };
        match self.transferred(&completion, offset, len) {
            Some(done) => self.record_write(offset, &data[..done], len - done),
            None => self.record_unknown(offset, len),
        }
    }

    fn punch_hole(&mut self, offset: u64, len: usize) {
        let user_data = self.next_user_data();
        if self.io.punch_hole(offset, len as u64, user_data).is_err() {
            // A refused op changed nothing. VHD and VHDX refuse every sparse
            // op, so marking the range unknown would blank the model.
            return;
        }

        if self.completion_succeeded(user_data) && F::PUNCH_HOLE_READS_ZEROES {
            self.record_zeroes(offset, len);
        } else {
            self.record_unknown(offset, len);
        }
    }

    fn write_zeroes(&mut self, offset: u64, len: usize) {
        let user_data = self.next_user_data();
        if self.io.write_zeroes(offset, len as u64, user_data).is_err() {
            // As in `punch_hole`.
            return;
        }

        if self.completion_succeeded(user_data) {
            self.record_zeroes(offset, len);
        } else {
            self.record_unknown(offset, len);
        }
    }

    fn fsync(&mut self, completion: bool) {
        let user_data = self.next_user_data();
        let requested = completion.then_some(user_data);

        if self.io.fsync(requested).is_err() {
            return;
        }
        if completion {
            self.expect_completion(user_data);
        } else {
            assert!(
                self.io.next_completed_request().is_none(),
                "{}: fsync without user data produced a completion",
                F::NAME
            );
        }
    }

    fn resize(&mut self, size: u64) {
        let size = size.min(MAX_RESIZE_LEN);
        let _ = self.disk.resize(size);

        // The engine may round the size, or change it even on failure.
        let reported = self.disk.logical_size().unwrap_or(self.size);
        if reported == self.size {
            return;
        }

        self.size = reported;
        if reported > MAX_MODEL_LEN {
            self.model = None;
        } else if let Some(model) = self.model.as_mut() {
            model.resize(reported as usize);
        }
    }

    fn use_clone(&mut self, ring_depth: u32) {
        let Ok(clone) = self.disk.try_clone() else {
            return;
        };
        let Ok(io) = clone.create_async_io(ring_depth) else {
            return;
        };

        // The clone shares engine state, so the model stays valid.
        self.io = io;
        self.clone = Some(clone);
    }

    fn query_caps(&mut self) {
        let reported = self.disk.logical_size().unwrap_or(self.size);
        if F::FIXED_CAPACITY {
            assert_eq!(
                reported,
                self.size,
                "{}: reported size changed without a resize",
                F::NAME
            );
        } else {
            self.size = reported;
        }

        let _ = self.disk.physical_size();
        self.check_capacity_backing();
        let _ = self.disk.topology();
        let _ = self.disk.supports_sparse_operations();
        let _ = self.disk.fd();
        let _ = self.io.alignment();
        let _ = self.io.batch_requests_enabled();
        let _ = self.io.notifier();
    }

    /// Submits a data op and returns its completion, if it was accepted.
    fn submit(&mut self, op: AsyncIoOperation, user_data: u64) -> Option<AsyncIoCompletion> {
        if self.io.submit_data_operation(op).is_err() {
            assert!(
                self.io.next_completed_request().is_none(),
                "{}: rejected op {user_data} produced a completion",
                F::NAME
            );
            return None;
        }

        self.expect_completion(user_data)
    }

    /// Collects the single completion an accepted op owes the caller.
    fn expect_completion(&mut self, user_data: u64) -> Option<AsyncIoCompletion> {
        let Some(completion) = self.io.next_completed_request() else {
            assert!(
                !F::COMPLETES_INLINE,
                "{}: accepted op {user_data} produced no completion",
                F::NAME
            );
            return None;
        };

        assert_eq!(
            completion.user_data,
            user_data,
            "{}: completion carried the wrong user data",
            F::NAME
        );
        assert!(
            self.io.next_completed_request().is_none(),
            "{}: op {user_data} produced more than one completion",
            F::NAME
        );

        Some(completion)
    }

    /// Returns whether the op behind `user_data` completed successfully.
    fn completion_succeeded(&mut self, user_data: u64) -> bool {
        self.expect_completion(user_data)
            .is_some_and(|completion| completion.result >= 0)
    }

    /// Returns how many bytes a completed data op transferred.
    fn transferred(
        &self,
        completion: &AsyncIoCompletion,
        offset: u64,
        len: usize,
    ) -> Option<usize> {
        if completion.result < 0 {
            return None;
        }

        let done = completion.result as usize;
        assert!(
            done <= len,
            "{}: op reported {done} bytes for a {len} byte request",
            F::NAME
        );
        if F::FIXED_CAPACITY {
            assert!(
                done == 0 || offset < self.size,
                "{}: op at offset {offset} transferred {done} bytes past the {} byte capacity",
                F::NAME,
                self.size
            );
        }

        Some(done)
    }

    /// Returns how many bytes a successful read transferred.
    fn read_transferred(
        &self,
        completion: &AsyncIoCompletion,
        offset: u64,
        len: usize,
    ) -> Option<usize> {
        let done = self.transferred(completion, offset, len)?;

        if F::NO_SHORT_READS {
            assert_eq!(
                done,
                len,
                "{}: read at offset {offset} transferred {done} of the {len} bytes requested",
                F::NAME
            );
        }

        Some(done)
    }

    /// Checks the advertised capacity against the file holding it.
    fn check_capacity_backing(&self) {
        let Some(tail) = F::CAPACITY_FILE_TAIL else {
            return;
        };
        let (Ok(logical), Ok(physical)) = (self.disk.logical_size(), self.disk.physical_size())
        else {
            return;
        };

        assert!(
            logical.saturating_add(tail) <= physical,
            "{}: capacity {logical} plus a {tail} byte tail exceeds the {physical} byte image file",
            F::NAME
        );
    }

    fn guest_target(&self, len: usize) -> Option<GuestMemoryTarget> {
        GuestMemoryTarget::new(Arc::clone(&self.mem), &[(GuestAddress(0), len as u32)]).ok()
    }

    fn check_read(&self, offset: u64, data: &[u8]) {
        let Some(model) = self.model.as_ref() else {
            return;
        };
        if let Err(mismatch) = model.check(offset, data) {
            panic!("{}: read back mismatch: {mismatch}", F::NAME);
        }
    }

    fn record_write(&mut self, offset: u64, written: &[u8], missing: usize) {
        let Some(model) = self.model.as_mut() else {
            return;
        };
        model.record_write(offset, written);
        if missing > 0 {
            model.record_unknown(offset + written.len() as u64, missing);
        }
    }

    fn record_zeroes(&mut self, offset: u64, len: usize) {
        if let Some(model) = self.model.as_mut() {
            model.record_zeroes(offset, len);
        }
    }

    fn record_unknown(&mut self, offset: u64, len: usize) {
        if let Some(model) = self.model.as_mut() {
            model.record_unknown(offset, len);
        }
    }

    fn next_user_data(&mut self) -> u64 {
        self.user_data += 1;
        self.user_data
    }
}

/// Builds a pattern whose every byte depends on its disk offset, so data
/// read from the wrong place is caught.
fn pattern(offset: u64, len: usize, seed: u8) -> Vec<u8> {
    (0..len)
        .map(|i| {
            let at = offset.wrapping_add(i as u64);
            seed ^ (at as u8) ^ ((at >> 8) as u8).rotate_left(3) ^ ((at >> 16) as u8).rotate_left(5)
        })
        .collect()
}
