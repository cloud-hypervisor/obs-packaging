// Copyright 2022 Arm Limited (or its affiliates). All rights reserved.

pub mod gic;
