// Copyright 2020, ARM Limited.
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::result;
use std::sync::{Arc, Mutex};

use anyhow::anyhow;
use arch::layout;
use hypervisor::arch::aarch64::gic::{GicState, Vgic, VgicConfig};
use vm_device::interrupt::{
    InterruptIndex, InterruptManager, InterruptSourceConfig, InterruptSourceGroup,
    LegacyIrqSourceConfig, MsiIrqGroupConfig,
};
use vm_memory::address::Address;
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vmm_sys_util::eventfd::EventFd;

use super::interrupt_controller::{Error, InterruptController};

type Result<T> = result::Result<T, Error>;

// Reserve 32 IRQs for legacy devices.
pub const IRQ_LEGACY_BASE: usize = layout::IRQ_BASE as usize;
pub const IRQ_LEGACY_COUNT: usize = 32;
pub const GIC_SNAPSHOT_ID: &str = "gic-v3-its";

// Gic (Generic Interrupt Controller) struct provides all the functionality of a
// GIC device. It wraps a hypervisor-emulated GIC device (Vgic) provided by the
// `hypervisor` crate.
// Gic struct also implements InterruptController to provide interrupt delivery
// service.
pub struct Gic {
    interrupt_source_group: Arc<dyn InterruptSourceGroup>,
    // The hypervisor agnostic virtual GIC
    vgic: Arc<Mutex<dyn Vgic>>,
    config: VgicConfig,
}

impl Gic {
    #[expect(clippy::needless_pass_by_value)]
    pub fn new(
        vcpu_count: u32,
        interrupt_manager: Arc<dyn InterruptManager<GroupConfig = MsiIrqGroupConfig>>,
        vm: Arc<dyn hypervisor::Vm>,
        maintenance_irq: Option<u32>,
        state: Option<&GicState>,
    ) -> Result<Gic> {
        let interrupt_source_group = interrupt_manager
            .create_group(MsiIrqGroupConfig {
                base: IRQ_LEGACY_BASE as InterruptIndex,
                count: IRQ_LEGACY_COUNT as InterruptIndex,
            })
            .map_err(Error::CreateInterruptSourceGroup)?;

        let mut config = Gic::create_config(vcpu_count as u64, state)?;
        config.maintenance_irq = maintenance_irq;
        let vgic = vm.create_vgic(&config).map_err(Error::CreateGic)?;

        let gic = Gic {
            interrupt_source_group,
            vgic,
            config,
        };
        gic.enable()?;

        Ok(gic)
    }

    pub fn restore_vgic(&self, state: Option<GicState>) -> Result<()> {
        let mut vgic = self.vgic.lock().unwrap();
        vgic.set_state(&state.unwrap()).map_err(Error::RestoreGic)
    }

    fn enable(&self) -> Result<()> {
        // Set irqfd for legacy interrupts
        self.interrupt_source_group
            .enable()
            .map_err(Error::EnableInterrupt)?;

        // Set irq_routing for legacy interrupts.
        //   irqchip: Hardcode to 0 as we support only 1 GIC
        //   pin: Use irq number as pin
        for i in IRQ_LEGACY_BASE..(IRQ_LEGACY_BASE + IRQ_LEGACY_COUNT) {
            let config = LegacyIrqSourceConfig {
                irqchip: 0,
                pin: (i - IRQ_LEGACY_BASE) as u32,
            };
            self.interrupt_source_group
                .update(
                    i as InterruptIndex,
                    InterruptSourceConfig::LegacyIrq(config),
                    false,
                    false,
                )
                .map_err(Error::EnableInterrupt)?;
        }

        self.interrupt_source_group
            .set_gsi()
            .map_err(Error::EnableInterrupt)?;
        Ok(())
    }

    /// Create a GICv3 configuration. On restore, uses the distributor base
    /// address recorded in state, falling back to LEGACY_GIC_V3_DIST_START
    /// when the snapshot has no recorded address.
    pub fn create_config(vcpu_count: u64, state: Option<&GicState>) -> Result<VgicConfig> {
        if vcpu_count > layout::GIC_V3_LAYOUT_MAX_VCPUS {
            return Err(Error::GicTooManyVcpus(
                vcpu_count,
                layout::GIC_V3_LAYOUT_MAX_VCPUS,
            ));
        }
        let dist_addr = match state {
            Some(state) => state
                .dist_addr()
                .unwrap_or(layout::LEGACY_GIC_V3_DIST_START.raw_value()),
            None => layout::GIC_V3_DIST_START.raw_value(),
        };
        let redists_size = layout::GIC_V3_REDIST_SIZE * vcpu_count;
        let redists_addr = dist_addr - redists_size;
        Ok(VgicConfig {
            vcpu_count,
            dist_addr,
            dist_size: layout::GIC_V3_DIST_SIZE,
            redists_addr,
            redists_size,
            msi_addr: redists_addr - layout::GIC_V3_ITS_SIZE,
            msi_size: layout::GIC_V3_ITS_SIZE,
            nr_irqs: layout::IRQ_NUM,
            maintenance_irq: None,
        })
    }

    pub fn get_vgic(&mut self) -> Result<Arc<Mutex<dyn Vgic>>> {
        Ok(Arc::clone(&self.vgic))
    }

    pub fn config(&self) -> VgicConfig {
        self.config
    }
}

impl InterruptController for Gic {
    // This should be called anytime an interrupt needs to be injected into the
    // running guest.
    fn service_irq(&mut self, irq: usize) -> Result<()> {
        self.interrupt_source_group
            .trigger(irq as InterruptIndex)
            .map_err(Error::TriggerInterrupt)?;

        Ok(())
    }

    fn notifier(&self, irq: usize) -> Option<EventFd> {
        self.interrupt_source_group.notifier(irq as InterruptIndex)
    }
}

impl Snapshottable for Gic {
    fn id(&self) -> String {
        GIC_SNAPSHOT_ID.to_string()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        let state = self.vgic.lock().unwrap().state().unwrap();
        Snapshot::new_from_state(&state)
    }
}

impl Pausable for Gic {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        // Flush tables to guest RAM
        self.vgic.lock().unwrap().save_data_tables().map_err(|e| {
            MigratableError::Pause(anyhow!("Could not save GICv3ITS GIC pending tables {e:?}",))
        })?;
        Ok(())
    }
}
impl Transportable for Gic {}
impl Migratable for Gic {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_create_config_limit() {
        let floor = layout::UEFI_START.raw_value() + layout::UEFI_SIZE;
        let limit = layout::GIC_V3_LAYOUT_MAX_VCPUS;

        // At the limit the ITS clears the UEFI flash, and one more
        // Redistributor frame would push it into the flash.
        let config = Gic::create_config(limit, None).unwrap();
        assert!(config.msi_addr >= floor);
        assert!(config.msi_addr - layout::GIC_V3_REDIST_SIZE < floor);

        assert!(matches!(
            Gic::create_config(limit + 1, None),
            Err(Error::GicTooManyVcpus(n, l)) if n == limit + 1 && l == limit
        ));
        // Counts whose layout would have wrapped below address 0 are refused
        // too, rather than wrapping or panicking.
        let wraps = layout::GIC_V3_DIST_START.raw_value() / layout::GIC_V3_REDIST_SIZE + 1;
        for n in [wraps, u64::MAX] {
            assert!(matches!(
                Gic::create_config(n, None),
                Err(Error::GicTooManyVcpus(..))
            ));
        }
    }
}
