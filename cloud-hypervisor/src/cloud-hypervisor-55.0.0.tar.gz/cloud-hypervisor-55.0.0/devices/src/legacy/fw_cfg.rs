// Copyright 2025 Google LLC.
//
// SPDX-License-Identifier: Apache-2.0
//

//! Cloud Hypervisor implementation of QEMU's fw_cfg spec
//! https://www.qemu.org/docs/master/specs/fw_cfg.html
//! Linux kernel fw_cfg driver header
//! https://github.com/torvalds/linux/blob/master/include/uapi/linux/qemu_fw_cfg.h
//! Uploading files to the guest via fw_cfg is supported for all kernels 4.6+ w/ CONFIG_FW_CFG_SYSFS enabled
//! https://cateee.net/lkddb/web-lkddb/FW_CFG_SYSFS.html
//! No kernel requirement if above functionality is not required,
//! only firmware must implement mechanism to interact with this fw_cfg device
use std::ffi::CString;
use std::fs::File;
#[cfg(target_arch = "x86_64")]
use std::io::Error;
use std::io::{ErrorKind, Result};
use std::mem::offset_of;
use std::os::unix::fs::FileExt;
use std::sync::{Arc, Barrier};
use std::{cmp, result};

use acpi_tables::rsdp::Rsdp;
use acpi_tables::{Aml, AmlSink, aml};
#[cfg(target_arch = "x86_64")]
use arch::x86_64::generate_e820_memory_map;
use bitfield_struct::bitfield;
#[cfg(target_arch = "x86_64")]
use linux_loader::bootparam::boot_params;
use log::{debug, error};
use serde::{Deserialize, Serialize};
use vm_allocator::GuestMemory;
use vm_device::BusDevice;
#[cfg(target_arch = "x86_64")]
use vm_memory::ByteValued;
use vm_memory::{Bytes, GuestAddress, GuestAddressSpace, GuestMemoryAtomic};
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vmm_sys_util::sock_ctrl_msg::IntoIovec;
use zerocopy::{FromBytes, FromZeros, Immutable, IntoBytes};

#[cfg(target_arch = "x86_64")]
// https://github.com/project-oak/oak/tree/main/stage0_bin#memory-layout
const STAGE0_START_ADDRESS: GuestAddress = GuestAddress(0xfffe_0000);
#[cfg(target_arch = "x86_64")]
const STAGE0_SIZE: usize = 0x2_0000;
#[cfg(target_arch = "x86_64")]
const E820_RESERVED: u32 = 2;

#[cfg(target_arch = "x86_64")]
const FW_CFG_SELECTOR_OFFSET: u64 = 0;
#[cfg(target_arch = "x86_64")]
const FW_CFG_DATA_OFFSET: u64 = 1;
#[cfg(target_arch = "x86_64")]
const FW_CFG_DMA_HI_OFFSET: u64 = 4;
#[cfg(target_arch = "x86_64")]
const FW_CFG_DMA_LO_OFFSET: u64 = 8;
#[cfg(target_arch = "x86_64")]
pub const FW_CFG_ADDRESS_BASE: u64 = 0x510;
#[cfg(target_arch = "x86_64")]
pub const FW_CFG_ADDRESS_WIDTH: u64 = 0xc;
#[cfg(target_arch = "aarch64")]
const FW_CFG_SELECTOR_OFFSET: u64 = 8;
#[cfg(target_arch = "aarch64")]
const FW_CFG_DATA_OFFSET: u64 = 0;
#[cfg(target_arch = "aarch64")]
const FW_CFG_DMA_HI_OFFSET: u64 = 0x10;
#[cfg(target_arch = "aarch64")]
const FW_CFG_DMA_LO_OFFSET: u64 = 0x14;
#[cfg(target_arch = "aarch64")]
pub const FW_CFG_ADDRESS_BASE: u64 = 0x9030000;
#[cfg(target_arch = "aarch64")]
pub const FW_CFG_ADDRESS_WIDTH: u64 = 0x18;

const FW_CFG_SIGNATURE: u16 = 0x00;
const FW_CFG_ID: u16 = 0x01;
const FW_CFG_KERNEL_SIZE: u16 = 0x08;
const FW_CFG_INITRD_SIZE: u16 = 0x0b;
const FW_CFG_KERNEL_DATA: u16 = 0x11;
const FW_CFG_INITRD_DATA: u16 = 0x12;
const FW_CFG_CMDLINE_SIZE: u16 = 0x14;
const FW_CFG_CMDLINE_DATA: u16 = 0x15;
#[cfg(target_arch = "x86_64")]
const FW_CFG_SETUP_SIZE: u16 = 0x17;
#[cfg(target_arch = "x86_64")]
const FW_CFG_SETUP_DATA: u16 = 0x18;
const FW_CFG_FILE_DIR: u16 = 0x19;
const FW_CFG_KNOWN_ITEMS: usize = 0x20;

pub const FW_CFG_FILE_FIRST: u16 = 0x20;
pub const FW_CFG_DMA_SIGNATURE_CONTENT: [u8; 8] = *b"QEMU CFG";
pub const FW_CFG_SIGNATURE_CONTENT: [u8; 4] = *b"QEMU";
// https://github.com/torvalds/linux/blob/master/include/uapi/linux/qemu_fw_cfg.h
pub const FW_CFG_ACPI_ID: &str = "QEMU0002";
// Reserved (must be enabled)
const FW_CFG_F_RESERVED: u8 = 1 << 0;
// DMA Toggle Bit (enabled by default)
const FW_CFG_F_DMA: u8 = 1 << 1;
pub const FW_CFG_FEATURE: [u8; 4] = [FW_CFG_F_RESERVED | FW_CFG_F_DMA, 0, 0, 0];

const COMMAND_ALLOCATE: u32 = 0x1;
const COMMAND_ADD_POINTER: u32 = 0x2;
const COMMAND_ADD_CHECKSUM: u32 = 0x3;

const ALLOC_ZONE_HIGH: u8 = 0x1;
const ALLOC_ZONE_FSEG: u8 = 0x2;

const FW_CFG_FILENAME_TABLE_LOADER: &str = "etc/table-loader";
const FW_CFG_FILENAME_RSDP: &str = "acpi/rsdp";
const FW_CFG_FILENAME_ACPI_TABLES: &str = "acpi/tables";

#[derive(Debug)]
pub enum FwCfgContent {
    Bytes(Vec<u8>),
    Slice(&'static [u8]),
    File(u64, File),
    U32(u32),
}

impl Default for FwCfgContent {
    fn default() -> Self {
        FwCfgContent::Slice(&[])
    }
}

impl FwCfgContent {
    fn size(&self) -> Result<u32> {
        let ret = match self {
            FwCfgContent::Bytes(v) => v.len(),
            FwCfgContent::File(offset, f) => {
                f.metadata()?
                    .len()
                    .checked_sub(*offset)
                    .ok_or(ErrorKind::InvalidData)? as usize
            }
            FwCfgContent::Slice(s) => s.len(),
            FwCfgContent::U32(n) => size_of_val(n),
        };
        u32::try_from(ret).map_err(|_| ErrorKind::InvalidInput.into())
    }
}

#[derive(Debug, Default)]
pub struct FwCfgItem {
    pub name: String,
    pub content: FwCfgContent,
}

pub const FW_CFG_SNAPSHOT_ID: &str = "__fw_cfg";

#[derive(Default, Serialize, Deserialize)]
pub struct FwCfgState {
    selector: u16,
    data_offset: u32,
    dma_address: u64,
}

/// https://www.qemu.org/docs/master/specs/fw_cfg.html
#[derive(Debug)]
pub struct FwCfg {
    selector: u16,
    data_offset: u32,
    dma_address: u64,
    items: Vec<FwCfgItem>,                           // 0x20 and above
    known_items: [FwCfgContent; FW_CFG_KNOWN_ITEMS], // 0x0 to 0x19
    memory: GuestMemoryAtomic<GuestMemory>,
}

#[repr(C)]
#[derive(Debug, IntoBytes, FromBytes)]
struct FwCfgDmaAccess {
    control_be: u32,
    length_be: u32,
    address_be: u64,
}

// https://github.com/torvalds/linux/blob/master/include/uapi/linux/qemu_fw_cfg.h#L67
#[bitfield(u32)]
struct AccessControl {
    // FW_CFG_DMA_CTL_ERROR = 0x01
    error: bool,
    // FW_CFG_DMA_CTL_READ = 0x02
    read: bool,
    // FW_CFG_DMA_CTL_SKIP = 0x04
    skip: bool,
    // FW_CFG_DMA_CTL_SELECT = 0x08
    select: bool,
    // FW_CFG_DMA_CTL_WRITE = 0x10
    write: bool,
    #[bits(11)]
    _unused: u16,
    #[bits(16)]
    selector: u16,
}

#[repr(C)]
#[derive(Debug, IntoBytes, FromBytes)]
struct FwCfgFilesHeader {
    count_be: u32,
}

pub const FILE_NAME_SIZE: usize = 56;

pub fn create_file_name(name: &str) -> [u8; FILE_NAME_SIZE] {
    let mut c_name = [0u8; FILE_NAME_SIZE];
    let c_len = cmp::min(FILE_NAME_SIZE - 1, name.len());
    c_name[0..c_len].copy_from_slice(&name.as_bytes()[0..c_len]);
    c_name
}

#[cfg(target_arch = "x86_64")]
#[repr(C, packed)]
#[derive(Debug, IntoBytes, FromBytes, Clone, Copy)]
struct BootE820Entry {
    addr: u64,
    size: u64,
    type_: u32,
}

#[repr(C)]
#[derive(Debug, IntoBytes, FromBytes)]
struct FwCfgFile {
    size_be: u32,
    select_be: u16,
    _reserved: u16,
    name: [u8; FILE_NAME_SIZE],
}

#[repr(C, align(4))]
#[derive(Debug, IntoBytes, Immutable)]
struct Allocate {
    command: u32,
    file: [u8; FILE_NAME_SIZE],
    align: u32,
    zone: u8,
    _pad: [u8; 63],
}

#[repr(C, align(4))]
#[derive(Debug, IntoBytes, Immutable)]
struct AddPointer {
    command: u32,
    dst: [u8; FILE_NAME_SIZE],
    src: [u8; FILE_NAME_SIZE],
    offset: u32,
    size: u8,
    _pad: [u8; 7],
}

#[repr(C, align(4))]
#[derive(Debug, IntoBytes, Immutable)]
struct AddChecksum {
    command: u32,
    file: [u8; FILE_NAME_SIZE],
    offset: u32,
    start: u32,
    len: u32,
    _pad: [u8; 56],
}

fn create_intra_pointer(name: &str, offset: usize, size: u8) -> AddPointer {
    AddPointer {
        command: COMMAND_ADD_POINTER,
        dst: create_file_name(name),
        src: create_file_name(name),
        offset: offset as u32,
        size,
        _pad: [0; 7],
    }
}

fn create_acpi_table_checksum(offset: usize, len: usize) -> AddChecksum {
    AddChecksum {
        command: COMMAND_ADD_CHECKSUM,
        file: create_file_name(FW_CFG_FILENAME_ACPI_TABLES),
        offset: (offset + offset_of!(AcpiTableHeader, checksum)) as u32,
        start: offset as u32,
        len: len as u32,
        _pad: [0; 56],
    }
}

#[repr(C, align(4))]
#[derive(Debug, Clone, Default, FromBytes, IntoBytes)]
struct AcpiTableHeader {
    signature: [u8; 4],
    length: u32,
    revision: u8,
    checksum: u8,
    oem_id: [u8; 6],
    oem_table_id: [u8; 8],
    oem_revision: u32,
    asl_compiler_id: [u8; 4],
    asl_compiler_revision: u32,
}

struct AcpiTable {
    rsdp: Rsdp,
    tables: Vec<u8>,
    table_pointers: Vec<usize>,
    table_checksums: Vec<(usize, usize)>,
}

impl AcpiTable {
    fn pointers(&self) -> &[usize] {
        &self.table_pointers
    }

    fn checksums(&self) -> &[(usize, usize)] {
        &self.table_checksums
    }

    fn take(self) -> (Rsdp, Vec<u8>) {
        (self.rsdp, self.tables)
    }
}

// Creates fw_cfg items used by firmware to load and verify Acpi tables
// https://github.com/qemu/qemu/blob/master/hw/acpi/bios-linker-loader.c
fn create_acpi_loader(acpi_table: AcpiTable) -> [FwCfgItem; 3] {
    let mut table_loader_bytes: Vec<u8> = Vec::new();
    let allocate_rsdp = Allocate {
        command: COMMAND_ALLOCATE,
        file: create_file_name(FW_CFG_FILENAME_RSDP),
        align: 4,
        zone: ALLOC_ZONE_FSEG,
        _pad: [0; 63],
    };
    table_loader_bytes.extend(allocate_rsdp.as_bytes());

    let allocate_tables = Allocate {
        command: COMMAND_ALLOCATE,
        file: create_file_name(FW_CFG_FILENAME_ACPI_TABLES),
        align: 4,
        zone: ALLOC_ZONE_HIGH,
        _pad: [0; 63],
    };
    table_loader_bytes.extend(allocate_tables.as_bytes());

    for pointer_offset in acpi_table.pointers().iter() {
        let pointer = create_intra_pointer(FW_CFG_FILENAME_ACPI_TABLES, *pointer_offset, 8);
        table_loader_bytes.extend(pointer.as_bytes());
    }
    for (offset, len) in acpi_table.checksums().iter() {
        let checksum = create_acpi_table_checksum(*offset, *len);
        table_loader_bytes.extend(checksum.as_bytes());
    }
    let pointer_rsdp_to_xsdt = AddPointer {
        command: COMMAND_ADD_POINTER,
        dst: create_file_name(FW_CFG_FILENAME_RSDP),
        src: create_file_name(FW_CFG_FILENAME_ACPI_TABLES),
        offset: offset_of!(Rsdp, xsdt_addr) as u32,
        size: 8,
        _pad: [0; 7],
    };
    table_loader_bytes.extend(pointer_rsdp_to_xsdt.as_bytes());
    let checksum_rsdp = AddChecksum {
        command: COMMAND_ADD_CHECKSUM,
        file: create_file_name(FW_CFG_FILENAME_RSDP),
        offset: offset_of!(Rsdp, checksum) as u32,
        start: 0,
        len: offset_of!(Rsdp, length) as u32,
        _pad: [0; 56],
    };
    let checksum_rsdp_ext = AddChecksum {
        command: COMMAND_ADD_CHECKSUM,
        file: create_file_name(FW_CFG_FILENAME_RSDP),
        offset: offset_of!(Rsdp, extended_checksum) as u32,
        start: 0,
        len: size_of::<Rsdp>() as u32,
        _pad: [0; 56],
    };
    table_loader_bytes.extend(checksum_rsdp.as_bytes());
    table_loader_bytes.extend(checksum_rsdp_ext.as_bytes());

    let table_loader = FwCfgItem {
        name: FW_CFG_FILENAME_TABLE_LOADER.to_owned(),
        content: FwCfgContent::Bytes(table_loader_bytes),
    };
    let (rsdp, tables) = acpi_table.take();
    let acpi_rsdp = FwCfgItem {
        name: FW_CFG_FILENAME_RSDP.to_owned(),
        content: FwCfgContent::Bytes(rsdp.as_bytes().to_owned()),
    };
    let apci_tables = FwCfgItem {
        name: FW_CFG_FILENAME_ACPI_TABLES.to_owned(),
        content: FwCfgContent::Bytes(tables),
    };
    [table_loader, acpi_rsdp, apci_tables]
}

impl FwCfg {
    pub fn new(memory: GuestMemoryAtomic<GuestMemory>, state: Option<FwCfgState>) -> FwCfg {
        let state = state.unwrap_or_default();
        const DEFAULT_ITEM: FwCfgContent = FwCfgContent::Slice(&[]);
        let mut known_items = [DEFAULT_ITEM; FW_CFG_KNOWN_ITEMS];
        known_items[FW_CFG_SIGNATURE as usize] = FwCfgContent::Slice(&FW_CFG_SIGNATURE_CONTENT);
        known_items[FW_CFG_ID as usize] = FwCfgContent::Slice(&FW_CFG_FEATURE);
        let file_buf = Vec::from(FwCfgFilesHeader { count_be: 0 }.as_mut_bytes());
        known_items[FW_CFG_FILE_DIR as usize] = FwCfgContent::Bytes(file_buf);

        FwCfg {
            selector: state.selector,
            data_offset: state.data_offset,
            dma_address: state.dma_address,
            items: vec![],
            known_items,
            memory,
        }
    }

    pub fn populate_fw_cfg(
        &mut self,
        kernel: Option<File>,
        initramfs: Option<File>,
        cmdline: Option<CString>,
        fw_cfg_item_list: Option<Vec<FwCfgItem>>,
        #[cfg(target_arch = "x86_64")] kvm_sev_snp_enabled: bool,
    ) -> Result<()> {
        if let Some(kernel) = kernel {
            self.add_kernel_data(
                &kernel,
                #[cfg(target_arch = "x86_64")]
                kvm_sev_snp_enabled,
            )?;
        }
        if let Some(cmdline) = cmdline {
            self.add_kernel_cmdline(cmdline);
        }
        if let Some(initramfs) = initramfs {
            self.add_initramfs_data(&initramfs)?;
        }
        if let Some(fw_cfg_item_list) = fw_cfg_item_list {
            for item in fw_cfg_item_list {
                self.add_item(item)?;
            }
        }
        Ok(())
    }

    #[cfg(target_arch = "x86_64")]
    pub fn add_e820(&mut self, boot_memory: &GuestMemory, kvm_sev_snp_enabled: bool) -> Result<()> {
        let mut entries = generate_e820_memory_map(boot_memory).map_err(Error::other)?;
        if kvm_sev_snp_enabled {
            entries.push((STAGE0_START_ADDRESS.0, STAGE0_SIZE as u64, E820_RESERVED));
            entries.sort_unstable_by_key(|entry| entry.0);
        }
        let mut bytes = vec![];
        for (addr, size, type_) in entries {
            let mut entry = BootE820Entry { addr, size, type_ };
            bytes.extend_from_slice(entry.as_mut_bytes());
        }
        let item = FwCfgItem {
            name: "etc/e820".to_owned(),
            content: FwCfgContent::Bytes(bytes),
        };
        self.add_item(item)
    }

    fn file_dir_mut(&mut self) -> &mut Vec<u8> {
        let FwCfgContent::Bytes(file_buf) = &mut self.known_items[FW_CFG_FILE_DIR as usize] else {
            unreachable!("fw_cfg: selector {FW_CFG_FILE_DIR:#x} should be FwCfgContent::Byte!")
        };
        file_buf
    }

    fn update_count(&mut self) {
        let mut header = FwCfgFilesHeader {
            count_be: (self.items.len() as u32).to_be(),
        };
        self.file_dir_mut()[0..4].copy_from_slice(header.as_mut_bytes());
    }

    pub fn add_item(&mut self, item: FwCfgItem) -> Result<()> {
        let index = self.items.len();
        let c_name = create_file_name(&item.name);
        let size = item.content.size()?;
        let mut cfg_file = FwCfgFile {
            size_be: size.to_be(),
            select_be: (FW_CFG_FILE_FIRST + index as u16).to_be(),
            _reserved: 0,
            name: c_name,
        };
        self.file_dir_mut()
            .extend_from_slice(cfg_file.as_mut_bytes());
        self.items.push(item);
        self.update_count();
        Ok(())
    }

    fn dma_read_content(&self, content: &FwCfgContent, len: u32, address: u64) -> Result<u32> {
        let content_size = content.size()?.saturating_sub(self.data_offset);
        let op_size = cmp::min(content_size, len);
        let mut buf = vec![0u8; op_size as usize];
        Self::read_content(content, self.data_offset, buf.as_mut_bytes())?;
        let r = self
            .memory
            .memory()
            .write(buf.as_bytes(), GuestAddress(address));
        match r {
            Err(e) => {
                error!("fw_cfg: dma read error: {e:x?}");
                Err(ErrorKind::InvalidInput.into())
            }
            Ok(size) => Ok(size as u32),
        }
    }

    fn item_size(&self, selector: u16) -> Option<u32> {
        let content = if let Some(content) = self.known_items.get(selector as usize) {
            content
        } else {
            &self
                .items
                .get((selector - FW_CFG_FILE_FIRST) as usize)?
                .content
        };
        content.size().ok()
    }

    /// Retrieves the [`FwCfgContent`] corresponding to the selector currently set in the internal
    /// selector buffer.
    fn get_selected_content(&self) -> Result<&FwCfgContent> {
        if let Some(known_item) = self.known_items.get(usize::from(self.selector)) {
            Ok(known_item)
        } else if let Some(item) = self
            .items
            .get(usize::from(self.selector - FW_CFG_FILE_FIRST))
        {
            Ok(&item.content)
        } else {
            error!("fw_cfg: selector {:#x} does not exist.", self.selector);
            Err(ErrorKind::NotFound.into())
        }
    }

    fn dma_read(&mut self, len: u32, address: u64) -> Result<()> {
        let content = self.get_selected_content()?;
        let op_size = self.dma_read_content(content, len, address)?;
        self.data_offset += op_size;
        Ok(())
    }

    fn do_dma(&mut self) {
        let dma_address = self.dma_address;
        let mut access = FwCfgDmaAccess::new_zeroed();
        // TODO although the name indicates, there is no retry internally: https://github.com/rust-vmm/rust-vmm/issues/43
        // For now, we prefer to fail loudly at least.
        let dma_access = match self
            .memory
            .memory()
            .read_slice(access.as_mut_bytes(), GuestAddress(dma_address))
        {
            Ok(()) => access,
            Err(e) => {
                error!("fw_cfg: invalid address of dma access {dma_address:#x}: {e:?}");
                return;
            }
        };
        let control = AccessControl(u32::from_be(dma_access.control_be));
        if control.select() {
            self.selector = control.selector();
            self.data_offset = 0;
        }
        let len = u32::from_be(dma_access.length_be);
        let addr = u64::from_be(dma_access.address_be);
        let ret = if control.read() {
            self.dma_read(len, addr)
        } else if control.write() {
            Err(ErrorKind::InvalidInput.into())
        } else if control.skip() {
            let size = self.item_size(self.selector).unwrap_or(0);
            self.data_offset += len.min(size.saturating_sub(self.data_offset));
            Ok(())
        } else if control.select() {
            Ok(())
        } else {
            Err(ErrorKind::InvalidData.into())
        };
        let mut access_resp = AccessControl(0);
        if let Err(e) = ret {
            error!("fw_cfg: dma operation {dma_access:x?}: {e:x?}");
            access_resp.set_error(true);
        }
        if let Err(e) = self.memory.memory().write_slice(
            &access_resp.0.to_be_bytes(),
            GuestAddress(dma_address + core::mem::offset_of!(FwCfgDmaAccess, control_be) as u64),
        ) {
            error!("fw_cfg: finishing dma: {e:?}");
        }
    }

    #[cfg(target_arch = "x86_64")]
    pub fn add_kernel_data(&mut self, file: &File, kvm_sev_snp_enabled: bool) -> Result<()> {
        let mut buffer = vec![0u8; size_of::<boot_params>()];
        file.read_exact_at(&mut buffer, 0)?;
        let bp = boot_params::from_mut_slice(&mut buffer).unwrap();
        // For SEV-SNP guests on KVM, don't modify the kernel header so the
        // bytes sent via fw_cfg match what the VMM hashes for the launch digest.
        // The guest firmware handles these fields itself.
        if !kvm_sev_snp_enabled {
            if bp.hdr.setup_sects == 0 {
                bp.hdr.setup_sects = 4;
            }
            bp.hdr.type_of_loader = 0xff;
        }
        let kernel_start = {
            let sects = if bp.hdr.setup_sects == 0 {
                4
            } else {
                bp.hdr.setup_sects
            };
            (sects as usize + 1) * 512
        };

        if kernel_start <= buffer.len() {
            buffer.truncate(kernel_start);
        } else {
            buffer.resize(kernel_start, 0);
            file.read_exact_at(
                &mut buffer[size_of::<boot_params>()..],
                size_of::<boot_params>() as u64,
            )?;
        }

        self.known_items[FW_CFG_SETUP_SIZE as usize] = FwCfgContent::U32(buffer.len() as u32);
        self.known_items[FW_CFG_SETUP_DATA as usize] = FwCfgContent::Bytes(buffer);
        self.known_items[FW_CFG_KERNEL_SIZE as usize] =
            FwCfgContent::U32(file.metadata()?.len() as u32 - kernel_start as u32);
        self.known_items[FW_CFG_KERNEL_DATA as usize] =
            FwCfgContent::File(kernel_start as u64, file.try_clone()?);
        Ok(())
    }

    #[cfg(target_arch = "aarch64")]
    pub fn add_kernel_data(&mut self, file: &File) -> Result<()> {
        let kernel_size =
            u32::try_from(file.metadata()?.len()).map_err(|_| ErrorKind::InvalidInput)?;

        // AArch64 firmware expects the complete Image in FW_CFG_KERNEL_DATA,
        // matching QEMU's firmware boot path.
        self.known_items[FW_CFG_KERNEL_SIZE as usize] = FwCfgContent::U32(kernel_size);
        self.known_items[FW_CFG_KERNEL_DATA as usize] = FwCfgContent::File(0, file.try_clone()?);
        Ok(())
    }

    pub fn add_kernel_cmdline(&mut self, s: CString) {
        let bytes = s.into_bytes_with_nul();
        self.known_items[FW_CFG_CMDLINE_SIZE as usize] = FwCfgContent::U32(bytes.len() as u32);
        self.known_items[FW_CFG_CMDLINE_DATA as usize] = FwCfgContent::Bytes(bytes);
    }

    pub fn add_acpi(
        &mut self,
        rsdp: Rsdp,
        tables: Vec<u8>,
        table_checksums: Vec<(usize, usize)>,
        table_pointers: Vec<usize>,
    ) -> Result<()> {
        let acpi_table = AcpiTable {
            rsdp,
            tables,
            table_checksums,
            table_pointers,
        };
        let [table_loader, acpi_rsdp, apci_tables] = create_acpi_loader(acpi_table);
        self.add_item(table_loader)?;
        self.add_item(acpi_rsdp)?;
        self.add_item(apci_tables)
    }

    pub fn add_initramfs_data(&mut self, file: &File) -> Result<()> {
        let initramfs_size = file.metadata()?.len();
        self.known_items[FW_CFG_INITRD_SIZE as usize] = FwCfgContent::U32(initramfs_size as _);
        self.known_items[FW_CFG_INITRD_DATA as usize] = FwCfgContent::File(0, file.try_clone()?);
        Ok(())
    }

    fn read_content(content: &FwCfgContent, offset: u32, data: &mut [u8]) -> Result<()> {
        // Zero fill rather than the usual 0xff fill for QEMU compatibility
        data.fill(0);
        let start = offset as usize;
        let end = start + data.len();
        match content {
            FwCfgContent::Bytes(b) => {
                if end <= b.len() {
                    data.copy_from_slice(&b[start..end]);
                }
            }
            FwCfgContent::Slice(s) => {
                if end <= s.len() {
                    data.copy_from_slice(&s[start..end]);
                }
            }
            FwCfgContent::File(o, f) => {
                f.read_exact_at(data, o + offset as u64)?;
            }
            FwCfgContent::U32(n) => {
                let bytes = n.to_le_bytes();
                if end <= bytes.len() {
                    data.copy_from_slice(&bytes[start..end]);
                }
            }
        }
        Ok(())
    }

    fn read_data(&mut self, data: &mut [u8]) {
        if let Ok(content) = self.get_selected_content()
            && Self::read_content(content, self.data_offset, data).is_ok()
        {
            self.data_offset += data.len() as u32;
        }
    }
}

impl Snapshottable for FwCfg {
    fn id(&self) -> String {
        FW_CFG_SNAPSHOT_ID.to_string()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        Snapshot::new_from_state(&FwCfgState {
            selector: self.selector,
            data_offset: self.data_offset,
            dma_address: self.dma_address,
        })
    }
}

impl Pausable for FwCfg {}
impl Transportable for FwCfg {}
impl Migratable for FwCfg {}

impl Aml for FwCfg {
    fn to_aml_bytes(&self, sink: &mut dyn AmlSink) {
        aml::Device::new(
            "_SB_.FWCF".into(),
            vec![
                &aml::Name::new("_HID".into(), &FW_CFG_ACPI_ID.to_string()),
                &aml::Name::new("_STA".into(), &0xB_usize),
                #[cfg(target_arch = "aarch64")]
                &aml::Name::new("_CCA".into(), &aml::ONE),
                &aml::Name::new(
                    "_CRS".into(),
                    &aml::ResourceTemplate::new(vec![
                        #[cfg(target_arch = "x86_64")]
                        &aml::IO::new(
                            FW_CFG_ADDRESS_BASE as u16,
                            FW_CFG_ADDRESS_BASE as u16,
                            0x01,
                            FW_CFG_ADDRESS_WIDTH as u8,
                        ),
                        #[cfg(target_arch = "aarch64")]
                        &aml::Memory32Fixed::new(
                            true,
                            FW_CFG_ADDRESS_BASE as u32,
                            FW_CFG_ADDRESS_WIDTH as u32,
                        ),
                    ]),
                ),
            ],
        )
        .to_aml_bytes(sink);
    }
}

impl BusDevice for FwCfg {
    fn read(&mut self, _base: u64, offset: u64, data: &mut [u8]) {
        match (offset, data.len()) {
            (FW_CFG_SELECTOR_OFFSET, _) => {
                error!("fw_cfg: selector register is write-only.");
            }
            (FW_CFG_DATA_OFFSET, _) => self.read_data(data),
            (FW_CFG_DMA_HI_OFFSET, 4) => {
                let addr = self.dma_address;
                let addr_hi = (addr >> 32) as u32;
                data.copy_from_slice(&addr_hi.to_be_bytes());
            }
            (FW_CFG_DMA_LO_OFFSET, 4) => {
                let addr = self.dma_address;
                let addr_lo = (addr & 0xffff_ffff) as u32;
                data.copy_from_slice(&addr_lo.to_be_bytes());
            }
            _ => {
                debug!(
                    "fw_cfg: read from unknown offset {offset:#x}: {:#x} bytes.",
                    data.len()
                );
            }
        }
    }

    fn write(&mut self, _base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        let size = data.size();
        match (offset, size) {
            (FW_CFG_SELECTOR_OFFSET, 2) => {
                let mut buf = [0u8; 2];
                buf[..size].copy_from_slice(&data[..size]);
                #[cfg(target_arch = "x86_64")]
                let val = u16::from_le_bytes(buf);
                #[cfg(target_arch = "aarch64")]
                let val = u16::from_be_bytes(buf);
                self.selector = val;
                self.data_offset = 0;
            }
            (FW_CFG_DATA_OFFSET, 1) => error!("fw_cfg: data register is read-only."),
            #[cfg(target_arch = "aarch64")]
            (FW_CFG_DMA_HI_OFFSET, 8) => {
                let mut buf = [0u8; 8];
                buf.copy_from_slice(data);
                self.dma_address = u64::from_be_bytes(buf);
                self.do_dma();
            }
            (FW_CFG_DMA_HI_OFFSET, 4) => {
                let mut buf = [0u8; 4];
                buf[..size].copy_from_slice(&data[..size]);
                let val = u32::from_be_bytes(buf);
                self.dma_address &= 0xffff_ffff;
                self.dma_address |= (val as u64) << 32;
            }
            (FW_CFG_DMA_LO_OFFSET, 4) => {
                let mut buf = [0u8; 4];
                buf[..size].copy_from_slice(&data[..size]);
                let val = u32::from_be_bytes(buf);
                self.dma_address &= !0xffff_ffff;
                self.dma_address |= val as u64;
                self.do_dma();
            }
            _ => debug!("fw_cfg: write to unknown offset {offset:#x}: {size:#x} bytes."),
        }
        None
    }
}

#[cfg(test)]
mod tests {
    use std::ffi::CString;
    use std::io::Write;

    use vmm_sys_util::tempfile::TempFile;

    use super::*;

    /// Selects `key` with the correct byte order
    fn select(fw_cfg: &mut FwCfg, key: u16) {
        #[cfg(target_arch = "x86_64")] // port IO -> little endian
        let key = key.to_le_bytes();
        #[cfg(target_arch = "aarch64")] // MMIO -> big endian
        let key = key.to_be_bytes();
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &key);
    }

    #[test]
    fn restore_continues_selected_file_and_partial_dma_address() {
        let memory =
            GuestMemoryAtomic::new(GuestMemory::from_ranges(&[(GuestAddress(0), 0x1000)]).unwrap());
        let file = TempFile::new().unwrap();
        file.as_file().write_all(b"abcdef").unwrap();
        let mut fw_cfg = FwCfg::new(memory.clone(), None);
        fw_cfg
            .add_item(FwCfgItem {
                name: "test".into(),
                content: FwCfgContent::File(1, file.as_file().try_clone().unwrap()),
            })
            .unwrap();
        select(&mut fw_cfg, FW_CFG_FILE_FIRST);
        let mut data = [0; 2];
        fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
        assert_eq!(&data, b"bc");
        fw_cfg.write(0, FW_CFG_DMA_HI_OFFSET, &0x1234u32.to_be_bytes());

        let state = fw_cfg.snapshot().unwrap().to_state().unwrap();
        let mut restored = FwCfg::new(memory, Some(state));
        restored
            .add_item(FwCfgItem {
                name: "test".into(),
                content: FwCfgContent::File(1, file.as_file().try_clone().unwrap()),
            })
            .unwrap();
        restored.read(0, FW_CFG_DATA_OFFSET, &mut data);
        assert_eq!(&data, b"de");
        let mut address = [0; 4];
        restored.read(0, FW_CFG_DMA_HI_OFFSET, &mut address);
        assert_eq!(u32::from_be_bytes(address), 0x1234);
        select(&mut restored, FW_CFG_SIGNATURE);
        let mut signature = [0; 4];
        restored.read(0, FW_CFG_DATA_OFFSET, &mut signature);
        assert_eq!(&signature, b"QEMU");
    }

    #[test]
    #[cfg(target_arch = "x86_64")]
    fn test_stage0_reserved_only_for_sev_snp() {
        for sev_snp in [false, true] {
            let gm = GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap();
            let mut fw_cfg = FwCfg::new(GuestMemoryAtomic::new(gm.clone()), None);
            fw_cfg.add_e820(&gm, sev_snp).unwrap();

            let FwCfgContent::Bytes(bytes) = &fw_cfg.items[0].content else {
                panic!("Expected an E820 file");
            };
            let has_stage0 = bytes
                .as_chunks::<{ size_of::<BootE820Entry>() }>()
                .0
                .iter()
                .any(|entry| {
                    u64::from_le_bytes(entry[0..8].try_into().unwrap()) == STAGE0_START_ADDRESS.0
                        && u64::from_le_bytes(entry[8..16].try_into().unwrap())
                            == STAGE0_SIZE as u64
                });
            assert_eq!(has_stage0, sev_snp);
        }
    }

    #[test]
    #[cfg(target_arch = "x86_64")]
    fn test_e820_matches_boot_map_and_reserves_stage0_only_for_sev_snp() {
        let gm = GuestMemory::from_ranges(&[
            (GuestAddress(0), 2 << 20),
            (GuestAddress(1 << 32), 2 << 20),
        ])
        .unwrap();
        let boot_entries = arch::x86_64::generate_e820_memory_map(&gm).unwrap();

        for sev_snp in [false, true] {
            let mut fw_cfg = FwCfg::new(GuestMemoryAtomic::new(gm.clone()), None);
            // Noncontiguous boot RAM must be represented without inferring
            // its layout from the configured total memory size.
            fw_cfg.add_e820(&gm, sev_snp).unwrap();

            let FwCfgContent::Bytes(bytes) = &fw_cfg
                .items
                .iter()
                .find(|item| item.name == "etc/e820")
                .unwrap()
                .content
            else {
                panic!("Expected an e820 file");
            };
            let entries: Vec<_> = bytes
                .as_chunks::<{ size_of::<BootE820Entry>() }>()
                .0
                .iter()
                .map(|entry| {
                    (
                        u64::from_le_bytes(entry[0..8].try_into().unwrap()),
                        u64::from_le_bytes(entry[8..16].try_into().unwrap()),
                        u32::from_le_bytes(entry[16..20].try_into().unwrap()),
                    )
                })
                .collect();

            let mut expected = boot_entries.clone();
            if sev_snp {
                expected.push((STAGE0_START_ADDRESS.0, STAGE0_SIZE as u64, E820_RESERVED));
                expected.sort_unstable_by_key(|entry| entry.0);
            }
            assert_eq!(entries, expected);
        }
    }

    #[test]
    fn test_signature() {
        let gm = GuestMemoryAtomic::new(
            GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap(),
        );

        let mut fw_cfg = FwCfg::new(gm, None);

        let mut data = vec![0u8];

        let mut sig_iter = FW_CFG_SIGNATURE_CONTENT.into_iter();
        select(&mut fw_cfg, FW_CFG_SIGNATURE);
        loop {
            if let Some(char) = sig_iter.next() {
                fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
                assert_eq!(data[0], char);
            } else {
                return;
            }
        }
    }

    #[test]
    fn test_kernel_cmdline() {
        let gm = GuestMemoryAtomic::new(
            GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap(),
        );

        let mut fw_cfg = FwCfg::new(gm, None);

        let cmdline = *b"cmdline\0";

        fw_cfg.add_kernel_cmdline(CString::from_vec_with_nul(cmdline.to_vec()).unwrap());

        let mut data = vec![0u8];

        let mut cmdline_iter = cmdline.into_iter();
        select(&mut fw_cfg, FW_CFG_CMDLINE_DATA);
        loop {
            if let Some(char) = cmdline_iter.next() {
                fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
                assert_eq!(data[0], char);
            } else {
                return;
            }
        }
    }

    #[test]
    #[cfg(target_arch = "aarch64")]
    fn test_kernel_data() {
        let gm = GuestMemoryAtomic::new(
            GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap(),
        );
        let mut fw_cfg = FwCfg::new(gm, None);
        let kernel = b"test kernel image";
        let temp = TempFile::new().unwrap();
        temp.as_file().write_all(kernel).unwrap();

        fw_cfg.add_kernel_data(temp.as_file()).unwrap();

        let mut size = [0u8; size_of::<u32>()];
        select(&mut fw_cfg, FW_CFG_KERNEL_SIZE);
        fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut size);
        assert_eq!(u32::from_le_bytes(size), kernel.len() as u32);

        let mut data = vec![0u8; kernel.len()];
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &FW_CFG_KERNEL_DATA.to_be_bytes());
        fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
        assert_eq!(data, kernel);
    }

    #[test]
    fn test_initram_fs() {
        let gm = GuestMemoryAtomic::new(
            GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap(),
        );

        let mut fw_cfg = FwCfg::new(gm, None);

        let temp = TempFile::new().unwrap();
        let mut temp_file = temp.as_file();

        let initram_content = b"this is the initramfs";
        let written = temp_file.write(initram_content);
        assert_eq!(written.unwrap(), 21);
        let _ = fw_cfg.add_initramfs_data(temp_file);

        let mut data = vec![0u8];

        let mut initram_iter = (*initram_content).into_iter();
        select(&mut fw_cfg, FW_CFG_INITRD_DATA);
        loop {
            if let Some(char) = initram_iter.next() {
                fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
                assert_eq!(data[0], char);
            } else {
                return;
            }
        }
    }

    #[test]
    fn test_string_item() {
        let gm = GuestMemoryAtomic::new(
            GuestMemory::from_ranges(&[(GuestAddress(0), 2 << 20)]).unwrap(),
        );

        let mut fw_cfg = FwCfg::new(gm, None);

        // Simulate OVMF X-PciMmio64Mb string item for GPU CC passthrough
        let item = FwCfgItem {
            name: "opt/ovmf/X-PciMmio64Mb".to_owned(),
            content: FwCfgContent::Bytes("262144".as_bytes().to_vec()),
        };
        fw_cfg.add_item(item).unwrap();

        let expected = b"262144";
        let mut data = vec![0u8];

        // Select the first file item (FW_CFG_FILE_FIRST = 0x20)
        select(&mut fw_cfg, FW_CFG_FILE_FIRST);
        for &byte in expected.iter() {
            fw_cfg.read(0, FW_CFG_DATA_OFFSET, &mut data);
            assert_eq!(data[0], byte);
        }
    }

    #[test]
    fn test_dma() {
        let code = [
            0xba, 0xf8, 0x03, 0x00, 0xd8, 0x04, b'0', 0xee, 0xb0, b'\n', 0xee, 0xf4,
        ];

        let content = FwCfgContent::Bytes(code.to_vec());

        let mem_size = 0x1000;
        let load_addr = GuestAddress(0x1000);
        let mem: GuestMemory = GuestMemory::from_ranges(&[(load_addr, mem_size)]).unwrap();

        // Note: In firmware we would just allocate FwCfgDmaAccess struct
        // and use address of struct (&) as dma address
        let mut access_control = AccessControl(0);
        // bit 1 = read access
        access_control.set_read(true);
        // length of data to access
        let length_be = (code.len() as u32).to_be();
        // guest address for data
        let code_address = 0x1900_u64;
        let address_be = code_address.to_be();
        let mut access = FwCfgDmaAccess {
            control_be: access_control.0.to_be(), // bit(1) = read bit
            length_be,
            address_be,
        };
        // access address is where to put the code
        let access_address = GuestAddress(load_addr.0);
        let address_bytes = access_address.0.to_be_bytes();
        #[cfg(target_arch = "x86_64")]
        // Note: address is big endian.
        let dma_hi: [u8; 4] = address_bytes[0..4].try_into().unwrap();
        #[cfg(target_arch = "x86_64")]
        let dma_lo: [u8; 4] = address_bytes[4..8].try_into().unwrap();

        // writing the FwCfgDmaAccess to mem (this would just be self.dma_access.as_ref() in guest)
        let _ = mem.write(access.as_mut_bytes(), access_address);
        let mem_m = GuestMemoryAtomic::new(mem.clone());
        let mut fw_cfg = FwCfg::new(mem_m, None);
        let cfg_item = FwCfgItem {
            name: "code".to_string(),
            content,
        };
        let _ = fw_cfg.add_item(cfg_item);

        let mut data = [0u8; 12];

        let _ = mem.read(&mut data, GuestAddress(code_address));
        assert_ne!(data, code);

        #[cfg(target_arch = "aarch64")]
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &FW_CFG_FILE_FIRST.to_be_bytes());
        #[cfg(target_arch = "x86_64")]
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &[FW_CFG_FILE_FIRST as u8, 0]);
        #[cfg(target_arch = "aarch64")]
        fw_cfg.write(0, FW_CFG_DMA_HI_OFFSET, &address_bytes);
        #[cfg(target_arch = "x86_64")]
        {
            fw_cfg.write(0, FW_CFG_DMA_HI_OFFSET, &dma_hi);
            fw_cfg.write(0, FW_CFG_DMA_LO_OFFSET, &dma_lo);
        }
        let _ = mem.read(&mut data, GuestAddress(code_address));
        assert_eq!(data, code);
    }

    #[test]
    fn test_dma_control_bits() {
        assert_eq!(AccessControl::new().with_error(true).0, 0x01);
        assert_eq!(AccessControl::new().with_read(true).0, 0x02);
        assert_eq!(AccessControl::new().with_skip(true).0, 0x04);
        assert_eq!(AccessControl::new().with_select(true).0, 0x08);
        assert_eq!(AccessControl::new().with_write(true).0, 0x10);
        assert_eq!(AccessControl::new().with_selector(0xabcd).0, 0xabcd_0000);
    }

    const DMA_DESCRIPTOR: GuestAddress = GuestAddress(0x1000);
    const DMA_BUFFER: GuestAddress = GuestAddress(0x1800);

    fn run_dma(fw_cfg: &mut FwCfg, mem: &GuestMemory, control: AccessControl, len: u32) -> u32 {
        let mut access = FwCfgDmaAccess {
            control_be: control.0.to_be(),
            length_be: len.to_be(),
            address_be: DMA_BUFFER.0.to_be(),
        };
        mem.write(access.as_mut_bytes(), DMA_DESCRIPTOR).unwrap();
        let address = DMA_DESCRIPTOR.0.to_be_bytes();
        #[cfg(target_arch = "aarch64")]
        fw_cfg.write(0, FW_CFG_DMA_HI_OFFSET, &address);
        #[cfg(target_arch = "x86_64")]
        {
            fw_cfg.write(0, FW_CFG_DMA_HI_OFFSET, &address[0..4]);
            fw_cfg.write(0, FW_CFG_DMA_LO_OFFSET, &address[4..8]);
        }
        let mut status = [0u8; 4];
        mem.read(&mut status, DMA_DESCRIPTOR).unwrap();
        u32::from_be_bytes(status)
    }

    fn dma_buffer(mem: &GuestMemory, len: usize) -> Vec<u8> {
        let mut data = vec![0u8; len];
        mem.read(&mut data, DMA_BUFFER).unwrap();
        data
    }

    #[test]
    fn test_dma_select_and_skip() {
        let mem: GuestMemory = GuestMemory::from_ranges(&[(DMA_DESCRIPTOR, 0x1000)]).unwrap();
        let mut fw_cfg = FwCfg::new(GuestMemoryAtomic::new(mem.clone()), None);
        let item_a = FW_CFG_FILE_FIRST;
        let item_b = FW_CFG_FILE_FIRST + 1;
        for (name, data) in [
            ("a", [1, 2, 3, 4, 5, 6, 7, 8]),
            ("b", [11, 12, 13, 14, 15, 16, 17, 18]),
        ] {
            let content = FwCfgContent::Bytes(data.to_vec());
            fw_cfg
                .add_item(FwCfgItem {
                    name: name.to_string(),
                    content,
                })
                .unwrap();
        }
        let select = |item| AccessControl::new().with_select(true).with_selector(item);
        let read = AccessControl::new().with_read(true);
        let skip = AccessControl::new().with_skip(true);
        let write = AccessControl::new().with_write(true);
        let error = AccessControl::new().with_error(true).0;

        #[cfg(target_arch = "aarch64")]
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &item_a.to_be_bytes());
        #[cfg(target_arch = "x86_64")]
        fw_cfg.write(0, FW_CFG_SELECTOR_OFFSET, &item_a.to_le_bytes());

        assert_eq!(
            run_dma(&mut fw_cfg, &mem, select(item_b).with_read(true), 4),
            0
        );
        assert_eq!(dma_buffer(&mem, 4), [11, 12, 13, 14]);

        assert_eq!(run_dma(&mut fw_cfg, &mem, skip, 2), 0);
        assert_eq!(run_dma(&mut fw_cfg, &mem, read, 2), 0);
        assert_eq!(dma_buffer(&mem, 2), [17, 18]);

        assert_eq!(
            run_dma(&mut fw_cfg, &mem, select(item_b).with_read(true), 2),
            0
        );
        assert_eq!(dma_buffer(&mem, 2), [11, 12]);

        assert_eq!(run_dma(&mut fw_cfg, &mem, skip, u32::MAX), 0);
        assert_eq!(fw_cfg.data_offset, 8);

        assert_eq!(run_dma(&mut fw_cfg, &mem, select(item_a), 0), 0);
        assert_eq!(run_dma(&mut fw_cfg, &mem, read, 3), 0);
        assert_eq!(dma_buffer(&mem, 3), [1, 2, 3]);

        assert_eq!(run_dma(&mut fw_cfg, &mem, write, 1), error);
    }

    #[test]
    fn test_dma_truncated_file() {
        let mem: GuestMemory = GuestMemory::from_ranges(&[(DMA_DESCRIPTOR, 0x1000)]).unwrap();
        let mut fw_cfg = FwCfg::new(GuestMemoryAtomic::new(mem.clone()), None);
        let temp = TempFile::new().unwrap();
        let file = temp.as_file();
        file.set_len(16).unwrap();
        let content = FwCfgContent::File(8, file.try_clone().unwrap());
        fw_cfg
            .add_item(FwCfgItem {
                name: "file".to_string(),
                content,
            })
            .unwrap();
        file.set_len(4).unwrap();

        let select = AccessControl::new()
            .with_select(true)
            .with_selector(FW_CFG_FILE_FIRST);
        let skip = select.with_skip(true);
        let read = select.with_read(true);
        let error = AccessControl::new().with_error(true).0;
        assert_eq!(run_dma(&mut fw_cfg, &mem, skip, 4), 0);
        assert_eq!(fw_cfg.data_offset, 0);
        assert_eq!(run_dma(&mut fw_cfg, &mem, read, 4), error);
    }

    #[test]
    fn test_dma_skip_after_truncation_keeps_offset() {
        let mem: GuestMemory = GuestMemory::from_ranges(&[(DMA_DESCRIPTOR, 0x1000)]).unwrap();
        let mut fw_cfg = FwCfg::new(GuestMemoryAtomic::new(mem.clone()), None);
        let temp = TempFile::new().unwrap();
        let file = temp.as_file();
        file.set_len(8).unwrap();
        let content = FwCfgContent::File(0, file.try_clone().unwrap());
        fw_cfg
            .add_item(FwCfgItem {
                name: "file".to_string(),
                content,
            })
            .unwrap();

        let select = AccessControl::new()
            .with_select(true)
            .with_selector(FW_CFG_FILE_FIRST);
        assert_eq!(run_dma(&mut fw_cfg, &mem, select.with_read(true), 6), 0);
        file.set_len(4).unwrap();
        let skip = AccessControl::new().with_skip(true);
        assert_eq!(run_dma(&mut fw_cfg, &mem, skip, 0), 0);
        assert_eq!(run_dma(&mut fw_cfg, &mem, skip, 2), 0);
        assert_eq!(fw_cfg.data_offset, 6);
    }
}
