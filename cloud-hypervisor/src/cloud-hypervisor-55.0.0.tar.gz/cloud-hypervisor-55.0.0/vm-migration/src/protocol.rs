// Copyright © 2020 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0
//

//! # Migration Protocol
//!
//! ## TCP Migration
//!
//! TCP is the normal transport for cross-host migration. It can also be used
//! between VMs on the same host for development and testing. Guest memory is
//! copied over the stream. Externally provided FDs must be opened and managed
//! by the management software on the destination side.
//!
//! The following sequence diagram shows precopy migration over a stream:
//!
//! <!-- Best viewed and edited here: https://mermaid.live/edit -->
//! ```mermaid
//! sequenceDiagram
//!    Source<<->>Destination: Establish connection
//!    Source->>Destination: Start
//!    Destination-->>Source: OK
//!    Source->>Destination: Config
//!      Note right of Destination: Payload: VM Config
//!    Destination-->>Source: OK
//!      Note right of Source: Start Dirty Logging
//!    loop Dirty Memory Ranges (until handover decision was made)
//!      Source->>Destination: Memory
//!        Note right of Destination: Payload: Memory Range Table
//!        Note right of Destination: Payload: Memory Content
//!      Destination-->>Source: OK
//!      Note right of Source: VM is paused after last OK
//!    end
//!    Source->>Destination: Memory
//!      Note right of Destination: Payload: Final Memory Range Table
//!      Note right of Destination: Payload: Final Memory Content
//!    Destination-->>Source: OK
//!    Source->>Destination: State
//!      Note right of Destination: Final VM State (vCPU, devices)
//!    Destination-->>Source: OK
//!    Source->>Destination: Complete
//!    Destination-->>Source: OK
//! ```
//!
//! ## UNIX Domain Socket Migration
//!
//! UNIX domain sockets connect two Cloud Hypervisor instances on the same
//! host. They can transfer guest memory normally, as TCP does, or use
//! `memory_mode=memfds` to pass the guest memory backing FDs instead of
//! copying memory ("local migration").
//!
//! The following sequence diagram shows the MemFD mode:
//!
//! <!-- Best viewed and edited here: https://mermaid.live/edit -->
//! ```mermaid
//! sequenceDiagram
//!    Source<<->>Destination: Establish connection
//!    Source->>Destination: Start
//!    Destination-->>Source: OK
//!    loop For each Memory FD
//!      Source->>Destination: Memory FD (1/n)
//!        Note right of Destination: Payload: (slot: u32, fd: u32)
//!      Destination-->>Source: OK
//!    end
//!    Source->>Destination: Config
//!      Note right of Destination: Payload: VM Config
//!    Destination-->>Source: OK
//!      Note right of Source: VM is paused
//!    Source->>Destination: State
//!      Note right of Destination: Payload: Final VM State (vCPU, devices)
//!    Destination-->>Source: OK
//!    Source->>Destination: Complete
//!    Destination-->>Source: OK
//! ```
//!
//! ## Protocol Versioning
//!
//! The migration protocol versions the mechanism used to transport VM state
//! from source to destination. It does not version VMM or device model state.
//! The protocol version is an internal implementation detail.
//!
//! ### Version Negotiation
//!
//! [`Start`][start-command] carries the sender's protocol version, which is the
//! current protocol version of that Cloud Hypervisor release. The destination
//! validates the version and, if supported, receives the migration accordingly.
//!
//! ### Compatibility
//!
//! Each Cloud Hypervisor release must support all protocol versions required by
//! the guaranteed migration compatibility window (see the public live-migration
//! documentation).
//!
//! The protocol version must be bumped for breaking protocol changes, but not
//! for additive ones.
//!
//! [start-command]: [`Command::Start`]

use std::cmp::max;
use std::io::{Read, Write};
use std::iter;
use std::ops::RangeInclusive;

use anyhow::anyhow;
use log::error;
use serde::{Deserialize, Serialize};
use zerocopy::{FromBytes, Immutable, IntoBytes, TryFromBytes};

use crate::MigratableError;
use crate::bitpos_iterator::BitposIteratorExt;

/// The commands of the [live-migration protocol].
///
/// ### Sender State Machine
///
/// TODO refactor sender into state machine and add diagram
///
/// ### Receiver State Machine
///
/// <!-- Best viewed and edited here: https://mermaid.live/edit -->
/// ```mermaid
/// stateDiagram-v2
///     direction TB
///     [*] --> Started: Start
///     Started --> MemoryFdsReceived: MemoryFd
///     MemoryFdsReceived --> MemoryFdsReceived: MemoryFd
///     Started --> Configured: Config
///     MemoryFdsReceived --> Configured: Config
///     Configured --> Configured: Memory
///     Configured --> StateReceived: State
///     StateReceived --> Completed: Complete
///     StateReceived --> Completed: CompletePaused
///     Completed --> Completed: PageFault
/// ```
///
/// [live-migration protocol]: super::protocol
#[repr(u16)]
#[derive(Debug, Copy, Clone, Default, PartialEq, Eq, TryFromBytes, IntoBytes, Immutable)]
pub enum Command {
    #[default]
    Invalid = 0,
    Start = 1,
    Config = 2,
    State = 3,
    Memory = 4,
    /// Finalizes the migration and resumes the VM on the destination.
    /// Sent when the source VM was running at migration time.
    Complete = 5,
    MemoryFd = 7,
    /// Finalizes the migration without resuming the VM on the destination.
    /// Sent when the source VM was paused at migration time.
    CompletePaused = 8,
    /// Request a page to be faulted in. The page content can be sent
    /// through the response or simply written to the shared memory.
    PageFault = 9,
}

/// Role announced as the first message on an additional migration connection.
#[repr(u16)]
#[derive(Debug, Copy, Clone, Default, PartialEq, Eq)]
pub enum ConnectionRole {
    /// Invalid role. Reserves the zero value so a default/zeroed message
    /// carries no valid meaning on the wire.
    #[default]
    Invalid = 0,
    /// Dedicated connection carrying precopy memory chunks.
    PrecopyMemory = 1,
    /// Dedicated connection carrying page faults.
    Fault = 2,
}

impl ConnectionRole {
    pub fn write_to(self, fd: &mut dyn Write) -> Result<(), MigratableError> {
        fd.write_all(&(self as u16).to_le_bytes())
            .map_err(MigratableError::MigrateSocket)
    }

    pub fn read_from(fd: &mut dyn Read) -> Result<ConnectionRole, MigratableError> {
        let mut buf = [0u8; 2];
        fd.read_exact(&mut buf)
            .map_err(MigratableError::MigrateSocket)?;
        ConnectionRole::try_from(u16::from_le_bytes(buf))
    }
}

impl TryFrom<u16> for ConnectionRole {
    type Error = MigratableError;

    fn try_from(value: u16) -> Result<Self, Self::Error> {
        match value {
            0 => Ok(ConnectionRole::Invalid),
            1 => Ok(ConnectionRole::PrecopyMemory),
            2 => Ok(ConnectionRole::Fault),
            _ => Err(MigratableError::MigrateReceive(anyhow!(
                "unknown connection role: {value}"
            ))),
        }
    }
}

/// Newest migration protocol version sent by this implementation.
pub const CURRENT_PROTOCOL_VERSION: u16 = 0;

/// Returns the current migration protocol version and the previous version, if any.
fn supported_protocol_versions() -> RangeInclusive<u16> {
    CURRENT_PROTOCOL_VERSION.saturating_sub(1)..=CURRENT_PROTOCOL_VERSION
}

#[repr(C)]
#[derive(Default, Copy, Clone, TryFromBytes, IntoBytes, Immutable)]
pub struct Request {
    command: Command,
    command_headers: [u8; 6],
    /// Length of payload for command excluding the Request struct
    length: u64,
}

impl Request {
    fn encode_sender_version(version: u16) -> [u8; 6] {
        let mut command_headers = [0; 6];
        command_headers[..size_of::<u16>()].copy_from_slice(&version.to_le_bytes());
        command_headers
    }

    pub fn new(command: Command, length: u64) -> Self {
        Self {
            command,
            length,
            ..Default::default()
        }
    }

    pub fn start() -> Self {
        Self {
            command: Command::Start,
            command_headers: Self::encode_sender_version(CURRENT_PROTOCOL_VERSION),
            length: 0,
        }
    }

    pub fn state(length: u64) -> Self {
        Self::new(Command::State, length)
    }

    pub fn config(length: u64) -> Self {
        Self::new(Command::Config, length)
    }

    pub fn memory(length: u64) -> Self {
        Self::new(Command::Memory, length)
    }

    pub fn memory_fd(length: u64) -> Self {
        Self::new(Command::MemoryFd, length)
    }

    /// Finalizes the migration and resumes the VM on the destination.
    pub fn complete() -> Self {
        Self::new(Command::Complete, 0)
    }

    /// Finalizes the migration without resuming the VM on the destination.
    pub fn complete_paused() -> Self {
        Self::new(Command::CompletePaused, 0)
    }

    /// PageFault request always carries a single `MemoryRange`.
    pub fn page_fault() -> Self {
        Self::new(Command::PageFault, size_of::<MemoryRange>() as u64)
    }

    pub fn command(&self) -> Command {
        self.command
    }

    pub fn length(&self) -> u64 {
        self.length
    }

    pub fn command_headers(&self) -> &[u8; 6] {
        &self.command_headers
    }

    /// Returns the sender protocol version from a `Start` request if it is supported.
    pub fn sender_protocol_version(&self) -> Result<u16, MigratableError> {
        assert_eq!(
            self.command(),
            Command::Start,
            "sender_protocol_version() must only be called for Start requests",
        );

        // The protocol version is stored in the first two header bytes, the remaining bytes are ignored.
        let sender_version = u16::from_le_bytes([self.command_headers[0], self.command_headers[1]]);
        if !supported_protocol_versions().any(|version| version == sender_version) {
            let supported_versions = supported_protocol_versions()
                .map(|version| version.to_string())
                .collect::<Vec<_>>()
                .join(", ");
            return Err(MigratableError::MigrateReceive(anyhow!(
                "Migration protocol version {sender_version} of sender doesn't match any supported version: {supported_versions}"
            )));
        }

        Ok(sender_version)
    }

    pub fn read_from(fd: &mut dyn Read) -> Result<Request, MigratableError> {
        let mut buf = [0u8; size_of::<Request>()];
        fd.read_exact(&mut buf)
            .map_err(MigratableError::MigrateSocket)?;

        Request::try_read_from_bytes(&buf).map_err(|_| {
            MigratableError::MigrateReceive(anyhow!("received request with unknown command"))
        })
    }

    pub fn write_to(&self, fd: &mut dyn Write) -> Result<(), MigratableError> {
        fd.write_all(self.as_bytes())
            .map_err(MigratableError::MigrateSocket)
    }
}

#[repr(u16)]
#[derive(Copy, Clone, Debug, PartialEq, Eq, Default, TryFromBytes, IntoBytes, Immutable)]
pub enum Status {
    #[default]
    Invalid,
    Ok,
    Error,
}

#[repr(C)]
#[derive(Default, Copy, Clone, TryFromBytes, IntoBytes, Immutable)]
pub struct Response {
    status: Status,
    padding: [u8; 6],
    length: u64, // Length of payload for command excluding the Response struct
}

impl Response {
    pub fn new(status: Status, length: u64) -> Self {
        Self {
            status,
            length,
            ..Default::default()
        }
    }

    pub fn ok() -> Self {
        Self::new(Status::Ok, 0)
    }

    pub fn error() -> Self {
        Self::new(Status::Error, 0)
    }

    pub fn status(&self) -> Status {
        self.status
    }

    pub fn length(&self) -> u64 {
        self.length
    }

    pub fn read_from(fd: &mut dyn Read) -> Result<Response, MigratableError> {
        let mut buf = [0u8; size_of::<Response>()];
        fd.read_exact(&mut buf)
            .map_err(MigratableError::MigrateSocket)?;

        Response::try_read_from_bytes(&buf).map_err(|_| {
            MigratableError::MigrateReceive(anyhow!("received response with unknown status"))
        })
    }

    /// Return the response if its status is `Ok`.
    ///
    /// Otherwise, returns an error and logs that the receiving VMM responded
    /// with an error, which aborts the migration.
    pub fn ok_or_fatal_error(
        self,
        sender_error: MigratableError,
    ) -> Result<Response, MigratableError> {
        if self.status != Status::Ok {
            error!("Receiver reported error: aborting migration");
            // `sender_error` identifies the sender-side operation that was in
            // progress when the receiver reported failure; the receiver's
            // actual error is unknown to the sender VMM.
            return Err(sender_error);
        }
        Ok(self)
    }

    pub fn write_to(&self, fd: &mut dyn Write) -> Result<(), MigratableError> {
        fd.write_all(self.as_bytes())
            .map_err(MigratableError::MigrateSocket)
    }
}

#[repr(C)]
#[derive(
    Copy,
    Clone,
    Default,
    Debug,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    FromBytes,
    IntoBytes,
    Immutable,
)]
pub struct MemoryRange {
    pub gpa: u64,
    pub length: u64,
}

impl MemoryRange {
    pub fn read_from(fd: &mut dyn Read) -> Result<MemoryRange, MigratableError> {
        let mut range = MemoryRange::default();
        fd.read_exact(range.as_mut_bytes())
            .map_err(MigratableError::MigrateSocket)?;
        Ok(range)
    }

    pub fn write_to(&self, fd: &mut dyn Write) -> Result<(), MigratableError> {
        fd.write_all(self.as_bytes())
            .map_err(MigratableError::MigrateSocket)
    }
}

/// A set of guest-memory ranges to transfer as one migration payload.
#[derive(Clone, Default, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MemoryRangeTable {
    data: Vec<MemoryRange>,
}

impl MemoryRangeTable {
    /// Partitions the table into chunks of at most `chunk_size` bytes.
    pub fn partition(self, chunk_size: u64) -> impl Iterator<Item = MemoryRangeTable> {
        MemoryRangeTableIterator::new(self, chunk_size)
    }

    /// Converts an iterator over a dirty bitmap into an iterator of dirty
    /// [`MemoryRange`]s, merging consecutive dirty pages into contiguous ranges.
    ///
    /// A memory page (i.e., a range) is marked dirty when its corresponding bit
    /// is set.
    fn dirty_ranges_iter(
        bitmap: impl IntoIterator<Item = u64>,
        start_addr: u64,
        page_size: u64,
    ) -> impl Iterator<Item = MemoryRange> {
        let mut pages = bitmap.into_iter().bit_positions().peekable();
        iter::from_fn(move || {
            let first = pages.next()?;
            // Merge adjacent dirty pages.
            let mut end = first + 1;
            while pages.next_if_eq(&end).is_some() {
                end += 1;
            }
            Some(MemoryRange {
                gpa: start_addr + first * page_size,
                length: (end - first) * page_size,
            })
        })
    }

    /// Creates a new [`MemoryRangeTable`] from a bitmap (represented as
    /// multiple `u64`) where each bit corresponds to a dirty memory page.
    ///
    /// Only dirty ranges are represented in the resulting bitmap.
    pub fn from_dirty_bitmap(
        bitmap: impl IntoIterator<Item = u64>,
        start_addr: u64,
        page_size: u64,
    ) -> Self {
        let mut table = Self::default();
        table.extend_from_dirty_bitmap(bitmap, start_addr, page_size);
        table
    }

    /// Appends the dirty ranges of the given bitmap.
    pub fn extend_from_dirty_bitmap(
        &mut self,
        bitmap: impl IntoIterator<Item = u64>,
        start_addr: u64,
        page_size: u64,
    ) {
        self.data
            .extend(Self::dirty_ranges_iter(bitmap, start_addr, page_size));
    }

    pub fn ranges(&self) -> &[MemoryRange] {
        &self.data
    }

    /// Sorts the ranges by guest address.
    pub fn sort(&mut self) {
        self.data.sort_unstable_by_key(|range| range.gpa);
    }

    pub fn push(&mut self, range: MemoryRange) {
        self.data.push(range);
    }

    pub fn read_from(fd: &mut dyn Read, length: u64) -> Result<MemoryRangeTable, MigratableError> {
        if !(length as usize).is_multiple_of(size_of::<MemoryRange>()) {
            return Err(MigratableError::MigrateReceive(anyhow!(
                "Memory range table size {length} must be a multiple of MemoryRange size {}",
                size_of::<MemoryRange>()
            )));
        }

        let mut data: Vec<MemoryRange> =
            vec![MemoryRange::default(); length as usize / size_of::<MemoryRange>()];

        fd.read_exact(data.as_mut_bytes())
            .map_err(MigratableError::MigrateSocket)?;

        Ok(Self { data })
    }

    pub fn length(&self) -> u64 {
        (size_of::<MemoryRange>() * self.data.len()) as u64
    }

    pub fn as_bytes(&self) -> &[u8] {
        self.data.as_bytes()
    }

    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }

    pub fn extend(&mut self, table: Self) {
        self.data.extend(table.data);
    }

    /// Merges `self` and `other` and combines adjacent and overlapping ranges
    /// into a continuous and sorted table.
    #[must_use]
    pub fn merge(mut self, other: Self) -> Self {
        self.data.extend(other.data);
        // Faster than sort_unstable() as both ranges are mostly sorted already.
        self.data.sort_by_key(|range| range.gpa);
        self.data.dedup_by(|curr, prev| {
            if curr.gpa <= prev.gpa + prev.length {
                let end = max(prev.gpa + prev.length, curr.gpa + curr.length);
                prev.length = end - prev.gpa;
                true
            } else {
                false
            }
        });
        self
    }

    /// Returns the effective size in bytes.
    pub fn effective_size(&self) -> u64 {
        self.data.iter().map(|r| r.length).sum()
    }
}

#[cfg(test)]
impl<const N: usize> From<&[(u64, u64); N]> for MemoryRangeTable {
    fn from(pairs: &[(u64, u64); N]) -> Self {
        let pairs: &[(u64, u64)] = &pairs[..];
        MemoryRangeTable {
            data: pairs
                .iter()
                .map(|&(gpa, length)| MemoryRange { gpa, length })
                .collect(),
        }
    }
}

/// Iterator returned by [`MemoryRangeTable::partition`].
///
/// Each item contains at most `chunk_size` bytes. A range may be split across
/// multiple items.
///
/// The iterator may reorder ranges for efficiency, so callers must not rely on
/// the order in which chunks or ranges are yielded.
#[derive(Clone, Default, Debug)]
struct MemoryRangeTableIterator {
    chunk_size: u64,
    data: Vec<MemoryRange>,
}

impl MemoryRangeTableIterator {
    /// Create an iterator that partitions `table` into chunks of at most
    /// `chunk_size` bytes.
    pub(crate) fn new(table: MemoryRangeTable, chunk_size: u64) -> Self {
        MemoryRangeTableIterator {
            chunk_size,
            data: table.data,
        }
    }
}

impl Iterator for MemoryRangeTableIterator {
    type Item = MemoryRangeTable;

    /// Return the next memory range in the table, making sure that
    /// the returned range is not larger than `chunk_size`.
    ///
    /// **Note**: Do not rely on the order of the ranges returned by this
    /// iterator. This allows for a more efficient implementation.
    fn next(&mut self) -> Option<Self::Item> {
        let mut ranges: Vec<MemoryRange> = vec![];
        let mut ranges_size: u64 = 0;

        loop {
            assert!(ranges_size <= self.chunk_size);

            if ranges_size == self.chunk_size || self.data.is_empty() {
                break;
            }

            if let Some(range) = self.data.pop() {
                let next_range: MemoryRange = if ranges_size + range.length > self.chunk_size {
                    // How many bytes we need to put back into the table.
                    let leftover_bytes = ranges_size + range.length - self.chunk_size;
                    assert!(leftover_bytes <= range.length);
                    let returned_bytes = range.length - leftover_bytes;
                    assert!(returned_bytes <= range.length);
                    assert_eq!(leftover_bytes + returned_bytes, range.length);

                    self.data.push(MemoryRange {
                        gpa: range.gpa,
                        length: leftover_bytes,
                    });
                    MemoryRange {
                        gpa: range.gpa + leftover_bytes,
                        length: returned_bytes,
                    }
                } else {
                    range
                };

                ranges_size += next_range.length;
                ranges.push(next_range);
            }
        }

        if ranges.is_empty() {
            None
        } else {
            Some(MemoryRangeTable { data: ranges })
        }
    }
}

#[cfg(test)]
mod tests {
    use std::io::Cursor;

    use crate::protocol::{
        CURRENT_PROTOCOL_VERSION, Command, ConnectionRole, MemoryRange, MemoryRangeTable, Request,
    };

    #[test]
    fn test_memory_range_table_incorrect_length() {
        let mut fd = Cursor::new(vec![0u8; 8]);
        MemoryRangeTable::read_from(&mut fd, 7).unwrap_err();

        let bytes = MemoryRangeTable::from(&[(0x1000u64, 0x2000u64)])
            .as_bytes()
            .to_vec();
        let len = bytes.len() as u64;
        let mut fd = Cursor::new(bytes);
        let table = MemoryRangeTable::read_from(&mut fd, len).unwrap();
        assert_eq!(table.as_bytes().len() as u64, len);
    }

    #[test]
    fn test_start_request_ignores_residual_command_headers_bytes() {
        let request = Request {
            command: Command::Start,
            command_headers: [1, 0, 0xaa, 0xbb, 0xcc, 0xdd],
            length: 0,
        };

        assert_eq!(
            u16::from_le_bytes([request.command_headers()[0], request.command_headers()[1]]),
            1
        );
    }

    #[test]
    fn test_sender_protocol_version_rejects_unsupported_version() {
        let request = Request {
            command: Command::Start,
            command_headers: [255, 0, 0, 0, 0, 0],
            length: 0,
        };

        const { assert!(CURRENT_PROTOCOL_VERSION < 255) };
        request.sender_protocol_version().unwrap_err();
    }

    #[test]
    fn test_page_fault_request_roundtrip() {
        let req = Request::page_fault();
        assert_eq!(req.command(), Command::PageFault);
        assert_eq!(req.length(), size_of::<MemoryRange>() as u64);

        let range = MemoryRange {
            gpa: 0x4000,
            length: 0x1000,
        };

        let mut buf = Vec::new();
        req.write_to(&mut buf).unwrap();
        range.write_to(&mut buf).unwrap();

        let mut cursor = Cursor::new(buf);
        let parsed_req = Request::read_from(&mut cursor).unwrap();
        assert_eq!(parsed_req.command(), Command::PageFault);
        assert_eq!(parsed_req.length(), size_of::<MemoryRange>() as u64);
        let parsed_range = MemoryRange::read_from(&mut cursor).unwrap();
        assert_eq!(parsed_range, range);
    }

    #[test]
    fn test_conn_role_roundtrip() {
        for role in [ConnectionRole::PrecopyMemory, ConnectionRole::Fault] {
            let mut buf = Vec::new();
            role.write_to(&mut buf).unwrap();
            assert_eq!(buf.len(), size_of::<u16>());

            let mut cursor = Cursor::new(buf);
            assert_eq!(ConnectionRole::read_from(&mut cursor).unwrap(), role);
        }
    }

    #[test]
    fn test_conn_role_unknown_value_is_rejected() {
        // An unknown on-the-wire role value must be rejected rather than
        // producing an out-of-range enum discriminant.
        let mut cursor = Cursor::new(99u16.to_le_bytes().to_vec());
        ConnectionRole::read_from(&mut cursor).unwrap_err();
    }

    #[test]
    fn test_memory_range_table_from_dirty_ranges_iter() {
        let input = [0b1111_1110_1110, 0b1_0000];

        let start_gpa = 0x10000;
        for page_size in [4096, 16384, 65536] {
            let range = MemoryRangeTable::from_dirty_bitmap(input, start_gpa, page_size);
            assert_eq!(
                range.ranges(),
                &[
                    MemoryRange {
                        gpa: start_gpa + page_size,
                        length: page_size * 3,
                    },
                    MemoryRange {
                        gpa: start_gpa + 5 * page_size,
                        length: page_size * 7,
                    },
                    MemoryRange {
                        gpa: start_gpa + (64 + 4) * page_size,
                        length: page_size,
                    }
                ]
            );
        }
    }

    #[test]
    fn test_memory_range_table_from_dirty_bitmap_edge_cases() {
        let page_size = 0x1000;
        let start_gpa = 0x10000;

        // Without dirty pages there must be no range, not even an empty one.
        assert!(MemoryRangeTable::from_dirty_bitmap([], start_gpa, page_size).is_empty());
        assert!(MemoryRangeTable::from_dirty_bitmap([0, 0], start_gpa, page_size).is_empty());

        // The run only ends with the bitmap, so the last range must still be
        // emitted, and as one range across the u64 boundary.
        let full = MemoryRangeTable::from_dirty_bitmap([u64::MAX, u64::MAX], start_gpa, page_size);
        assert_eq!(
            full.ranges(),
            &[MemoryRange {
                gpa: start_gpa,
                length: 128 * page_size,
            }]
        );
        // The last bit of the first u64 and the first bit of the second are
        // the adjacent pages 63 and 64, so they form one range.
        let straddling = MemoryRangeTable::from_dirty_bitmap([1 << 63, 1], start_gpa, page_size);
        assert_eq!(
            straddling.ranges(),
            &[MemoryRange {
                gpa: start_gpa + 63 * page_size,
                length: 2 * page_size,
            }]
        );
    }

    /// Appending multiple bitmaps must yield the same table as merging the
    /// tables of each bitmap.
    #[test]
    fn test_memory_range_table_extend_from_dirty_bitmap() {
        let page_size = 0x1000;
        let slots = [(0x1000, [0b1110u64]), (0x100000, [0b1_0001])];

        let mut appended = MemoryRangeTable::default();
        let mut merged = MemoryRangeTable::default();
        for (start_gpa, bitmap) in slots {
            appended.extend_from_dirty_bitmap(bitmap, start_gpa, page_size);
            merged.extend(MemoryRangeTable::from_dirty_bitmap(
                bitmap, start_gpa, page_size,
            ));
        }

        assert_eq!(
            appended.ranges(),
            &[
                MemoryRange {
                    gpa: 0x1000 + page_size,
                    length: page_size * 3,
                },
                MemoryRange {
                    gpa: 0x100000,
                    length: page_size,
                },
                MemoryRange {
                    gpa: 0x100000 + 4 * page_size,
                    length: page_size,
                },
            ]
        );
        assert_eq!(appended.ranges(), merged.ranges());
    }

    #[test]
    fn test_memory_range_table_partition() {
        // We start the test similar as the one above, but with a input that is simpler to parse for
        // developers.
        let input = [0b11_0011_0011_0011];

        let start_gpa = 0x1000;
        let page_size = 0x1000;

        let table = MemoryRangeTable::from_dirty_bitmap(input, start_gpa, page_size);
        let expected_regions = [
            MemoryRange {
                gpa: start_gpa,
                length: page_size * 2,
            },
            MemoryRange {
                gpa: start_gpa + 4 * page_size,
                length: page_size * 2,
            },
            MemoryRange {
                gpa: start_gpa + 8 * page_size,
                length: page_size * 2,
            },
            MemoryRange {
                gpa: start_gpa + 12 * page_size,
                length: page_size * 2,
            },
        ];
        assert_eq!(table.ranges(), &expected_regions);

        // In the first test, we expect to see the exact same result as above, as we use the length
        // of every region (which is fixed!).
        {
            let chunks = table
                .clone()
                .partition(page_size * 2)
                .map(|table| table.data)
                .collect::<Vec<_>>();

            // The implementation currently returns the ranges in reverse order.
            // For better testability, we reverse it.
            let chunks = chunks
                .into_iter()
                .map(|vec| vec.into_iter().rev().collect::<Vec<_>>())
                .rev()
                .collect::<Vec<_>>();

            assert_eq!(
                chunks,
                &[
                    [expected_regions[0]].to_vec(),
                    [expected_regions[1]].to_vec(),
                    [expected_regions[2]].to_vec(),
                    [expected_regions[3]].to_vec(),
                ]
            );
        }

        // Next, we have a more sophisticated test with a chunk size of 5 pages.
        {
            let chunks = table
                .clone()
                .partition(page_size * 5)
                .map(|table| table.data)
                .collect::<Vec<_>>();

            // The implementation currently returns the ranges in reverse order.
            // For better testability, we reverse it.
            let chunks = chunks
                .into_iter()
                .map(|vec| vec.into_iter().rev().collect::<Vec<_>>())
                .rev()
                .collect::<Vec<_>>();

            assert_eq!(
                chunks,
                &[
                    vec![
                        MemoryRange {
                            gpa: start_gpa,
                            length: 2 * page_size
                        },
                        MemoryRange {
                            gpa: start_gpa + 4 * page_size,
                            length: page_size
                        }
                    ],
                    vec![
                        MemoryRange {
                            gpa: start_gpa + 5 * page_size,
                            length: page_size
                        },
                        MemoryRange {
                            gpa: start_gpa + 8 * page_size,
                            length: 2 * page_size
                        },
                        MemoryRange {
                            gpa: start_gpa + 12 * page_size,
                            length: 2 * page_size
                        }
                    ]
                ]
            );
        }
    }

    #[test]
    fn test_merge() {
        let a = MemoryRangeTable::from(&[
            (0x1000_u64, 0x2000_u64),
            (0x8000, 0x1000),
            (0x0, 0x1000),
            (0x20000, 0x1000),
        ]);
        let b = MemoryRangeTable::from(&[
            (0x2000_u64, 0x2000_u64),
            (0x9000, 0x1000),
            (0x30000, 0x1000),
        ]);

        let merged = a.clone().merge(b.clone());

        assert_eq!(
            merged.ranges(),
            MemoryRangeTable::from(&[
                (0x0_u64, 0x4000_u64),
                (0x8000, 0x2000),
                (0x20000, 0x1000),
                (0x30000, 0x1000),
            ])
            .ranges()
        );
    }

    #[test]
    fn test_merge_empty_operands() {
        let empty = MemoryRangeTable::default();
        let t = MemoryRangeTable::from(&[(0x1000_u64, 0x1000_u64)]);

        assert!(empty.clone().merge(empty.clone()).is_empty());
        assert_eq!(t.clone().merge(empty.clone()).ranges(), t.ranges());
        assert_eq!(empty.merge(t.clone()).ranges(), t.ranges());
    }

    #[test]
    fn test_memory_range_table_partition_uneven_split() {
        // Three consecutive dirty pages produce one 3-page range, which lets
        // us test an uneven 1+2 page split while using the same helper as the
        // other partition tests above.
        let input = [0b111];
        let start_gpa = 0x1000;
        let page_size = 0x1000;

        let table = MemoryRangeTable::from_dirty_bitmap(input, start_gpa, page_size);

        let chunks = table
            .partition(page_size * 2)
            .map(|table| table.data)
            .collect::<Vec<_>>();

        // The implementation currently returns ranges in reverse order.
        let chunks = chunks.into_iter().rev().collect::<Vec<_>>();

        assert_eq!(
            chunks,
            &[
                vec![MemoryRange {
                    gpa: start_gpa,
                    length: page_size,
                }],
                vec![MemoryRange {
                    gpa: start_gpa + page_size,
                    length: page_size * 2,
                }],
            ]
        );
    }
}
