// Copyright 2019 Intel Corporation. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
//
// Portions Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the THIRD-PARTY file.

mod csm;
mod device;
mod packet;
mod unix;

use std::os::unix::io::RawFd;
use std::result;
use std::str::FromStr;

use packet::VsockPacket;
use thiserror::Error;

pub use self::device::Vsock;
pub use self::unix::{VsockUnixBackend, VsockUnixError};

mod defs {

    /// Max vsock packet data/buffer size.
    pub(super) const MAX_PKT_BUF_SIZE: usize = 64 * 1024;

    pub(super) mod uapi {

        /// Vsock packet operation IDs.
        /// Defined in `/include/uapi/linux/virtio_vsock.h`.
        ///
        /// Connection request.
        pub(crate) const VSOCK_OP_REQUEST: u16 = 1;
        /// Connection response.
        pub(crate) const VSOCK_OP_RESPONSE: u16 = 2;
        /// Connection reset.
        pub(crate) const VSOCK_OP_RST: u16 = 3;
        /// Connection clean shutdown.
        pub(crate) const VSOCK_OP_SHUTDOWN: u16 = 4;
        /// Connection data (read/write).
        pub(crate) const VSOCK_OP_RW: u16 = 5;
        /// Flow control credit update.
        pub(crate) const VSOCK_OP_CREDIT_UPDATE: u16 = 6;
        /// Flow control credit update request.
        pub(crate) const VSOCK_OP_CREDIT_REQUEST: u16 = 7;

        /// Vsock packet flags.
        /// Defined in `/include/uapi/linux/virtio_vsock.h`.
        ///
        /// Valid with a VSOCK_OP_SHUTDOWN packet: the packet sender will receive no more data.
        pub(crate) const VSOCK_FLAGS_SHUTDOWN_RCV: u32 = 1;
        /// Valid with a VSOCK_OP_SHUTDOWN packet: the packet sender will send no more data.
        pub(crate) const VSOCK_FLAGS_SHUTDOWN_SEND: u32 = 2;

        /// Vsock packet types.
        /// Defined in `/include/uapi/linux/virtio_vsock.h`.
        pub(crate) const VSOCK_TYPE_STREAM: u16 = 1;
        pub(crate) const VSOCK_TYPE_SEQPACKET: u16 = 2;
        pub(crate) const VIRTIO_VSOCK_F_SEQPACKET: u32 = 1;
        pub(crate) const VSOCK_FLAGS_SEQ_EOM: u32 = 1;

        pub(crate) const VSOCK_HOST_CID: u64 = 2;
    }
}

pub type ConnectionInfo = (
    u32, /* local port */
    u32, /* peer port */
    u16, /* socket type */
);

#[derive(
    Clone, Copy, Debug, Default, Eq, Hash, PartialEq, serde::Serialize, serde::Deserialize,
)]
pub enum SocketType {
    #[default]
    Stream,
    SeqPacket,
}

impl FromStr for SocketType {
    type Err = &'static str;
    fn from_str(value: &str) -> result::Result<Self, Self::Err> {
        match value {
            "stream" => Ok(Self::Stream),
            "seqpacket" => Ok(Self::SeqPacket),
            _ => Err("Socket type must be stream or seqpacket"),
        }
    }
}

impl From<SocketType> for u16 {
    fn from(socket_type: SocketType) -> Self {
        match socket_type {
            SocketType::Stream => defs::uapi::VSOCK_TYPE_STREAM,
            SocketType::SeqPacket => defs::uapi::VSOCK_TYPE_SEQPACKET,
        }
    }
}

impl TryFrom<u16> for SocketType {
    type Error = &'static str;

    fn try_from(socket_type: u16) -> result::Result<Self, Self::Error> {
        match socket_type {
            defs::uapi::VSOCK_TYPE_STREAM => Ok(Self::Stream),
            defs::uapi::VSOCK_TYPE_SEQPACKET => Ok(Self::SeqPacket),
            _ => Err("Unsupported vsock socket type"),
        }
    }
}

#[derive(Debug, Error)]
pub enum VsockError {
    /// The vsock data/buffer virtio descriptor length is smaller than expected.
    #[error("The vsock data/buffer virtio descriptor length is smaller than expected")]
    BufDescTooSmall,
    /// The vsock data/buffer virtio descriptor is expected, but missing.
    #[error("The vsock data/buffer virtio descriptor is expected, but missing")]
    BufDescMissing,
    /// Chained GuestMemory error.
    #[error("Guest memory error")]
    GuestMemory,
    /// Chained GuestMemory access error.
    #[error("Guest memory access error")]
    GuestMemoryAccess(#[source] vm_memory::GuestMemoryError),
    /// The vsock header descriptor length is too small.
    #[error("The vsock header descriptor length is too small: {0}")]
    HdrDescTooSmall(u32),
    /// The vsock header descriptor is expected, but missing.
    #[error("The vsock header descriptor is expected, but missing")]
    HdrDescMissing,
    /// The vsock header `len` field holds an invalid value.
    #[error("The vsock header len field holds an invalid value: {0}")]
    InvalidPktLen(u32),
    /// A data fetch was attempted when no data was available.
    #[error("A data fetch was attempted when no data was available")]
    NoData,
    /// A data buffer was expected for the provided packet, but it is missing.
    #[error("A data buffer was expected for the provided packet, but it is missing")]
    PktBufMissing,
    /// Encountered an unexpected write-only virtio descriptor.
    #[error("Encountered an unexpected write-only virtio descriptor")]
    UnreadableDescriptor,
    /// Encountered an unexpected read-only virtio descriptor.
    #[error("Encountered an unexpected read-only virtio descriptor")]
    UnwritableDescriptor,
}
type Result<T> = result::Result<T, VsockError>;

/// A passive, event-driven object, that needs to be notified whenever an epoll-able event occurs.
///
/// An event-polling control loop will use `get_polled_fd()` and `get_polled_evset()` to query
/// the listener for the file descriptor and the set of events it's interested in. When such an
/// event occurs, the control loop will route the event to the listener via `notify()`.
pub trait VsockEpollListener {
    /// Get the file descriptor the listener needs polled.
    fn get_polled_fd(&self) -> RawFd;

    /// Get the set of events for which the listener wants to be notified.
    fn get_polled_evset(&self) -> epoll::Events;

    /// Notify the listener that one or more events have occurred.
    fn notify(&mut self, evset: epoll::Events);
}

/// Trait to describe any channel that handles vsock packet traffic (sending and receiving packets)
///
/// Since we're implementing the device model here, our responsibility is to always process the sending of
/// packets (i.e. the TX queue). So, any locally generated data, addressed to the driver (e.g.
/// a connection response or RST), will have to be queued, until we get to processing the RX queue.
///
/// Note: `recv_pkt()` and `send_pkt()` are named analogous to `Read::read()` and `Write::write()`,
///       respectively. I.e.
///       - `recv_pkt(&mut pkt)` will read data from the channel, and place it into `pkt`; and
///       - `send_pkt(&pkt)` will fetch data from `pkt`, and place it into the channel.
pub trait VsockChannel {
    /// Read/receive an incoming packet from the channel.
    fn recv_pkt(&mut self, pkt: &mut VsockPacket) -> Result<()>;

    /// Write/send a packet through the channel.
    fn send_pkt(&mut self, pkt: &VsockPacket) -> Result<()>;

    /// Checks whether there is pending incoming data inside the channel, meaning that a subsequent
    /// call to `recv_pkt()` won't fail.
    fn has_pending_rx(&self) -> bool;
}

/// The vsock backend, which is basically an epoll-event-driven vsock channel
///
/// It that needs to be sendable through a mpsc channel (the latter due to how `vmm::EpollContext` works).
/// Currently, the only implementation we have is `crate::virtio::unix::muxer::VsockMuxer`, which
/// translates guest-side vsock connections to host-side Unix domain socket connections.
pub trait VsockBackend: VsockChannel + VsockEpollListener + Send {
    fn connections(&self) -> Vec<ConnectionInfo> {
        Vec::new()
    }
    fn queue_rst_for_connections(&mut self, _conns: Vec<ConnectionInfo>) {}
    fn local_port_last(&self) -> Option<u32> {
        None
    }
    fn set_local_port_last(&mut self, _local_port_last: u32) {}
}

#[cfg(any(test, fuzzing))]
pub mod tests {
    use std::io;
    use std::os::unix::io::AsRawFd;
    use std::path::PathBuf;
    use std::sync::{Arc, RwLock};

    use libc::EFD_NONBLOCK;
    use virtio_bindings::virtio_ring::{VRING_DESC_F_NEXT, VRING_DESC_F_WRITE};
    use vm_memory::{GuestAddress, GuestMemoryAtomic};
    use vm_virtio::queue::testing::VirtQueue as GuestQ;
    use vmm_sys_util::eventfd::EventFd;

    use super::device::{RX_QUEUE_EVENT, TX_QUEUE_EVENT, VsockEpollHandler};
    use super::packet::VSOCK_PKT_HDR_SIZE;
    use super::*;
    use crate::device::{VirtioInterrupt, VirtioInterruptType};
    use crate::epoll_helper::EpollHelperHandler;
    use crate::{EpollHelper, GuestMemory};

    pub struct NoopVirtioInterrupt {}

    impl VirtioInterrupt for NoopVirtioInterrupt {
        fn trigger(&self, _int_type: VirtioInterruptType) -> io::Result<()> {
            Ok(())
        }

        fn set_notifier(
            &self,
            _interrupt: u32,
            _eventfd: Option<EventFd>,
            _vm: &dyn hypervisor::Vm,
        ) -> io::Result<()> {
            unimplemented!()
        }
    }

    struct TestVirtioInterrupt {
        fail: bool,
    }

    impl VirtioInterrupt for TestVirtioInterrupt {
        fn trigger(&self, _int_type: VirtioInterruptType) -> io::Result<()> {
            if self.fail {
                Err(io::Error::other("fuzz interrupt failure"))
            } else {
                Ok(())
            }
        }

        fn set_notifier(
            &self,
            _interrupt: u32,
            _eventfd: Option<EventFd>,
            _vm: &dyn hypervisor::Vm,
        ) -> io::Result<()> {
            Ok(())
        }
    }

    pub struct TestBackend {
        pub evfd: EventFd,
        pub rx_err: Option<VsockError>,
        pub tx_err: Option<VsockError>,
        pub pending_rx: bool,
        pub rx_ok_cnt: usize,
        pub tx_ok_cnt: usize,
        pub evset: Option<epoll::Events>,
    }
    impl TestBackend {
        #[expect(clippy::new_without_default)]
        pub fn new() -> Self {
            Self {
                evfd: EventFd::new(EFD_NONBLOCK).unwrap(),
                rx_err: None,
                tx_err: None,
                pending_rx: false,
                rx_ok_cnt: 0,
                tx_ok_cnt: 0,
                evset: None,
            }
        }
        pub fn set_rx_err(&mut self, err: Option<VsockError>) {
            self.rx_err = err;
        }
        pub fn set_tx_err(&mut self, err: Option<VsockError>) {
            self.tx_err = err;
        }
        pub fn set_pending_rx(&mut self, prx: bool) {
            self.pending_rx = prx;
        }
    }
    impl VsockChannel for TestBackend {
        fn recv_pkt(&mut self, _pkt: &mut VsockPacket) -> Result<()> {
            match self.rx_err.take() {
                None => {
                    self.rx_ok_cnt += 1;
                    Ok(())
                }
                Some(e) => Err(e),
            }
        }
        fn send_pkt(&mut self, _pkt: &VsockPacket) -> Result<()> {
            match self.tx_err.take() {
                None => {
                    self.tx_ok_cnt += 1;
                    Ok(())
                }
                Some(e) => Err(e),
            }
        }
        fn has_pending_rx(&self) -> bool {
            self.pending_rx
        }
    }
    impl VsockEpollListener for TestBackend {
        fn get_polled_fd(&self) -> RawFd {
            self.evfd.as_raw_fd()
        }
        fn get_polled_evset(&self) -> epoll::Events {
            epoll::Events::EPOLLIN
        }
        fn notify(&mut self, evset: epoll::Events) {
            self.evset = Some(evset);
        }
    }
    impl VsockBackend for TestBackend {}

    pub struct TestContext {
        pub cid: u64,
        pub mem: GuestMemory,
        pub device: Vsock<TestBackend>,
    }

    impl TestContext {
        #[expect(clippy::new_without_default)]
        pub fn new() -> Self {
            const CID: u32 = 52;
            const MEM_SIZE: usize = 1024 * 1024 * 128;
            Self {
                cid: CID as u64,
                mem: GuestMemory::from_ranges(&[(GuestAddress(0), MEM_SIZE)]).unwrap(),
                device: Vsock::new(
                    String::from("vsock"),
                    CID,
                    PathBuf::from("/test/sock"),
                    TestBackend::new(),
                    false,
                    seccompiler::SeccompAction::Trap,
                    EventFd::new(EFD_NONBLOCK).unwrap(),
                    None,
                )
                .unwrap(),
            }
        }

        pub fn create_epoll_handler_context(&self) -> EpollHandlerContext<'_> {
            const QSIZE: u16 = 2;

            let guest_rxvq = GuestQ::new(GuestAddress(0x0010_0000), &self.mem, QSIZE);
            let guest_txvq = GuestQ::new(GuestAddress(0x0020_0000), &self.mem, QSIZE);
            let guest_evvq = GuestQ::new(GuestAddress(0x0030_0000), &self.mem, QSIZE);
            let rxvq = guest_rxvq.create_queue();
            let txvq = guest_txvq.create_queue();
            let evvq = guest_evvq.create_queue();

            // Set up one available descriptor in the RX queue.
            guest_rxvq.dtable[0].set(
                0x0040_0000,
                VSOCK_PKT_HDR_SIZE as u32,
                (VRING_DESC_F_WRITE | VRING_DESC_F_NEXT).try_into().unwrap(),
                1,
            );
            guest_rxvq.dtable[1].set(0x0040_1000, 4096, VRING_DESC_F_WRITE.try_into().unwrap(), 0);
            guest_rxvq.avail.ring[0].set(0);
            guest_rxvq.avail.idx.set(1);

            // Set up one available descriptor in the TX queue.
            guest_txvq.dtable[0].set(
                0x0050_0000,
                VSOCK_PKT_HDR_SIZE as u32,
                VRING_DESC_F_NEXT.try_into().unwrap(),
                1,
            );
            guest_txvq.dtable[1].set(0x0050_1000, 4096, 0, 0);
            guest_txvq.avail.ring[0].set(0);
            guest_txvq.avail.idx.set(1);

            let queues = vec![rxvq, txvq, evvq];
            let queue_evts = vec![
                EventFd::new(EFD_NONBLOCK).unwrap(),
                EventFd::new(EFD_NONBLOCK).unwrap(),
                EventFd::new(EFD_NONBLOCK).unwrap(),
            ];
            let interrupt_cb = Arc::new(NoopVirtioInterrupt {});

            EpollHandlerContext {
                guest_rxvq,
                guest_txvq,
                guest_evvq,
                handler: VsockEpollHandler {
                    mem: GuestMemoryAtomic::new(self.mem.clone()),
                    queues,
                    queue_evts,
                    kill_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
                    pause_evt: EventFd::new(EFD_NONBLOCK).unwrap(),
                    interrupt_cb,
                    backend: Arc::new(RwLock::new(TestBackend::new())),
                    access_platform: None,
                    backend_parked: false,
                    seqpacket_negotiated: false,
                },
            }
        }
    }

    pub struct EpollHandlerContext<'a> {
        pub(crate) handler: VsockEpollHandler<TestBackend>,
        pub guest_rxvq: GuestQ<'a, GuestMemory>,
        pub guest_txvq: GuestQ<'a, GuestMemory>,
        pub guest_evvq: GuestQ<'a, GuestMemory>,
    }

    // The event helpers are inline so external callers instantiate the
    // handler in the same crate as the device worker.
    impl EpollHandlerContext<'_> {
        pub fn configure_backend(
            &mut self,
            pending_rx: bool,
            rx_err: Option<VsockError>,
            tx_err: Option<VsockError>,
        ) {
            let mut backend = self.handler.backend.write().unwrap();
            backend.set_pending_rx(pending_rx);
            backend.set_rx_err(rx_err);
            backend.set_tx_err(tx_err);
        }

        pub fn fail_interrupt(&mut self, fail: bool) {
            self.handler.interrupt_cb = Arc::new(TestVirtioInterrupt { fail });
        }

        #[inline]
        pub fn dispatch_event(&mut self, events: epoll::Events, data: u16) {
            self.dispatch_raw_event(events.bits(), data);
        }

        #[inline]
        pub fn dispatch_raw_event(&mut self, events: u32, data: u16) {
            let event = epoll::Event {
                events,
                data: data as u64,
            };
            let mut epoll_helper =
                EpollHelper::new(&self.handler.kill_evt, &self.handler.pause_evt).unwrap();
            self.handler.handle_event(&mut epoll_helper, &event).ok();
        }

        #[inline]
        pub fn signal_backend_event(&mut self) {
            self.handler.backend.write().unwrap().evfd.write(1).unwrap();
            self.dispatch_event(epoll::Events::EPOLLIN, super::device::BACKEND_EVENT);
        }

        #[inline]
        pub fn signal_txq_event(&mut self) {
            self.handler.queue_evts[1].write(1).unwrap();
            self.dispatch_event(epoll::Events::EPOLLIN, TX_QUEUE_EVENT);
        }
        #[inline]
        pub fn signal_rxq_event(&mut self) {
            self.handler.queue_evts[0].write(1).unwrap();
            self.dispatch_event(epoll::Events::EPOLLIN, RX_QUEUE_EVENT);
        }
    }
}
