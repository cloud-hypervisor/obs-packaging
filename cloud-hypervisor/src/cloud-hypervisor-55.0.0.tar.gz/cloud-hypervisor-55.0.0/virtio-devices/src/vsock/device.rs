// Copyright 2019 Intel Corporation. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
//
// Portions Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the THIRD-PARTY file.

use std::os::unix::io::AsRawFd;
use std::path::PathBuf;
use std::sync::{Arc, RwLock};
use std::{fs, io, result};

use anyhow::anyhow;
use event_monitor::event;
use log::{debug, error, info, warn};
use seccompiler::SeccompAction;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use virtio_queue::{Queue, QueueOwnedT, QueueT};
use vm_memory::{GuestAddressSpace, GuestMemoryAtomic};
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vm_virtio::AccessPlatform;
use vmm_sys_util::eventfd::EventFd;

/// This is the `VirtioDevice` implementation for our vsock device. It handles the virtio-level
/// device logic: feature negotiation, device configuration, and device activation.
/// The run-time device logic (i.e. event-driven data handling) is implemented by
/// `super::epoll_handler::EpollHandler`.
///
/// We aim to conform to the VirtIO v1.1 spec:
/// https://docs.oasis-open.org/virtio/virtio/v1.1/virtio-v1.1.html
///
/// The vsock device has two input parameters: a CID to identify the device, and a `VsockBackend`
/// to use for offloading vsock traffic.
///
/// Upon its activation, the vsock device creates its `EpollHandler`, passes it the event-interested
/// file descriptors, and registers these descriptors with the VMM `EpollContext`. Going forward,
/// the `EpollHandler` will get notified whenever an event occurs on the just-registered FDs:
/// - an RX queue FD;
/// - a TX queue FD;
/// - an event queue FD; and
/// - a backend FD.
use super::{
    ConnectionInfo, SocketType, VsockBackend, VsockPacket,
    defs::uapi::{self, VIRTIO_VSOCK_F_SEQPACKET},
};
use crate::device::ActivationContext;
use crate::seccomp_filters::Thread;
use crate::thread_helper::PauseCommon;
use crate::{
    ActivateResult, EPOLL_HELPER_EVENT_LAST, EpollHelper, EpollHelperError, EpollHelperHandler,
    Error as DeviceError, GuestMemory, VIRTIO_F_ACCESS_PLATFORM, VIRTIO_F_IN_ORDER,
    VIRTIO_F_VERSION_1, VirtioCommon, VirtioDevice, VirtioDeviceType, VirtioInterrupt,
    VirtioInterruptType,
};

const QUEUE_SIZE: u16 = 256;
const NUM_QUEUES: u16 = 3;
const QUEUE_SIZES: &[u16] = &[QUEUE_SIZE; NUM_QUEUES as usize];

// New descriptors are pending on the rx queue.
pub(super) const RX_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 1;
// New descriptors are pending on the tx queue.
pub(super) const TX_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 2;
// New descriptors are pending on the event queue.
pub(super) const EVT_QUEUE_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 3;
// Notification coming from the backend.
pub(super) const BACKEND_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 4;

#[derive(Error, Debug)]
enum Error {
    #[error("Failed adding used index")]
    QueueAddUsed(#[source] virtio_queue::Error),
}

/// The `VsockEpollHandler` implements the runtime logic of our vsock device:
/// 1. Respond to TX queue events by wrapping virtio buffers into `VsockPacket`s, then sending those
///    packets to the `VsockBackend`;
/// 2. Forward backend FD event notifications to the `VsockBackend`;
/// 3. Fetch incoming packets from the `VsockBackend` and place them into the virtio RX queue;
/// 4. Whenever we have processed some virtio buffers (either TX or RX), let the driver know by
///    raising our assigned IRQ.
///
/// In a nutshell, the `VsockEpollHandler` logic looks like this:
/// - on TX queue event:
///   - fetch all packets from the TX queue and send them to the backend; then
///   - if the backend has queued up any incoming packets, fetch them into any available RX buffers.
/// - on RX queue event:
///   - fetch any incoming packets, queued up by the backend, into newly available RX buffers.
/// - on backend event:
///   - forward the event to the backend; then
///   - again, attempt to fetch any incoming packets queued by the backend into virtio RX buffers.
pub(crate) struct VsockEpollHandler<B: VsockBackend> {
    pub mem: GuestMemoryAtomic<GuestMemory>,
    pub queues: Vec<Queue>,
    pub queue_evts: Vec<EventFd>,
    pub kill_evt: EventFd,
    pub pause_evt: EventFd,
    pub interrupt_cb: Arc<dyn VirtioInterrupt>,
    pub backend: Arc<RwLock<B>>,
    pub access_platform: Option<Arc<dyn AccessPlatform>>,
    pub backend_parked: bool,
    pub seqpacket_negotiated: bool,
}

impl<B> VsockEpollHandler<B>
where
    B: VsockBackend,
{
    /// Signal the guest driver that we've used some virtio buffers that it had previously made
    /// available.
    fn signal_used_queue(&self, queue_index: u16) -> result::Result<(), DeviceError> {
        debug!("vsock: raising IRQ");

        self.interrupt_cb
            .trigger(VirtioInterruptType::Queue(queue_index))
            .map_err(|e| {
                error!("Failed to signal used queue: {e:?}");
                DeviceError::FailedSignalingUsedQueue(e)
            })
    }

    /// Walk the driver-provided RX queue buffers and attempt to fill them up with any data that we
    /// have pending. Returns whether a buffer was used, and whether data is left without a buffer.
    fn process_rx(&mut self) -> result::Result<(bool, bool), Error> {
        debug!("vsock: epoll_handler::process_rx()");

        let mut used_descs = false;

        while let Some(mut desc_chain) = self.queues[0].pop_descriptor_chain(self.mem.memory()) {
            let used_len = match VsockPacket::from_rx_virtq_head(
                &mut desc_chain,
                self.access_platform.as_deref(),
            ) {
                Ok(mut pkt) => {
                    let received = self.backend.write().unwrap().recv_pkt(&mut pkt);
                    if received.is_ok() {
                        if pkt.type_() == uapi::VSOCK_TYPE_SEQPACKET && !self.seqpacket_negotiated {
                            let (src_cid, dst_cid, src_port, dst_port) =
                                (pkt.src_cid(), pkt.dst_cid(), pkt.src_port(), pkt.dst_port());
                            pkt.set_src_cid(dst_cid)
                                .set_dst_cid(src_cid)
                                .set_src_port(dst_port)
                                .set_dst_port(src_port)
                                .set_op(uapi::VSOCK_OP_RST)
                                .set_len(0)
                                .set_flags(0);
                            if let Err(error) = self.backend.write().unwrap().send_pkt(&pkt) {
                                warn!(
                                    "vsock: failed to reset unnegotiated SEQPACKET connection: {error:?}"
                                );
                            }
                            self.queues[0].go_to_previous_position();
                            continue;
                        }

                        match pkt.commit_hdr(desc_chain.memory()) {
                            Ok(()) => pkt.hdr().len() as u32 + pkt.len(),
                            Err(err) => {
                                warn!(
                                    "vsock: Error writing packet header to guest memory: \
                                     {err:?}. Discarding the package."
                                );
                                0
                            }
                        }
                    } else {
                        // We are using a consuming iterator over the virtio buffers, so, if we can't
                        // fill in this buffer, we'll need to undo the last iterator step.
                        self.queues[0].go_to_previous_position();
                        return Ok((used_descs, false));
                    }
                }
                Err(e) => {
                    warn!("vsock: RX queue error: {e:?}");
                    0
                }
            };

            self.queues[0]
                .add_used(desc_chain.memory(), desc_chain.head_index(), used_len)
                .map_err(Error::QueueAddUsed)?;
            used_descs = true;
        }

        Ok((used_descs, self.backend.read().unwrap().has_pending_rx()))
    }

    /// Fill RX buffers and stop polling the backend while it has data but no RX buffer is left.
    fn rx_and_park(&mut self, helper: &mut EpollHelper) -> result::Result<(), EpollHelperError> {
        if !self.backend_parked && !self.backend.read().unwrap().has_pending_rx() {
            return Ok(());
        }
        let (used, starved) = self.process_rx().map_err(|e| {
            EpollHelperError::HandleEvent(anyhow!("Failed to process RX queue: {e:?}"))
        })?;
        if used {
            self.signal_used_queue(0).map_err(|e| {
                EpollHelperError::HandleEvent(anyhow!("Failed to signal used RX queue: {e:?}"))
            })?;
        }
        if starved != self.backend_parked {
            let evset = if starved {
                epoll::Events::empty()
            } else {
                epoll::Events::EPOLLIN
            };
            let fd = self.backend.read().unwrap().get_polled_fd();
            match helper.mod_event_custom(fd, BACKEND_EVENT, evset) {
                Ok(()) => self.backend_parked = starved,
                Err(e) => warn!("vsock: failed to update backend polling: {e:?}"),
            }
        }
        Ok(())
    }

    /// Walk the driver-provided TX queue buffers, package them up as vsock packets, and send them to
    /// the backend for processing.
    fn process_tx(&mut self) -> result::Result<bool, Error> {
        debug!("vsock: epoll_handler::process_tx()");

        let mut used_descs = false;

        while let Some(mut desc_chain) = self.queues[1].pop_descriptor_chain(self.mem.memory()) {
            let pkt = match VsockPacket::from_tx_virtq_head(
                &mut desc_chain,
                self.access_platform.as_deref(),
            ) {
                Ok(pkt) => pkt,
                Err(e) => {
                    error!("vsock: error reading TX packet: {e:?}");
                    self.queues[1]
                        .add_used(desc_chain.memory(), desc_chain.head_index(), 0)
                        .map_err(Error::QueueAddUsed)?;
                    used_descs = true;
                    continue;
                }
            };

            if pkt.type_() == uapi::VSOCK_TYPE_SEQPACKET && !self.seqpacket_negotiated {
                error!("vsock: dropping SEQPACKET packet without feature negotiation");
                self.queues[1]
                    .add_used(desc_chain.memory(), desc_chain.head_index(), 0)
                    .map_err(Error::QueueAddUsed)?;
                used_descs = true;
                continue;
            }

            if self.backend.write().unwrap().send_pkt(&pkt).is_err() {
                self.queues[1].go_to_previous_position();
                break;
            }

            self.queues[1]
                .add_used(desc_chain.memory(), desc_chain.head_index(), 0)
                .map_err(Error::QueueAddUsed)?;
            used_descs = true;
        }

        Ok(used_descs)
    }

    fn run(&mut self, pause_common: &PauseCommon) -> result::Result<(), EpollHelperError> {
        let mut helper = EpollHelper::new(&self.kill_evt, &self.pause_evt)?;
        helper.add_event(self.queue_evts[0].as_raw_fd(), RX_QUEUE_EVENT)?;
        helper.add_event(self.queue_evts[1].as_raw_fd(), TX_QUEUE_EVENT)?;
        helper.add_event(self.queue_evts[2].as_raw_fd(), EVT_QUEUE_EVENT)?;
        helper.add_event(self.backend.read().unwrap().get_polled_fd(), BACKEND_EVENT)?;
        helper.run(pause_common, self)?;

        Ok(())
    }
}

impl<B> EpollHelperHandler for VsockEpollHandler<B>
where
    B: VsockBackend,
{
    fn handle_event(
        &mut self,
        helper: &mut EpollHelper,
        event: &epoll::Event,
    ) -> result::Result<(), EpollHelperError> {
        let evset = match epoll::Events::from_bits(event.events) {
            Some(evset) => evset,
            None => {
                let evbits = event.events;
                warn!("epoll: ignoring unknown event set: 0x{evbits:x}");
                return Ok(());
            }
        };

        let ev_type = event.data as u16;
        match ev_type {
            RX_QUEUE_EVENT => {
                debug!("vsock: RX queue event");
                self.queue_evts[0].read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get RX queue event: {e:?}"))
                })?;
                if self.backend_parked {
                    self.backend.write().unwrap().notify(epoll::Events::EPOLLIN);
                }
                self.rx_and_park(helper)?;
            }
            TX_QUEUE_EVENT => {
                debug!("vsock: TX queue event");
                self.queue_evts[1].read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get TX queue event: {e:?}"))
                })?;
                if self.backend_parked {
                    self.backend.write().unwrap().notify(epoll::Events::EPOLLIN);
                }

                let needs_notification = self.process_tx().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to process TX queue: {e:?}"))
                })?;
                if needs_notification {
                    self.signal_used_queue(1).map_err(|e| {
                        EpollHelperError::HandleEvent(anyhow!(
                            "Failed to signal used TX queue: {e:?}"
                        ))
                    })?;
                }

                // The backend may have queued up responses to the packets we sent during TX queue
                // processing. If that happened, we need to fetch those responses and place them
                // into RX buffers.
                self.rx_and_park(helper)?;
            }
            EVT_QUEUE_EVENT => {
                debug!("vsock: EVT queue event");
                self.queue_evts[2].read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get EVT queue event: {e:?}"))
                })?;
            }
            BACKEND_EVENT => {
                debug!("vsock: backend event");
                self.backend.write().unwrap().notify(evset);
                // After the backend has been kicked, it might've freed up some resources, so we
                // can attempt to send it more data to process.
                // In particular, if `self.backend.send_pkt()` halted the TX queue processing (by
                // returning an error) at some point in the past, now is the time to try walking the
                // TX queue again.
                let needs_notification = self.process_tx().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to process TX queue: {e:?}"))
                })?;
                if needs_notification {
                    self.signal_used_queue(1).map_err(|e| {
                        EpollHelperError::HandleEvent(anyhow!(
                            "Failed to signal used TX queue: {e:?}"
                        ))
                    })?;
                }
                self.rx_and_park(helper)?;
            }
            _ => {
                return Err(EpollHelperError::HandleEvent(anyhow!(
                    "Unknown event for virtio-vsock"
                )));
            }
        }

        Ok(())
    }
}

/// Virtio device exposing virtual socket to the guest.
pub struct Vsock<B: VsockBackend> {
    common: VirtioCommon,
    id: String,
    cid: u64,
    backend: Arc<RwLock<B>>,
    path: PathBuf,
    seccomp_action: SeccompAction,
    exit_evt: EventFd,
}

#[derive(Serialize, Deserialize)]
pub struct VsockState {
    pub avail_features: u64,
    pub acked_features: u64,
    #[serde(default, deserialize_with = "deserialize_connections")]
    pub connections: Vec<ConnectionInfo>,
    #[serde(default)]
    pub local_port_last: Option<u32>,
}

fn deserialize_connections<'de, D>(deserializer: D) -> result::Result<Vec<ConnectionInfo>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum Connection {
        Typed(ConnectionInfo),
        Stream((u32, u32)),
    }
    Vec::<Connection>::deserialize(deserializer).map(|connections| {
        connections
            .into_iter()
            .map(|connection| match connection {
                Connection::Typed(connection) => connection,
                Connection::Stream((local_port, peer_port)) => {
                    (local_port, peer_port, SocketType::Stream.into())
                }
            })
            .collect()
    })
}

impl<B> Vsock<B>
where
    B: VsockBackend + Sync,
{
    /// Create a new virtio-vsock device with the given VM CID and vsock
    /// backend.
    #[expect(clippy::too_many_arguments)]
    pub fn new(
        id: String,
        cid: u32,
        path: PathBuf,
        mut backend: B,
        access_platform_enabled: bool,
        seccomp_action: SeccompAction,
        exit_evt: EventFd,
        state: Option<VsockState>,
    ) -> io::Result<Vsock<B>> {
        let (avail_features, acked_features, paused) = if let Some(state) = state {
            info!("Restoring virtio-vsock {id}");
            // Instead of letting the guest connection hang/timeout, proactively let
            // the guest know the connection is gone.
            backend.queue_rst_for_connections(state.connections.clone());
            // New connection must not use old, stale, port
            if let Some(local_port_last) = state.local_port_last {
                backend.set_local_port_last(local_port_last);
            }
            (state.avail_features, state.acked_features, true)
        } else {
            let mut avail_features = (1u64 << VIRTIO_F_VERSION_1)
                | (1u64 << VIRTIO_F_IN_ORDER)
                | (1u64 << VIRTIO_VSOCK_F_SEQPACKET);

            if access_platform_enabled {
                avail_features |= 1u64 << VIRTIO_F_ACCESS_PLATFORM;
            }
            (avail_features, 0, false)
        };

        Ok(Vsock {
            common: VirtioCommon {
                device_type: VirtioDeviceType::Vsock as u32,
                avail_features,
                acked_features,
                queue_sizes: QUEUE_SIZES.to_vec(),
                min_queues: NUM_QUEUES,
                ..VirtioCommon::new(paused)?
            },
            id,
            cid: cid.into(),
            backend: Arc::new(RwLock::new(backend)),
            path,
            seccomp_action,
            exit_evt,
        })
    }

    fn state(&self) -> VsockState {
        let backend = self.backend.read().unwrap();
        VsockState {
            avail_features: self.common.avail_features,
            acked_features: self.common.acked_features,
            connections: backend.connections(),
            local_port_last: backend.local_port_last(),
        }
    }

    #[cfg(fuzzing)]
    pub fn wait_for_epoll_threads(&mut self) {
        self.common.wait_for_epoll_threads();
    }
}

impl<B> VirtioDevice for Vsock<B>
where
    B: VsockBackend + Sync + 'static,
{
    fn device_type(&self) -> u32 {
        self.common.device_type
    }

    fn queue_max_sizes(&self) -> &[u16] {
        &self.common.queue_sizes
    }

    fn features(&self) -> u64 {
        self.common.avail_features
    }

    fn ack_features(&mut self, value: u64) {
        self.common.ack_features(value);
    }

    fn read_config(&self, offset: u64, data: &mut [u8]) {
        match offset {
            0 if data.len() == 8 => data.copy_from_slice(&self.cid.to_le_bytes()),
            0 if data.len() == 4 => {
                data.copy_from_slice(&((self.cid & 0xffff_ffff) as u32).to_le_bytes());
            }
            4 if data.len() == 4 => {
                data.copy_from_slice(&(((self.cid >> 32) & 0xffff_ffff) as u32).to_le_bytes());
            }
            _ => warn!(
                "vsock: virtio-vsock received invalid read request of {} bytes at offset {}",
                data.len(),
                offset
            ),
        }
    }

    fn activate(&mut self, context: ActivationContext) -> ActivateResult {
        let ActivationContext {
            mem,
            interrupt_cb,
            queues,
            device_status,
        } = context;
        self.common.activate(&queues, Arc::clone(&interrupt_cb))?;
        let (kill_evt, pause_evt) = self.common.dup_eventfds()?;

        let mut virtqueues = Vec::new();
        let mut queue_evts = Vec::new();
        for (_, queue, queue_evt) in queues {
            virtqueues.push(queue);
            queue_evts.push(queue_evt);
        }

        let mut handler = VsockEpollHandler {
            mem,
            queues: virtqueues,
            queue_evts,
            kill_evt,
            pause_evt,
            interrupt_cb: Arc::clone(&interrupt_cb),
            backend: Arc::clone(&self.backend),
            access_platform: self.common.access_platform(),
            backend_parked: false,
            seqpacket_negotiated: self.common.acked_features & (1 << VIRTIO_VSOCK_F_SEQPACKET) != 0,
        };

        self.common.spawn_worker(
            &self.id,
            &self.seccomp_action,
            Thread::VirtioVsock,
            &self.exit_evt,
            Arc::clone(&device_status),
            Arc::clone(&interrupt_cb),
            move |pause_common| handler.run(pause_common),
        )?;

        event!("virtio-device", "activated", "id", &self.id);
        Ok(())
    }

    fn reset(&mut self) {
        self.common.reset();
        self.common.acked_features = 0;
        event!("virtio-device", "reset", "id", &self.id);
    }

    fn shutdown(&mut self) {
        fs::remove_file(&self.path).ok();
    }

    fn set_access_platform(&mut self, access_platform: Arc<dyn AccessPlatform>) {
        self.common.set_access_platform(access_platform);
    }

    fn access_platform(&self) -> Option<Arc<dyn AccessPlatform>> {
        self.common.access_platform()
    }
}

impl<B> Pausable for Vsock<B>
where
    B: VsockBackend + Sync + 'static,
{
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        self.common.pause()
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        self.common.resume()
    }
}

impl<B> Snapshottable for Vsock<B>
where
    B: VsockBackend + Sync + 'static,
{
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        Snapshot::new_from_state(&self.state())
    }
}
impl<B> Transportable for Vsock<B> where B: VsockBackend + Sync + 'static {}
impl<B> Migratable for Vsock<B> where B: VsockBackend + Sync + 'static {}

#[cfg(test)]
mod tests {
    use std::sync::atomic::AtomicU8;

    use libc::EFD_NONBLOCK;

    use super::super::tests::{NoopVirtioInterrupt, TestContext};
    use super::super::*;
    use super::*;
    use crate::ActivateError;

    #[test]
    fn test_virtio_device() {
        let mut ctx = TestContext::new();
        let avail_features = (1u64 << VIRTIO_F_VERSION_1)
            | (1u64 << VIRTIO_F_IN_ORDER)
            | (1u64 << VIRTIO_VSOCK_F_SEQPACKET);
        let device_features = avail_features;
        let driver_features: u64 = avail_features | 1 | (1 << 32);
        let device_pages = [
            (device_features & 0xffff_ffff) as u32,
            (device_features >> 32) as u32,
        ];
        assert_eq!(ctx.device.device_type(), VirtioDeviceType::Vsock as u32);
        assert_eq!(ctx.device.queue_max_sizes(), QUEUE_SIZES);
        assert_eq!(ctx.device.features() as u32, device_pages[0]);
        assert_eq!((ctx.device.features() >> 32) as u32, device_pages[1]);

        // Ack device features.
        ctx.device.ack_features(driver_features);
        // Check that no side effect are present, and that the acked features are exactly the same
        // as the device features.
        assert_eq!(
            ctx.device.common.acked_features,
            device_features & driver_features
        );

        // Test reading 32-bit chunks.
        let mut data = [0u8; 4];
        ctx.device.read_config(0, &mut data);
        assert_eq!(u64::from(u32::from_le_bytes(data)), ctx.cid & 0xffff_ffff);
        ctx.device.read_config(4, &mut data);
        assert_eq!(
            u64::from(u32::from_le_bytes(data)),
            (ctx.cid >> 32) & 0xffff_ffff
        );

        // Test reading 64-bit.
        let mut data = [0u8; 8];
        ctx.device.read_config(0, &mut data);
        assert_eq!(u64::from_le_bytes(data), ctx.cid);

        // Check that out-of-bounds reading doesn't mutate the destination buffer.
        let mut data = [0u8, 1, 2, 3, 4, 5, 6, 7];
        ctx.device.read_config(2, &mut data);
        assert_eq!(data, [0u8, 1, 2, 3, 4, 5, 6, 7]);

        // Just covering lines here, since the vsock device has no writable config.
        // A warning is, however, logged, if the guest driver attempts to write any config data.
        ctx.device.write_config(0, &data[..4]);

        let memory = GuestMemoryAtomic::new(ctx.mem.clone());

        // Test a bad activation.
        let bad_activate = ctx.device.activate(ActivationContext {
            mem: memory.clone(),
            interrupt_cb: Arc::new(NoopVirtioInterrupt {}),
            queues: Vec::new(),
            device_status: Arc::new(AtomicU8::new(0)),
        });
        match bad_activate {
            Err(ActivateError::BadActivate) => (),
            other => panic!("{other:?}"),
        }

        // Test a correct activation.
        ctx.device
            .activate(ActivationContext {
                mem: memory,
                interrupt_cb: Arc::new(NoopVirtioInterrupt {}),
                queues: vec![
                    (
                        0,
                        Queue::new(256).unwrap(),
                        EventFd::new(EFD_NONBLOCK).unwrap(),
                    ),
                    (
                        1,
                        Queue::new(256).unwrap(),
                        EventFd::new(EFD_NONBLOCK).unwrap(),
                    ),
                    (
                        2,
                        Queue::new(256).unwrap(),
                        EventFd::new(EFD_NONBLOCK).unwrap(),
                    ),
                ],
                device_status: Arc::new(AtomicU8::new(0)),
            })
            .unwrap();
    }

    #[test]
    fn test_txq_event() {
        // Test case:
        // - the driver has something to send (there's data in the TX queue); and
        // - the backend has no pending RX data.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(false);
            ctx.signal_txq_event();

            // The available TX descriptor should have been used.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 1);
            // The available RX descriptor should be untouched.
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 0);
        }

        // Test case:
        // - the driver has something to send (there's data in the TX queue); and
        // - the backend also has some pending RX data.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(true);
            ctx.signal_txq_event();

            // Both available RX and TX descriptors should have been used.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 1);
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 1);
        }

        // Test case:
        // - the driver has something to send (there's data in the TX queue); and
        // - the backend errors out and cannot process the TX queue.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(false);
            ctx.handler
                .backend
                .write()
                .unwrap()
                .set_tx_err(Some(VsockError::NoData));
            ctx.signal_txq_event();

            // Both RX and TX queues should be untouched.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 0);
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 0);
        }

        // Test case:
        // - the driver supplied a malformed TX buffer.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            // Invalidate the packet header descriptor, by setting its length to 0.
            ctx.guest_txvq.dtable[0].len.set(0);
            ctx.signal_txq_event();

            // The available descriptor should have been consumed, but no packet should have
            // reached the backend.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 1);
            assert_eq!(ctx.handler.backend.read().unwrap().tx_ok_cnt, 0);
        }

        // Test case: spurious TXQ_EVENT.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            let events = epoll::Events::EPOLLIN;
            let event = epoll::Event::new(events, TX_QUEUE_EVENT as u64);
            let mut epoll_helper =
                EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();

            ctx.handler
                .handle_event(&mut epoll_helper, &event)
                .expect_err("handle_event() should have failed");
        }
    }

    #[test]
    fn test_rxq_event() {
        // Test case:
        // - there is pending RX data in the backend; and
        // - the driver makes RX buffers available; and
        // - the backend successfully places its RX data into the queue.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(true);
            ctx.handler
                .backend
                .write()
                .unwrap()
                .set_rx_err(Some(VsockError::NoData));
            ctx.signal_rxq_event();

            // The available RX buffer should've been left untouched.
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 0);
        }

        // Test case:
        // - there is pending RX data in the backend; and
        // - the driver makes RX buffers available; and
        // - the backend errors out, when attempting to receive data.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(true);
            ctx.signal_rxq_event();

            // The available RX buffer should have been used.
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 1);
        }

        // Test case: the driver provided a malformed RX descriptor chain.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            // Invalidate the packet header descriptor, by setting its length to 0.
            ctx.guest_rxvq.dtable[0].len.set(0);

            // The chain should've been processed, without employing the backend.
            ctx.handler.process_rx().unwrap();
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 1);
            assert_eq!(ctx.handler.backend.read().unwrap().rx_ok_cnt, 0);
        }

        // Test case: spurious RXQ_EVENT.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();
            ctx.handler.backend.write().unwrap().set_pending_rx(false);

            let events = epoll::Events::EPOLLIN;
            let event = epoll::Event::new(events, RX_QUEUE_EVENT as u64);
            let mut epoll_helper =
                EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();

            assert_eq!(ctx.guest_rxvq.used.idx.get(), 0);
            ctx.handler
                .handle_event(&mut epoll_helper, &event)
                .expect_err("handle_event() should have failed");
        }
    }

    #[test]
    fn test_evq_event() {
        // Test case: spurious EVQ_EVENT.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();
            ctx.handler.backend.write().unwrap().set_pending_rx(false);

            let events = epoll::Events::EPOLLIN;
            let event = epoll::Event::new(events, EVT_QUEUE_EVENT as u64);
            let mut epoll_helper =
                EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();

            assert_eq!(ctx.guest_evvq.used.idx.get(), 0);

            ctx.handler
                .handle_event(&mut epoll_helper, &event)
                .expect_err("handle_event() should have failed");
        }
    }

    #[test]
    fn test_backend_event() {
        // Test case:
        // - a backend event is received; and
        // - the backend has pending RX data.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(true);

            let events = epoll::Events::EPOLLIN;
            let event = epoll::Event::new(events, BACKEND_EVENT as u64);
            let mut epoll_helper =
                EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();
            ctx.handler.handle_event(&mut epoll_helper, &event).unwrap();

            // The backend should've received this event.
            assert_eq!(
                ctx.handler.backend.read().unwrap().evset,
                Some(epoll::Events::EPOLLIN)
            );
            // TX queue processing should've been triggered.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 1);
            // RX queue processing should've been triggered.
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 1);
        }

        // Test case:
        // - a backend event is received; and
        // - the backend doesn't have any pending RX data.
        {
            let test_ctx = TestContext::new();
            let mut ctx = test_ctx.create_epoll_handler_context();

            ctx.handler.backend.write().unwrap().set_pending_rx(false);

            let events = epoll::Events::EPOLLIN;
            let event = epoll::Event::new(events, BACKEND_EVENT as u64);
            let mut epoll_helper =
                EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();
            ctx.handler.handle_event(&mut epoll_helper, &event).unwrap();

            // The backend should've received this event.
            assert_eq!(
                ctx.handler.backend.read().unwrap().evset,
                Some(epoll::Events::EPOLLIN)
            );
            // TX queue processing should've been triggered.
            assert_eq!(ctx.guest_txvq.used.idx.get(), 1);
            // The RX queue should've been left untouched.
            assert_eq!(ctx.guest_rxvq.used.idx.get(), 0);
        }
    }

    #[test]
    fn test_backend_parked_without_rx_buffers() {
        let test_ctx = TestContext::new();
        let mut ctx = test_ctx.create_epoll_handler_context();
        let mut helper = EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();
        let fd = ctx.handler.backend.read().unwrap().get_polled_fd();
        helper.add_event(fd, BACKEND_EVENT).unwrap();

        // The backend has data but the guest posted only one RX buffer, so the backend is parked.
        ctx.handler.backend.write().unwrap().set_pending_rx(true);
        let event = epoll::Event::new(epoll::Events::EPOLLIN, BACKEND_EVENT as u64);
        ctx.handler.handle_event(&mut helper, &event).unwrap();
        assert_eq!(ctx.guest_rxvq.used.idx.get(), 1);
        assert!(ctx.handler.backend_parked);

        ctx.handler.backend.write().unwrap().evset = None;
        // A TX kick still lets the backend handle its events while it stays parked.
        ctx.handler.queue_evts[1].write(1).unwrap();
        let event = epoll::Event::new(epoll::Events::EPOLLIN, TX_QUEUE_EVENT as u64);
        ctx.handler.handle_event(&mut helper, &event).unwrap();
        assert_eq!(
            ctx.handler.backend.read().unwrap().evset,
            Some(epoll::Events::EPOLLIN)
        );
        assert!(ctx.handler.backend_parked);

        ctx.handler.backend.write().unwrap().evset = None;
        // Once the backend has no more data, an RX kick polls it again.
        ctx.handler.backend.write().unwrap().set_pending_rx(false);
        ctx.handler.queue_evts[0].write(1).unwrap();
        let event = epoll::Event::new(epoll::Events::EPOLLIN, RX_QUEUE_EVENT as u64);
        ctx.handler.handle_event(&mut helper, &event).unwrap();
        assert_eq!(
            ctx.handler.backend.read().unwrap().evset,
            Some(epoll::Events::EPOLLIN)
        );
        assert!(!ctx.handler.backend_parked);
    }

    #[test]
    fn test_unknown_event() {
        let test_ctx = TestContext::new();
        let mut ctx = test_ctx.create_epoll_handler_context();

        let events = epoll::Events::EPOLLIN;
        let event = epoll::Event::new(events, 0xff);
        let mut epoll_helper =
            EpollHelper::new(&ctx.handler.kill_evt, &ctx.handler.pause_evt).unwrap();

        ctx.handler
            .handle_event(&mut epoll_helper, &event)
            .expect_err("handle_event() should have failed");
    }
}
