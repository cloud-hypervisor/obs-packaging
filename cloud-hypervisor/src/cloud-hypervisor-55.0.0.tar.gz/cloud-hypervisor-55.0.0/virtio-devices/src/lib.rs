// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

//! Implements virtio devices, queues, and transport mechanisms.

use std::sync::atomic::{AtomicU8, Ordering};
use std::{fmt, io, result};

use serde::{Deserialize, Serialize};
use thiserror::Error;
use vmm_sys_util::errno::Error as ErrnoError;

#[macro_use]
mod device;
pub mod balloon;
pub mod block;
mod console;
pub mod epoll_helper;
mod iommu;
pub mod mem;
pub mod net;
mod pmem;
mod rng;
mod rtc;
pub mod seccomp_filters;
mod thread_helper;
pub mod transport;
pub mod vdpa;
pub mod vhost_user;
pub mod vsock;
pub mod watchdog;

use vm_allocator::{GuestMemory, GuestRegion};
use vm_memory::bitmap::AtomicBitmap;
use vm_memory::{GuestAddress, GuestMemoryBackend, GuestMemoryError};
use vm_virtio::VirtioDeviceType;

pub use self::balloon::{Balloon, BalloonStats, BalloonStatsSnapshot};
pub use self::block::{Block, BlockState};
pub use self::console::{Console, ConsoleResizer, Endpoint};
pub use self::device::{
    ActivationContext, DmaRemapping, VirtioCommon, VirtioDevice, VirtioInterrupt,
    VirtioInterruptType, VirtioSharedMemoryList,
};
pub use self::epoll_helper::{
    EPOLL_HELPER_EVENT_LAST, EpollHelper, EpollHelperError, EpollHelperHandler,
};
pub use self::iommu::{AccessPlatformMapping, Iommu, IommuMapping};
pub use self::mem::{BlocksState, Mem, VIRTIO_MEM_ALIGN_SIZE, VirtioMemMappingSource};
pub use self::net::{Net, NetCtrlEpollHandler};
pub use self::pmem::Pmem;
pub use self::rng::Rng;
pub use self::rtc::Rtc;
pub use self::thread_helper::PauseCommon;
pub use self::vdpa::{Vdpa, VdpaDmaMapping};
pub use self::vsock::Vsock;
pub use self::watchdog::Watchdog;

type MmapRegion = vm_memory::MmapRegion<AtomicBitmap>;

const DEVICE_INIT: u32 = 0x00;
const DEVICE_ACKNOWLEDGE: u32 = 0x01;
const DEVICE_DRIVER: u32 = 0x02;
const DEVICE_DRIVER_OK: u32 = 0x04;
const DEVICE_FEATURES_OK: u32 = 0x08;
const DEVICE_NEEDS_RESET: u32 = 0x40;
const DEVICE_FAILED: u32 = 0x80;

const VIRTIO_F_RING_INDIRECT_DESC: u32 = 28;
const VIRTIO_F_RING_EVENT_IDX: u32 = 29;
const VIRTIO_F_VERSION_1: u32 = 32;
const VIRTIO_F_ACCESS_PLATFORM: u32 = 33;
const VIRTIO_F_IN_ORDER: u32 = 35;
const VIRTIO_F_ORDER_PLATFORM: u32 = 36;
#[expect(dead_code)]
const VIRTIO_F_SR_IOV: u32 = 37;
const VIRTIO_F_NOTIFICATION_DATA: u32 = 38;

#[derive(Error, Debug)]
pub enum ActivateError {
    #[error("Failed to activate virtio device")]
    BadActivate,
    #[error("VIRTIO_F_ACCESS_PLATFORM was not acknowledged")]
    AccessPlatformNotAcknowledged,
    #[error("Failed to clone EventFd")]
    CloneEventFd(#[source] io::Error),
    #[error("Failed to create EventFd")]
    CreateEventFd(#[source] io::Error),
    #[error("Failed to spawn thread")]
    ThreadSpawn(#[source] io::Error),
    #[error("Failed to setup vhost-user daemon")]
    VhostUserSetup(#[source] vhost_user::Error),
    #[error("Failed to create seccomp filter")]
    CreateSeccompFilter(#[source] seccompiler::Error),
    #[error("Failed to create rate limiter")]
    CreateRateLimiter(#[source] io::Error),
    #[error("Failed to activate the vDPA device")]
    ActivateVdpa(#[source] vdpa::Error),
    #[error("Failed to create TimerFd")]
    CreateTimerFd(#[source] ErrnoError),
}

pub type ActivateResult = result::Result<(), ActivateError>;

#[derive(Error, Debug)]
pub enum Error {
    #[error("Failed to single used queue")]
    FailedSignalingUsedQueue(#[source] io::Error),
    #[error("I/O Error")]
    IoError(#[source] io::Error),
    #[error("Failed to update memory vhost-user")]
    VhostUserUpdateMemory(#[source] vhost_user::Error),
    #[error("Failed to add memory region vhost-user")]
    VhostUserAddMemoryRegion(#[source] vhost_user::Error),
    #[error("Failed to set shared memory region")]
    SetShmRegionsNotSupported,
    #[error("Failed to process net queue")]
    NetQueuePair(#[source] ::net_util::NetQueuePairError),
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
pub struct TokenBucketConfig {
    pub size: u64,
    pub one_time_burst: Option<u64>,
    pub refill_time: u64,
    /// Peak rate in tokens per second.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub burst_rate: Option<u64>,
    /// Burst duration in seconds, defaulting to one when a burst rate is set.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub burst_seconds: Option<u64>,
    /// Seconds to regain full burst credit from empty while idle.
    /// When absent, recharge takes burst_rate * burst_seconds / sustained rate seconds.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub burst_recharge_seconds: Option<u64>,
}

impl TokenBucketConfig {
    /// Build the token bucket, using bounded burst accounting when configured.
    pub fn token_bucket(&self) -> Option<rate_limiter::TokenBucket> {
        if let Some(rate) = self.burst_rate {
            rate_limiter::TokenBucket::new_with_burst(
                self.size,
                self.refill_time,
                rate,
                self.burst_seconds.unwrap_or(1),
                self.burst_recharge_seconds.unwrap_or(0),
            )
        } else {
            rate_limiter::TokenBucket::new(
                self.size,
                self.one_time_burst.unwrap_or(0),
                self.refill_time,
            )
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Serialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct RateLimiterConfig {
    pub bandwidth: Option<TokenBucketConfig>,
    pub ops: Option<TokenBucketConfig>,
}

impl TryInto<rate_limiter::RateLimiter> for RateLimiterConfig {
    type Error = io::Error;

    fn try_into(self) -> result::Result<rate_limiter::RateLimiter, Self::Error> {
        rate_limiter::RateLimiter::from_buckets(
            self.bandwidth.and_then(|b| b.token_bucket()),
            self.ops.and_then(|o| o.token_bucket()),
        )
    }
}

/// Failure to resolve a guest range to a host address.
#[derive(Debug, Error)]
pub enum HostAddressRangeError {
    /// An empty range has no usable host pointer.
    #[error("Zero size guest range: gpa={gpa:#x}")]
    ZeroSize { gpa: u64 },
    /// The guest memory backend could not provide the range.
    #[error("Failed to access guest range: gpa={gpa:#x}, size={size:#x}")]
    GuestMemory {
        gpa: u64,
        size: usize,
        #[source]
        source: GuestMemoryError,
    },
}

/// Return the host virtual address corresponding to the given guest address range
///
/// Convert an absolute address into an address space (GuestMemoryBackend)
/// to a host pointer and verify that the provided size defines a valid
/// range within a single memory region.
/// Return an error if the range is empty or the backend cannot provide it.
pub fn get_host_address_range<M: GuestMemoryBackend + ?Sized>(
    mem: &M,
    addr: GuestAddress,
    size: usize,
) -> Result<*mut u8, HostAddressRangeError> {
    // Reject zero-length, no use of a pointer to an empty range.
    if size == 0 {
        return Err(HostAddressRangeError::ZeroSize { gpa: addr.0 });
    }
    let slice = mem
        .get_slice(addr, size)
        .map_err(|source| HostAddressRangeError::GuestMemory {
            gpa: addr.0,
            size,
            source,
        })?;
    Ok(slice.ptr_guard_mut().as_ptr())
}

/// Marks a virtio device as `NEEDS_RESET` and notifies the guest via a config
/// change interrupt. Used when a guest induced error (corrupted virtqueue,
/// malformed descriptor chain or similar) is detected and the worker thread
/// has stopped processing the device's queues.
///
/// `context` is included verbatim in the warning log to identify the cause.
pub(crate) fn mark_device_needs_reset(
    device_status: &AtomicU8,
    interrupt_cb: &dyn self::VirtioInterrupt,
    context: fmt::Arguments<'_>,
) {
    log::warn!(
        "Corrupted request detected ({context}). Setting device status to 'NEEDS_RESET' and stopping processing queues until reset."
    );

    device_status.fetch_or(DEVICE_NEEDS_RESET as u8, Ordering::SeqCst);

    if let Err(e) = interrupt_cb.trigger(self::VirtioInterruptType::Config) {
        log::error!("Failed to signal config interrupt: {e:?}");
    }
}
