// Copyright 2019 Intel Corporation. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

use std::mem::offset_of;
use std::sync::{Arc, Mutex};
use std::{io, result};

use block::VirtioBlockConfig;
use log::{error, info};
use seccompiler::SeccompAction;
use vhost::vhost_user::message::{VhostUserConfigFlags, VhostUserProtocolFeatures};
use vhost::vhost_user::{FrontendReqHandler, VhostUserFrontend, VhostUserFrontendReqHandler};
use virtio_bindings::virtio_blk::{
    VIRTIO_BLK_F_BLK_SIZE, VIRTIO_BLK_F_CONFIG_WCE, VIRTIO_BLK_F_DISCARD, VIRTIO_BLK_F_FLUSH,
    VIRTIO_BLK_F_GEOMETRY, VIRTIO_BLK_F_MQ, VIRTIO_BLK_F_RO, VIRTIO_BLK_F_SEG_MAX,
    VIRTIO_BLK_F_SIZE_MAX, VIRTIO_BLK_F_TOPOLOGY, VIRTIO_BLK_F_WRITE_ZEROES,
};
use vm_memory::ByteValued;
use vm_migration::protocol::MemoryRangeTable;
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vmm_sys_util::eventfd::EventFd;

use super::super::{ActivateResult, VirtioCommon, VirtioDevice, VirtioDeviceType};
use super::vu_common_ctrl::{VhostUserConfig, VhostUserHandle};
use super::{DEFAULT_VIRTIO_FEATURES, Error, Result};
use crate::device::ActivationContext;
use crate::seccomp_filters::Thread;
use crate::vhost_user::{PostcopyHandler, VhostUserCommon, VhostUserState};
use crate::{GuestRegion, VIRTIO_F_ACCESS_PLATFORM, VirtioInterrupt, VirtioInterruptType};

const DEFAULT_QUEUE_NUMBER: u16 = 1;

pub type State = VhostUserState<VirtioBlockConfig>;

fn get_block_config(vu: &mut VhostUserHandle, num_queues: u16) -> Result<VirtioBlockConfig> {
    let config_len = size_of::<VirtioBlockConfig>();
    let config_space = vec![0u8; config_len];
    let (_, config_space) = vu
        .socket_handle()
        .get_config(
            0,
            config_len as u32,
            VhostUserConfigFlags::WRITABLE,
            config_space.as_slice(),
        )
        .map_err(Error::VhostUserGetConfig)?;
    let mut config = VirtioBlockConfig::default();
    if let Some(backend_config) = VirtioBlockConfig::from_slice(config_space.as_slice()) {
        config = *backend_config;
        config.num_queues = num_queues;
    }

    Ok(config)
}

struct BackendReqHandler {
    vu: Arc<Mutex<VhostUserHandle>>,
    config: Arc<Mutex<VirtioBlockConfig>>,
    num_queues: u16,
    interrupt_cb: Arc<dyn VirtioInterrupt>,
}

impl VhostUserFrontendReqHandler for BackendReqHandler {
    fn handle_config_change(&self) -> io::Result<u64> {
        let mut vu = self.vu.lock().unwrap();
        let config = get_block_config(&mut vu, self.num_queues).map_err(|e| {
            error!("Failed to refresh vhost-user-blk configuration: {e:?}");
            io::Error::other(e)
        })?;
        *self.config.lock().unwrap() = config;
        self.interrupt_cb
            .trigger(VirtioInterruptType::Config)
            .map_err(|e| {
                error!("Failed to signal vhost-user-blk config change: {e:?}");
                io::Error::other(e)
            })?;
        Ok(0)
    }
}

pub struct Blk {
    vu_common: VhostUserCommon,
    id: String,
    config: Arc<Mutex<VirtioBlockConfig>>,
    seccomp_action: SeccompAction,
    exit_evt: EventFd,
}

impl Blk {
    /// Create a new vhost-user-blk device
    pub fn new(
        id: String,
        vu_cfg: VhostUserConfig,
        seccomp_action: SeccompAction,
        exit_evt: EventFd,
        access_platform_enabled: bool,
        state: Option<State>,
        postcopy_handler: Option<Arc<dyn PostcopyHandler>>,
    ) -> Result<Blk> {
        let num_queues = vu_cfg.num_queues;

        let mut vu = VhostUserHandle::connect_vhost_user(
            false,
            &vu_cfg.socket,
            num_queues,
            false,
            &exit_evt,
            |_| Ok(()),
        )?;

        let (
            avail_features,
            acked_features,
            acked_protocol_features,
            vu_num_queues,
            config,
            paused,
            vring_bases,
        ) = if let Some(state) = state {
            info!("Restoring vhost-user-block {id}");

            vu.set_protocol_features_vhost_user(
                state.acked_protocol_features,
                postcopy_handler.is_some(),
            )?;

            vu.restore_state(&state)?;

            (
                state.avail_features,
                state.acked_features,
                state.acked_protocol_features,
                state.vu_num_queues,
                state.config,
                true,
                state.vring_bases,
            )
        } else {
            // Filling device and vring features VMM supports.
            let mut avail_features = (1 << VIRTIO_BLK_F_SIZE_MAX)
                | (1 << VIRTIO_BLK_F_SEG_MAX)
                | (1 << VIRTIO_BLK_F_GEOMETRY)
                | (1 << VIRTIO_BLK_F_RO)
                | (1 << VIRTIO_BLK_F_BLK_SIZE)
                | (1 << VIRTIO_BLK_F_FLUSH)
                | (1 << VIRTIO_BLK_F_TOPOLOGY)
                | (1 << VIRTIO_BLK_F_CONFIG_WCE)
                | (1 << VIRTIO_BLK_F_DISCARD)
                | (1 << VIRTIO_BLK_F_WRITE_ZEROES)
                | DEFAULT_VIRTIO_FEATURES;

            if num_queues > 1 {
                avail_features |= 1 << VIRTIO_BLK_F_MQ;
            }

            let avail_protocol_features = VhostUserProtocolFeatures::CONFIG
                | VhostUserProtocolFeatures::MQ
                | VhostUserProtocolFeatures::CONFIGURE_MEM_SLOTS
                | VhostUserProtocolFeatures::REPLY_ACK
                | VhostUserProtocolFeatures::INFLIGHT_SHMFD
                | VhostUserProtocolFeatures::LOG_SHMFD
                | VhostUserProtocolFeatures::DEVICE_STATE
                | VhostUserProtocolFeatures::BACKEND_REQ;

            let (acked_features, acked_protocol_features) = vu.negotiate_features_vhost_user(
                avail_features,
                avail_protocol_features,
                postcopy_handler.is_some(),
            )?;

            let backend_num_queues =
                if acked_protocol_features & VhostUserProtocolFeatures::MQ.bits() != 0 {
                    vu.socket_handle()
                        .get_queue_num()
                        .map_err(Error::VhostUserGetQueueMaxNum)?
                } else {
                    DEFAULT_QUEUE_NUMBER as u64
                };

            if num_queues as u64 > backend_num_queues {
                error!(
                    "vhost-user-blk requested too many queues ({num_queues}) since the backend only supports {backend_num_queues}\n"
                );
                return Err(Error::BadQueueNum);
            }

            let config = get_block_config(&mut vu, num_queues)?;

            let mut avail_features = acked_features;
            if access_platform_enabled {
                avail_features |= 1u64 << VIRTIO_F_ACCESS_PLATFORM;
            }

            (
                avail_features,
                0,
                acked_protocol_features,
                num_queues,
                config,
                false,
                None,
            )
        };

        if let Some(postcopy_handler) = postcopy_handler {
            vu.start_postcopy(id.clone(), postcopy_handler)?;
        }

        let virtio_common = VirtioCommon {
            device_type: VirtioDeviceType::Block as u32,
            queue_sizes: vec![vu_cfg.queue_size; num_queues as usize],
            avail_features,
            acked_features,
            min_queues: DEFAULT_QUEUE_NUMBER,
            ..VirtioCommon::new(paused).map_err(Error::CreateEventFd)?
        };

        Ok(Blk {
            vu_common: VhostUserCommon {
                vu: Some(Arc::new(Mutex::new(vu))),
                acked_protocol_features,
                socket_path: vu_cfg.socket,
                vu_num_queues,
                vring_bases,
                ..VhostUserCommon::new(virtio_common)
            },
            id,
            config: Arc::new(Mutex::new(config)),
            seccomp_action,
            exit_evt,
        })
    }

    fn state(&self) -> result::Result<State, MigratableError> {
        // Release the config lock before vu_common.state() locks vu.
        let config = *self.config.lock().unwrap();
        self.vu_common.state(config)
    }
}

impl Drop for Blk {
    fn drop(&mut self) {
        self.vu_common.shutdown();
    }
}

impl VirtioDevice for Blk {
    fn device_type(&self) -> u32 {
        self.vu_common.virtio_common.device_type
    }

    fn queue_max_sizes(&self) -> &[u16] {
        &self.vu_common.virtio_common.queue_sizes
    }

    fn features(&self) -> u64 {
        self.vu_common.virtio_common.avail_features
    }

    fn ack_features(&mut self, value: u64) {
        self.vu_common.virtio_common.ack_features(value);
    }

    fn read_config(&self, offset: u64, data: &mut [u8]) {
        self.read_config_from_slice(self.config.lock().unwrap().as_slice(), offset, data);
    }

    fn write_config(&mut self, offset: u64, data: &[u8]) {
        // The "writeback" field is the only mutable field
        let writeback_offset = offset_of!(VirtioBlockConfig, writeback) as u64;
        if offset != writeback_offset || data.len() != size_of::<u8>() {
            error!(
                "Attempt to write to read-only field: offset {:x} length {}",
                offset,
                data.len()
            );
            return;
        }

        if let Some(vu) = &self.vu_common.vu {
            let mut vu = vu.lock().unwrap();
            let result = vu
                .socket_handle()
                .set_config(offset as u32, VhostUserConfigFlags::WRITABLE, data)
                .map_err(Error::VhostUserSetConfig);
            self.config.lock().unwrap().writeback = data[0];

            if let Err(e) = result {
                error!(
                    "Failed setting vhost-user-blk configuration for socket {} at offset 0x{offset:x} with length {}: {e:?}",
                    self.vu_common.socket_path,
                    data.len()
                );
            }
        } else {
            self.config.lock().unwrap().writeback = data[0];
        }
    }

    fn activate(&mut self, context: ActivationContext) -> ActivateResult {
        let ActivationContext {
            mem,
            interrupt_cb,
            queues,
            device_status,
        } = context;
        self.vu_common
            .virtio_common
            .activate(&queues, Arc::clone(&interrupt_cb))?;

        let backend_req_handler = if self.vu_common.acked_protocol_features
            & VhostUserProtocolFeatures::BACKEND_REQ.bits()
            != 0
        {
            let vu = self
                .vu_common
                .vu
                .as_ref()
                .ok_or(crate::ActivateError::BadActivate)?;
            let mut handler = FrontendReqHandler::new(Arc::new(BackendReqHandler {
                vu: Arc::clone(vu),
                config: Arc::clone(&self.config),
                num_queues: u16::try_from(self.vu_common.virtio_common.queue_sizes.len())
                    .map_err(|_| crate::ActivateError::VhostUserSetup(Error::BadQueueNum))?,
                interrupt_cb: Arc::clone(&interrupt_cb),
            }))
            .map_err(|e| {
                crate::ActivateError::VhostUserSetup(Error::FrontendReqHandlerCreation(e))
            })?;

            if self.vu_common.acked_protocol_features & VhostUserProtocolFeatures::REPLY_ACK.bits()
                != 0
            {
                handler.set_reply_ack_flag(true);
            }

            Some(handler)
        } else {
            None
        };

        // Run a dedicated thread for handling potential reconnections with
        // the backend.
        let (kill_evt, pause_evt) = self.vu_common.virtio_common.dup_eventfds()?;

        let mut handler = self.vu_common.activate(
            mem,
            &queues,
            Arc::clone(&interrupt_cb),
            self.vu_common.virtio_common.acked_features,
            backend_req_handler,
            kill_evt,
            pause_evt,
        )?;

        self.vu_common.spawn_worker(
            &self.id,
            &self.seccomp_action,
            Thread::VirtioVhostBlock,
            &self.exit_evt,
            Arc::clone(&device_status),
            Arc::clone(&interrupt_cb),
            move |pause_common| handler.run(pause_common),
        )?;

        Ok(())
    }

    fn reset(&mut self) {
        self.vu_common.reset(&self.id);
    }

    fn shutdown(&mut self) {
        self.vu_common.shutdown();
    }

    fn add_memory_region(&mut self, region: &Arc<GuestRegion>) -> result::Result<(), crate::Error> {
        self.vu_common.add_memory_region(region)
    }
}

impl Pausable for Blk {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.pause()?;
        self.vu_common.virtio_common.pause()
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.virtio_common.resume()?;
        self.vu_common.resume()
    }
}

impl Snapshottable for Blk {
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        self.vu_common.snapshot(&self.state()?)
    }
}
impl Transportable for Blk {}

impl Migratable for Blk {
    fn start_dirty_log(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.start_dirty_log()
    }

    fn stop_dirty_log(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.stop_dirty_log()
    }

    fn dirty_log(&mut self) -> result::Result<MemoryRangeTable, MigratableError> {
        self.vu_common.dirty_log()
    }

    fn notify_started_migration(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.notify_started_migration()
    }

    fn notify_failed_migration(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.notify_failed_migration()
    }

    fn notify_completed_migration(&mut self) -> result::Result<(), MigratableError> {
        self.vu_common.notify_completed_migration()
    }
}
