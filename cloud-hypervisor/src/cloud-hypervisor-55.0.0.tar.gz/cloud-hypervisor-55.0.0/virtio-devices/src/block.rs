// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// Copyright © 2020 Intel Corporation
//
// Copyright (c) Meta Platforms, Inc. and affiliates.
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::cmp::max;
use std::collections::{BTreeMap, HashMap, VecDeque};
use std::num::Wrapping;
use std::ops::Deref;
use std::os::unix::io::AsRawFd;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicU8, AtomicU64, AtomicUsize, Ordering};
use std::time::{Duration, Instant};
use std::{io, mem, result, thread};

use anyhow::anyhow;
use block::async_io::AsyncIo;
use block::disk_file::AsyncFullDiskFile;
use block::error::BlockError;
use block::fcntl::{LockError, LockGranularity, LockGranularityChoice, LockType, get_lock_state};
use block::{
    ExecuteAsync, ExecuteError, MAX_DISCARD_WRITE_ZEROES_SEG, Request, RequestType,
    VirtioBlockConfig, build_serial, fcntl,
};
use event_monitor::event;
use log::{debug, error, info, warn};
use rate_limiter::TokenType;
use rate_limiter::group::{RateLimiterGroup, RateLimiterGroupHandle};
use seccompiler::SeccompAction;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use virtio_bindings::virtio_blk::*;
use virtio_bindings::virtio_config::*;
use virtio_bindings::virtio_ring::{VIRTIO_RING_F_EVENT_IDX, VIRTIO_RING_F_INDIRECT_DESC};
use virtio_queue::{Queue, QueueOwnedT, QueueT};
use vm_memory::{
    ByteValued, Bytes, GuestAddress, GuestAddressSpace, GuestMemoryAtomic, GuestMemoryError,
};
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vm_virtio::AccessPlatform;
use vmm_sys_util::eventfd::EventFd;

use super::{
    ActivateError, ActivateResult, EPOLL_HELPER_EVENT_LAST, EpollHelper, EpollHelperError,
    EpollHelperHandler, Error as DeviceError, VirtioCommon, VirtioDevice, VirtioDeviceType,
    VirtioInterruptType,
};
use crate::device::ActivationContext;
use crate::seccomp_filters::Thread;
use crate::thread_helper::PauseCommon;
use crate::{GuestMemory, VirtioInterrupt};

const SECTOR_SHIFT: u8 = 9;
pub const SECTOR_SIZE: u64 = 0x01 << SECTOR_SHIFT;

// New descriptors are pending on the virtio queue.
const QUEUE_AVAIL_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 1;
// New completed tasks are pending on the completion ring.
const COMPLETION_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 2;
// New 'wake up' event from the rate limiter
const RATE_LIMITER_EVENT: u16 = EPOLL_HELPER_EVENT_LAST + 3;

// latency scale, for reduce precision loss in calculate.
const LATENCY_SCALE: u64 = 10000;

pub const MINIMUM_BLOCK_QUEUE_SIZE: u16 = 2;

#[derive(Error, Debug)]
pub enum Error {
    #[error("Failed to complete the request")]
    RequestCompleting(#[source] block::Error),
    #[error("Missing the expected entry in the list of requests")]
    MissingEntryRequestList,
    #[error("Failed adding used index")]
    QueueAddUsed(#[source] virtio_queue::Error),
    #[error("Failed creating an iterator over the queue")]
    QueueIterator(#[source] virtio_queue::Error),
    #[error("Duplicated head index in the queue")]
    QueueDuplicatedHeadIndex,
    #[error("Failed to update request status")]
    RequestStatus(#[source] GuestMemoryError),
    #[error("Failed to enable notification")]
    QueueEnableNotification(#[source] virtio_queue::Error),
    #[error("Failed to get {lock_type:?} lock for disk image: {path}")]
    LockDiskImage {
        /// The underlying error.
        #[source]
        error: LockError,
        /// The requested lock type.
        lock_type: LockType,
        /// The path of the disk image.
        path: PathBuf,
    },
    #[error("Disk image size is not a multiple of {}", SECTOR_SIZE)]
    InvalidSize,
    #[error("Failed to pause worker thread")]
    Pause(#[source] MigratableError),
    #[error("Failed to resume worker thread")]
    Resume(#[source] MigratableError),
    #[error("Failed signal config interrupt")]
    ConfigChange(#[source] io::Error),
    #[error("Disk resize failed")]
    DiskResize(#[source] BlockError),
}

pub type Result<T> = result::Result<T, Error>;

// latency will be records as microseconds, average latency
// will be save as scaled value.
#[derive(Clone)]
pub struct BlockCounters {
    read_bytes: Arc<AtomicU64>,
    read_ops: Arc<AtomicU64>,
    read_latency_min: Arc<AtomicU64>,
    read_latency_max: Arc<AtomicU64>,
    read_latency_avg: Arc<AtomicU64>,
    write_bytes: Arc<AtomicU64>,
    write_ops: Arc<AtomicU64>,
    write_latency_min: Arc<AtomicU64>,
    write_latency_max: Arc<AtomicU64>,
    write_latency_avg: Arc<AtomicU64>,
}

impl Default for BlockCounters {
    fn default() -> Self {
        BlockCounters {
            read_bytes: Arc::new(AtomicU64::new(0)),
            read_ops: Arc::new(AtomicU64::new(0)),
            read_latency_min: Arc::new(AtomicU64::new(u64::MAX)),
            read_latency_max: Arc::new(AtomicU64::new(u64::MAX)),
            read_latency_avg: Arc::new(AtomicU64::new(u64::MAX)),
            write_bytes: Arc::new(AtomicU64::new(0)),
            write_ops: Arc::new(AtomicU64::new(0)),
            write_latency_min: Arc::new(AtomicU64::new(u64::MAX)),
            write_latency_max: Arc::new(AtomicU64::new(u64::MAX)),
            write_latency_avg: Arc::new(AtomicU64::new(u64::MAX)),
        }
    }
}

/// Releases one active request count when dropped.
struct ActiveRequestGuard {
    counter: Arc<AtomicUsize>,
}

impl ActiveRequestGuard {
    fn new(counter: &Arc<AtomicUsize>) -> Self {
        Self {
            counter: Arc::clone(counter),
        }
    }
}

impl Drop for ActiveRequestGuard {
    fn drop(&mut self) {
        let previous = self.counter.fetch_sub(1, Ordering::SeqCst);
        debug_assert!(previous > 0);
    }
}

struct BlockEpollHandler {
    queue_index: u16,
    queue: Queue,
    mem: GuestMemoryAtomic<GuestMemory>,
    disk_image: Box<dyn AsyncIo>,
    disk_nsectors: Arc<AtomicU64>,
    interrupt_cb: Arc<dyn VirtioInterrupt>,
    serial: Box<[u8]>,
    kill_evt: EventFd,
    pause_evt: EventFd,
    writeback: Arc<AtomicBool>,
    counters: BlockCounters,
    queue_evt: EventFd,
    inflight_requests: VecDeque<(u16, Request, GuestAddress)>,
    // The active count includes `inflight_requests` plus requests in transition
    // from the queue to inflight or inflight to completion.
    active_request_count: Arc<AtomicUsize>,
    // True when draining before pause.
    draining_active_requests: Arc<AtomicBool>,
    rate_limiter: Option<RateLimiterGroupHandle>,
    access_platform: Option<Arc<dyn AccessPlatform>>,
    host_cpus: Option<Box<[usize]>>,
    acked_features: u64,
}

fn has_feature(features: u64, feature_flag: u64) -> bool {
    (features & (1u64 << feature_flag)) != 0
}

impl BlockEpollHandler {
    fn check_request(features: u64, request: &Request) -> result::Result<(), ExecuteError> {
        let request_type = request.request_type();
        if (has_feature(features, VIRTIO_BLK_F_RO.into()))
            && matches!(
                request_type,
                RequestType::Out | RequestType::Discard | RequestType::WriteZeroes
            )
        {
            // For virtio spec compliance
            // "A device MUST set the status byte to VIRTIO_BLK_S_IOERR for a write request
            // if the VIRTIO_BLK_F_RO feature if offered, and MUST NOT write any data."
            warn!(
                "Rejecting block request {request_type:?}: device is read-only (VIRTIO_BLK_F_RO negotiated)"
            );
            return Err(ExecuteError::ReadOnly);
        }

        Ok(())
    }

    // A spec-compliant driver never reuses a virtqueue head_index while the
    // corresponding chain is still available (virtio 1.x §2.7.13.4).
    // Double check the guest driver is behaving.
    fn is_head_in_flight(
        inflight: &VecDeque<(u16, Request, GuestAddress)>,
        batch: &[(u16, Request, GuestAddress)],
        head: u16,
    ) -> bool {
        batch.iter().any(|(h, ..)| *h == head) || inflight.iter().any(|(h, ..)| *h == head)
    }

    fn process_queue_submit(&mut self) -> Result<()> {
        // Artificially bump the active counter while submitting so pause doesn't
        // race and read a zero.
        self.active_request_count.fetch_add(1, Ordering::SeqCst);
        let _active_request = ActiveRequestGuard::new(&self.active_request_count);
        // Clone the Arc so the `self.queue` mutable borrow is allowed.
        let draining_active_requests = Arc::clone(&self.draining_active_requests);
        if draining_active_requests.load(Ordering::SeqCst) {
            return Ok(());
        }

        let queue = &mut self.queue;
        let queue_size = queue.size();
        let mut batch_requests = Vec::new();
        let mut batch_inflight_requests = Vec::new();
        let mut processed = 0;

        loop {
            // Cap a single drain at the virtqueue size. A compliant driver won't submit more that
            // queue_size, but a buggy or malicious one can keep adding as the VMM is reading.
            if processed >= queue_size {
                break;
            }
            if draining_active_requests.load(Ordering::SeqCst) {
                break;
            }
            processed += 1;
            let mut desc_chain = match queue
                .iter(self.mem.memory())
                .map_err(Error::QueueIterator)?
                .next()
            {
                Some(c) => c,
                None => break,
            };

            let head = desc_chain.head_index();
            if Self::is_head_in_flight(&self.inflight_requests, &batch_inflight_requests, head) {
                warn!("Guest reused virtio-blk head_index {head} while the chain was used");
                return Err(Error::QueueDuplicatedHeadIndex);
            }

            let result = Request::parse(&mut desc_chain, self.access_platform.as_deref());
            let (mut request, status_addr) = match result {
                (Ok(request), Some(status_addr)) => (request, status_addr),
                (Ok(_), None) => unreachable!("parse() returns the status address with a request"),
                (Err(e), status_addr) => {
                    warn!("Failed to parse virtio-blk request at head {head}: {e}");
                    if let Some(status_addr) = status_addr {
                        desc_chain
                            .memory()
                            .write_obj(VIRTIO_BLK_S_IOERR as u8, status_addr)
                            .map_err(Error::RequestStatus)?;
                    }
                    queue
                        .add_used(desc_chain.memory(), head, 0)
                        .map_err(Error::QueueAddUsed)?;
                    queue
                        .enable_notification(desc_chain.memory())
                        .map_err(Error::QueueEnableNotification)?;
                    continue;
                }
            };

            // For virtio spec compliance
            // "A device MUST set the status byte to VIRTIO_BLK_S_IOERR for a write request
            // if the VIRTIO_BLK_F_RO feature if offered, and MUST NOT write any data."
            if let Err(e) = Self::check_request(self.acked_features, &request) {
                warn!("Request check failed: {request:x?} {e:?}");
                desc_chain
                    .memory()
                    .write_obj(VIRTIO_BLK_S_IOERR as u8, status_addr)
                    .map_err(Error::RequestStatus)?;

                // If no asynchronous operation has been submitted, we can
                // simply return the used descriptor.
                queue
                    .add_used(desc_chain.memory(), desc_chain.head_index(), 1)
                    .map_err(Error::QueueAddUsed)?;
                queue
                    .enable_notification(desc_chain.memory())
                    .map_err(Error::QueueEnableNotification)?;
                continue;
            }

            if let Some(rate_limiter) = &mut self.rate_limiter {
                // If limiter.consume() fails it means there is no more TokenType::Ops
                // budget and rate limiting is in effect.
                if !rate_limiter.consume(1, TokenType::Ops) {
                    // Stop processing the queue and return this descriptor chain to the
                    // avail ring, for later processing.
                    queue.go_to_previous_position();
                    break;
                }
                // Exercise the rate limiter only if this request is of data transfer type.
                if request.request_type() == RequestType::In
                    || request.request_type() == RequestType::Out
                {
                    let mut bytes = Wrapping(0);
                    for (_, data_len) in request.data_descriptors() {
                        bytes += Wrapping(*data_len as u64);
                    }

                    // If limiter.consume() fails it means there is no more TokenType::Bytes
                    // budget and rate limiting is in effect.
                    if !rate_limiter.consume(bytes.0, TokenType::Bytes) {
                        // Revert the OPS consume().
                        rate_limiter.manual_replenish(1, TokenType::Ops);
                        // Stop processing the queue and return this descriptor chain to the
                        // avail ring, for later processing.
                        queue.go_to_previous_position();
                        break;
                    }
                }
            }

            request.writeback = self.writeback.load(Ordering::Acquire);

            let result = request.execute_async(
                self.mem.memory().into_inner(),
                self.disk_nsectors.load(Ordering::SeqCst),
                self.disk_image.as_mut(),
                &self.serial,
                desc_chain.head_index() as u64,
            );

            if let Ok(ExecuteAsync {
                async_complete: true,
                batch_request,
            }) = result
            {
                if let Some(batch_request) = batch_request {
                    batch_requests.push(batch_request);
                    batch_inflight_requests.push((desc_chain.head_index(), request, status_addr));
                } else {
                    self.inflight_requests.push_back((
                        desc_chain.head_index(),
                        request,
                        status_addr,
                    ));
                    self.active_request_count.fetch_add(1, Ordering::SeqCst);
                }
            } else {
                let status = match result {
                    Ok(_) => VIRTIO_BLK_S_OK,
                    Err(e) => {
                        warn!("Request failed: {request:x?} {e:?}");
                        e.status() as u32
                    }
                };

                desc_chain
                    .memory()
                    .write_obj(status as u8, status_addr)
                    .map_err(Error::RequestStatus)?;

                let len = if status == VIRTIO_BLK_S_OK
                    && request.request_type() == RequestType::GetDeviceId
                {
                    self.serial.len() as u32 + 1
                } else {
                    1
                };
                // If no asynchronous operation has been submitted, we can
                // simply return the used descriptor.
                queue
                    .add_used(desc_chain.memory(), desc_chain.head_index(), len)
                    .map_err(Error::QueueAddUsed)?;
                queue
                    .enable_notification(desc_chain.memory())
                    .map_err(Error::QueueEnableNotification)?;
            }
        }

        if !batch_requests.is_empty() {
            match self.disk_image.submit_batch_requests(batch_requests) {
                Ok(()) => {
                    let batch_len = batch_inflight_requests.len();
                    self.inflight_requests.extend(batch_inflight_requests);
                    self.active_request_count
                        .fetch_add(batch_len, Ordering::SeqCst);
                }
                Err(e) => {
                    // If batch submission fails, report VIRTIO_BLK_S_IOERR for all requests.
                    for (user_data, request, status_addr) in batch_inflight_requests {
                        warn!("Request failed with batch submission: {request:x?} {e:?}");
                        let desc_index = user_data;
                        let mem = self.mem.memory();
                        mem.write_obj(VIRTIO_BLK_S_IOERR as u8, status_addr)
                            .map_err(Error::RequestStatus)?;
                        queue
                            .add_used(mem.deref(), desc_index, 1)
                            .map_err(Error::QueueAddUsed)?;
                        queue
                            .enable_notification(mem.deref())
                            .map_err(Error::QueueEnableNotification)?;
                    }
                }
            }
        }

        Ok(())
    }

    fn try_signal_used_queue(&mut self) -> result::Result<(), EpollHelperError> {
        if self
            .queue
            .needs_notification(self.mem.memory().deref())
            .map_err(|e| {
                EpollHelperError::HandleEvent(anyhow!("Failed to check needs_notification: {e:?}"))
            })?
        {
            self.signal_used_queue().map_err(|e| {
                EpollHelperError::HandleEvent(anyhow!("Failed to signal used queue: {e:?}"))
            })?;
        }

        Ok(())
    }

    fn process_queue_submit_and_signal(&mut self) -> result::Result<(), EpollHelperError> {
        match self.process_queue_submit() {
            Ok(()) => {}
            Err(e @ (Error::QueueIterator(_) | Error::QueueDuplicatedHeadIndex)) => {
                // Virtqueue is corrupted or guest driver is misbehaving; exit
                // the worker so spawn_worker marks the device NEEDS_RESET.
                return Err(EpollHelperError::HandleEvent(anyhow!(
                    "Failed to process queue (submit): {e}"
                )));
            }
            Err(e) => {
                // Per-request errors are logged but non-device fatal.
                warn!("Failed to process queue (submit): {e}");
            }
        }

        self.try_signal_used_queue()
    }

    #[inline]
    fn find_inflight_request(&mut self, completed_head: u16) -> Result<(Request, GuestAddress)> {
        // This loop neatly handles the fast path where the completions are
        // in order (it turns into just a pop_front()) and the 1% of the time
        // (analysis during boot) where slight out of ordering has been
        // observed e.g.
        // Submissions: 1 2 3 4 5 6 7
        // Completions: 2 1 3 5 4 7 6
        // In this case find the corresponding item and swap it with the front
        // This is a O(1) operation and is prepared for the future as it it likely
        // the next completion would be for the one that was skipped which will
        // now be the new front.
        for (i, (head, ..)) in self.inflight_requests.iter().enumerate() {
            if head == &completed_head {
                let (_, request, status_addr) =
                    self.inflight_requests.swap_remove_front(i).unwrap();
                return Ok((request, status_addr));
            }
        }

        Err(Error::MissingEntryRequestList)
    }

    fn process_queue_complete(&mut self) -> Result<()> {
        let mem = self.mem.memory();
        let mut read_bytes = Wrapping(0);
        let mut write_bytes = Wrapping(0);
        let mut read_ops = Wrapping(0);
        let mut write_ops = Wrapping(0);

        while let Some(mut completion) = self.disk_image.next_completed_request() {
            let mut result = completion.result;
            let desc_index = completion.user_data as u16;

            let (mut request, status_addr) = self.find_inflight_request(desc_index)?;
            let _active_request = ActiveRequestGuard::new(&self.active_request_count);

            request
                .complete_async(&*mem, &mut completion)
                .map_err(Error::RequestCompleting)?;

            // Generate a virtio-block error if the fsync fails and writethrough requested
            if result >= 0
                && request.request_type() == RequestType::Out
                && !request.writeback
                && let Err(e) = self.disk_image.fsync(None)
            {
                warn!("Writethrough fsync failed: {e}");
                result = -libc::EIO;
            }

            let latency = request.start().elapsed().as_micros() as u64;
            let read_ops_last = self.counters.read_ops.load(Ordering::Relaxed);
            let write_ops_last = self.counters.write_ops.load(Ordering::Relaxed);
            let read_max = self.counters.read_latency_max.load(Ordering::Relaxed);
            let write_max = self.counters.write_latency_max.load(Ordering::Relaxed);
            let mut read_avg = self.counters.read_latency_avg.load(Ordering::Relaxed);
            let mut write_avg = self.counters.write_latency_avg.load(Ordering::Relaxed);

            let expected_len: usize = request
                .data_descriptors()
                .iter()
                .map(|(_, len)| *len as usize)
                .sum();

            let (status, len) = if result < 0 {
                warn!(
                    "Request failed: {:x?} {:?}",
                    request,
                    io::Error::from_raw_os_error(-result)
                );
                (VIRTIO_BLK_S_IOERR as u8, 1)
            } else if matches!(request.request_type(), RequestType::In | RequestType::Out)
                && result as usize != expected_len
            {
                warn!(
                    "Unexpected completion length for {:?}: got {} bytes, expected {}",
                    request.request_type(),
                    result,
                    expected_len
                );
                (VIRTIO_BLK_S_IOERR as u8, 1)
            } else {
                match request.request_type() {
                    RequestType::In => {
                        for (_, data_len) in request.data_descriptors() {
                            read_bytes += Wrapping(*data_len as u64);
                        }
                        read_ops += Wrapping(1);
                        if latency < self.counters.read_latency_min.load(Ordering::Relaxed) {
                            self.counters
                                .read_latency_min
                                .store(latency, Ordering::Relaxed);
                        }
                        if latency > read_max || read_max == u64::MAX {
                            self.counters
                                .read_latency_max
                                .store(latency, Ordering::Relaxed);
                        }

                        // Special case the first real latency report
                        read_avg = if read_avg == u64::MAX {
                            latency * LATENCY_SCALE
                        } else {
                            // Cumulative average is guaranteed to be
                            // positive if being calculated properly
                            (read_avg as i64
                                + ((latency * LATENCY_SCALE) as i64 - read_avg as i64)
                                    / (read_ops_last + read_ops.0) as i64)
                                .try_into()
                                .unwrap()
                        };
                    }
                    RequestType::Out => {
                        for (_, data_len) in request.data_descriptors() {
                            write_bytes += Wrapping(*data_len as u64);
                        }
                        write_ops += Wrapping(1);
                        if latency < self.counters.write_latency_min.load(Ordering::Relaxed) {
                            self.counters
                                .write_latency_min
                                .store(latency, Ordering::Relaxed);
                        }
                        if latency > write_max || write_max == u64::MAX {
                            self.counters
                                .write_latency_max
                                .store(latency, Ordering::Relaxed);
                        }

                        // Special case the first real latency report
                        write_avg = if write_avg == u64::MAX {
                            latency * LATENCY_SCALE
                        } else {
                            // Cumulative average is guaranteed to be
                            // positive if being calculated properly
                            (write_avg as i64
                                + ((latency * LATENCY_SCALE) as i64 - write_avg as i64)
                                    / (write_ops_last + write_ops.0) as i64)
                                .try_into()
                                .unwrap()
                        }
                    }
                    _ => {}
                }

                self.counters
                    .read_latency_avg
                    .store(read_avg, Ordering::Relaxed);

                self.counters
                    .write_latency_avg
                    .store(write_avg, Ordering::Relaxed);

                let len = if request.request_type() == RequestType::In {
                    result as u32 + 1
                } else {
                    1
                };
                (VIRTIO_BLK_S_OK as u8, len)
            };

            mem.write_obj(status, status_addr)
                .map_err(Error::RequestStatus)?;

            let queue = &mut self.queue;

            queue
                .add_used(mem.deref(), desc_index, len)
                .map_err(Error::QueueAddUsed)?;
            queue
                .enable_notification(mem.deref())
                .map_err(Error::QueueEnableNotification)?;
        }

        self.counters
            .write_bytes
            .fetch_add(write_bytes.0, Ordering::AcqRel);
        self.counters
            .write_ops
            .fetch_add(write_ops.0, Ordering::AcqRel);

        self.counters
            .read_bytes
            .fetch_add(read_bytes.0, Ordering::AcqRel);
        self.counters
            .read_ops
            .fetch_add(read_ops.0, Ordering::AcqRel);

        Ok(())
    }

    fn signal_used_queue(&self) -> result::Result<(), DeviceError> {
        self.interrupt_cb
            .trigger(VirtioInterruptType::Queue(self.queue_index))
            .map_err(|e| {
                error!("Failed to signal used queue: {e:?}");
                DeviceError::FailedSignalingUsedQueue(e)
            })
    }

    fn set_queue_thread_affinity(&self) {
        // Prepare the CPU set the current queue thread is expected to run onto.
        let cpuset = self.host_cpus.as_ref().map(|host_cpus| {
            // SAFETY: all zeros is a valid pattern
            let mut cpuset: libc::cpu_set_t = unsafe { mem::zeroed() };
            // SAFETY: FFI call, trivially safe
            unsafe { libc::CPU_ZERO(&mut cpuset) };
            for host_cpu in host_cpus {
                // SAFETY: FFI call, trivially safe
                unsafe { libc::CPU_SET(*host_cpu, &mut cpuset) };
            }
            cpuset
        });

        // Schedule the thread to run on the expected CPU set
        if let Some(cpuset) = cpuset.as_ref() {
            let cpuset: *const libc::cpu_set_t = cpuset;
            // SAFETY: FFI call with correct arguments
            let ret = unsafe { libc::sched_setaffinity(0, size_of::<libc::cpu_set_t>(), cpuset) };

            if ret != 0 {
                error!(
                    "Failed scheduling the virtqueue thread {} on the expected CPU set: {}",
                    self.queue_index,
                    io::Error::last_os_error()
                );
            }
        }
    }

    fn run(&mut self, pause_common: &PauseCommon) -> result::Result<(), EpollHelperError> {
        let mut helper = EpollHelper::new(&self.kill_evt, &self.pause_evt)?;
        helper.add_event(self.queue_evt.as_raw_fd(), QUEUE_AVAIL_EVENT)?;
        helper.add_event(self.disk_image.notifier().as_raw_fd(), COMPLETION_EVENT)?;
        if let Some(rate_limiter) = &self.rate_limiter {
            helper.add_event(rate_limiter.as_raw_fd(), RATE_LIMITER_EVENT)?;
        }
        self.set_queue_thread_affinity();
        helper.run(pause_common, self)?;

        Ok(())
    }
}

impl EpollHelperHandler for BlockEpollHandler {
    fn handle_event(
        &mut self,
        _helper: &mut EpollHelper,
        event: &epoll::Event,
    ) -> result::Result<(), EpollHelperError> {
        let ev_type = event.data as u16;
        match ev_type {
            QUEUE_AVAIL_EVENT => {
                self.queue_evt.read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get queue event: {e:?}"))
                })?;

                let rate_limit_reached = self.rate_limiter.as_ref().is_some_and(|r| r.is_blocked());

                // Process the queue only when the rate limit is not reached
                if !rate_limit_reached {
                    self.process_queue_submit_and_signal()?;
                }
            }
            COMPLETION_EVENT => {
                self.disk_image.notifier().read().map_err(|e| {
                    EpollHelperError::HandleEvent(anyhow!("Failed to get queue event: {e:?}"))
                })?;

                if let Err(e) = self.process_queue_complete() {
                    warn!("Failed to process queue (complete): {e:?}");
                }

                self.try_signal_used_queue()?;

                let rate_limit_reached = self.rate_limiter.as_ref().is_some_and(|r| r.is_blocked());

                // Process the queue only when the rate limit is not reached
                if !rate_limit_reached {
                    self.process_queue_submit_and_signal()?;
                }
            }
            RATE_LIMITER_EVENT => {
                if let Some(rate_limiter) = &mut self.rate_limiter {
                    // Upon rate limiter event, call the rate limiter handler
                    // and restart processing the queue.
                    rate_limiter.event_handler().map_err(|e| {
                        EpollHelperError::HandleEvent(anyhow!(
                            "Failed to process rate limiter event: {e:?}"
                        ))
                    })?;

                    self.process_queue_submit_and_signal()?;
                } else {
                    return Err(EpollHelperError::HandleEvent(anyhow!(
                        "Unexpected 'RATE_LIMITER_EVENT' when rate_limiter is not enabled."
                    )));
                }
            }
            _ => {
                return Err(EpollHelperError::HandleEvent(anyhow!(
                    "Unexpected event: {ev_type}"
                )));
            }
        }
        Ok(())
    }
}

/// Virtio device for exposing block level read/write operations on a host file.
pub struct Block {
    common: VirtioCommon,
    id: String,
    disk_image: Box<dyn AsyncFullDiskFile>,
    disk_path: PathBuf,
    disk_nsectors: Arc<AtomicU64>,
    config: VirtioBlockConfig,
    writeback: Arc<AtomicBool>,
    counters: BlockCounters,
    seccomp_action: SeccompAction,
    rate_limiter: Option<Arc<RateLimiterGroup>>,
    exit_evt: EventFd,
    serial: Box<[u8]>,
    queue_affinity: BTreeMap<u16, Box<[usize]>>,
    lock_granularity_choice: LockGranularityChoice,
    device_status: Arc<AtomicU8>,
    active_request_count: Arc<AtomicUsize>,
    draining_active_requests: Arc<AtomicBool>,
}

#[derive(Serialize, Deserialize)]
pub struct BlockState {
    pub disk_path: String,
    pub disk_nsectors: u64,
    pub avail_features: u64,
    pub acked_features: u64,
    pub config: VirtioBlockConfig,
}

impl Block {
    /// Create a new virtio block device that operates on the given file.
    #[expect(clippy::too_many_arguments)]
    pub fn new(
        id: String,
        disk_image: Box<dyn AsyncFullDiskFile>,
        disk_path: PathBuf,
        read_only: bool,
        access_platform_enabled: bool,
        num_queues: u16,
        queue_size: u16,
        serial: Option<&str>,
        seccomp_action: SeccompAction,
        rate_limiter: Option<Arc<RateLimiterGroup>>,
        exit_evt: EventFd,
        state: Option<BlockState>,
        queue_affinity: BTreeMap<u16, Box<[usize]>>,
        sparse: bool,
        lock_granularity: LockGranularityChoice,
        guest_block_size: Option<u32>,
    ) -> io::Result<Self> {
        let (disk_nsectors, avail_features, acked_features, config, paused) =
            if let Some(state) = state {
                info!("Restoring virtio-block {id}");
                (
                    state.disk_nsectors,
                    state.avail_features,
                    state.acked_features,
                    state.config,
                    true,
                )
            } else {
                let disk_size = disk_image
                    .logical_size()
                    .map_err(|e| io::Error::other(format!("Failed getting disk size: {e}")))?;
                if !disk_size.is_multiple_of(SECTOR_SIZE) {
                    warn!(
                        "Disk size {disk_size} is not a multiple of sector size {SECTOR_SIZE}; \
                 the remainder will not be visible to the guest."
                    );
                }

                let mut avail_features = (1u64 << VIRTIO_F_VERSION_1)
                    | (1u64 << VIRTIO_BLK_F_FLUSH)
                    | (1u64 << VIRTIO_BLK_F_CONFIG_WCE)
                    | (1u64 << VIRTIO_BLK_F_BLK_SIZE)
                    | (1u64 << VIRTIO_BLK_F_TOPOLOGY)
                    | (1u64 << VIRTIO_BLK_F_SEG_MAX)
                    | (1u64 << VIRTIO_RING_F_EVENT_IDX)
                    | (1u64 << VIRTIO_RING_F_INDIRECT_DESC);

                // When backend supports sparse operations:
                // - Always advertise WRITE_ZEROES (safe for all drivers)
                // - Advertise DISCARD only when sparse=true, since DISCARD
                //   deallocates space via punch_hole and should require
                //   explicit user opt in.
                let mut discard_supported = false;
                if disk_image.supports_sparse_operations() {
                    avail_features |= 1u64 << VIRTIO_BLK_F_WRITE_ZEROES;
                    if sparse {
                        avail_features |= 1u64 << VIRTIO_BLK_F_DISCARD;
                        discard_supported = true;
                    }
                } else if sparse {
                    warn!("sparse=on requested but backend does not support sparse operations");
                }

                if access_platform_enabled {
                    avail_features |= 1u64 << VIRTIO_F_ACCESS_PLATFORM;
                }

                if read_only {
                    avail_features |= 1u64 << VIRTIO_BLK_F_RO;
                }

                let mut topology = disk_image.topology();
                if let Some(block_size) = guest_block_size {
                    topology = topology.with_block_size(block_size as u64);
                }
                info!("Disk topology: {topology:?}");

                let logical_block_size = if topology.logical_block_size > 512 {
                    topology.logical_block_size
                } else {
                    512
                };

                // Calculate the exponent that maps physical block to logical block
                let mut physical_block_exp = 0;
                let mut size = logical_block_size;
                while size < topology.physical_block_size {
                    physical_block_exp += 1;
                    size <<= 1;
                }

                let disk_nsectors = disk_size / SECTOR_SIZE;
                let mut config = VirtioBlockConfig {
                    capacity: disk_nsectors,
                    writeback: 1,
                    blk_size: topology.logical_block_size as u32,
                    physical_block_exp,
                    min_io_size: (topology.minimum_io_size / logical_block_size) as u16,
                    opt_io_size: (topology.optimal_io_size / logical_block_size) as u32,
                    seg_max: (queue_size - MINIMUM_BLOCK_QUEUE_SIZE) as u32,
                    ..Default::default()
                };

                if avail_features & (1u64 << VIRTIO_BLK_F_WRITE_ZEROES) != 0 {
                    config.max_write_zeroes_sectors = u32::MAX;
                    config.max_write_zeroes_seg = MAX_DISCARD_WRITE_ZEROES_SEG;
                    config.write_zeroes_may_unmap = if discard_supported { 1 } else { 0 };
                }
                if avail_features & (1u64 << VIRTIO_BLK_F_DISCARD) != 0 {
                    config.max_discard_sectors = u32::MAX;
                    config.max_discard_seg = MAX_DISCARD_WRITE_ZEROES_SEG;
                    config.discard_sector_alignment = (logical_block_size / SECTOR_SIZE) as u32;
                }

                if num_queues > 1 {
                    avail_features |= 1u64 << VIRTIO_BLK_F_MQ;
                    config.num_queues = num_queues;
                }

                (disk_nsectors, avail_features, 0, config, false)
            };

        let serial = build_serial(serial, &disk_path).into_boxed_slice();

        Ok(Block {
            common: VirtioCommon {
                device_type: VirtioDeviceType::Block as u32,
                avail_features,
                acked_features,
                queue_sizes: vec![queue_size; num_queues as usize],
                min_queues: 1,
                ..VirtioCommon::new(paused)?
            },
            id,
            disk_image,
            disk_path,
            disk_nsectors: Arc::new(AtomicU64::new(disk_nsectors)),
            config,
            writeback: Arc::new(AtomicBool::new(true)),
            counters: BlockCounters::default(),
            seccomp_action,
            rate_limiter,
            exit_evt,
            serial,
            queue_affinity,
            lock_granularity_choice: lock_granularity,
            device_status: Arc::new(AtomicU8::new(0)),
            active_request_count: Arc::new(AtomicUsize::new(0)),
            draining_active_requests: Arc::new(AtomicBool::new(false)),
        })
    }

    fn wait_for_active_requests(&self) -> result::Result<(), anyhow::Error> {
        const BLOCK_PAUSE_DRAIN_TIMEOUT: Duration = Duration::from_secs(30);
        const BLOCK_PAUSE_FIRST_DRAIN_WARNING: Duration = Duration::from_secs(1);
        const BLOCK_PAUSE_DRAIN_WARNING_INTERVAL: Duration = Duration::from_secs(5);

        let started = Instant::now();
        let mut next_warning = BLOCK_PAUSE_FIRST_DRAIN_WARNING;

        loop {
            let active = self.active_request_count.load(Ordering::SeqCst);
            if active == 0 {
                return Ok(());
            }

            let elapsed = started.elapsed();
            if elapsed >= BLOCK_PAUSE_DRAIN_TIMEOUT {
                return Err(anyhow!("timed out draining block requests"));
            }

            if elapsed >= next_warning {
                warn!("pause: still waiting for {active} active block requests after {elapsed:?}");
                next_warning += BLOCK_PAUSE_DRAIN_WARNING_INTERVAL;
            }

            thread::yield_now();
        }
    }

    fn read_only(&self) -> bool {
        has_feature(self.features(), VIRTIO_BLK_F_RO.into())
    }

    /// Returns the granularity for the advisory lock for this disk.
    fn lock_granularity(&mut self) -> LockGranularity {
        match self.lock_granularity_choice {
            LockGranularityChoice::Full => LockGranularity::WholeFile,
            LockGranularityChoice::ByteRange => {
                // Byte range lock covering [0, max(logical, physical))
                // logical > physical for sparse files, physical > logical
                // for small dense files due to filesystem block rounding.
                let logical = self.disk_image.logical_size();
                let physical = self.disk_image.physical_size();
                match (logical, physical) {
                    (Ok(l), Ok(p)) => LockGranularity::ByteRange(0, max(l, p)),
                    (Ok(l), Err(_)) => LockGranularity::ByteRange(0, l),
                    (Err(_), Ok(p)) => LockGranularity::ByteRange(0, p),
                    (Err(e), Err(_)) => {
                        let fallback = LockGranularity::WholeFile;
                        warn!(
                            "Can't get disk size for id={},path={}, falling back to {:?}: error: {e}",
                            self.id,
                            self.disk_path.display(),
                            fallback
                        );
                        fallback
                    }
                }
            }
        }
    }

    /// Tries to set an advisory lock for the corresponding disk image.
    pub fn try_lock_image(&mut self) -> Result<()> {
        let lock_type = match self.read_only() {
            true => LockType::Read,
            false => LockType::Write,
        };
        let granularity = self.lock_granularity();
        debug!(
            "Attempting to acquire {lock_type:?} lock for disk image: id={},path={},granularity={granularity:?}",
            self.id,
            self.disk_path.display()
        );
        let fd = self.disk_image.fd();
        fcntl::try_acquire_lock(&fd, lock_type, granularity).map_err(|error| {
            let current_lock = get_lock_state(&fd, granularity);
            // Don't propagate the error to the outside, as it is not useful at all. Instead,
            // we try to log additional help to the user.
            if let Ok(current_lock) = current_lock {
                error!("Can't get {lock_type:?} lock for {} as there is already a {current_lock:?} lock", self.disk_path.display());
            } else {
                error!("Can't get {lock_type:?} lock for {}, but also can't determine the current lock state", self.disk_path.display());
            }
            Error::LockDiskImage {
                path: self.disk_path.clone(),
                error,
                lock_type,
            }
        })?;
        info!(
            "Acquired {lock_type:?} lock for disk image id={},path={}",
            self.id,
            self.disk_path.display()
        );
        Ok(())
    }

    /// Releases the advisory lock held for the corresponding disk image.
    pub fn unlock_image(&mut self) -> Result<()> {
        let granularity = self.lock_granularity();

        // It is very unlikely that this fails;
        // Should we remove the Result to simplify the error propagation on
        // higher levels?
        let fd = self.disk_image.fd();
        fcntl::clear_lock(&fd, granularity).map_err(|error| Error::LockDiskImage {
            path: self.disk_path.clone(),
            error,
            lock_type: LockType::Unlock,
        })
    }

    fn state(&self) -> BlockState {
        BlockState {
            disk_path: self.disk_path.to_str().unwrap().to_owned(),
            disk_nsectors: self.disk_nsectors.load(Ordering::SeqCst),
            avail_features: self.common.avail_features,
            acked_features: self.common.acked_features,
            config: self.config,
        }
    }

    /// The virtio v1.2 spec says "If VIRTIO_BLK_F_CONFIG_WCE was not
    /// negotiated but VIRTIO_BLK_F_FLUSH was, the driver SHOULD assume
    /// presence of a writeback cache." It also says "If
    /// VIRTIO_BLK_F_CONFIG_WCE is negotiated but VIRTIO_BLK_F_FLUSH is not,
    /// the device MUST initialize writeback to 0."
    fn is_writeback_enabled(&self, desired: bool) -> bool {
        let flush = self.common.feature_acked(VIRTIO_BLK_F_FLUSH.into());
        let wce = self.common.feature_acked(VIRTIO_BLK_F_CONFIG_WCE.into());
        if wce { flush && desired } else { flush }
    }

    fn set_writeback_mode(&mut self, enabled: bool) {
        self.config.writeback = enabled as u8;
        self.writeback.store(enabled, Ordering::Release);
        info!(
            "Changing cache mode to {}",
            if enabled { "writeback" } else { "writethrough" }
        );
    }

    pub fn resize(&mut self, new_size: u64) -> Result<()> {
        if !new_size.is_multiple_of(SECTOR_SIZE) {
            return Err(Error::InvalidSize);
        }

        self.disk_image
            .resize(new_size)
            .map_err(Error::DiskResize)?;

        let nsectors = new_size / SECTOR_SIZE;

        let was_paused = self.common.pause_common.pause_requested();
        self.common.pause().map_err(Error::Pause)?;

        self.disk_nsectors.store(nsectors, Ordering::SeqCst);
        self.config.capacity = nsectors;
        self.state().disk_nsectors = nsectors;

        if !was_paused {
            self.common.resume().map_err(Error::Resume)?;
        }

        self.common
            .trigger_interrupt(VirtioInterruptType::Config)
            .map_err(Error::ConfigChange)
    }

    #[cfg(fuzzing)]
    pub fn wait_for_epoll_threads(&mut self) {
        self.common.wait_for_epoll_threads();
    }
}

impl VirtioDevice for Block {
    fn device_type(&self) -> u32 {
        self.common.device_type
    }

    fn queue_max_sizes(&self) -> &[u16] {
        &self.common.queue_sizes
    }

    fn features(&self) -> u64 {
        self.common.avail_features
    }

    fn ack_features(&mut self, value: u64) {
        self.common.ack_features(value);
    }

    fn read_config(&self, offset: u64, data: &mut [u8]) {
        self.read_config_from_slice(self.config.as_slice(), offset, data);
    }

    fn write_config(&mut self, offset: u64, data: &[u8]) {
        // The "writeback" field is the only mutable field
        let writeback_offset =
            (&raw const self.config.writeback as u64) - (&raw const self.config as u64);
        if offset != writeback_offset || data.len() != size_of_val(&self.config.writeback) {
            error!(
                "Attempt to write to read-only field: offset {:x} length {}",
                offset,
                data.len()
            );
            return;
        }

        let writeback = self.is_writeback_enabled(data[0] == 1);
        self.set_writeback_mode(writeback);
    }

    fn activate(&mut self, context: ActivationContext) -> ActivateResult {
        let ActivationContext {
            mem,
            interrupt_cb,
            mut queues,
            device_status,
        } = context;
        self.device_status = device_status;
        // See if the guest didn't ack the device being read-only.
        // If so, warn and pretend it did.
        let original_acked_features = self.common.acked_features;
        self.common.acked_features |= self.common.avail_features & (1u64 << VIRTIO_BLK_F_RO);
        if original_acked_features != self.common.acked_features {
            warn!("Guest did not acknowledge that device is read-only, acting as if it did!");
        }
        self.common.activate(&queues, Arc::clone(&interrupt_cb))?;

        let writeback = self.is_writeback_enabled(self.config.writeback == 1);
        self.set_writeback_mode(writeback);

        let event_idx = self.common.feature_acked(VIRTIO_RING_F_EVENT_IDX.into());

        // `queue_idx` is the virtqueue number the driver configured. It differs from
        // the position in `queues`, which only holds the enabled queues.
        for (queue_idx, mut queue, queue_evt) in queues.drain(..) {
            queue.set_event_idx(event_idx);

            let queue_size = queue.size();
            let (kill_evt, pause_evt) = self.common.dup_eventfds()?;

            let mut handler = BlockEpollHandler {
                queue_index: queue_idx,
                queue,
                mem: mem.clone(),
                disk_image: self
                    .disk_image
                    .create_async_io(queue_size as u32)
                    .map_err(|e| {
                        error!("failed to create new AsyncIo: {e}");
                        ActivateError::BadActivate
                    })?,
                disk_nsectors: Arc::clone(&self.disk_nsectors),
                interrupt_cb: Arc::clone(&interrupt_cb),
                serial: self.serial.clone(),
                kill_evt,
                pause_evt,
                writeback: Arc::clone(&self.writeback),
                counters: self.counters.clone(),
                queue_evt,
                // Analysis during boot shows around ~40 maximum requests
                // This gives head room for systems with slower I/O without
                // compromising the cost of the reallocation or memory overhead
                inflight_requests: VecDeque::with_capacity(64),
                rate_limiter: self
                    .rate_limiter
                    .as_ref()
                    .map(|r| r.new_handle())
                    .transpose()
                    .unwrap(),
                access_platform: self.common.access_platform(),
                host_cpus: self.queue_affinity.get(&queue_idx).cloned(),
                acked_features: self.common.acked_features,
                active_request_count: Arc::clone(&self.active_request_count),
                draining_active_requests: Arc::clone(&self.draining_active_requests),
            };

            self.common.spawn_worker(
                &format!("{}_q{}", self.id.clone(), queue_idx),
                &self.seccomp_action,
                Thread::VirtioBlock,
                &self.exit_evt,
                Arc::clone(&self.device_status),
                Arc::clone(&interrupt_cb),
                move |pause_common| handler.run(pause_common),
            )?;
        }

        event!("virtio-device", "activated", "id", &self.id);

        Ok(())
    }

    fn reset(&mut self) {
        self.common.reset();
        self.draining_active_requests.store(false, Ordering::SeqCst);
        self.active_request_count.store(0, Ordering::SeqCst);
        self.set_writeback_mode(true);
        event!("virtio-device", "reset", "id", &self.id);
    }

    fn shutdown(&mut self) {
        self.common.wait_for_epoll_threads();
    }

    fn counters(&self) -> Option<HashMap<&'static str, Wrapping<u64>>> {
        let mut counters = HashMap::new();

        let read_ops = self.counters.read_ops.load(Ordering::Acquire);
        let write_ops = self.counters.write_ops.load(Ordering::Acquire);

        counters.insert(
            "read_bytes",
            Wrapping(self.counters.read_bytes.load(Ordering::Acquire)),
        );
        counters.insert(
            "write_bytes",
            Wrapping(self.counters.write_bytes.load(Ordering::Acquire)),
        );
        counters.insert("read_ops", Wrapping(read_ops));
        counters.insert("write_ops", Wrapping(write_ops));

        // Don't publish read/write operations counters until the first operation
        if write_ops > 0 {
            counters.insert(
                "write_latency_min",
                Wrapping(self.counters.write_latency_min.load(Ordering::Acquire)),
            );
            counters.insert(
                "write_latency_max",
                Wrapping(self.counters.write_latency_max.load(Ordering::Acquire)),
            );
            counters.insert(
                "write_latency_avg",
                Wrapping(self.counters.write_latency_avg.load(Ordering::Acquire) / LATENCY_SCALE),
            );
        }
        if read_ops > 0 {
            counters.insert(
                "read_latency_min",
                Wrapping(self.counters.read_latency_min.load(Ordering::Acquire)),
            );
            counters.insert(
                "read_latency_max",
                Wrapping(self.counters.read_latency_max.load(Ordering::Acquire)),
            );
            counters.insert(
                "read_latency_avg",
                Wrapping(self.counters.read_latency_avg.load(Ordering::Acquire) / LATENCY_SCALE),
            );
        }

        Some(counters)
    }

    fn set_access_platform(&mut self, access_platform: Arc<dyn AccessPlatform>) {
        self.common.set_access_platform(access_platform);
    }

    fn access_platform(&self) -> Option<Arc<dyn AccessPlatform>> {
        self.common.access_platform()
    }
}

impl Pausable for Block {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        self.draining_active_requests.store(true, Ordering::SeqCst);

        // Drain before parking the worker threads: the workers are what
        // complete in-flight I/O, so they must keep running until the count
        // reaches zero. Roll back the drain flag if any step fails.
        let result = self
            .wait_for_active_requests()
            .map_err(MigratableError::Pause)
            .and_then(|()| {
                // Flush cached format metadata (e.g. qcow2 L2/refcount tables) so
                // the on-disk image is self-consistent while paused: snapshot
                // copies and migration disk-lock handoff read the file directly.
                self.disk_image.sync_metadata().map_err(|e| {
                    MigratableError::Pause(anyhow::Error::new(e).context("sync disk metadata"))
                })
            })
            .and_then(|()| self.common.pause());

        self.draining_active_requests.store(false, Ordering::SeqCst);
        result
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        self.draining_active_requests.store(false, Ordering::SeqCst);
        self.common.resume()
    }
}

impl Snapshottable for Block {
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        Snapshot::new_from_state(&self.state())
    }
}
impl Transportable for Block {}
impl Migratable for Block {
    fn notify_started_migration(&mut self) -> result::Result<(), MigratableError> {
        if let Err(e) = self.disk_image.sync_metadata() {
            warn!("Failed to flush disk {} before migration: {e}", self.id);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use std::fs;
    use std::io::{self, Result as IoResult};
    use std::path::Path;
    use std::sync::{Mutex, mpsc};

    use block::async_io::{AsyncIoCompletion, AsyncIoError, AsyncIoOperation, AsyncIoResult};
    use hypervisor::Vm;
    use virtio_bindings::virtio_ring::{VRING_DESC_F_NEXT, VRING_DESC_F_WRITE};
    use virtio_queue::desc::split::Descriptor;
    use vm_memory::GuestAddress;
    use vm_virtio::AccessType;
    use vm_virtio::queue::testing::VirtQueue as GuestQ;
    use vmm_sys_util::eventfd::EFD_NONBLOCK;

    use super::*;

    struct Noop(EventFd);
    impl VirtioInterrupt for Noop {
        fn trigger(&self, _: VirtioInterruptType) -> IoResult<()> {
            Ok(())
        }
        fn set_notifier(&self, _: u32, _: Option<EventFd>, _: &dyn Vm) -> IoResult<()> {
            Ok(())
        }
    }
    impl AsyncIo for Noop {
        fn notifier(&self) -> &EventFd {
            &self.0
        }
        fn submit_data_operation(&mut self, _: AsyncIoOperation) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn fsync(&mut self, _: Option<u64>) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn punch_hole(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn write_zeroes(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn next_completed_request(&mut self) -> Option<AsyncIoCompletion> {
            None
        }
    }

    fn make_block_with_serial(dir: &Path, serial: Option<&str>, num_queues: u16) -> Block {
        use block::ImageType;
        use block::factory::{DiskOpenOptions, open_disk};

        let path = dir.join("serial.raw");
        fs::write(&path, vec![0u8; 4096]).unwrap();
        let disk = open_disk(
            &DiskOpenOptions {
                path: &path,
                readonly: false,
                direct: false,
                sparse: true,
                backing_files: false,
                disable_io_uring: true,
                disable_aio: true,
            },
            ImageType::Raw,
        )
        .unwrap();
        Block::new(
            "serial".to_string(),
            disk,
            path,
            false,
            false,
            num_queues,
            256,
            serial,
            SeccompAction::Allow,
            None,
            EventFd::new(0).unwrap(),
            None,
            BTreeMap::new(),
            true,
            LockGranularityChoice::default(),
            None,
        )
        .unwrap()
    }

    #[test]
    fn short_serial_is_nul_padded() {
        use vmm_sys_util::tempdir::TempDir;

        let dir = TempDir::new_with_prefix("/dev/shm/ch-serial").unwrap();
        let block = make_block_with_serial(dir.as_path(), Some("abc"), 1);
        assert_eq!(block.serial.len(), VIRTIO_BLK_ID_BYTES as usize);
        assert_eq!(&block.serial[..3], b"abc");
        assert!(block.serial[3..].iter().all(|b| *b == 0));
    }

    #[test]
    fn full_length_serial_is_unchanged() {
        use vmm_sys_util::tempdir::TempDir;

        let dir = TempDir::new_with_prefix("/dev/shm/ch-serial").unwrap();
        let serial = "0123456789abcdefghij";
        let block = make_block_with_serial(dir.as_path(), Some(serial), 1);
        assert_eq!(&block.serial[..], serial.as_bytes());
    }

    fn make_handler(queue: Queue, mem: &GuestMemory, acked_features: u64) -> BlockEpollHandler {
        let evt = || EventFd::new(EFD_NONBLOCK).unwrap();
        make_handler_with_io(queue, mem, acked_features, Box::new(Noop(evt())))
    }

    fn make_handler_with_io(
        queue: Queue,
        mem: &GuestMemory,
        acked_features: u64,
        disk_image: Box<dyn AsyncIo>,
    ) -> BlockEpollHandler {
        let evt = || EventFd::new(EFD_NONBLOCK).unwrap();
        BlockEpollHandler {
            queue_index: 0,
            queue,
            mem: GuestMemoryAtomic::new(mem.clone()),
            disk_image,
            disk_nsectors: Arc::new(AtomicU64::new(0)),
            interrupt_cb: Arc::new(Noop(evt())),
            serial: Box::default(),
            kill_evt: evt(),
            pause_evt: evt(),
            writeback: Arc::new(AtomicBool::new(false)),
            counters: BlockCounters::default(),
            queue_evt: evt(),
            inflight_requests: VecDeque::new(),
            active_request_count: Arc::new(AtomicUsize::new(0)),
            draining_active_requests: Arc::new(AtomicBool::new(false)),
            rate_limiter: None,
            access_platform: None,
            host_cpus: None,
            acked_features,
        }
    }

    const REQ_HDR_ADDR: u64 = 0x2000;
    const REQ_DATA_ADDR: u64 = 0x3000;
    const REQ_STATUS_ADDR: u64 = 0x4000;

    /// Processes one request of `request_type` with a 16 byte device-readable
    /// data descriptor and a 1 byte status descriptor. Returns the status
    /// byte and the 3 bytes after it, which are poisoned with 0xff before.
    fn process_one_request(request_type: u32, acked_features: u64) -> [u8; 4] {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(request_type, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        mem.write_slice(&[0xff; 4], GuestAddress(REQ_STATUS_ADDR))
            .unwrap();
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        vq.dtable[0].set(REQ_HDR_ADDR, 16, next, 1);
        vq.dtable[1].set(REQ_DATA_ADDR, 16, next, 2);
        vq.dtable[2].set(REQ_STATUS_ADDR, 1, write, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler(vq.create_queue(), &mem, acked_features);
        handler.process_queue_submit().unwrap();

        assert_eq!(vq.used.idx.get(), 1);
        let mut status = [0u8; 4];
        mem.read_slice(&mut status, GuestAddress(REQ_STATUS_ADDR))
            .unwrap();
        status
    }

    struct QueueInterruptSender(Mutex<mpsc::Sender<u16>>);
    impl VirtioInterrupt for QueueInterruptSender {
        fn trigger(&self, int_type: VirtioInterruptType) -> IoResult<()> {
            if let VirtioInterruptType::Queue(queue_index) = int_type {
                self.0.lock().unwrap().send(queue_index).unwrap();
            }
            Ok(())
        }
        fn set_notifier(&self, _: u32, _: Option<EventFd>, _: &dyn Vm) -> IoResult<()> {
            Ok(())
        }
    }

    // A driver may enable only some queues. The worker of each queue must
    // still signal the vector of its own queue index.
    #[test]
    fn sparse_queue_signals_its_own_index() {
        use vmm_sys_util::tempdir::TempDir;

        // Boring setup: a GET_ID request on a 2 queue device of which the
        // driver only enabled queue 1.
        let dir = TempDir::new_with_prefix("/dev/shm/ch-sparse-queue").unwrap();
        let mut block = make_block_with_serial(dir.as_path(), None, 2);
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(VIRTIO_BLK_T_GET_ID, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        vq.dtable[0].set(REQ_HDR_ADDR, 16, next, 1);
        vq.dtable[1].set(REQ_DATA_ADDR, VIRTIO_BLK_ID_BYTES, next | write, 2);
        vq.dtable[2].set(REQ_STATUS_ADDR, 1, write, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);
        let queue_evt = EventFd::new(EFD_NONBLOCK).unwrap();
        let (tx, rx) = mpsc::channel();

        block
            .activate(ActivationContext {
                mem: GuestMemoryAtomic::new(mem.clone()),
                interrupt_cb: Arc::new(QueueInterruptSender(Mutex::new(tx))),
                queues: vec![(1, vq.create_queue(), queue_evt.try_clone().unwrap())],
                device_status: Arc::new(AtomicU8::new(0)),
            })
            .unwrap();
        queue_evt.write(1).unwrap();

        // The interesting part: the completion signals queue 1, not queue 0.
        let queue_index = rx.recv_timeout(Duration::from_secs(10)).unwrap();
        block.reset();
        assert_eq!(queue_index, 1);
    }

    #[test]
    fn parse_failure_reclaims_head() {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        vq.dtable[0].set(0x2000, 16, 0, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler(vq.create_queue(), &mem, 0);

        handler.process_queue_submit().unwrap();

        assert_eq!(vq.used.idx.get(), 1);
    }

    // The status descriptor may be a single byte, so a rejected request must
    // not write past it.
    #[test]
    fn rejected_request_writes_one_status_byte() {
        let status = process_one_request(VIRTIO_BLK_T_OUT, 1 << VIRTIO_BLK_F_RO);
        assert_eq!(status, [VIRTIO_BLK_S_IOERR as u8, 0xff, 0xff, 0xff]);
    }

    fn used_len(vq: &GuestQ<'_, GuestMemory>, mem: &GuestMemory) -> u32 {
        mem.read_obj(GuestAddress(vq.used.ring[0].location.0 + 4))
            .unwrap()
    }

    /// Processes the chain `descs`, which holds a read request that fails to
    /// parse, and returns the 4 bytes at `probe`, poisoned with 0xff before.
    fn process_rejected(descs: &[Descriptor], probe: u64) -> [u8; 4] {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(VIRTIO_BLK_T_IN, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        mem.write_slice(&[0xff; 4], GuestAddress(probe)).unwrap();
        for (i, desc) in descs.iter().enumerate() {
            vq.dtable[i].set(desc.addr().0, desc.len(), desc.flags(), desc.next());
        }
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler(vq.create_queue(), &mem, 0);
        handler.process_queue_submit().unwrap();

        // A rejected request is returned with used length 0.
        assert_eq!(vq.used.idx.get(), 1);
        assert_eq!(used_len(&vq, &mem), 0);
        let mut bytes = [0u8; 4];
        mem.read_slice(&mut bytes, GuestAddress(probe)).unwrap();
        bytes
    }

    #[test]
    fn parse_failure_reports_ioerr() {
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        let status = process_rejected(
            &[
                Descriptor::new(REQ_HDR_ADDR, 16, next, 1),
                // The data buffer lides outside the guest memory
                Descriptor::new(0x1_0000_0000, 4096, next | write, 2),
                Descriptor::new(REQ_STATUS_ADDR, 1, write, 0),
            ],
            REQ_STATUS_ADDR,
        );
        assert_eq!(status, [VIRTIO_BLK_S_IOERR as u8, 0xff, 0xff, 0xff]);
    }

    #[test]
    fn parse_failure_past_the_status_reports_ioerr() {
        let status = process_rejected(
            &[
                Descriptor::new(REQ_HDR_ADDR, 16, VRING_DESC_F_NEXT as u16, 1),
                Descriptor::new(REQ_STATUS_ADDR, 1, VRING_DESC_F_WRITE as u16, 0),
            ],
            REQ_STATUS_ADDR,
        );
        assert_eq!(status, [VIRTIO_BLK_S_IOERR as u8, 0xff, 0xff, 0xff]);
    }

    #[test]
    fn parse_failure_leaves_a_device_readable_status_alone() {
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        let status = process_rejected(
            &[
                Descriptor::new(REQ_HDR_ADDR, 16, next, 1),
                Descriptor::new(0x1_0000_0000, 4096, next | write, 2),
                Descriptor::new(REQ_STATUS_ADDR, 1, 0, 0),
            ],
            REQ_STATUS_ADDR,
        );
        assert_eq!(status, [0xff; 4]);
    }

    #[test]
    fn parse_failure_leaves_a_truncated_chain_alone() {
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        let data = process_rejected(
            &[
                Descriptor::new(REQ_HDR_ADDR, 16, next, 1),
                Descriptor::new(0x1_0000_0000, 4096, next | write, 2),
                Descriptor::new(REQ_DATA_ADDR, 512, next | write, 9),
            ],
            REQ_DATA_ADDR,
        );
        assert_eq!(data, [0xff; 4]);
    }

    // Completes every write in full and fails every fsync.
    struct FailingFsync(EventFd, Vec<AsyncIoCompletion>);
    impl AsyncIo for FailingFsync {
        fn notifier(&self) -> &EventFd {
            &self.0
        }
        fn submit_data_operation(&mut self, op: AsyncIoOperation) -> AsyncIoResult<()> {
            let len = op.total_len() as i32;
            self.1.push(AsyncIoCompletion::from_operation(op, len));
            Ok(())
        }
        fn fsync(&mut self, _: Option<u64>) -> AsyncIoResult<()> {
            Err(AsyncIoError::Fsync(io::Error::from_raw_os_error(libc::EIO)))
        }
        fn punch_hole(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn write_zeroes(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn next_completed_request(&mut self) -> Option<AsyncIoCompletion> {
            self.1.pop()
        }
    }

    #[test]
    fn writethrough_write_fails_when_fsync_fails() {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(VIRTIO_BLK_T_OUT, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        vq.dtable[0].set(REQ_HDR_ADDR, 16, next, 1);
        vq.dtable[1].set(REQ_DATA_ADDR, 512, next, 2);
        vq.dtable[2].set(REQ_STATUS_ADDR, 1, write, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler(vq.create_queue(), &mem, 0);
        handler.disk_nsectors.store(1, Ordering::SeqCst);
        handler.disk_image = Box::new(FailingFsync(
            EventFd::new(EFD_NONBLOCK).unwrap(),
            Vec::new(),
        ));
        handler.process_queue_submit().unwrap();
        handler.process_queue_complete().unwrap();

        assert_eq!(vq.used.idx.get(), 1);
        let status: u8 = mem.read_obj(GuestAddress(REQ_STATUS_ADDR)).unwrap();
        assert_eq!(status, VIRTIO_BLK_S_IOERR as u8);
    }

    #[test]
    fn read_only_device_reports_unknown_request_unsupported() {
        let status = process_one_request(0x7f, 1 << VIRTIO_BLK_F_RO);
        assert_eq!(status[0], VIRTIO_BLK_S_UNSUPP as u8);
    }

    /// AsyncIo backend that returns one fixed completion length.
    struct OneShotAsyncIo {
        notifier: EventFd,
        result: i32,
        completion: Option<AsyncIoCompletion>,
    }

    impl OneShotAsyncIo {
        fn new(result: i32) -> Self {
            Self {
                notifier: EventFd::new(EFD_NONBLOCK).unwrap(),
                result,
                completion: None,
            }
        }
    }

    impl AsyncIo for OneShotAsyncIo {
        fn notifier(&self) -> &EventFd {
            &self.notifier
        }

        fn submit_data_operation(&mut self, op: AsyncIoOperation) -> AsyncIoResult<()> {
            self.completion = Some(AsyncIoCompletion::from_operation(op, self.result));
            Ok(())
        }

        fn fsync(&mut self, _: Option<u64>) -> AsyncIoResult<()> {
            Ok(())
        }

        fn punch_hole(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }

        fn write_zeroes(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }

        fn next_completed_request(&mut self) -> Option<AsyncIoCompletion> {
            self.completion.take()
        }
    }

    fn completion_status(request_type: u32, result: i32) -> (u8, u32) {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(request_type, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        mem.write_slice(&[0xff; 4], GuestAddress(REQ_STATUS_ADDR))
            .unwrap();
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        let data_flags = if request_type == VIRTIO_BLK_T_IN {
            next | write
        } else {
            next
        };
        vq.dtable[0].set(REQ_HDR_ADDR, 16, next, 1);
        vq.dtable[1].set(REQ_DATA_ADDR, 512, data_flags, 2);
        vq.dtable[2].set(REQ_STATUS_ADDR, 1, write, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler_with_io(
            vq.create_queue(),
            &mem,
            0,
            Box::new(OneShotAsyncIo::new(result)),
        );
        // The request is one sector; make it fit and reach the async path.
        handler.disk_nsectors.store(8, Ordering::SeqCst);
        handler.process_queue_submit().unwrap();
        assert_eq!(
            handler.inflight_requests.len(),
            1,
            "request did not enter the async completion path"
        );
        handler.process_queue_complete().unwrap();
        assert_eq!(vq.used.idx.get(), 1);

        let mut status = [0u8; 1];
        mem.read_slice(&mut status, GuestAddress(REQ_STATUS_ADDR))
            .unwrap();
        (
            status[0],
            mem.read_obj(GuestAddress(vq.used.ring[0].location.0 + 4))
                .unwrap(),
        )
    }

    #[test]
    fn full_read_completion_reports_ok() {
        assert_eq!(
            completion_status(VIRTIO_BLK_T_IN, 512),
            (VIRTIO_BLK_S_OK as u8, 513)
        );
    }

    #[test]
    fn short_read_completion_reports_ioerr() {
        assert_eq!(
            completion_status(VIRTIO_BLK_T_IN, 256),
            (VIRTIO_BLK_S_IOERR as u8, 1)
        );
    }

    #[test]
    fn short_write_completion_reports_ioerr() {
        assert_eq!(
            completion_status(VIRTIO_BLK_T_OUT, 256),
            (VIRTIO_BLK_S_IOERR as u8, 1)
        );
    }

    #[test]
    fn full_write_completion_reports_ok() {
        assert_eq!(
            completion_status(VIRTIO_BLK_T_OUT, 512),
            (VIRTIO_BLK_S_OK as u8, 1)
        );
    }

    #[test]
    fn error_completion_reports_ioerr() {
        assert_eq!(
            completion_status(VIRTIO_BLK_T_IN, -libc::EIO),
            (VIRTIO_BLK_S_IOERR as u8, 1)
        );
    }

    #[derive(Debug)]
    struct Offset;
    impl AccessPlatform for Offset {
        fn translate_gva(&self, base: u64, _size: u64, _access_type: AccessType) -> IoResult<u64> {
            base.checked_sub(0x8000_0000)
                .ok_or_else(|| io::Error::other("unmapped"))
        }
        fn translate_gpa(&self, base: u64, _size: u64) -> IoResult<u64> {
            Ok(base + 0x8000_0000)
        }
    }

    #[test]
    fn parse_failure_reports_ioerr_through_access_platform() {
        let mem = GuestMemory::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
        mem.write_obj(VIRTIO_BLK_T_IN, GuestAddress(REQ_HDR_ADDR))
            .unwrap();
        mem.write_slice(&[0xff; 4], GuestAddress(REQ_STATUS_ADDR))
            .unwrap();
        let next = VRING_DESC_F_NEXT as u16;
        let write = VRING_DESC_F_WRITE as u16;
        vq.dtable[0].set(0x8000_0000 + REQ_HDR_ADDR, 16, next, 1);
        vq.dtable[1].set(0x1_0000_0000, 4096, next | write, 2);
        vq.dtable[2].set(0x8000_0000 + REQ_STATUS_ADDR, 1, write, 0);
        vq.avail.ring[0].set(0);
        vq.avail.idx.set(1);

        let mut handler = make_handler(vq.create_queue(), &mem, 0);
        handler.access_platform = Some(Arc::new(Offset));
        handler.process_queue_submit().unwrap();

        assert_eq!(vq.used.idx.get(), 1);
        assert_eq!(used_len(&vq, &mem), 0);
        assert_eq!(
            mem.read_obj::<u8>(GuestAddress(REQ_STATUS_ADDR)).unwrap(),
            VIRTIO_BLK_S_IOERR as u8
        );
    }
}
