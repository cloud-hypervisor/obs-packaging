// Copyright 2018 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::collections::HashMap;
use std::io::Write;
use std::num::Wrapping;
use std::sync::atomic::AtomicU8;
use std::sync::{Arc, Mutex};
use std::{cmp, io, result, thread};

use anyhow::anyhow;
use libc::EFD_NONBLOCK;
use log::{error, info, warn};
use seccompiler::SeccompAction;
use virtio_bindings::virtio_config::VIRTIO_F_ACCESS_PLATFORM;
use virtio_queue::Queue;
use vm_memory::GuestMemoryAtomic;
use vm_migration::{MigratableError, Pausable};
use vm_virtio::{AccessPlatform, AccessType, VirtioDeviceType};
use vmm_sys_util::eventfd::EventFd;

use crate::epoll_helper::EpollHelperError;
use crate::seccomp_filters::Thread;
use crate::thread_helper::spawn_virtio_thread;
use crate::{
    ActivateError, ActivateResult, Error, GuestMemory, GuestRegion, PauseCommon,
    VIRTIO_F_RING_INDIRECT_DESC,
};

pub enum VirtioInterruptType {
    Config,
    Queue(u16),
}

pub trait VirtioInterrupt: Send + Sync {
    fn trigger(&self, int_type: VirtioInterruptType) -> io::Result<()>;
    fn notifier(&self, _int_type: VirtioInterruptType) -> Option<EventFd> {
        None
    }
    fn set_notifier(
        &self,
        int_type: u32,
        notifier: Option<EventFd>,
        vm: &dyn hypervisor::Vm,
    ) -> io::Result<()>;
}

#[derive(Clone)]
pub struct VirtioSharedMemory {
    pub offset: u64,
    pub len: u64,
}

#[derive(Clone)]
pub struct VirtioSharedMemoryList {
    pub mapping: Arc<Mutex<GuestRegion>>,
    pub region_list: Vec<VirtioSharedMemory>,
}

pub struct ActivationContext {
    pub mem: GuestMemoryAtomic<GuestMemory>,
    pub interrupt_cb: Arc<dyn VirtioInterrupt>,
    pub queues: Vec<(u16, Queue, EventFd)>,
    pub device_status: Arc<AtomicU8>,
}

/// Trait for virtio devices to be driven by a virtio transport.
///
/// The lifecycle of a virtio device is to be moved to a virtio transport, which will then query the
/// device. Once the guest driver has configured the device, `VirtioDevice::activate` will be called
/// and all the events, memory, and queues for device operation will be moved into the device.
/// Optionally, a virtio device can implement device reset in which it returns said resources and
/// resets its internal.
pub trait VirtioDevice: Send {
    /// The virtio device type.
    fn device_type(&self) -> u32;

    /// The maximum size of each queue that this device supports.
    fn queue_max_sizes(&self) -> &[u16];

    /// Whether the device needs to register extra irqfds at runtime
    /// from external sources.
    /// The default is false.  If this is true, locking is required for
    /// most operations involving interrupts (but not for sending)
    /// interrupts from external irqfds).
    ///
    /// If the device claims to not need to register irqfds, but
    /// attempts to do so, a panic will ensue.
    fn interrupt_source_mutable(&self) -> bool {
        false
    }

    /// The set of feature bits that this device supports.
    fn features(&self) -> u64 {
        0
    }

    /// Acknowledges that this set of features should be enabled.
    fn ack_features(&mut self, value: u64) {
        let _ = value;
    }

    fn config_size(&self) -> Option<u64> {
        None
    }

    /// Reads this device configuration space at `offset`.
    fn read_config(&self, _offset: u64, _data: &mut [u8]) {
        warn!(
            "No readable configuration fields for {}",
            VirtioDeviceType::from(self.device_type())
        );
    }

    /// Writes to this device configuration space at `offset`.
    fn write_config(&mut self, _offset: u64, _data: &[u8]) {
        warn!(
            "No writable configuration fields for {}",
            VirtioDeviceType::from(self.device_type())
        );
    }

    /// Activates this device for real usage.
    fn activate(&mut self, context: ActivationContext) -> ActivateResult;

    /// Optionally deactivates this device.
    fn reset(&mut self) {}

    /// Returns the list of shared memory regions required by the device.
    fn get_shm_regions(&self) -> Option<VirtioSharedMemoryList> {
        None
    }

    /// Updates the list of shared memory regions required by the device.
    fn set_shm_regions(
        &mut self,
        _shm_regions: VirtioSharedMemoryList,
    ) -> result::Result<(), Error> {
        std::unimplemented!()
    }

    /// Some devices may need to do some explicit shutdown work. This method
    /// may be implemented to do this. The VMM should call shutdown() on
    /// every device as part of shutting down the VM. Acting on the device
    /// after a shutdown() can lead to unpredictable results.
    fn shutdown(&mut self) {}

    fn add_memory_region(&mut self, _region: &Arc<GuestRegion>) -> result::Result<(), Error> {
        Ok(())
    }

    /// Return the counters that this device exposes
    fn counters(&self) -> Option<HashMap<&'static str, Wrapping<u64>>> {
        None
    }

    /// Helper to allow common implementation of read_config
    fn read_config_from_slice(&self, config: &[u8], offset: u64, mut data: &mut [u8]) {
        let config_len = config.len() as u64;
        let data_len = data.len() as u64;
        if offset + data_len > config_len {
            error!(
                "Out-of-bound access to configuration: config_len = {} offset = {:x} length = {} for {}",
                config_len,
                offset,
                data_len,
                self.device_type()
            );
            return;
        }
        if let Some(end) = offset.checked_add(data.len() as u64) {
            data.write_all(&config[offset as usize..cmp::min(end, config_len) as usize])
                .unwrap();
        }
    }

    /// Set the access platform trait to let the device perform address
    /// translations if needed.
    fn set_access_platform(&mut self, _access_platform: Arc<dyn AccessPlatform>) {}

    /// Returns the access platform only if VIRTIO_F_ACCESS_PLATFORM was
    /// negotiated with the guest.
    fn access_platform(&self) -> Option<Arc<dyn AccessPlatform>> {
        None
    }
}

/// Trait to define address translation for devices managed by virtio-iommu
///
/// Trait providing address translation the same way a physical DMA remapping
/// table would provide translation between an IOVA and a physical address.
/// The goal of this trait is to be used by virtio devices to perform the
/// address translation before they try to read from the guest physical address.
/// On the other side, the implementation itself should be provided by the code
/// emulating the IOMMU for the guest.
pub trait DmaRemapping {
    /// Provide a way to translate GVA address ranges into GPAs. The
    /// implementation must reject translations whose [addr, addr+size)
    /// span isn't entirely covered by a single mapping.
    fn translate_gva(
        &self,
        id: u32,
        addr: u64,
        size: u64,
        access_type: AccessType,
    ) -> io::Result<u64>;
    /// Provide a way to translate GPA address ranges into GVAs. Same
    /// span requirement as `translate_gva`.
    fn translate_gpa(&self, id: u32, addr: u64, size: u64) -> io::Result<u64>;
}

/// Owns a device's worker threads plus the kill event that stops them.
pub struct WorkerThreads {
    /// shared kill event, a single write wakes all of them.
    kill_evt: EventFd,
    pause_common: Arc<PauseCommon>,
    // The running worker thread's handles.
    threads: Vec<thread::JoinHandle<()>>,
}

impl WorkerThreads {
    fn new(kill_evt: EventFd, pause_common: Arc<PauseCommon>) -> Self {
        WorkerThreads {
            kill_evt,
            pause_common,
            threads: Vec::new(),
        }
    }

    /// Borrow access to the kill eventfd
    fn kill_evt(&self) -> &EventFd {
        &self.kill_evt
    }

    /// Signal the workers to exit without joining; they are joined later when
    /// this is dropped.
    pub(crate) fn signal_exit(&self) -> io::Result<()> {
        let result = self.kill_evt.write(1);
        self.pause_common.resume();
        result
    }
}

impl Drop for WorkerThreads {
    fn drop(&mut self) {
        let _ = self.signal_exit();
        for t in self.threads.drain(..) {
            if let Err(e) = t.join() {
                error!("Error joining thread: {e:?}");
            }
        }
    }
}

/// Structure to handle device state common to all devices
pub struct VirtioCommon {
    pub avail_features: u64,
    pub acked_features: u64,
    pub interrupt_cb: Option<Arc<dyn VirtioInterrupt>>,
    pub pause_common: Arc<PauseCommon>,
    pub workers: Option<WorkerThreads>,
    pub queue_sizes: Vec<u16>,
    pub queue_evts: Vec<(u16, EventFd)>,
    pub device_type: u32,
    pub min_queues: u16,
    pub access_platform: Option<Arc<dyn AccessPlatform>>,
}

impl VirtioCommon {
    pub fn new(pause_requested: bool) -> io::Result<Self> {
        Ok(Self {
            avail_features: 0,
            acked_features: 0,
            interrupt_cb: None,
            pause_common: Arc::new(PauseCommon::new(pause_requested)?),
            workers: None,
            queue_sizes: Vec::new(),
            queue_evts: Vec::new(),
            device_type: 0,
            min_queues: 0,
            access_platform: None,
        })
    }

    pub fn feature_acked(&self, feature: u64) -> bool {
        self.acked_features & (1 << feature) == 1 << feature
    }

    pub fn ack_features(&mut self, value: u64) {
        let mut v = value;
        // Check if the guest is ACK'ing a feature that we didn't claim to have.
        let unrequested_features = v & !self.avail_features;
        if unrequested_features != 0 {
            warn!("Received acknowledge request for unknown feature.");

            // Don't count these features as acked.
            v &= !unrequested_features;
        }
        self.acked_features = v;
    }

    pub(crate) fn check_access_platform(&self) -> ActivateResult {
        let access_platform = 1u64 << VIRTIO_F_ACCESS_PLATFORM;
        if self.avail_features & access_platform != 0 && self.acked_features & access_platform == 0
        {
            return Err(ActivateError::AccessPlatformNotAcknowledged);
        }
        Ok(())
    }

    pub fn activate(
        &mut self,
        queues: &[(u16, Queue, EventFd)],
        interrupt_cb: Arc<dyn VirtioInterrupt>,
    ) -> ActivateResult {
        self.check_access_platform()?;

        if queues.len() < self.min_queues.into() {
            error!(
                "Number of enabled queues lower than min: {} vs {}",
                queues.len(),
                self.min_queues
            );
            return Err(ActivateError::BadActivate);
        }

        self.queue_evts = queues
            .iter()
            .map(|(queue_index, _, queue_evt)| {
                queue_evt
                    .try_clone()
                    .map(|queue_evt| (*queue_index, queue_evt))
                    .map_err(|e| {
                        error!("Failed cloning queue EventFd: {e}");
                        ActivateError::BadActivate
                    })
            })
            .collect::<Result<Vec<_>, _>>()?;

        let kill_evt = EventFd::new(EFD_NONBLOCK).map_err(|e| {
            error!("failed creating kill EventFd: {e}");
            ActivateError::BadActivate
        })?;
        // Create the worker collection up front so it owns the kill event;
        // handlers clone it via dup_eventfds() before any worker is spawned.
        self.workers = Some(WorkerThreads::new(kill_evt, Arc::clone(&self.pause_common)));

        // Save the interrupt EventFD as we need to return it on reset
        // but clone it to pass into the thread.
        self.interrupt_cb = Some(interrupt_cb);

        Ok(())
    }

    pub fn reset(&mut self) {
        self.queue_evts.clear();
        self.workers = None;
        self.pause_common.reset();

        // Drop the interrupt callback clone
        self.interrupt_cb = None;
    }

    /// Spawn a worker; on failure, reset the device to join prior workers.
    #[expect(clippy::too_many_arguments)]
    pub fn spawn_worker<F>(
        &mut self,
        name: &str,
        seccomp_action: &SeccompAction,
        thread_type: Thread,
        exit_evt: &EventFd,
        device_status: Arc<AtomicU8>,
        interrupt_cb: Arc<dyn VirtioInterrupt>,
        f: F,
    ) -> Result<(), ActivateError>
    where
        F: FnOnce(&PauseCommon) -> Result<(), EpollHelperError> + Send + 'static,
    {
        // Scope the borrow of `workers` so it ends before the reset() below.
        let res = {
            let Some(workers) = self.workers.as_mut() else {
                error!("spawn_worker called before activate()");
                return Err(ActivateError::BadActivate);
            };
            spawn_virtio_thread(
                name,
                seccomp_action,
                thread_type,
                &mut workers.threads,
                exit_evt,
                device_status,
                interrupt_cb,
                Arc::clone(&self.pause_common),
                f,
            )
        };
        if let Err(e) = res {
            self.reset();
            return Err(e);
        }
        Ok(())
    }

    pub fn trigger_interrupt(&self, int_type: VirtioInterruptType) -> io::Result<()> {
        if let Some(interrupt_cb) = &self.interrupt_cb {
            interrupt_cb.trigger(int_type)
        } else {
            Ok(())
        }
    }

    pub fn wait_for_epoll_threads(&mut self) {
        self.workers = None;
    }

    pub fn dup_eventfds(&self) -> Result<(EventFd, EventFd), ActivateError> {
        let kill_evt = self
            .workers
            .as_ref()
            .ok_or(ActivateError::BadActivate)?
            .kill_evt()
            .try_clone()
            .map_err(ActivateError::CloneEventFd)?;
        let pause_evt = self
            .pause_common
            .pause_evt()
            .try_clone()
            .map_err(ActivateError::CloneEventFd)?;
        Ok((kill_evt, pause_evt))
    }

    pub fn set_access_platform(&mut self, access_platform: Arc<dyn AccessPlatform>) {
        self.access_platform = Some(access_platform);
        // Indirect descriptors feature is not supported when the device
        // requires the addresses held by the descriptors to be translated.
        self.avail_features &= !(1 << VIRTIO_F_RING_INDIRECT_DESC);
    }

    /// Returns the access platform only if the feature has been acked.
    pub fn access_platform(&self) -> Option<Arc<dyn AccessPlatform>> {
        if self.feature_acked(VIRTIO_F_ACCESS_PLATFORM as u64) {
            self.access_platform.clone()
        } else {
            None
        }
    }
}

impl Pausable for VirtioCommon {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        info!(
            "Pausing virtio-{}",
            VirtioDeviceType::from(self.device_type)
        );

        self.pause_common
            .pause()
            .map_err(|e| MigratableError::Pause(e.into()))
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        info!(
            "Resuming virtio-{}",
            VirtioDeviceType::from(self.device_type)
        );
        self.pause_common.resume();

        // Signal each activated queue eventfd so workers process restored queues
        // that may already contain pending requests.
        for (_, queue_evt) in &self.queue_evts {
            queue_evt.write(1).map_err(|e| {
                MigratableError::Resume(anyhow!(
                    "Could not notify restored virtio worker on resume: {e}"
                ))
            })?;
        }

        // Also trigger interrupts into the guest to wake up the driver to avoid a "livelock"
        for (queue_index, _) in &self.queue_evts {
            self.trigger_interrupt(crate::VirtioInterruptType::Queue(*queue_index))
                .ok();
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use std::os::fd::AsRawFd;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, mpsc};
    use std::time::Duration;

    use virtio_queue::QueueT;
    use vmm_sys_util::eventfd::EFD_NONBLOCK;

    use super::*;
    use crate::epoll_helper::EPOLL_HELPER_EVENT_PAUSE;
    use crate::{EPOLL_HELPER_EVENT_LAST, EpollHelper, EpollHelperHandler};

    #[derive(Default)]
    struct RecordingInterrupt {
        queue_indices: Mutex<Vec<u16>>,
    }

    impl VirtioInterrupt for RecordingInterrupt {
        fn trigger(&self, int_type: VirtioInterruptType) -> io::Result<()> {
            if let VirtioInterruptType::Queue(queue_index) = int_type {
                self.queue_indices.lock().unwrap().push(queue_index);
            }
            Ok(())
        }

        fn set_notifier(
            &self,
            _: u32,
            _: Option<EventFd>,
            _: &dyn hypervisor::Vm,
        ) -> io::Result<()> {
            Ok(())
        }
    }

    struct NoopInterrupt;
    impl VirtioInterrupt for NoopInterrupt {
        fn trigger(&self, _: VirtioInterruptType) -> io::Result<()> {
            Ok(())
        }
        fn set_notifier(
            &self,
            _: u32,
            _: Option<EventFd>,
            _: &dyn hypervisor::Vm,
        ) -> io::Result<()> {
            Ok(())
        }
    }

    struct QueueEventHandler {
        queue_evt: EventFd,
        entered: mpsc::Sender<()>,
        ready: mpsc::Receiver<()>,
        processed: mpsc::Sender<u64>,
    }

    impl QueueEventHandler {
        fn run(
            &mut self,
            kill_evt: &EventFd,
            pause_evt: &EventFd,
            pause_common: &PauseCommon,
        ) -> Result<(), EpollHelperError> {
            self.entered.send(()).unwrap();
            self.ready.recv().unwrap();
            let mut helper = EpollHelper::new(kill_evt, pause_evt)?;
            helper.add_event(self.queue_evt.as_raw_fd(), EPOLL_HELPER_EVENT_LAST + 1)?;
            helper.run(pause_common, self)
        }
    }

    impl EpollHelperHandler for QueueEventHandler {
        fn handle_event(
            &mut self,
            _: &mut EpollHelper,
            _: &epoll::Event,
        ) -> Result<(), EpollHelperError> {
            self.processed.send(self.queue_evt.read().unwrap()).unwrap();
            Ok(())
        }
    }

    struct PauseTestDevice {
        exit_evt: EventFd,
        status: Arc<AtomicU8>,
        entering: mpsc::Receiver<()>,
        requests: mpsc::Receiver<u64>,
        releases: Vec<mpsc::Sender<()>>,
        queue_evts: Vec<EventFd>,
        common: VirtioCommon,
    }

    impl PauseTestDevice {
        const TIMEOUT: Duration = Duration::from_secs(5);

        fn new() -> Self {
            let exit_evt = EventFd::new(EFD_NONBLOCK).unwrap();
            let status = Arc::new(AtomicU8::new(0));
            let mut common = VirtioCommon {
                device_type: VirtioDeviceType::Block as u32,
                ..VirtioCommon::new(true).unwrap()
            };
            common.activate(&[], Arc::new(NoopInterrupt)).unwrap();
            let (entered, entering) = mpsc::channel();
            let (processed, requests) = mpsc::channel();
            let mut releases = Vec::new();
            let mut queue_evts = Vec::new();

            for index in 0..2 {
                let queue_evt = EventFd::new(EFD_NONBLOCK).unwrap();
                queue_evts.push(queue_evt.try_clone().unwrap());
                let (release, ready) = mpsc::channel();
                releases.push(release);
                let mut handler = QueueEventHandler {
                    queue_evt,
                    entered: entered.clone(),
                    ready,
                    processed: processed.clone(),
                };
                let (kill_evt, pause_evt) = common.dup_eventfds().unwrap();
                common
                    .spawn_worker(
                        &format!("pause_test_{index}"),
                        &SeccompAction::Allow,
                        Thread::VirtioBlock,
                        &exit_evt,
                        Arc::clone(&status),
                        Arc::new(NoopInterrupt),
                        move |pause_common| handler.run(&kill_evt, &pause_evt, pause_common),
                    )
                    .unwrap();
            }

            Self {
                exit_evt,
                status,
                entering,
                requests,
                releases,
                queue_evts,
                common,
            }
        }

        fn pause_during_startup(mut self) -> Self {
            self.common.resume().unwrap();
            for _ in &self.queue_evts {
                self.entering
                    .recv_timeout(Self::TIMEOUT)
                    .expect("Thread did not enter handler startup");
            }
            let pause_common = Arc::clone(&self.common.pause_common);
            let pause_evt = self.common.pause_common.pause_evt();
            let pause_monitor = EpollHelper::new(&self.exit_evt, pause_evt).unwrap();
            let (paused, completed) = mpsc::channel();
            let pausing = thread::spawn(move || {
                self.common.pause().unwrap();
                paused.send(self.common).unwrap();
            });
            let mut events = [epoll::Event::new(epoll::Events::empty(), 0)];
            assert_eq!(
                epoll::wait(
                    pause_monitor.as_raw_fd(),
                    Self::TIMEOUT.as_millis() as i32,
                    &mut events,
                )
                .unwrap(),
                1
            );
            let event_id = events[0].data;
            assert_eq!(event_id, u64::from(EPOLL_HELPER_EVENT_PAUSE));
            assert!(pause_common.pause_requested());
            for release in self.releases.drain(..) {
                release.send(()).unwrap();
            }
            self.common = completed
                .recv_timeout(Self::TIMEOUT)
                .expect("Late threads did not acknowledge pause");
            pausing.join().unwrap();
            self
        }

        fn resume_and_pause(mut self) -> Self {
            let (paused, completed) = mpsc::channel();
            let pausing = thread::spawn(move || {
                self.common.resume().unwrap();
                self.common.pause().unwrap();
                paused.send(self.common).unwrap();
            });
            self.common = completed
                .recv_timeout(Self::TIMEOUT)
                .expect("Pause after immediate resume did not complete");
            pausing.join().unwrap();
            self
        }
    }

    /// VirtioCommon with its worker collection created (as activate() does)
    /// and a kill_evt clone for the spawned worker to watch.
    fn make_common_with_workers() -> (VirtioCommon, EventFd) {
        let kill_evt = EventFd::new(EFD_NONBLOCK).unwrap();
        let kill_evt_clone = kill_evt.try_clone().unwrap();
        let common = VirtioCommon::new(false).unwrap();
        let workers = WorkerThreads::new(kill_evt, Arc::clone(&common.pause_common));
        let common = VirtioCommon {
            workers: Some(workers),
            ..common
        };
        (common, kill_evt_clone)
    }

    #[test]
    fn activate_requires_acknowledgment_only_when_access_platform_is_offered() {
        let access_platform = 1u64 << VIRTIO_F_ACCESS_PLATFORM;

        for (offered, acknowledged, should_activate) in [
            (false, false, true),
            (false, true, true),
            (true, false, false),
            (true, true, true),
        ] {
            let mut common = VirtioCommon {
                avail_features: if offered { access_platform } else { 0 },
                ..VirtioCommon::new(false).unwrap()
            };
            if acknowledged {
                common.ack_features(access_platform);
            }
            let result = common.activate(&[], Arc::new(NoopInterrupt));

            if should_activate {
                assert!(
                    result.is_ok(),
                    "offered={offered}, acknowledged={acknowledged}"
                );
            } else {
                assert!(matches!(
                    result,
                    Err(ActivateError::AccessPlatformNotAcknowledged)
                ));
                assert!(common.workers.is_none());
            }
        }
    }

    #[test]
    fn spawn_worker_appends_to_workers() {
        let (mut common, kill_evt_clone) = make_common_with_workers();
        let started = Arc::new(AtomicUsize::new(0));
        let started_clone = Arc::clone(&started);

        let exit_evt = EventFd::new(EFD_NONBLOCK).unwrap();
        let status = Arc::new(AtomicU8::new(0));

        common
            .spawn_worker(
                "test",
                &SeccompAction::Allow,
                Thread::VirtioBlock,
                &exit_evt,
                status,
                Arc::new(NoopInterrupt),
                move |_| {
                    started_clone.fetch_add(1, Ordering::SeqCst);
                    let _ = kill_evt_clone.read();
                    Ok(())
                },
            )
            .unwrap();

        let workers = common.workers.as_ref().expect("workers set");
        assert_eq!(workers.threads.len(), 1);

        // reset() drops the WorkerThreads and joins the worker, exercising
        // the spawn-failure cleanup path on a real running thread.
        common.reset();
        assert!(common.workers.is_none());
        assert_eq!(started.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn dropping_common_joins_workers() {
        let (mut common, kill_evt_clone) = make_common_with_workers();
        let started = Arc::new(AtomicUsize::new(0));
        let started_clone = Arc::clone(&started);

        let exit_evt = EventFd::new(EFD_NONBLOCK).unwrap();
        let status = Arc::new(AtomicU8::new(0));

        common
            .spawn_worker(
                "test",
                &SeccompAction::Allow,
                Thread::VirtioBlock,
                &exit_evt,
                status,
                Arc::new(NoopInterrupt),
                move |_| {
                    started_clone.fetch_add(1, Ordering::SeqCst);
                    let _ = kill_evt_clone.read();
                    Ok(())
                },
            )
            .unwrap();

        // Dropping `common` alone must join the worker via WorkerThreads' Drop.
        drop(common);
        assert_eq!(started.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn resume_preserves_sparse_queue_indices() {
        let interrupt = Arc::new(RecordingInterrupt::default());
        let queues = vec![
            (
                1,
                Queue::new(256).unwrap(),
                EventFd::new(EFD_NONBLOCK).unwrap(),
            ),
            (
                3,
                Queue::new(256).unwrap(),
                EventFd::new(EFD_NONBLOCK).unwrap(),
            ),
        ];
        let mut common = VirtioCommon::new(false).unwrap();
        let interrupt_cb = Arc::clone(&interrupt) as Arc<dyn VirtioInterrupt>;

        common.activate(&queues, interrupt_cb).unwrap();
        common.resume().unwrap();

        assert_eq!(queues[0].2.read().unwrap(), 1);
        assert_eq!(queues[1].2.read().unwrap(), 1);
        assert_eq!(*interrupt.queue_indices.lock().unwrap(), vec![1, 3]);
    }

    #[test]
    fn reset_clears_paused_without_workers() {
        // reset() before any worker was spawned must still clear paused, or
        // the next activation's workers would park immediately and never run.
        let mut common = VirtioCommon::new(false).unwrap();
        common.pause_common.pause().unwrap();
        assert!(common.workers.is_none());

        common.reset();

        assert!(!common.pause_common.pause_requested());
    }

    #[test]
    fn pause_handles_late_threads_and_immediate_resume() {
        let mut device = PauseTestDevice::new();

        // Late threads must acknowledge pause before processing queued work.
        device = device.pause_during_startup();
        for (index, queue_evt) in device.queue_evts.iter().enumerate() {
            queue_evt.write(index as u64 + 1).unwrap();
        }
        assert!(matches!(
            device.requests.recv_timeout(Duration::from_millis(20)),
            Err(mpsc::RecvTimeoutError::Timeout)
        ));

        // A brief resume must not prevent the following pause from completing.
        device = device.resume_and_pause();
        device.common.resume().unwrap();
        let timeout = PauseTestDevice::TIMEOUT;
        let mut values = vec![
            device.requests.recv_timeout(timeout).unwrap(),
            device.requests.recv_timeout(timeout).unwrap(),
        ];
        values.sort_unstable();
        assert_eq!(values, vec![1, 2]);
        device.common.reset();
        assert_eq!(device.status.load(Ordering::SeqCst), 0);
    }
}
