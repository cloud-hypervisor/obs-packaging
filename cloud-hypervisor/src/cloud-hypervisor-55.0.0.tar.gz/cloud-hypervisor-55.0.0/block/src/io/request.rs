// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// Copyright © 2020 Intel Corporation
//
// Copyright (c) Meta Platforms, Inc. and affiliates.
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::mem;
use std::os::unix::fs::FileExt;
use std::sync::Arc;
use std::time::Instant;

use log::{error, warn};
use smallvec::SmallVec;
use virtio_bindings::virtio_blk::{
    VIRTIO_BLK_T_DISCARD, VIRTIO_BLK_T_WRITE_ZEROES, VIRTIO_BLK_WRITE_ZEROES_FLAG_UNMAP,
    virtio_blk_discard_write_zeroes, virtio_blk_outhdr,
};
use virtio_queue::DescriptorChain;
use vm_memory::bitmap::Bitmap;
use vm_memory::{
    Address as _, Bytes as _, GuestAddress, GuestMemoryBackend, GuestMemoryError,
    GuestMemoryLoadGuard,
};
use vm_virtio::checked_descriptor::DescriptorChainExt;
use vm_virtio::{AccessPlatform, AccessType, Translatable};
use vmm_sys_util::file_traits::FileSync;

use crate::async_io::{
    AsyncIo, AsyncIoCompletion, AsyncIoOperation, GuestMemoryTarget, OwnedIoBuffer,
};
use crate::{Error, ExecuteError, request_type, sector};

const SECTOR_SHIFT: u8 = 9;
pub const SECTOR_SIZE: u64 = 0x01 << SECTOR_SHIFT;

/// Maximum number of segments per DISCARD or WRITE_ZEROES request.
pub const MAX_DISCARD_WRITE_ZEROES_SEG: u32 = 1;
/// Size and field offsets within `struct virtio_blk_discard_write_zeroes`.
const DISCARD_WZ_SEG_SIZE: u32 = size_of::<virtio_blk_discard_write_zeroes>() as u32;
const DISCARD_WZ_MAX_PAYLOAD: u32 = DISCARD_WZ_SEG_SIZE * MAX_DISCARD_WRITE_ZEROES_SEG;
const DISCARD_WZ_SECTOR_OFFSET: u64 =
    mem::offset_of!(virtio_blk_discard_write_zeroes, sector) as u64;
const DISCARD_WZ_NUM_SECTORS_OFFSET: u64 =
    mem::offset_of!(virtio_blk_discard_write_zeroes, num_sectors) as u64;
const DISCARD_WZ_FLAGS_OFFSET: u64 = mem::offset_of!(virtio_blk_discard_write_zeroes, flags) as u64;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RequestType {
    In,
    Out,
    Flush,
    GetDeviceId,
    Discard,
    WriteZeroes,
    Unsupported(u32),
}

pub const DEFAULT_DESCRIPTOR_VEC_SIZE: usize = 32;

pub struct ExecuteAsync {
    // `true` if the execution will complete asynchronously
    pub async_complete: bool,
    // request need to be batched for submission if any
    pub batch_request: Option<AsyncIoOperation>,
}

#[derive(Debug)]
pub struct Request {
    request_type: RequestType,
    sector: u64,
    data_descriptors: SmallVec<[(GuestAddress, u32); DEFAULT_DESCRIPTOR_VEC_SIZE]>,
    pub writeback: bool,
    start: Instant,
}

impl Request {
    pub fn parse<M: GuestMemoryBackend>(
        desc_chain: &mut DescriptorChain<GuestMemoryLoadGuard<M>>,
        access_platform: Option<&dyn AccessPlatform>,
    ) -> (Result<Request, Error>, Option<GuestAddress>) {
        let status_addr = match Self::find_status_addr(&mut desc_chain.clone(), access_platform) {
            Ok(status_addr) => status_addr,
            Err(e) => return (Err(e), None),
        };

        let result = (|| -> Result<Request, Error> {
            let hdr_desc = desc_chain
                .next_checked(access_platform)
                .map_err(|addr| Error::GuestMemory(GuestMemoryError::InvalidGuestAddress(addr)))?
                .ok_or_else(|| {
                    error!("Missing head descriptor");
                    Error::DescriptorChainTooShort
                })?;

            // The head contains the request type which MUST be readable.
            if hdr_desc.is_write_only() {
                return Err(Error::UnexpectedWriteOnlyDescriptor);
            }

            if (hdr_desc.len() as usize) < size_of::<virtio_blk_outhdr>() {
                return Err(Error::DescriptorLengthTooSmall);
            }

            let hdr_desc_addr = hdr_desc.addr();

            let mut req = Request {
                request_type: request_type(desc_chain.memory(), hdr_desc_addr)?,
                sector: sector(desc_chain.memory(), hdr_desc_addr)?,
                data_descriptors: SmallVec::with_capacity(DEFAULT_DESCRIPTOR_VEC_SIZE),
                writeback: true,
                start: Instant::now(),
            };

            let mut desc = desc_chain
                .next_checked(access_platform)
                .map_err(|addr| Error::GuestMemory(GuestMemoryError::InvalidGuestAddress(addr)))?
                .ok_or_else(|| {
                    error!("Only head descriptor present: request = {req:?}");
                    Error::DescriptorChainTooShort
                })?;

            if desc.has_next() {
                req.data_descriptors.reserve_exact(1);
                while desc.has_next() {
                    if desc.is_write_only() && req.request_type == RequestType::Out {
                        return Err(Error::UnexpectedWriteOnlyDescriptor);
                    }
                    if desc.is_write_only() && req.request_type == RequestType::Discard {
                        return Err(Error::UnexpectedWriteOnlyDescriptor);
                    }
                    if desc.is_write_only() && req.request_type == RequestType::WriteZeroes {
                        return Err(Error::UnexpectedWriteOnlyDescriptor);
                    }
                    if !desc.is_write_only() && req.request_type == RequestType::In {
                        return Err(Error::UnexpectedReadOnlyDescriptor);
                    }
                    if !desc.is_write_only() && req.request_type == RequestType::GetDeviceId {
                        return Err(Error::UnexpectedReadOnlyDescriptor);
                    }

                    req.data_descriptors.push((desc.addr(), desc.len()));
                    desc = desc_chain
                        .next_checked(access_platform)
                        .map_err(|addr| {
                            Error::GuestMemory(GuestMemoryError::InvalidGuestAddress(addr))
                        })?
                        .ok_or_else(|| {
                            error!("DescriptorChain corrupted: request = {req:?}");
                            Error::DescriptorChainTooShort
                        })?;
                }
            } else {
                // Only flush requests are allowed to skip the data descriptor.
                if req.request_type != RequestType::Flush {
                    error!("Need a data descriptor: request = {req:?}");
                    return Err(Error::DescriptorChainTooShort);
                }
            }

            Ok(req)
        })();

        (result, Some(status_addr))
    }

    fn find_status_addr<M: GuestMemoryBackend>(
        desc_chain: &mut DescriptorChain<GuestMemoryLoadGuard<M>>,
        access_platform: Option<&dyn AccessPlatform>,
    ) -> Result<GuestAddress, Error> {
        let status_desc = desc_chain
            .by_ref()
            .last()
            .ok_or(Error::DescriptorChainTooShort)?;

        if status_desc.has_next() {
            return Err(Error::DescriptorChainTooShort);
        }
        // The status MUST always be writable.
        if !status_desc.is_write_only() {
            return Err(Error::UnexpectedReadOnlyDescriptor);
        }
        if status_desc.len() == 0 {
            return Err(Error::DescriptorLengthTooSmall);
        }

        let addr = status_desc
            .addr()
            .translate_gva(access_platform, 1, AccessType::Write)
            .map_err(|_| {
                Error::GuestMemory(GuestMemoryError::InvalidGuestAddress(status_desc.addr()))
            })?;
        desc_chain
            .memory()
            .check_range(addr, 1)
            .then_some(addr)
            .ok_or(Error::GuestMemory(GuestMemoryError::InvalidGuestAddress(
                addr,
            )))
    }

    pub fn execute<T: FileExt + FileSync, M: GuestMemoryBackend>(
        &self,
        disk: &mut T,
        disk_nsectors: u64,
        mem: &M,
        serial: &[u8],
    ) -> Result<u32, ExecuteError> {
        self.check_data_bounds(disk_nsectors)?;

        let mut offset = self.sector << SECTOR_SHIFT;
        let mut len = 0;
        for (data_addr, data_len) in &self.data_descriptors {
            match self.request_type {
                RequestType::In => {
                    let mut buf = vec![0u8; *data_len as usize];
                    disk.read_exact_at(&mut buf, offset)
                        .map_err(ExecuteError::ReadExact)?;
                    mem.read_exact_volatile_from(
                        *data_addr,
                        &mut buf.as_slice(),
                        *data_len as usize,
                    )
                    .map_err(ExecuteError::Read)?;
                    offset += u64::from(*data_len);
                    len += data_len;
                }
                RequestType::Out => {
                    let mut buf: Vec<u8> = Vec::new();
                    mem.write_all_volatile_to(*data_addr, &mut buf, *data_len as usize)
                        .map_err(ExecuteError::Write)?;
                    disk.write_all_at(&buf, offset)
                        .map_err(ExecuteError::WriteAll)?;
                    if !self.writeback {
                        disk.fsync().map_err(ExecuteError::Flush)?;
                    }
                    offset += u64::from(*data_len);
                }
                RequestType::Flush => disk.fsync().map_err(ExecuteError::Flush)?,
                RequestType::GetDeviceId => {
                    if (*data_len as usize) < serial.len() {
                        return Err(ExecuteError::BadRequest(Error::InvalidOffset));
                    }
                    mem.write_slice(serial, *data_addr)
                        .map_err(ExecuteError::Write)?;
                }
                RequestType::Discard => {
                    return Err(ExecuteError::Unsupported(VIRTIO_BLK_T_DISCARD));
                }
                RequestType::WriteZeroes => {
                    return Err(ExecuteError::Unsupported(VIRTIO_BLK_T_WRITE_ZEROES));
                }
                RequestType::Unsupported(t) => return Err(ExecuteError::Unsupported(t)),
            }
        }
        Ok(len)
    }

    pub fn execute_async<M: GuestMemoryBackend + Send + Sync + 'static>(
        &mut self,
        mem: Arc<M>,
        disk_nsectors: u64,
        disk_image: &mut dyn AsyncIo,
        serial: &[u8],
        user_data: u64,
    ) -> Result<ExecuteAsync, ExecuteError> {
        let sector = self.sector;
        let request_type = self.request_type;
        let offset = (sector << SECTOR_SHIFT) as libc::off_t;
        let alignment = disk_image.alignment();

        self.check_data_bounds(disk_nsectors)?;

        let mut ret = ExecuteAsync {
            async_complete: true,
            batch_request: None,
        };
        // Queue operations expected to be submitted.
        match request_type {
            RequestType::In | RequestType::Out => {
                let op = self.build_data_operation(mem, offset, alignment, user_data)?;
                if disk_image.batch_requests_enabled() {
                    ret.batch_request = Some(op);
                } else {
                    disk_image.submit_data_operation(op).map_err(|e| {
                        if request_type == RequestType::In {
                            ExecuteError::AsyncRead(e)
                        } else {
                            ExecuteError::AsyncWrite(e)
                        }
                    })?;
                }
            }
            RequestType::Flush => {
                disk_image
                    .fsync(Some(user_data))
                    .map_err(ExecuteError::AsyncFlush)?;
            }
            RequestType::GetDeviceId => {
                let (data_addr, data_len) = if self.data_descriptors.len() == 1 {
                    (self.data_descriptors[0].0, self.data_descriptors[0].1)
                } else {
                    return Err(ExecuteError::BadRequest(Error::TooManyDescriptors));
                };
                if (data_len as usize) < serial.len() {
                    return Err(ExecuteError::BadRequest(Error::InvalidOffset));
                }
                mem.write_slice(serial, data_addr)
                    .map_err(ExecuteError::Write)?;
                ret.async_complete = false;
                return Ok(ret);
            }
            RequestType::Discard => {
                let (data_addr, data_len) = if self.data_descriptors.len() == 1 {
                    (self.data_descriptors[0].0, self.data_descriptors[0].1)
                } else {
                    return Err(ExecuteError::BadRequest(Error::TooManyDescriptors));
                };

                if data_len < DISCARD_WZ_SEG_SIZE {
                    return Err(ExecuteError::BadRequest(Error::DescriptorLengthTooSmall));
                }
                if data_len > DISCARD_WZ_MAX_PAYLOAD {
                    return Err(ExecuteError::BadRequest(Error::TooManySegments(
                        data_len.div_ceil(DISCARD_WZ_SEG_SIZE),
                    )));
                }

                let mut discard_sector = [0u8; 8];
                let mut discard_num_sectors = [0u8; 4];
                let mut discard_flags = [0u8; 4];

                let sector_addr = data_addr.checked_add(DISCARD_WZ_SECTOR_OFFSET).unwrap();
                mem.read_slice(&mut discard_sector, sector_addr)
                    .map_err(ExecuteError::Read)?;

                let num_sectors_addr = data_addr
                    .checked_add(DISCARD_WZ_NUM_SECTORS_OFFSET)
                    .unwrap();
                mem.read_slice(&mut discard_num_sectors, num_sectors_addr)
                    .map_err(ExecuteError::Read)?;

                let flags_addr = data_addr.checked_add(DISCARD_WZ_FLAGS_OFFSET).unwrap();
                mem.read_slice(&mut discard_flags, flags_addr)
                    .map_err(ExecuteError::Read)?;

                let discard_flags = u32::from_le_bytes(discard_flags);
                // Per virtio spec v1.2 reject discard if any flag is set, including unmap.
                if discard_flags != 0 {
                    warn!("Unsupported flags {discard_flags:#x} in discard request");
                    return Err(ExecuteError::UnsupportedFlags {
                        request_type: VIRTIO_BLK_T_DISCARD,
                        flags: discard_flags,
                    });
                }

                let discard_sector = u64::from_le_bytes(discard_sector);
                let discard_num_sectors = u32::from_le_bytes(discard_num_sectors);

                let top = discard_sector
                    .checked_add(discard_num_sectors as u64)
                    .ok_or(ExecuteError::BadRequest(Error::InvalidOffset))?;
                if top > disk_nsectors {
                    return Err(ExecuteError::BadRequest(Error::InvalidOffset));
                }

                let discard_offset = discard_sector * SECTOR_SIZE;
                let discard_length = (discard_num_sectors as u64) * SECTOR_SIZE;

                disk_image
                    .punch_hole(discard_offset, discard_length, user_data)
                    .map_err(ExecuteError::AsyncPunchHole)?;
            }
            RequestType::WriteZeroes => {
                let (data_addr, data_len) = if self.data_descriptors.len() == 1 {
                    (self.data_descriptors[0].0, self.data_descriptors[0].1)
                } else {
                    return Err(ExecuteError::BadRequest(Error::TooManyDescriptors));
                };

                if data_len < DISCARD_WZ_SEG_SIZE {
                    return Err(ExecuteError::BadRequest(Error::DescriptorLengthTooSmall));
                }
                if data_len > DISCARD_WZ_MAX_PAYLOAD {
                    return Err(ExecuteError::BadRequest(Error::TooManySegments(
                        data_len.div_ceil(DISCARD_WZ_SEG_SIZE),
                    )));
                }

                let mut wz_sector = [0u8; 8];
                let mut wz_num_sectors = [0u8; 4];
                let mut wz_flags = [0u8; 4];

                let sector_addr = data_addr.checked_add(DISCARD_WZ_SECTOR_OFFSET).unwrap();
                mem.read_slice(&mut wz_sector, sector_addr)
                    .map_err(ExecuteError::Read)?;

                let num_sectors_addr = data_addr
                    .checked_add(DISCARD_WZ_NUM_SECTORS_OFFSET)
                    .unwrap();
                mem.read_slice(&mut wz_num_sectors, num_sectors_addr)
                    .map_err(ExecuteError::Read)?;

                let flags_addr = data_addr.checked_add(DISCARD_WZ_FLAGS_OFFSET).unwrap();
                mem.read_slice(&mut wz_flags, flags_addr)
                    .map_err(ExecuteError::Read)?;

                let wz_sector = u64::from_le_bytes(wz_sector);
                let wz_num_sectors = u32::from_le_bytes(wz_num_sectors);

                let wz_flags = u32::from_le_bytes(wz_flags);
                // Per virtio spec v1.2 reject write zeroes if any unknown flag is set.
                if (wz_flags & !VIRTIO_BLK_WRITE_ZEROES_FLAG_UNMAP) != 0 {
                    warn!("Unsupported flags {wz_flags:#x} in write zeroes request");
                    return Err(ExecuteError::UnsupportedFlags {
                        request_type: VIRTIO_BLK_T_WRITE_ZEROES,
                        flags: wz_flags,
                    });
                }

                let top = wz_sector
                    .checked_add(wz_num_sectors as u64)
                    .ok_or(ExecuteError::BadRequest(Error::InvalidOffset))?;
                if top > disk_nsectors {
                    return Err(ExecuteError::BadRequest(Error::InvalidOffset));
                }

                let wz_offset = wz_sector * SECTOR_SIZE;

                let wz_length = (wz_num_sectors as u64) * SECTOR_SIZE;

                if wz_flags & VIRTIO_BLK_WRITE_ZEROES_FLAG_UNMAP != 0 {
                    disk_image
                        .punch_hole(wz_offset, wz_length, user_data)
                        .map_err(ExecuteError::AsyncPunchHole)?;
                } else {
                    disk_image
                        .write_zeroes(wz_offset, wz_length, user_data)
                        .map_err(ExecuteError::AsyncWriteZeroes)?;
                }
            }
            RequestType::Unsupported(t) => return Err(ExecuteError::Unsupported(t)),
        }

        Ok(ret)
    }

    // Builds a read or write operation for IO to or from `mem`.
    fn build_data_operation<M: GuestMemoryBackend + Send + Sync + 'static>(
        &self,
        mem: Arc<M>,
        offset: libc::off_t,
        alignment: Option<u64>,
        user_data: u64,
    ) -> Result<AsyncIoOperation, ExecuteError> {
        if offset < 0 {
            return Err(ExecuteError::BadRequest(Error::InvalidOffset));
        }

        if let Some(alignment) = alignment
            && (!(offset as u64).is_multiple_of(alignment)
                || !(self.data_len() as u64).is_multiple_of(alignment))
        {
            return Err(ExecuteError::BadRequest(Error::InvalidDataAlignment(
                alignment,
            )));
        }

        if let Some(alignment) = alignment
            && !self.guest_memory_is_aligned(mem.as_ref(), alignment)?
        {
            // The guest-memory buffers are unaligned, so use an aligned bounce buffer.
            let mut buffer = OwnedIoBuffer::new(self.data_len(), alignment as usize)
                .map_err(ExecuteError::TemporaryBufferAllocation)?;

            if self.request_type == RequestType::Out {
                self.copy_guest_to_buffer(mem.as_ref(), buffer.as_mut_slice())?;
            }

            return Ok(match self.request_type {
                RequestType::In => AsyncIoOperation::read_to_vec(offset, buffer, user_data),
                RequestType::Out => AsyncIoOperation::write_from_vec(offset, buffer, user_data),
                _ => unreachable!("unexpected data operation type"),
            });
        }

        let target = GuestMemoryTarget::new(mem, &self.data_descriptors)
            .map_err(ExecuteError::GetHostAddress)?;
        Ok(match self.request_type {
            RequestType::In => AsyncIoOperation::read_to_memory(offset, target, user_data),
            RequestType::Out => AsyncIoOperation::write_from_memory(offset, target, user_data),
            _ => unreachable!("unexpected data operation type"),
        })
    }

    // Checks whether `self.data_descriptors` are aligned to `alignment`.
    fn guest_memory_is_aligned<M: GuestMemoryBackend>(
        &self,
        mem: &M,
        alignment: u64,
    ) -> Result<bool, ExecuteError> {
        if alignment <= 1 {
            return Ok(true);
        }

        for &(data_addr, data_len) in &self.data_descriptors {
            let _: u32 = data_len;
            const _: () = assert!(
                size_of::<u32>() <= size_of::<usize>(),
                "unsupported platform"
            );
            if data_len == 0 {
                continue;
            }
            let data_len = data_len as usize;
            let origin_ptr = mem
                .get_slice(data_addr, data_len)
                .map_err(ExecuteError::GetHostAddress)?;
            let origin_ptr = origin_ptr.ptr_guard_mut();
            if !(origin_ptr.as_ptr() as u64).is_multiple_of(alignment)
                || !(origin_ptr.len() as u64).is_multiple_of(alignment)
            {
                return Ok(false);
            }
        }

        Ok(true)
    }

    // Returns the sum of the lengths of `self.data_descriptors`.
    fn data_len(&self) -> usize {
        self.data_descriptors
            .iter()
            .map(|(_, len)| *len as usize)
            .sum()
    }

    // Marks the first `len` bytes of the read destinations dirty.
    fn mark_read_dirty<M: GuestMemoryBackend>(&self, mem: &M, len: usize) -> Result<(), Error> {
        let mut remaining = len;
        for (data_addr, data_len) in &self.data_descriptors {
            if *data_len == 0 {
                continue;
            }
            if remaining == 0 {
                break;
            }
            let data_len = (*data_len as usize).min(remaining);
            mem.get_slice(*data_addr, data_len)
                .map_err(Error::GuestMemory)?
                .bitmap()
                .mark_dirty(0, data_len);
            remaining -= data_len;
        }
        Ok(())
    }

    // Copies guest descriptor contents into a contiguous host buffer.
    fn copy_guest_to_buffer<M: GuestMemoryBackend>(
        &self,
        mem: &M,
        buffer: &mut [u8],
    ) -> Result<(), ExecuteError> {
        let mut offset = 0usize;
        for (data_addr, data_len) in &self.data_descriptors {
            let data_len = *data_len as usize;
            mem.read_slice(&mut buffer[offset..offset + data_len], *data_addr)
                .map_err(ExecuteError::Read)?;
            offset += data_len;
        }
        Ok(())
    }

    // Copies a host completion buffer back into guest descriptors.
    fn copy_buffer_to_guest<M: GuestMemoryBackend>(
        &self,
        mem: &M,
        buffer: &[u8],
    ) -> Result<(), Error> {
        let mut buffer_offset = 0usize;
        for (data_addr, data_len) in &self.data_descriptors {
            if buffer_offset >= buffer.len() {
                break;
            }
            let data_len = (*data_len as usize).min(buffer.len() - buffer_offset);
            mem.write_slice(&buffer[buffer_offset..buffer_offset + data_len], *data_addr)
                .map_err(Error::GuestMemory)?;
            buffer_offset += data_len;
        }
        Ok(())
    }

    pub fn complete_async<M: GuestMemoryBackend>(
        &mut self,
        mem: &M,
        completion: &mut AsyncIoCompletion,
    ) -> Result<(), Error> {
        if self.request_type == RequestType::In && completion.result > 0 {
            if let Some(buffer) = completion.buffer.take() {
                let len = (completion.result as usize).min(buffer.as_slice().len());
                self.copy_buffer_to_guest(mem, &buffer.as_slice()[..len])?;
            } else {
                // No bounce buffer: the kernel read through raw iovecs (io_uring,
                // AIO or preadv()) straight into guest memory, which bypasses the
                // dirty bitmap. Formats that copy the data themselves already
                // marked it, so marking it again is harmless.
                self.mark_read_dirty(mem, completion.result as usize)?;
            }
        }

        Ok(())
    }

    #[inline]
    pub fn data_descriptors(
        &self,
    ) -> &SmallVec<[(GuestAddress, u32); DEFAULT_DESCRIPTOR_VEC_SIZE]> {
        &self.data_descriptors
    }

    #[inline]
    pub fn start(&self) -> Instant {
        self.start
    }

    #[inline]
    pub fn sector(&self) -> u64 {
        self.sector
    }

    #[inline]
    pub fn request_type(&self) -> RequestType {
        self.request_type
    }

    /// For In and Out requests, checks that the descriptors collectively fit in a backing disk of
    /// the given size. Returns `Ok(())` if they fit, or `ExecuteError::BadRequest` otherwise.
    fn check_data_bounds(&self, disk_nsectors: u64) -> Result<(), ExecuteError> {
        if !matches!(self.request_type, RequestType::In | RequestType::Out) {
            return Ok(());
        }
        let mut total_bytes: u64 = 0;
        for (_, data_len) in &self.data_descriptors {
            total_bytes = total_bytes
                .checked_add(u64::from(*data_len))
                .ok_or(ExecuteError::BadRequest(Error::InvalidOffset))?;
        }
        if !total_bytes.is_multiple_of(SECTOR_SIZE) {
            return Err(ExecuteError::BadRequest(Error::InvalidDataLength));
        }
        let total_sectors = total_bytes / SECTOR_SIZE;
        let end_sector = self
            .sector
            .checked_add(total_sectors)
            .ok_or(ExecuteError::BadRequest(Error::InvalidOffset))?;
        if end_sector > disk_nsectors {
            return Err(ExecuteError::BadRequest(Error::InvalidOffset));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use vm_memory::GuestMemoryMmap;
    use vmm_sys_util::eventfd::EventFd;

    use super::*;
    use crate::async_io::{AsyncIo, AsyncIoCompletion, AsyncIoOperation, AsyncIoResult};

    /// Records submitted data operations instead of performing them.
    struct RecordingAsyncIo {
        notifier: EventFd,
        submitted: Vec<AsyncIoOperation>,
    }

    impl RecordingAsyncIo {
        fn new() -> Self {
            Self {
                notifier: EventFd::new(0).unwrap(),
                submitted: Vec::new(),
            }
        }
    }

    impl AsyncIo for RecordingAsyncIo {
        fn notifier(&self) -> &EventFd {
            &self.notifier
        }
        fn submit_data_operation(&mut self, op: AsyncIoOperation) -> AsyncIoResult<()> {
            self.submitted.push(op);
            Ok(())
        }
        fn fsync(&mut self, _: Option<u64>) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn punch_hole(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn write_zeroes(&mut self, _: u64, _: u64, _: u64) -> AsyncIoResult<()> {
            unreachable!()
        }
        fn next_completed_request(&mut self) -> Option<AsyncIoCompletion> {
            None
        }
    }

    #[test]
    fn invalid_data_operations_are_rejected() {
        let mem = Arc::new(GuestMemoryMmap::<()>::from_ranges(&[(GuestAddress(0), 8192)]).unwrap());
        for request_type in [RequestType::In, RequestType::Out] {
            for (alignment, offset, len) in [
                (Some(4096), 512, 4096),
                (Some(4096), 0, 512),
                (None, -512, 0),
                (Some(4096), -512, 0),
            ] {
                let request = Request {
                    request_type,
                    sector: 0,
                    data_descriptors: SmallVec::from_slice(&[(GuestAddress(0), len)]),
                    writeback: true,
                    start: Instant::now(),
                };
                let result = request.build_data_operation(Arc::clone(&mem), offset, alignment, 1);
                if offset < 0 {
                    assert!(matches!(
                        result,
                        Err(ExecuteError::BadRequest(Error::InvalidOffset))
                    ));
                } else {
                    assert!(matches!(
                        result,
                        Err(ExecuteError::BadRequest(Error::InvalidDataAlignment(4096)))
                    ));
                }
            }
        }
    }

    #[test]
    fn unaligned_guest_buffers_are_bounced() {
        let mem = Arc::new(GuestMemoryMmap::<()>::from_ranges(&[(GuestAddress(0), 8192)]).unwrap());
        mem.write_slice(&vec![0x5a; 4096], GuestAddress(1)).unwrap();
        for request_type in [RequestType::In, RequestType::Out] {
            let request = Request {
                request_type,
                sector: 8,
                data_descriptors: SmallVec::from_slice(&[
                    (GuestAddress(1), 512),
                    (GuestAddress(513), 3584),
                ]),
                writeback: true,
                start: Instant::now(),
            };
            let op = request
                .build_data_operation(Arc::clone(&mem), 4096, Some(4096), 1)
                .unwrap();
            assert_eq!(op.offset(), 4096);
            assert_eq!(op.total_len(), 4096);
            assert_eq!(op.iovecs().len(), 1);
            assert!((op.iovecs()[0].iov_base as usize).is_multiple_of(4096));
            match op {
                AsyncIoOperation::WriteFromVec { buffer, .. } => {
                    assert!(buffer.as_slice().iter().all(|byte| *byte == 0x5a));
                }
                AsyncIoOperation::ReadToVec { .. } => {}
                _ => panic!("Expected an owned bounce buffer"),
            }
        }
    }

    #[test]
    fn write_zeroes_rejects_sector_arithmetic_overflow() {
        let mem = Arc::new(GuestMemoryMmap::<()>::from_ranges(&[(GuestAddress(0), 4096)]).unwrap());
        mem.write_slice(&(u64::MAX - 100).to_le_bytes(), GuestAddress(0))
            .unwrap();
        mem.write_slice(&1000u32.to_le_bytes(), GuestAddress(8))
            .unwrap();

        let mut request = Request {
            request_type: RequestType::WriteZeroes,
            sector: 0,
            data_descriptors: SmallVec::from_slice(&[(GuestAddress(0), DISCARD_WZ_SEG_SIZE)]),
            writeback: true,
            start: Instant::now(),
        };
        let mut disk = RecordingAsyncIo::new();

        let Err(ExecuteError::BadRequest(Error::InvalidOffset)) =
            request.execute_async(mem, 1024, &mut disk, &[], 0)
        else {
            panic!("expected BadRequest(InvalidOffset)");
        };
    }

    /// Drives the real submit path: page-aligned buffers are read straight
    /// into guest memory, the completion is built from the submitted
    /// operation as the engines do, and the dirty log is harvested while the
    /// read is in flight, as the migration thread does. A mark placed before
    /// the submit does not survive that harvest.
    #[test]
    fn read_marks_survive_a_dirty_log_harvest_while_in_flight() {
        use vm_allocator::page_size::get_page_size;
        use vm_memory::bitmap::AtomicBitmap;
        use vm_memory::{GuestMemoryBackend, GuestMemoryRegion};

        let page_size = get_page_size();
        let mem = Arc::new(
            GuestMemoryMmap::<AtomicBitmap>::from_ranges(&[(
                GuestAddress(0),
                16 * page_size as usize,
            )])
            .unwrap(),
        );
        let mut request = Request {
            request_type: RequestType::In,
            sector: 0,
            data_descriptors: SmallVec::from_slice(&[
                (GuestAddress(page_size), page_size as u32),
                (GuestAddress(4 * page_size), 2 * page_size as u32),
            ]),
            writeback: true,
            start: Instant::now(),
        };
        let mut disk = RecordingAsyncIo::new();
        request
            .execute_async(Arc::clone(&mem), 1024, &mut disk, &[], 0)
            .unwrap();
        let op = disk.submitted.pop().unwrap();
        assert!(matches!(op, AsyncIoOperation::ReadToMemory { .. }));

        // The interesting part: the migration thread harvests the dirty log
        // while the read is still in flight. A page marked dirty at submit
        // time is consumed here, and nothing would mark it dirty again.
        let region = mem.find_region(GuestAddress(0)).unwrap();
        (**region).bitmap().get_and_reset();

        // The backend filled the first buffer and one page of the second
        let mut completion = AsyncIoCompletion::from_operation(op, 2 * page_size as i32);
        request
            .complete_async(mem.as_ref(), &mut completion)
            .unwrap();

        let bitmap = region.bitmap();
        assert!(bitmap.dirty_at(page_size as usize));
        assert!(bitmap.dirty_at(4 * page_size as usize));
        assert!(!bitmap.dirty_at(5 * page_size as usize));
    }

    // A request without data still has to start within the disk.
    #[test]
    fn zero_length_request_past_capacity_is_rejected() {
        for request_type in [RequestType::In, RequestType::Out] {
            for (sector, valid) in [(1024, true), (1025, false), (1 << 54, false)] {
                let request = Request {
                    request_type,
                    sector,
                    data_descriptors: SmallVec::from_slice(&[(GuestAddress(0), 0)]),
                    writeback: true,
                    start: Instant::now(),
                };
                let result = request.check_data_bounds(1024);
                if valid {
                    result.expect("an empty request at capacity should be accepted");
                } else {
                    assert!(
                        matches!(result, Err(ExecuteError::BadRequest(Error::InvalidOffset))),
                        "empty request at sector {sector} was accepted"
                    );
                }
            }
        }
    }

    #[test]
    fn short_header_descriptor_is_rejected() {
        use virtio_bindings::virtio_blk::VIRTIO_BLK_T_IN;
        use virtio_bindings::virtio_ring::{VRING_DESC_F_NEXT, VRING_DESC_F_WRITE};
        use virtio_queue::QueueT;
        use vm_memory::bitmap::AtomicBitmap;
        use vm_memory::{GuestAddressSpace, GuestMemoryAtomic};
        use vm_virtio::queue::testing::VirtQueue as GuestQ;

        let mem =
            GuestMemoryMmap::<AtomicBitmap>::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
        mem.write_obj(VIRTIO_BLK_T_IN, GuestAddress(0x2000))
            .unwrap();
        let mem_atomic = GuestMemoryAtomic::new(mem.clone());

        for (hdr_len, valid) in [(0, false), (8, false), (15, false), (16, true)] {
            let vq = GuestQ::new(GuestAddress(0x1000), &mem, 4);
            vq.dtable[0].set(0x2000, hdr_len, VRING_DESC_F_NEXT as u16, 1);
            vq.dtable[1].set(
                0x3000,
                512,
                (VRING_DESC_F_NEXT | VRING_DESC_F_WRITE) as u16,
                2,
            );
            vq.dtable[2].set(0x4000, 1, VRING_DESC_F_WRITE as u16, 0);
            vq.avail.ring[0].set(0);
            vq.avail.idx.set(1);

            let mut queue = vq.create_queue();
            let mut chain = queue.pop_descriptor_chain(mem_atomic.memory()).unwrap();
            let (result, _) = Request::parse(&mut chain, None);
            if valid {
                assert_eq!(result.unwrap().request_type(), RequestType::In);
            } else {
                assert!(
                    matches!(result, Err(Error::DescriptorLengthTooSmall)),
                    "header of {hdr_len} bytes was accepted"
                );
            }
        }
    }
}
