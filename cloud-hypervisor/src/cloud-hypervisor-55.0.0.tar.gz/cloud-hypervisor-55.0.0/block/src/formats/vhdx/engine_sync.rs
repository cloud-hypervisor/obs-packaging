// Copyright © 2021 Intel Corporation
//
// Copyright (c) Meta Platforms, Inc. and affiliates.
//
// SPDX-License-Identifier: Apache-2.0

use std::io;
use std::sync::{Arc, RwLock};

use vmm_sys_util::eventfd::EventFd;

use super::dynamic::Vhdx;
use crate::async_io::{
    AsyncIo, AsyncIoCompletion, AsyncIoError, AsyncIoOperation, AsyncIoResult, CompletionCommon,
};

pub(super) struct VhdxSync {
    vhdx_file: Arc<RwLock<Vhdx>>,
    completions: CompletionCommon,
    size: u64,
}

impl VhdxSync {
    pub(super) fn new(vhdx_file: Arc<RwLock<Vhdx>>, size: u64) -> Self {
        VhdxSync {
            vhdx_file,
            completions: CompletionCommon::new(),
            size,
        }
    }

    fn read_operation(&mut self, op: &mut AsyncIoOperation) -> AsyncIoResult<usize> {
        let offset = op.offset();
        let mut buf = vec![0u8; op.total_len()];
        let vhdx = self.vhdx_file.read().unwrap();
        let result = vhdx
            .read_at(&mut buf, offset as u64)
            .map_err(AsyncIoError::ReadVectored)?;
        drop(vhdx);

        op.write_bytes_at(0, &buf[..result])
            .map_err(AsyncIoError::ReadVectored)?;
        Ok(result)
    }

    fn write_operation(&mut self, op: &AsyncIoOperation) -> AsyncIoResult<usize> {
        let offset = op.offset();
        let mut buf = vec![0u8; op.total_len()];
        op.read_bytes_at(0, &mut buf)
            .map_err(AsyncIoError::WriteVectored)?;

        let mut vhdx = self.vhdx_file.write().unwrap();
        vhdx.write_all_at(&buf, offset as u64)
            .map_err(AsyncIoError::WriteVectored)?;
        Ok(buf.len())
    }
}

impl AsyncIo for VhdxSync {
    fn notifier(&self) -> &EventFd {
        self.completions.notifier()
    }

    fn submit_data_operation(&mut self, op: AsyncIoOperation) -> AsyncIoResult<()> {
        op.validate_bounds(self.size)?;
        let is_read = op.is_read();
        let mut op = op;
        let result = if is_read {
            self.read_operation(&mut op)?
        } else {
            self.write_operation(&op)?
        };

        self.completions
            .complete(AsyncIoCompletion::from_operation(op, result as i32));
        Ok(())
    }

    fn fsync(&mut self, user_data: Option<u64>) -> AsyncIoResult<()> {
        self.vhdx_file
            .read()
            .unwrap()
            .flush()
            .map_err(AsyncIoError::Fsync)?;
        if let Some(user_data) = user_data {
            self.completions
                .complete(AsyncIoCompletion::new(user_data, 0, None));
        }
        Ok(())
    }

    fn next_completed_request(&mut self) -> Option<AsyncIoCompletion> {
        self.completions.next_completed()
    }

    fn punch_hole(&mut self, _offset: u64, _length: u64, _user_data: u64) -> AsyncIoResult<()> {
        Err(AsyncIoError::PunchHole(io::Error::other(
            "punch_hole not supported for VHDX",
        )))
    }

    fn write_zeroes(&mut self, _offset: u64, _length: u64, _user_data: u64) -> AsyncIoResult<()> {
        Err(AsyncIoError::WriteZeroes(io::Error::other(
            "write_zeroes not supported for VHDX",
        )))
    }
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, RwLock};

    use vmm_sys_util::tempfile::TempFile;

    use super::*;
    use crate::async_io::{AsyncIo, AsyncIoError, AsyncIoOperation, OwnedIoBuffer};
    use crate::formats::vhdx::test_util::{create_dynamic_vhdx, open_vhdx};

    fn make_vhdx_sync(tf: &TempFile) -> (VhdxSync, u64) {
        let vhdx = open_vhdx(tf.as_path()).unwrap();
        let size = vhdx.virtual_disk_size();
        let sync = VhdxSync::new(Arc::new(RwLock::new(vhdx)), size);
        (sync, size)
    }

    /// Builds a `VhdxSync` from a fresh 1 MiB dynamic VHDX.
    fn setup() -> (VhdxSync, u64) {
        let tf = create_dynamic_vhdx(1, None);
        make_vhdx_sync(&tf)
    }

    #[test]
    fn sync_rejects_read_straddling_logical_size() {
        let (mut sync, size) = setup();

        let op = AsyncIoOperation::read_to_vec(
            (size - 512) as i64,
            OwnedIoBuffer::from_vec(vec![0u8; 1024]),
            1,
        );
        assert!(matches!(
            sync.submit_data_operation(op),
            Err(AsyncIoError::ReadVectored(_))
        ));
    }

    #[test]
    fn sync_rejects_write_straddling_logical_size() {
        let (mut sync, size) = setup();

        let op = AsyncIoOperation::write_from_vec(
            (size - 512) as i64,
            OwnedIoBuffer::from_vec(vec![0u8; 1024]),
            1,
        );
        assert!(matches!(
            sync.submit_data_operation(op),
            Err(AsyncIoError::WriteVectored(_))
        ));
    }

    #[test]
    fn sync_accepts_operation_exactly_filling_logical_size() {
        let (mut sync, size) = setup();

        let op =
            AsyncIoOperation::read_to_vec(0, OwnedIoBuffer::from_vec(vec![0u8; size as usize]), 1);
        sync.submit_data_operation(op).unwrap();
    }

    #[test]
    fn sync_accepts_operation_at_last_sector() {
        let (mut sync, size) = setup();

        // VHDX operates in 512-byte sectors; read exactly the last sector.
        let op = AsyncIoOperation::read_to_vec(
            (size - 512) as i64,
            OwnedIoBuffer::from_vec(vec![0u8; 512]),
            1,
        );
        sync.submit_data_operation(op).unwrap();
    }
}
