// Copyright 2018 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::collections::HashMap;
use std::collections::hash_map::IterMut;
use std::io;
use std::ops::{Deref, Index, IndexMut};
use std::slice::SliceIndex;

/// Trait that allows for checking if an implementor is dirty. Useful for types that are cached so
/// it can be checked if they need to be committed to disk.
pub(super) trait Cacheable {
    /// Used to check if the item needs to be written out or if it can be discarded.
    fn dirty(&self) -> bool;
}

#[derive(Clone, Debug)]
/// Represents a vector that implements the `Cacheable` trait so it can be held in a cache.
pub(super) struct VecCache<T: 'static + Copy + Default> {
    vec: Box<[T]>,
    dirty: bool,
}

impl<T: 'static + Copy + Default> VecCache<T> {
    /// Creates a `VecCache` that can hold `count` elements.
    pub(super) fn new(count: usize) -> VecCache<T> {
        VecCache {
            vec: vec![Default::default(); count].into_boxed_slice(),
            dirty: true,
        }
    }

    /// Creates a `VecCache` from the passed in `vec`.
    pub(super) fn from_vec(vec: Vec<T>) -> VecCache<T> {
        VecCache {
            vec: vec.into_boxed_slice(),
            dirty: false,
        }
    }

    pub(super) fn get<I>(&self, index: I) -> Option<&<I as SliceIndex<[T]>>::Output>
    where
        I: SliceIndex<[T]>,
    {
        self.vec.get(index)
    }

    /// Gets a reference to the underlying vector.
    pub(super) fn get_values(&self) -> &[T] {
        &self.vec
    }

    /// Mark this cache element as clean.
    pub(super) fn mark_clean(&mut self) {
        self.dirty = false;
    }

    /// Returns the number of elements in the vector.
    pub(super) fn len(&self) -> usize {
        self.vec.len()
    }

    /// Extends the cache capacity to `new_len` elements.
    ///
    /// No-op if `new_len <= self.len()`. Allocates a new buffer, copies
    /// existing data, and fills new elements with default values.
    /// Marks the cache as dirty.
    pub(super) fn extend(&mut self, new_len: usize) {
        if new_len <= self.vec.len() {
            return;
        }
        let mut new_vec = vec![Default::default(); new_len];
        new_vec[..self.vec.len()].copy_from_slice(&self.vec);
        self.vec = new_vec.into_boxed_slice();
        self.dirty = true;
    }
}

impl<T: 'static + Copy + Default> Cacheable for VecCache<T> {
    fn dirty(&self) -> bool {
        self.dirty
    }
}

impl<T: 'static + Copy + Default> Index<usize> for VecCache<T> {
    type Output = T;

    fn index(&self, index: usize) -> &T {
        self.vec.index(index)
    }
}

impl<T: 'static + Copy + Default> IndexMut<usize> for VecCache<T> {
    fn index_mut(&mut self, index: usize) -> &mut T {
        self.dirty = true;
        self.vec.index_mut(index)
    }
}

impl<T: 'static + Copy + Default> Deref for VecCache<T> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        &self.vec
    }
}

#[derive(Clone, Debug)]
pub(super) struct CacheMap<T: Cacheable> {
    capacity: usize,
    map: HashMap<usize, T>,
}

impl<T: Cacheable> CacheMap<T> {
    pub(super) fn new(capacity: usize) -> Self {
        CacheMap {
            capacity,
            map: HashMap::with_capacity(capacity),
        }
    }

    pub(super) fn contains_key(&self, key: usize) -> bool {
        self.map.contains_key(&key)
    }

    pub(super) fn get(&self, index: usize) -> Option<&T> {
        self.map.get(&index)
    }

    pub(super) fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        self.map.get_mut(&index)
    }

    pub(super) fn iter_mut(&mut self) -> IterMut<'_, usize, T> {
        self.map.iter_mut()
    }

    // Check if the refblock cache is full and we need to evict.
    pub(super) fn insert<F>(&mut self, index: usize, block: T, write_callback: F) -> io::Result<()>
    where
        F: FnOnce(usize, &T) -> io::Result<()>,
    {
        if self.map.len() == self.capacity {
            // TODO(dgreid) - smarter eviction strategy.
            let to_evict = *self.map.iter().next().unwrap().0;
            if let Some(evicted) = self.map.get(&to_evict)
                && evicted.dirty()
            {
                write_callback(to_evict, evicted)?;
            }
            self.map.remove(&to_evict);
        }
        self.map.insert(index, block);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct NumCache(());
    impl Cacheable for NumCache {
        fn dirty(&self) -> bool {
            true
        }
    }

    #[test]
    fn failed_writeback_keeps_dirty_entry() {
        let mut cache = CacheMap::new(1);
        let mut table = VecCache::new(1);
        table[0] = 42;
        cache.insert(0, table, |_, _| unreachable!()).unwrap();

        let err = cache
            .insert(1, VecCache::new(1), |index, table| {
                assert_eq!(index, 0);
                assert_eq!(table[0], 42);
                Err(io::Error::from_raw_os_error(libc::ENOSPC))
            })
            .unwrap_err();
        assert_eq!(err.raw_os_error(), Some(libc::ENOSPC));
        assert_eq!(cache.get(0).unwrap()[0], 42);
        assert!(cache.get(0).unwrap().dirty());
        assert!(!cache.contains_key(1));

        let mut written = None;
        cache
            .insert(1, VecCache::new(1), |index, table| {
                written = Some((index, table[0]));
                Ok(())
            })
            .unwrap();
        assert_eq!(written, Some((0, 42)));
        assert!(!cache.contains_key(0));
        assert!(cache.contains_key(1));
    }

    #[test]
    fn evicts_when_full() {
        let mut cache = CacheMap::<NumCache>::new(3);
        let mut evicted = None;
        cache
            .insert(0, NumCache(()), |index, _| {
                evicted = Some(index);
                Ok(())
            })
            .unwrap();
        assert_eq!(evicted, None);
        cache
            .insert(1, NumCache(()), |index, _| {
                evicted = Some(index);
                Ok(())
            })
            .unwrap();
        assert_eq!(evicted, None);
        cache
            .insert(2, NumCache(()), |index, _| {
                evicted = Some(index);
                Ok(())
            })
            .unwrap();
        assert_eq!(evicted, None);
        cache
            .insert(3, NumCache(()), |index, _| {
                evicted = Some(index);
                Ok(())
            })
            .unwrap();
        assert!(evicted.is_some());

        // Check that three of the four items inserted are still there and that the most recently
        // inserted is one of them.
        let num_items = (0..=3).filter(|k| cache.contains_key(*k)).count();
        assert_eq!(num_items, 3);
        assert!(cache.contains_key(3));
    }
}
