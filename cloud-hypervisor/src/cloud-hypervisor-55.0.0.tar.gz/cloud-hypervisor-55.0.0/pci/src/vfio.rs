// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause
//

use std::any::Any;
use std::collections::{BTreeMap, HashMap};
use std::os::fd::BorrowedFd;
#[cfg(feature = "kvm")]
use std::os::fd::OwnedFd;
use std::os::unix::io::AsRawFd;
use std::path::PathBuf;
use std::sync::{Arc, Barrier, Mutex};
use std::{cmp, io, process, result};

use anyhow::{Context, anyhow};
use base64::Engine;
use base64::engine::general_purpose::STANDARD as BASE64_STANDARD;
use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use vfio_bindings::bindings::vfio::{
    vfio_device_mig_state_VFIO_DEVICE_STATE_ERROR as VFIO_DEV_STATE_ERROR,
    vfio_device_mig_state_VFIO_DEVICE_STATE_PRE_COPY as VFIO_DEV_STATE_PRE_COPY,
    vfio_device_mig_state_VFIO_DEVICE_STATE_PRE_COPY_P2P as VFIO_DEV_STATE_PRE_COPY_P2P,
    vfio_device_mig_state_VFIO_DEVICE_STATE_RESUMING as VFIO_DEV_STATE_RESUMING,
    vfio_device_mig_state_VFIO_DEVICE_STATE_RUNNING as VFIO_DEV_STATE_RUNNING,
    vfio_device_mig_state_VFIO_DEVICE_STATE_RUNNING_P2P as VFIO_DEV_STATE_RUNNING_P2P,
    vfio_device_mig_state_VFIO_DEVICE_STATE_STOP as VFIO_DEV_STATE_STOP,
    vfio_device_mig_state_VFIO_DEVICE_STATE_STOP_COPY as VFIO_DEV_STATE_STOP_COPY, *,
};
use vfio_ioctls::{
    DmaLoggingRange, VfioDevice, VfioIrq, VfioOps, VfioRegionInfoCap, VfioRegionSparseMmapArea,
};
#[cfg(feature = "kvm")]
use vfio_ioctls::{VfioIommufd, VfioRegionDmaRange};
use vm_allocator::page_size::{
    align_page_size_down, align_page_size_up, get_page_size, is_4k_aligned, is_4k_multiple,
    is_page_size_aligned,
};
use vm_allocator::{
    AddressAllocator, GuestMemory, GuestRegion, GuestRegionError, MemorySlotAllocator,
    SystemAllocator,
};
use vm_device::dma_mapping::{ExternalDmaMapping, ExternalDmaMappingError};
use vm_device::interrupt::{
    InterruptIndex, InterruptManager, InterruptSourceGroup, MsiIrqGroupConfig,
};
use vm_device::{BusDevice, Resource};
use vm_memory::{
    Address, GuestAddress, GuestAddressSpace, GuestMemoryAtomic, GuestMemoryBackend,
    GuestMemoryRegion, GuestUsize,
};
use vm_migration::protocol::MemoryRangeTable;
use vm_migration::{Migratable, MigratableError, Pausable, Snapshot, Snapshottable, Transportable};
use vmm_sys_util::eventfd::EventFd;

#[cfg(feature = "kvm")]
use crate::configuration::COMMAND_REG_MEMORY_SPACE_MASK;
use crate::configuration::{
    COMMAND_REG, PCI_EXP_FLAGS_TYPE_MASK, PCI_EXP_FLAGS_VERS_MASK, PCI_EXP_FLAGS_VERS_SHIFT,
    PCI_EXP_LNKCTL, PCI_EXP_LNKCTL2, PCI_EXP_TYPE_RC_END, PCI_EXT_CAP_ALIGN, PCI_EXT_CAP_NEXT_MASK,
    PCI_EXT_CAP_NEXT_SHIFT, PCIE_CONFIG_SPACE_SIZE,
};
use crate::msi::{Error as MsiError, MSI_CONFIG_ID, MsiConfigState};
use crate::msix::{Error as MsixError, MaybeMutInterruptSourceGroup, MsixConfigState};
use crate::{
    BarReprogrammingParams, MSIX_CONFIG_ID, MSIX_TABLE_ENTRY_SIZE, MsiCap, MsiConfig, MsixCap,
    MsixConfig, PCI_CONFIGURATION_ID, PciBarConfiguration, PciBarPrefetchable, PciBarRegionType,
    PciBdf, PciCapabilityId, PciClassCode, PciConfiguration, PciDevice, PciDeviceError,
    PciExpressCapability, PciExpressCapabilityId, PciHeaderType, PciSubclass,
    msi_num_enabled_vectors,
};

pub(crate) const VFIO_COMMON_ID: &str = "vfio_common";
pub(crate) const VFIO_MIGRATION_ID: &str = "vfio_migration";

const ONE_GIB: usize = 1024 * 1024 * 1024;

pub(crate) fn find_alignment(len: usize) -> usize {
    let page_size = get_page_size() as usize;
    if len >= ONE_GIB {
        ONE_GIB
    } else {
        len.next_power_of_two().max(page_size)
    }
}

#[derive(Debug, Error)]
pub enum VfioPciError {
    #[error("BAR address overflows: base={base:#x}, offset={offset:#x}")]
    BarAddressOverflow { base: u64, offset: u64 },
    #[error("BAR range overflows: address={address:#x}, size={size:#x}")]
    BarRangeOverflow { address: u64, size: u64 },
    #[error("Failed to move BAR memory region")]
    MoveBarMemoryRegion(#[source] GuestRegionError),
    #[error("Failed to unmap peer to peer DMA")]
    DmaUnmap(#[source] vfio_ioctls::VfioError),
    #[error("Failed to create user memory region")]
    CreateUserMemoryRegion(#[source] GuestRegionError),
    #[error("Failed to DMA map: {0} for device {1} (guest BDF: {2})")]
    DmaMap(#[source] vfio_ioctls::VfioError, PathBuf, PciBdf),
    #[cfg(feature = "kvm")]
    #[error("Failed to map the dma-buf of device {1:?} at {2}")]
    DmaMapFile(#[source] iommufd_ioctls::IommufdError, PathBuf, PciBdf),
    #[error("Failed to enable INTx")]
    EnableIntx(#[source] VfioError),
    #[error("Failed to enable MSI")]
    EnableMsi(#[source] VfioError),
    #[error("Failed to enable MSI-x")]
    EnableMsix(#[source] VfioError),
    #[error("Failed to create MSI interrupt group")]
    CreateMsiInterruptGroup(#[source] io::Error),
    #[error("Failed to create MSI-X interrupt group")]
    CreateMsixInterruptGroup(#[source] io::Error),
    #[error("Failed to initialize MSI")]
    InitializeMsi(#[source] MsiError),
    #[error("Failed to initialize MSI-X")]
    InitializeMsix(#[source] MsixError),
    #[error("Failed to mmap the area")]
    MmapArea,
    #[error("Failed to notifier's eventfd")]
    MissingNotifier,
    #[error("Invalid region alignment")]
    RegionAlignment,
    #[error("Invalid region size")]
    RegionSize,
    #[error("Failed to retrieve MsiConfigState")]
    RetrieveMsiConfigState(#[source] MigratableError),
    #[error("Failed to retrieve MsixConfigState")]
    RetrieveMsixConfigState(#[source] MigratableError),
    #[error("Failed to retrieve PciConfigurationState")]
    RetrievePciConfigurationState(#[source] MigratableError),
    #[error("Failed to retrieve VfioCommonState")]
    RetrieveVfioCommonState(#[source] MigratableError),
    #[error("No space left for the extended capability {0:#x}")]
    ExtendedCapNoSpace(u16),
    #[error("Mismatched dwords and write masks for the extended capability {0:#x}")]
    ExtendedCapMismatchedWriteMasks(u16),
    #[error("Failed to restore VFIO migration state")]
    RestoreMigration(#[source] anyhow::Error),
}

#[derive(Copy, Clone)]
enum PciVfioSubclass {
    VfioSubclass = 0xff,
}

impl PciSubclass for PciVfioSubclass {
    fn get_register_value(&self) -> u8 {
        *self as u8
    }
}

enum InterruptUpdateAction {
    EnableMsi,
    DisableMsi,
    EnableMsix,
    DisableMsix,
}

#[derive(Serialize, Deserialize)]
struct IntxState {
    enabled: bool,
}

pub(crate) struct VfioIntx {
    interrupt_source_group: Arc<dyn InterruptSourceGroup>,
    enabled: bool,
}

#[derive(Serialize, Deserialize)]
struct MsiState {
    cap: MsiCap,
    cap_offset: u32,
}

pub(crate) struct VfioMsi {
    pub(crate) cfg: MsiConfig,
    cap_offset: u32,
    interrupt_source_group: Arc<dyn InterruptSourceGroup>,
}

impl VfioMsi {
    fn update(&mut self, offset: u64, data: &[u8]) -> Option<InterruptUpdateAction> {
        let old_enabled = self.cfg.enabled();

        self.cfg.update(offset, data);

        let new_enabled = self.cfg.enabled();

        if !old_enabled && new_enabled {
            return Some(InterruptUpdateAction::EnableMsi);
        }

        if old_enabled && !new_enabled {
            return Some(InterruptUpdateAction::DisableMsi);
        }

        None
    }
}

#[derive(Serialize, Deserialize)]
struct MsixState {
    cap: MsixCap,
    cap_offset: u32,
    bdf: u32,
}

pub(crate) struct VfioMsix {
    pub(crate) bar: MsixConfig,
    cap: MsixCap,
    cap_offset: u32,
    interrupt_source_group: Arc<dyn InterruptSourceGroup>,
}

impl VfioMsix {
    fn update(&mut self, offset: u64, data: &[u8]) -> Option<InterruptUpdateAction> {
        let old_enabled = self.bar.enabled();

        // Update "Message Control" word
        if offset == 2
            && let Ok(data) = <[u8; 2]>::try_from(data)
        {
            let data = u16::from_le_bytes(data);
            self.bar.set_msg_ctl(data);
            self.cap.set_msg_ctl(data);
        } else if offset == 0
            && let Ok(data) = <[u8; 4]>::try_from(data)
        {
            // Some guests update MSI-X control through the dword config write path.
            let data = (u32::from_le_bytes(data) >> 16) as u16;
            self.bar.set_msg_ctl(data);
            self.cap.set_msg_ctl(data);
        } else if offset == 3 && data.len() == 1 {
            let data = u16::from(data[0]) << 8;
            self.bar.set_msg_ctl(data);
            self.cap.set_msg_ctl(data);
        }

        let new_enabled = self.bar.enabled();

        if !old_enabled && new_enabled {
            return Some(InterruptUpdateAction::EnableMsix);
        }

        if old_enabled && !new_enabled {
            return Some(InterruptUpdateAction::DisableMsix);
        }

        None
    }

    fn table_accessed(&self, bar_index: u32, offset: u64) -> bool {
        let table_offset: u64 = u64::from(self.cap.table_offset());
        let table_size: u64 = u64::from(self.cap.table_size()) * (MSIX_TABLE_ENTRY_SIZE as u64);
        let table_bir: u32 = self.cap.table_bir();

        bar_index == table_bir && offset >= table_offset && offset < table_offset + table_size
    }
}

pub(crate) struct Interrupt {
    pub(crate) intx: Option<VfioIntx>,
    pub(crate) msi: Option<VfioMsi>,
    pub(crate) msix: Option<VfioMsix>,
}

impl Interrupt {
    fn update_msi(&mut self, offset: u64, data: &[u8]) -> Option<InterruptUpdateAction> {
        if let Some(msi) = &mut self.msi {
            let action = msi.update(offset, data);
            return action;
        }

        None
    }

    fn update_msix(&mut self, offset: u64, data: &[u8]) -> Option<InterruptUpdateAction> {
        if let Some(msix) = &mut self.msix {
            let action = msix.update(offset, data);
            return action;
        }

        None
    }

    fn accessed(&self, offset: u64) -> Option<(PciCapabilityId, u64)> {
        if let Some(msi) = &self.msi
            && offset >= u64::from(msi.cap_offset)
            && offset < u64::from(msi.cap_offset) + msi.cfg.size()
        {
            return Some((
                PciCapabilityId::MessageSignalledInterrupts,
                u64::from(msi.cap_offset),
            ));
        }

        if let Some(msix) = &self.msix
            && offset == u64::from(msix.cap_offset)
        {
            return Some((PciCapabilityId::MsiX, u64::from(msix.cap_offset)));
        }

        None
    }

    fn msix_table_accessed(&self, bar_index: u32, offset: u64) -> bool {
        if let Some(msix) = &self.msix {
            return msix.table_accessed(bar_index, offset);
        }

        false
    }

    fn msix_write_table(&mut self, offset: u64, data: &[u8]) {
        if let Some(msix) = &mut self.msix {
            let offset = offset - u64::from(msix.cap.table_offset());
            msix.bar.write_table(offset, data);
        }
    }

    fn msix_read_table(&self, offset: u64, data: &mut [u8]) {
        if let Some(msix) = &self.msix {
            let offset = offset - u64::from(msix.cap.table_offset());
            msix.bar.read_table(offset, data);
        }
    }

    pub(crate) fn intx_in_use(&self) -> bool {
        if let Some(intx) = &self.intx {
            return intx.enabled;
        }

        false
    }
}

#[derive(Clone)]
pub(crate) struct VfioBarMemoryRegion {
    pub offset: u64,
    pub region: Arc<Mutex<GuestRegion>>,
    pub p2p_mapping: Option<Arc<Mutex<VfioP2pMapping>>>,
}

pub(crate) struct VfioP2pMapping {
    #[cfg(feature = "kvm")]
    device: Arc<VfioDevice>,
    vfio_ops: Arc<dyn VfioOps>,
    device_path: PathBuf,
    bdf: PciBdf,
    region_index: u32,
    mapped: bool,
    #[cfg(feature = "kvm")]
    dma_buf: Option<OwnedFd>,
}

impl VfioBarMemoryRegion {
    pub(crate) fn move_region(&mut self, new_address: u64) -> Result<(), GuestRegionError> {
        self.region
            .lock()
            .unwrap()
            .move_guest_address(GuestAddress(new_address))
    }

    pub(crate) fn start(&self) -> u64 {
        self.region.lock().unwrap().start_addr().raw_value()
    }

    pub(crate) fn size(&self) -> usize {
        self.region.lock().unwrap().size()
    }

    #[cfg(test)]
    fn host_address(&self) -> *mut u8 {
        self.region.lock().unwrap().as_ptr()
    }

    fn p2p_mapped(&self) -> bool {
        self.p2p_mapping
            .as_ref()
            .is_some_and(|mapping| mapping.lock().unwrap().mapped)
    }

    fn map_for_p2p(&self) -> Result<(), VfioPciError> {
        let Some(p2p_mapping) = &self.p2p_mapping else {
            return Ok(());
        };
        let region = self.region.lock().unwrap();
        p2p_mapping
            .lock()
            .unwrap()
            .map_for_p2p(&region, self.offset)
    }

    fn unmap_p2p(&self) -> Result<(), vfio_ioctls::VfioError> {
        let Some(p2p_mapping) = &self.p2p_mapping else {
            return Ok(());
        };
        let region = self.region.lock().unwrap();
        p2p_mapping.lock().unwrap().unmap_p2p(&region)
    }
}

impl VfioP2pMapping {
    #[cfg_attr(not(feature = "kvm"), expect(unused_variables))]
    fn map_for_p2p(&mut self, region: &GuestRegion, offset: u64) -> Result<(), VfioPciError> {
        let iova = region.start_addr().raw_value();
        let length = region.size();
        let region_index = self.region_index;
        let bdf = self.bdf;

        #[cfg(feature = "kvm")]
        if let Some(vfio_iommufd) = self.vfio_ops.as_any().downcast_ref::<VfioIommufd>()
            && let Some(dma_buf) = self
                .device
                .export_dma_buf(
                    region_index,
                    &[VfioRegionDmaRange {
                        offset,
                        length: length as u64,
                    }],
                    libc::O_RDWR as u32,
                )
                .map_err(|e| VfioPciError::DmaMap(e, self.device_path.clone(), bdf))?
        {
            debug!(
                "Mapped region {region_index} of device {bdf} at 0x{iova:x} \
                 (0x{length:x} bytes) through dma-buf"
            );

            vfio_iommufd
                .ioas()
                .map_file(dma_buf.as_raw_fd(), 0, length as u64, iova, true)
                .map_err(|e| VfioPciError::DmaMapFile(e, self.device_path.clone(), bdf))?;

            self.dma_buf = Some(OwnedFd::from(dma_buf));
            self.mapped = true;
            return Ok(());
        }

        debug!(
            "Mapped region {region_index} of device {bdf} at 0x{iova:x} \
             (0x{length:x} bytes) through VFIO dma map since dma-buf isn't \
             available"
        );

        // SAFETY: The region owns the host mapping, which remains alive while
        // the BAR is DMA mapped. Teardown unmaps DMA before releasing it.
        unsafe { self.vfio_ops.vfio_dma_map(iova, length, region.as_ptr()) }
            .map_err(|e| VfioPciError::DmaMap(e, self.device_path.clone(), bdf))?;
        self.mapped = true;
        Ok(())
    }

    fn unmap_p2p(&mut self, region: &GuestRegion) -> Result<(), vfio_ioctls::VfioError> {
        if self.mapped {
            self.vfio_ops
                .vfio_dma_unmap(region.start_addr().raw_value(), region.size())?;
            self.mapped = false;
        }
        Ok(())
    }
}

#[derive(Clone)]
pub struct VfioBar {
    pub start: GuestAddress,
    pub length: GuestUsize,
    pub(crate) type_: PciBarRegionType,
    pub(crate) index: u32,
    pub(crate) bar_memory_regions: Vec<VfioBarMemoryRegion>,
}

impl VfioBar {
    /// Whether the BAR can be mapped for peer to peer DMA.
    fn is_p2p_mappable(&self) -> bool {
        self.length >= get_page_size()
    }

    /// Whether both BAR descriptions refer to the same backing regions.
    pub fn has_matching_mappings(&self, other: &VfioBar) -> bool {
        self.bar_memory_regions.len() == other.bar_memory_regions.len()
            && self.bar_memory_regions.iter().all(|u| {
                other
                    .bar_memory_regions
                    .iter()
                    .any(|o| Arc::ptr_eq(&o.region, &u.region))
            })
    }
}

#[derive(Debug, Error)]
enum VfioBarRangeError {
    #[error("User mapping not found: gpa={gpa:#x}, size={size:#x}")]
    UserMappingNotFound { gpa: u64, size: u64 },
}

/// # Safety
///
/// [`Self::find_user_address`] must always either return `Err`
/// or a pointer to `size` bytes of valid memory.
unsafe trait VfioBarRange {
    fn check_range(&self, guest_addr: u64, size: u64) -> bool;
    fn find_user_address(&self, guest_addr: u64, size: u64) -> Result<*mut u8, VfioBarRangeError>;
}

// SAFETY: See the comment in `find_user_address`.
unsafe impl VfioBarRange for Vec<VfioBar> {
    // Check if a guest address is within the range of mmio regions
    fn check_range(&self, guest_addr: u64, size: u64) -> bool {
        let Some(guest_addr_end) = guest_addr.checked_add(size) else {
            return false;
        };
        for region in self.iter() {
            let start = region
                .bar_memory_regions
                .first()
                .map_or(region.start.raw_value(), |entry| {
                    entry.start() - entry.offset
                });
            let Some(region_end) = start.checked_add(region.length) else {
                return false;
            };
            if guest_addr >= start && guest_addr_end <= region_end {
                return true;
            }
        }
        false
    }

    // Locate the user region address for a guest address within all mmio regions
    fn find_user_address(&self, guest_addr: u64, size: u64) -> Result<*mut u8, VfioBarRangeError> {
        for region in self.iter() {
            for bar_memory_region in region.bar_memory_regions.iter() {
                let mapping = bar_memory_region.region.lock().unwrap();
                let start = mapping.start_addr().raw_value();
                let len = mapping.len();
                // See if the guest address is inside the region.
                let Some(offset_from_start) = guest_addr.checked_sub(start) else {
                    continue;
                };
                if offset_from_start >= len {
                    continue;
                }
                // A VFIO MMIO region may be backed by multiple separately mmap'd areas,
                // which may be non-contiguous. The requested range must fit within one mapping.
                if size > len - offset_from_start {
                    continue;
                }
                // SAFETY: AlignedMapping guarantees that mapping.addr points to at least
                // mapping.len() bytes of valid memory. The checks above ensure that
                // offset_from_start + size stays within that mapping. Also, since
                // mapping.len() fit in usize, offset_from_start must as well, so the
                // cast is safe.
                return Ok(unsafe { mapping.as_ptr().add(offset_from_start as usize) });
            }
        }

        Err(VfioBarRangeError::UserMappingNotFound {
            gpa: guest_addr,
            size,
        })
    }
}

#[derive(Debug, Error)]
pub enum VfioError {
    #[error("Kernel VFIO error")]
    KernelVfio(#[source] vfio_ioctls::VfioError),
    #[error("VFIO user error")]
    VfioUser(#[source] vfio_user::Error),
    #[error("VFIO device does not support migration")]
    NoMigrationSupport,
    #[error("VFIO device reported unknown migration state {0}")]
    InvalidMigrationState(u32),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum VfioMigrationState {
    Error,
    Stop,
    Running,
    StopCopy,
    Resuming,
    RunningP2P,
    PreCopy,
    PreCopyP2P,
}

impl From<VfioMigrationState> for u32 {
    fn from(state: VfioMigrationState) -> u32 {
        match state {
            VfioMigrationState::Error => VFIO_DEV_STATE_ERROR,
            VfioMigrationState::Stop => VFIO_DEV_STATE_STOP,
            VfioMigrationState::Running => VFIO_DEV_STATE_RUNNING,
            VfioMigrationState::StopCopy => VFIO_DEV_STATE_STOP_COPY,
            VfioMigrationState::Resuming => VFIO_DEV_STATE_RESUMING,
            VfioMigrationState::RunningP2P => VFIO_DEV_STATE_RUNNING_P2P,
            VfioMigrationState::PreCopy => VFIO_DEV_STATE_PRE_COPY,
            VfioMigrationState::PreCopyP2P => VFIO_DEV_STATE_PRE_COPY_P2P,
        }
    }
}

impl TryFrom<u32> for VfioMigrationState {
    type Error = VfioError;

    fn try_from(value: u32) -> Result<Self, VfioError> {
        match value {
            VFIO_DEV_STATE_ERROR => Ok(Self::Error),
            VFIO_DEV_STATE_STOP => Ok(Self::Stop),
            VFIO_DEV_STATE_RUNNING => Ok(Self::Running),
            VFIO_DEV_STATE_STOP_COPY => Ok(Self::StopCopy),
            VFIO_DEV_STATE_RESUMING => Ok(Self::Resuming),
            VFIO_DEV_STATE_RUNNING_P2P => Ok(Self::RunningP2P),
            VFIO_DEV_STATE_PRE_COPY => Ok(Self::PreCopy),
            VFIO_DEV_STATE_PRE_COPY_P2P => Ok(Self::PreCopyP2P),
            other => Err(VfioError::InvalidMigrationState(other)),
        }
    }
}

pub(crate) trait Vfio: Send + Sync {
    fn read_config_byte(&self, offset: u32) -> u8 {
        let mut data: [u8; 1] = [0];
        self.read_config(offset, &mut data);
        data[0]
    }

    fn read_config_word(&self, offset: u32) -> u16 {
        let mut data: [u8; 2] = [0, 0];
        self.read_config(offset, &mut data);
        u16::from_le_bytes(data)
    }

    fn read_config_dword(&self, offset: u32) -> u32 {
        let mut data: [u8; 4] = [0, 0, 0, 0];
        self.read_config(offset, &mut data);
        u32::from_le_bytes(data)
    }

    fn write_config_dword(&self, offset: u32, buf: u32) {
        let data: [u8; 4] = buf.to_le_bytes();
        self.write_config(offset, &data);
    }

    fn read_config(&self, offset: u32, data: &mut [u8]) {
        self.region_read(VFIO_PCI_CONFIG_REGION_INDEX, offset.into(), data.as_mut());
    }

    fn write_config(&self, offset: u32, data: &[u8]) {
        self.region_write(VFIO_PCI_CONFIG_REGION_INDEX, offset.into(), data);
    }

    fn enable_msi(&self, fds: Vec<&EventFd>) -> Result<(), VfioError> {
        self.enable_irq(VFIO_PCI_MSI_IRQ_INDEX, fds)
    }

    fn disable_msi(&self) -> Result<(), VfioError> {
        self.disable_irq(VFIO_PCI_MSI_IRQ_INDEX)
    }

    fn enable_msix(&self, fds: Vec<&EventFd>) -> Result<(), VfioError> {
        self.enable_irq(VFIO_PCI_MSIX_IRQ_INDEX, fds)
    }

    fn disable_msix(&self) -> Result<(), VfioError> {
        self.disable_irq(VFIO_PCI_MSIX_IRQ_INDEX)
    }

    fn region_read(&self, _index: u32, _offset: u64, _data: &mut [u8]) {
        unimplemented!()
    }

    fn region_write(&self, _index: u32, _offset: u64, _data: &[u8]) {
        unimplemented!()
    }

    fn get_irq_info(&self, _irq_index: u32) -> Option<VfioIrq> {
        unimplemented!()
    }

    fn enable_irq(&self, _irq_index: u32, _event_fds: Vec<&EventFd>) -> Result<(), VfioError> {
        unimplemented!()
    }

    fn disable_irq(&self, _irq_index: u32) -> Result<(), VfioError> {
        unimplemented!()
    }

    fn unmask_irq(&self, _irq_index: u32) -> Result<(), VfioError> {
        unimplemented!()
    }

    fn migration_flags(&self) -> Result<Option<u64>, VfioError> {
        Ok(None)
    }

    fn set_migration_state(&self, _state: VfioMigrationState) -> Result<(), VfioError> {
        Err(VfioError::NoMigrationSupport)
    }

    fn read_migration_data(&self) -> Result<Vec<u8>, VfioError> {
        Err(VfioError::NoMigrationSupport)
    }

    fn write_migration_data(&self, _data: &[u8]) -> Result<(), VfioError> {
        Err(VfioError::NoMigrationSupport)
    }

    fn reset(&self) {}

    fn start_dma_logging(
        &self,
        _page_size: u64,
        _ranges: &[DmaLoggingRange],
    ) -> Result<u64, VfioError> {
        Err(VfioError::NoMigrationSupport)
    }

    fn stop_dma_logging(&self) -> Result<(), VfioError> {
        Err(VfioError::NoMigrationSupport)
    }

    fn report_dma_logging(
        &self,
        _range: DmaLoggingRange,
        _page_size: u64,
    ) -> Result<MemoryRangeTable, VfioError> {
        Err(VfioError::NoMigrationSupport)
    }
}

struct VfioDeviceWrapper {
    device: Arc<VfioDevice>,
}

impl VfioDeviceWrapper {
    fn new(device: Arc<VfioDevice>) -> Self {
        Self { device }
    }
}

impl Vfio for VfioDeviceWrapper {
    fn region_read(&self, index: u32, offset: u64, data: &mut [u8]) {
        self.device.region_read(index, data, offset);
    }

    fn region_write(&self, index: u32, offset: u64, data: &[u8]) {
        self.device.region_write(index, data, offset);
    }

    fn get_irq_info(&self, irq_index: u32) -> Option<VfioIrq> {
        self.device.get_irq_info(irq_index).copied()
    }

    fn enable_irq(&self, irq_index: u32, event_fds: Vec<&EventFd>) -> Result<(), VfioError> {
        self.device
            .enable_irq(irq_index, event_fds)
            .map_err(VfioError::KernelVfio)
    }

    fn disable_irq(&self, irq_index: u32) -> Result<(), VfioError> {
        self.device
            .disable_irq(irq_index)
            .map_err(VfioError::KernelVfio)
    }

    fn unmask_irq(&self, irq_index: u32) -> Result<(), VfioError> {
        self.device
            .unmask_irq(irq_index)
            .map_err(VfioError::KernelVfio)
    }

    fn migration_flags(&self) -> Result<Option<u64>, VfioError> {
        self.device
            .query_migration_support()
            .map_err(VfioError::KernelVfio)
    }

    fn set_migration_state(&self, state: VfioMigrationState) -> Result<(), VfioError> {
        self.device
            .set_migration_state(state.into())
            .map_err(VfioError::KernelVfio)
    }

    fn read_migration_data(&self) -> Result<Vec<u8>, VfioError> {
        self.device
            .read_migration_data_to_end()
            .map_err(VfioError::KernelVfio)
    }

    fn write_migration_data(&self, data: &[u8]) -> Result<(), VfioError> {
        self.device
            .write_migration_data(data)
            .map_err(VfioError::KernelVfio)
    }

    fn reset(&self) {
        self.device.reset();
    }

    fn start_dma_logging(
        &self,
        page_size: u64,
        ranges: &[DmaLoggingRange],
    ) -> Result<u64, VfioError> {
        self.device
            .start_dma_logging(page_size, ranges)
            .map_err(VfioError::KernelVfio)
    }

    fn stop_dma_logging(&self) -> Result<(), VfioError> {
        self.device
            .stop_dma_logging()
            .map_err(VfioError::KernelVfio)
    }

    // Wrap the kernel dirty bitmap into a MemoryRangeTable at the trait
    // boundary so callers work with guest memory ranges directly.
    fn report_dma_logging(
        &self,
        range: DmaLoggingRange,
        page_size: u64,
    ) -> Result<MemoryRangeTable, VfioError> {
        let bitmap = self
            .device
            .report_dma_logging(range, page_size)
            .map_err(VfioError::KernelVfio)?;
        Ok(MemoryRangeTable::from_dirty_bitmap(
            bitmap, range.iova, page_size,
        ))
    }
}

#[derive(Serialize, Deserialize)]
struct VfioCommonState {
    intx_state: Option<IntxState>,
    msi_state: Option<MsiState>,
    msix_state: Option<MsixState>,
    #[serde(default)]
    patches: HashMap<usize, ConfigPatch>,
}

#[derive(Serialize, Deserialize)]
struct VfioMigrationData {
    blob: String,
}

/// Patch for a PCI config space register
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct ConfigPatch {
    /// Mask for identifying emulated parts of the register. A set bit means
    /// emulated and a cleared bit means read from the device
    mask: u32,
    /// Emulated value only meaningful for the bits set in `mask`
    patch: u32,
    /// Set bits can't be written by the guest. Cleared bits can but it
    /// depends on `mask` if the write is propagated to the device or not
    readonly_mask: u32,
}

impl ConfigPatch {
    fn write<'a>(&mut self, offset: u64, data: &'a [u8]) -> Vec<(u64, &'a [u8])> {
        let mut bytes = self.patch.to_le_bytes();

        for (i, byte) in data.iter().enumerate() {
            let Some(slot) = bytes.get_mut(offset as usize + i) else {
                break;
            };
            *slot = *byte;
        }

        let written = u32::from_le_bytes(bytes);
        let writable = !self.readonly_mask;
        let patched = self.mask & writable;
        self.patch = (self.patch & !patched) | (written & patched);

        let forwarded = (!self.mask & writable).to_le_bytes();
        let is_forwarded = |index: usize| forwarded.get(offset as usize + index) == Some(&0xff);

        let mut device_writes = Vec::new();
        let mut index = 0;

        while index < data.len() {
            if !is_forwarded(index) {
                index += 1;
                continue;
            }

            let start = index;
            while index < data.len() && is_forwarded(index) {
                index += 1;
            }

            device_writes.push((offset + start as u64, &data[start..index]));
        }

        device_writes
    }
}

pub(crate) struct VfioCommon {
    pub(crate) configuration: PciConfiguration,
    pub(crate) bars: Vec<VfioBar>,
    pub(crate) interrupt: Interrupt,
    pub(crate) msi_interrupt_manager: Arc<dyn InterruptManager<GroupConfig = MsiIrqGroupConfig>>,
    pub(crate) legacy_interrupt_group: Option<Arc<dyn InterruptSourceGroup>>,
    pub(crate) vfio_wrapper: Arc<dyn Vfio>,
    pub(crate) patches: HashMap<usize, ConfigPatch>,
    pub(crate) vendor_id: u16,
    x_nv_gpudirect_clique: Option<u8>,
    x_exclude_mmap_bars: Vec<u8>,
    pub(crate) migration_flags: Option<u64>,
    // Negotiated dirty bitmap granularity while DMA logging is active.
    dma_logging_page_size: Option<u64>,
    extended_caps: Vec<Arc<dyn PciExpressCapability + Send + Sync>>,
}

#[derive(Default)]
pub(crate) struct VfioCommonConfig {
    pub(crate) x_nv_gpudirect_clique: Option<u8>,
    pub(crate) x_exclude_mmap_bars: Vec<u8>,
    pub(crate) extended_caps: Vec<Arc<dyn PciExpressCapability + Send + Sync>>,
}

impl VfioCommon {
    pub(crate) fn move_bar(&mut self, bar_idx: usize, new_base: u64) -> Result<(), VfioPciError> {
        for region in &mut self.bars {
            if region.index as usize != bar_idx || region.start == GuestAddress(new_base) {
                continue;
            }
            let moves = region
                .bar_memory_regions
                .iter()
                .map(|bar_memory_region| {
                    let new_address = new_base.checked_add(bar_memory_region.offset).ok_or(
                        VfioPciError::BarAddressOverflow {
                            base: new_base,
                            offset: bar_memory_region.offset,
                        },
                    )?;
                    let size = bar_memory_region.size() as u64;
                    new_address
                        .checked_add(size)
                        .ok_or(VfioPciError::BarRangeOverflow {
                            address: new_address,
                            size,
                        })?;
                    Ok((
                        bar_memory_region.start(),
                        new_address,
                        bar_memory_region.p2p_mapped(),
                    ))
                })
                .collect::<Result<Vec<_>, VfioPciError>>()?;
            for (i, &(_, new_address, map_p2p)) in moves.iter().enumerate() {
                let bar_memory_region = &mut region.bar_memory_regions[i];
                let result = (|| {
                    bar_memory_region
                        .unmap_p2p()
                        .map_err(VfioPciError::DmaUnmap)?;
                    bar_memory_region
                        .move_region(new_address)
                        .map_err(VfioPciError::MoveBarMemoryRegion)?;
                    if map_p2p {
                        bar_memory_region.map_for_p2p()?;
                    }
                    Ok(())
                })();
                if let Err(e) = result {
                    for (bar_memory_region, &(old_address, _, was_mapped)) in region
                        .bar_memory_regions[..=i]
                        .iter_mut()
                        .zip(&moves[..=i])
                        .rev()
                    {
                        if bar_memory_region.start() == old_address
                            && bar_memory_region.p2p_mapped() == was_mapped
                            && bar_memory_region.region.lock().unwrap().is_registered()
                        {
                            continue;
                        }
                        let rollback: Result<(), VfioPciError> = (|| {
                            bar_memory_region
                                .unmap_p2p()
                                .map_err(VfioPciError::DmaUnmap)?;
                            bar_memory_region
                                .move_region(old_address)
                                .map_err(VfioPciError::MoveBarMemoryRegion)?;
                            {
                                let mapping = bar_memory_region.region.lock().unwrap();
                                if !mapping.is_registered() {
                                    mapping
                                        .register()
                                        .map_err(VfioPciError::CreateUserMemoryRegion)?;
                                }
                            }
                            if was_mapped {
                                bar_memory_region.map_for_p2p()?;
                            }
                            Ok(())
                        })();
                        if let Err(rollback) = rollback {
                            // Continuing would leave the BAR with inconsistent mappings.
                            error!("FATAL: Failed to restore BAR mapping: {rollback:?}");
                            process::exit(1);
                        }
                    }
                    return Err(e);
                }
            }
            region.start = GuestAddress(new_base);
        }
        Ok(())
    }

    pub(crate) fn new(
        msi_interrupt_manager: Arc<dyn InterruptManager<GroupConfig = MsiIrqGroupConfig>>,
        legacy_interrupt_group: Option<Arc<dyn InterruptSourceGroup>>,
        vfio_wrapper: Arc<dyn Vfio>,
        subclass: &dyn PciSubclass,
        bdf: PciBdf,
        snapshot: Option<&Snapshot>,
        config: VfioCommonConfig,
    ) -> Result<Self, VfioPciError> {
        let pci_configuration_state = vm_migration::state_from_id(snapshot, PCI_CONFIGURATION_ID)
            .map_err(VfioPciError::RetrievePciConfigurationState)?;

        let configuration = PciConfiguration::new(
            0,
            0,
            0,
            PciClassCode::Other,
            subclass,
            None,
            PciHeaderType::Device,
            0,
            0,
            None,
            pci_configuration_state,
        );

        let migration_flags = match vfio_wrapper.migration_flags() {
            Ok(Some(flags)) => {
                info!(
                    "VFIO device {bdf} supports migration v2 (flags=0x{flags:x}, \
                     STOP_COPY={}, P2P={}, PRE_COPY={})",
                    flags & VFIO_MIGRATION_STOP_COPY as u64 != 0,
                    flags & VFIO_MIGRATION_P2P as u64 != 0,
                    flags & VFIO_MIGRATION_PRE_COPY as u64 != 0,
                );
                Some(flags)
            }
            Ok(None) => {
                debug!("VFIO device {bdf} does not support migration v2");
                None
            }
            Err(e) => {
                debug!("VFIO device {bdf} migration probe failed, treating as non-migratable: {e}");
                None
            }
        };

        let vendor_id = vfio_wrapper.read_config_word(PCI_CONFIG_VENDOR_ID_OFFSET);

        let mut vfio_common = VfioCommon {
            bars: Vec::new(),
            configuration,
            interrupt: Interrupt {
                intx: None,
                msi: None,
                msix: None,
            },
            msi_interrupt_manager,
            legacy_interrupt_group,
            vfio_wrapper,
            patches: HashMap::new(),
            vendor_id,
            x_nv_gpudirect_clique: config.x_nv_gpudirect_clique,
            x_exclude_mmap_bars: config.x_exclude_mmap_bars,
            migration_flags,
            dma_logging_page_size: None,
            extended_caps: config.extended_caps,
        };

        let state: Option<VfioCommonState> = snapshot
            .as_ref()
            .map(|s| s.to_state())
            .transpose()
            .map_err(VfioPciError::RetrieveVfioCommonState)?;
        let msi_state = vm_migration::state_from_id(snapshot, MSI_CONFIG_ID)
            .map_err(VfioPciError::RetrieveMsiConfigState)?;
        let msix_state = vm_migration::state_from_id(snapshot, MSIX_CONFIG_ID)
            .map_err(VfioPciError::RetrieveMsixConfigState)?;

        if let Some(state) = state.as_ref() {
            let mig: Option<VfioMigrationData> =
                vm_migration::state_from_id(snapshot, VFIO_MIGRATION_ID).map_err(|e| {
                    VfioPciError::RestoreMigration(anyhow!(
                        "Failed to get VfioMigrationData from Snapshot: {e}"
                    ))
                })?;
            vfio_common.set_state(state, msi_state, msix_state, mig)?;
        } else {
            vfio_common.parse_capabilities(bdf)?;
            vfio_common.initialize_legacy_interrupt()?;
        }

        Ok(vfio_common)
    }

    /// In case msix table offset is not page size aligned, we need do some fixup to achieve it.
    /// Because we don't want the MMIO RW region and trap region overlap each other.
    fn fixup_msix_region(&mut self, bar_id: u32, region_size: u64) -> u64 {
        if let Some(msix) = self.interrupt.msix.as_mut() {
            let msix_cap = &mut msix.cap;

            // Suppose table_bir equals to pba_bir here. Am I right?
            let (table_offset, table_size) = msix_cap.table_range();
            if is_page_size_aligned(table_offset) || msix_cap.table_bir() != bar_id {
                return region_size;
            }

            let (pba_offset, pba_size) = msix_cap.pba_range();
            let msix_sz = align_page_size_up(table_size + pba_size);
            // Expand region to hold RW and trap region which both page size aligned
            let size = cmp::max(region_size * 2, msix_sz * 2);
            // let table starts from the middle of the region
            msix_cap.table_set_offset((size / 2) as u32);
            msix_cap.pba_set_offset((size / 2 + pba_offset - table_offset) as u32);

            size
        } else {
            // MSI-X not supported for this device
            region_size
        }
    }

    pub(crate) fn allocate_bars(
        &mut self,
        allocator: &mut SystemAllocator,
        mmio32_allocator: &mut AddressAllocator,
        mmio64_allocator: &mut AddressAllocator,
        resources: Option<&[Resource]>,
    ) -> Result<Vec<PciBarConfiguration>, PciDeviceError> {
        let mut bars = Vec::new();
        let mut bar_id = VFIO_PCI_BAR0_REGION_INDEX;

        // Going through all regular regions to compute the BAR size.
        // We're not saving the BAR address to restore it, because we
        // are going to allocate a guest address for each BAR and write
        // that new address back.
        while bar_id < VFIO_PCI_CONFIG_REGION_INDEX {
            let mut region_size: u64 = 0;
            let mut region_type = PciBarRegionType::Memory32BitRegion;
            let mut prefetchable = PciBarPrefetchable::NotPrefetchable;
            let mut flags: u32 = 0;

            let mut restored_bar_addr = None;
            if let Some(resources) = resources {
                for resource in resources {
                    if let Resource::PciBar {
                        index,
                        base,
                        size,
                        type_,
                        ..
                    } = resource
                        && *index == bar_id as usize
                    {
                        restored_bar_addr = Some(GuestAddress(*base));
                        region_size = *size;
                        region_type = PciBarRegionType::from(*type_);
                        break;
                    }
                }
                if restored_bar_addr.is_none() {
                    bar_id += 1;
                    continue;
                }
            } else {
                let bar_offset = if bar_id == VFIO_PCI_ROM_REGION_INDEX {
                    (PCI_ROM_EXP_BAR_INDEX * 4) as u32
                } else {
                    PCI_CONFIG_BAR_OFFSET + bar_id * 4
                };

                // First read flags
                flags = self.vfio_wrapper.read_config_dword(bar_offset);

                // Is this an IO BAR?
                let io_bar = if bar_id == VFIO_PCI_ROM_REGION_INDEX {
                    false
                } else {
                    matches!(flags & PCI_CONFIG_IO_BAR, PCI_CONFIG_IO_BAR)
                };

                // Is this a 64-bit BAR?
                let is_64bit_bar = if bar_id == VFIO_PCI_ROM_REGION_INDEX {
                    false
                } else {
                    matches!(
                        flags & PCI_CONFIG_MEMORY_BAR_64BIT,
                        PCI_CONFIG_MEMORY_BAR_64BIT
                    )
                };

                if matches!(
                    flags & PCI_CONFIG_BAR_PREFETCHABLE,
                    PCI_CONFIG_BAR_PREFETCHABLE
                ) {
                    prefetchable = PciBarPrefetchable::Prefetchable;
                }

                // To get size write all 1s
                self.vfio_wrapper
                    .write_config_dword(bar_offset, 0xffff_ffff);

                // And read back BAR value. The device will write zeros for bits it doesn't care about
                let mut lower = self.vfio_wrapper.read_config_dword(bar_offset);

                if io_bar {
                    // Mask flag bits (lowest 2 for I/O bars)
                    lower &= !0b11;

                    // BAR is not enabled
                    if lower == 0 {
                        bar_id += 1;
                        continue;
                    }

                    // IO BAR
                    region_type = PciBarRegionType::IoRegion;

                    // Invert bits and add 1 to calculate size
                    region_size = (!lower + 1) as u64;
                } else if is_64bit_bar {
                    // 64 bits Memory BAR
                    region_type = PciBarRegionType::Memory64BitRegion;

                    // Query size of upper BAR of 64-bit BAR
                    let upper_offset: u32 = PCI_CONFIG_BAR_OFFSET + (bar_id + 1) * 4;
                    self.vfio_wrapper
                        .write_config_dword(upper_offset, 0xffff_ffff);
                    let upper = self.vfio_wrapper.read_config_dword(upper_offset);

                    let mut combined_size = (u64::from(upper) << 32) | u64::from(lower);

                    // Mask out flag bits (lowest 4 for memory bars)
                    combined_size &= !0b1111;

                    // BAR is not enabled
                    if combined_size == 0 {
                        bar_id += 1;
                        continue;
                    }

                    // Invert and add 1 to to find size
                    region_size = !combined_size + 1;
                } else {
                    region_type = PciBarRegionType::Memory32BitRegion;

                    // Mask out flag bits (lowest 4 for memory bars)
                    lower &= !0b1111;

                    if lower == 0 {
                        bar_id += 1;
                        continue;
                    }

                    // Invert and add 1 to to find size
                    region_size = (!lower + 1) as u64;
                }
            }

            let bar_addr = match region_type {
                PciBarRegionType::IoRegion => {
                    let alignment = if restored_bar_addr.is_some() {
                        Some(4)
                    } else {
                        Some(region_size.max(4))
                    };
                    allocator
                        .allocate_io_addresses(restored_bar_addr, region_size, alignment)
                        .ok_or(PciDeviceError::IoAllocationFailed(region_size))?
                }
                PciBarRegionType::Memory32BitRegion => {
                    // BAR allocation must be naturally aligned
                    mmio32_allocator
                        .allocate(restored_bar_addr, region_size, Some(region_size))
                        .ok_or(PciDeviceError::IoAllocationFailed(region_size))?
                }
                PciBarRegionType::Memory64BitRegion => {
                    // We need do some fixup to keep MMIO RW region and msix cap region page size
                    // aligned.
                    region_size = self.fixup_msix_region(bar_id, region_size);
                    mmio64_allocator
                        .allocate(
                            restored_bar_addr,
                            region_size,
                            Some(cmp::max(get_page_size(), region_size)),
                        )
                        .ok_or(PciDeviceError::IoAllocationFailed(region_size))?
                }
            };

            // We can now build our BAR configuration block.
            let bar = PciBarConfiguration::default()
                .set_index(bar_id as usize)
                .set_address(bar_addr.raw_value())
                .set_size(region_size)
                .set_region_type(region_type)
                .set_prefetchable(prefetchable);

            // Skip on restore as BARs come from the saved PciConfiguration state.
            if resources.is_none() {
                if bar_id == VFIO_PCI_ROM_REGION_INDEX {
                    self.configuration
                        .add_pci_rom_bar(&bar, flags & 0x1)
                        .map_err(|e| {
                            PciDeviceError::IoRegistrationFailed(bar_addr.raw_value(), e)
                        })?;
                } else {
                    self.configuration.add_pci_bar(&bar).map_err(|e| {
                        PciDeviceError::IoRegistrationFailed(bar_addr.raw_value(), e)
                    })?;
                }
            }

            bars.push(bar);
            self.bars.push(VfioBar {
                start: bar_addr,
                length: region_size,
                type_: region_type,
                index: bar_id,
                bar_memory_regions: Vec::new(),
            });

            bar_id += 1;
            if region_type == PciBarRegionType::Memory64BitRegion {
                bar_id += 1;
            }
        }
        Ok(bars)
    }

    pub(crate) fn free_bars(
        &mut self,
        allocator: &mut SystemAllocator,
        mmio32_allocator: &mut AddressAllocator,
        mmio64_allocator: &mut AddressAllocator,
    ) -> Result<(), PciDeviceError> {
        for region in self.bars.iter() {
            match region.type_ {
                PciBarRegionType::IoRegion => {
                    allocator.free_io_addresses(region.start, region.length);
                }
                PciBarRegionType::Memory32BitRegion => {
                    mmio32_allocator.free(region.start, region.length);
                }
                PciBarRegionType::Memory64BitRegion => {
                    mmio64_allocator.free(region.start, region.length);
                }
            }
        }
        Ok(())
    }

    fn parse_msix_capabilities(&mut self, cap: u8) -> MsixCap {
        let msg_ctl = self.vfio_wrapper.read_config_word((cap + 2).into());

        let table = self.vfio_wrapper.read_config_dword((cap + 4).into());

        let pba = self.vfio_wrapper.read_config_dword((cap + 8).into());

        MsixCap {
            msg_ctl,
            table,
            pba,
        }
    }

    fn initialize_msix(
        &mut self,
        msix_cap: MsixCap,
        cap_offset: u32,
        bdf: PciBdf,
        state: Option<MsixConfigState>,
    ) -> Result<(), VfioPciError> {
        let interrupt_source_group = self
            .msi_interrupt_manager
            .create_group(MsiIrqGroupConfig {
                base: 0,
                count: msix_cap.table_size() as InterruptIndex,
            })
            .map_err(VfioPciError::CreateMsixInterruptGroup)?;

        let msix_config = MsixConfig::new(
            msix_cap.table_size(),
            MaybeMutInterruptSourceGroup::Immutable(Arc::clone(&interrupt_source_group)),
            bdf.into(),
            state,
        )
        .map_err(VfioPciError::InitializeMsix)?;

        self.interrupt.msix = Some(VfioMsix {
            bar: msix_config,
            cap: msix_cap,
            cap_offset,
            interrupt_source_group,
        });
        Ok(())
    }

    fn parse_msi_capabilities(&mut self, cap: u8) -> u16 {
        self.vfio_wrapper.read_config_word((cap + 2).into())
    }

    fn initialize_msi(
        &mut self,
        msg_ctl: u16,
        cap_offset: u32,
        state: Option<MsiConfigState>,
    ) -> Result<(), VfioPciError> {
        let interrupt_source_group = self
            .msi_interrupt_manager
            .create_group(MsiIrqGroupConfig {
                base: 0,
                count: msi_num_enabled_vectors(msg_ctl) as InterruptIndex,
            })
            .map_err(VfioPciError::CreateMsiInterruptGroup)?;

        let msi_config = MsiConfig::new(msg_ctl, Arc::clone(&interrupt_source_group), state)
            .map_err(VfioPciError::InitializeMsi)?;

        self.interrupt.msi = Some(VfioMsi {
            cfg: msi_config,
            cap_offset,
            interrupt_source_group,
        });
        Ok(())
    }

    /// Returns true, if the device claims to have a PCI capability list.
    fn has_capabilities(&self) -> bool {
        let status = self.vfio_wrapper.read_config_word(PCI_CONFIG_STATUS_OFFSET);
        status & PCI_CONFIG_STATUS_CAPABILITIES_LIST != 0
    }

    fn get_msix_cap_idx(&self) -> Option<usize> {
        if !self.has_capabilities() {
            return None;
        }

        let mut cap_next = self
            .vfio_wrapper
            .read_config_byte(PCI_CONFIG_CAPABILITY_OFFSET)
            & PCI_CONFIG_CAPABILITY_PTR_MASK;

        while cap_next != 0 {
            let cap_id = self.vfio_wrapper.read_config_byte(cap_next.into());
            if PciCapabilityId::from(cap_id) == PciCapabilityId::MsiX {
                return Some(cap_next as usize);
            }
            let cap_ptr = self.vfio_wrapper.read_config_byte((cap_next + 1).into())
                & PCI_CONFIG_CAPABILITY_PTR_MASK;

            // See parse_capabilities below for an explanation.
            if cap_ptr == cap_next {
                break;
            }
            cap_next = cap_ptr;
        }

        None
    }

    fn parse_capabilities(&mut self, bdf: PciBdf) -> Result<(), VfioPciError> {
        if !self.has_capabilities() {
            return Ok(());
        }

        let mut cap_iter = self
            .vfio_wrapper
            .read_config_byte(PCI_CONFIG_CAPABILITY_OFFSET)
            & PCI_CONFIG_CAPABILITY_PTR_MASK;

        let mut pci_express_cap_found = false;
        let mut power_management_cap_found = false;

        while cap_iter != 0 {
            let cap_id = self.vfio_wrapper.read_config_byte(cap_iter.into());

            match PciCapabilityId::from(cap_id) {
                PciCapabilityId::MessageSignalledInterrupts => {
                    if let Some(irq_info) = self.vfio_wrapper.get_irq_info(VFIO_PCI_MSI_IRQ_INDEX)
                        && irq_info.count > 0
                    {
                        // Parse capability only if the VFIO device
                        // supports MSI.
                        let msg_ctl = self.parse_msi_capabilities(cap_iter);
                        self.initialize_msi(msg_ctl, cap_iter as u32, None)?;
                    }
                }
                PciCapabilityId::MsiX => {
                    if let Some(irq_info) = self.vfio_wrapper.get_irq_info(VFIO_PCI_MSIX_IRQ_INDEX)
                        && irq_info.count > 0
                    {
                        // Parse capability only if the VFIO device
                        // supports MSI-X.
                        let msix_cap = self.parse_msix_capabilities(cap_iter);
                        self.initialize_msix(msix_cap, cap_iter as u32, bdf, None)?;
                    }
                }
                PciCapabilityId::PciExpress => {
                    pci_express_cap_found = true;

                    // Advertise the device as a PCIe integrated endpoint if the
                    // PASID capability is enabled.
                    if self
                        .extended_caps
                        .iter()
                        .any(|cap| cap.id() == PciExpressCapabilityId::ProcessAddressSpaceId)
                    {
                        self.present_as_integrated_endpoint(cap_iter);
                    }
                }
                PciCapabilityId::PowerManagement => power_management_cap_found = true,
                _ => {}
            }

            let cap_next = self.vfio_wrapper.read_config_byte((cap_iter + 1).into())
                & PCI_CONFIG_CAPABILITY_PTR_MASK;

            // Break out of the loop, if we either find the end or we have a broken device. This
            // doesn't handle all cases where a device might send us in a loop here, but it
            // handles case of a device returning 0xFF instead of implementing a real
            // capabilities list.
            if cap_next == 0 || cap_next == cap_iter {
                break;
            }

            cap_iter = cap_next;
        }

        if let Some(clique_id) = self.x_nv_gpudirect_clique {
            self.add_nv_gpudirect_clique_cap(cap_iter, clique_id);
        }

        if pci_express_cap_found && power_management_cap_found {
            self.parse_extended_capabilities()?;
        }

        Ok(())
    }

    fn patch_reg(&mut self, reg_idx: usize, mask: u32, patch: u32, readonly_mask: u32) {
        let entry = self.patches.entry(reg_idx).or_insert(ConfigPatch {
            mask: 0,
            patch: 0,
            readonly_mask: 0,
        });

        entry.mask |= mask;
        entry.patch = (entry.patch & !mask) | (patch & mask);
        entry.readonly_mask |= readonly_mask;

        let forwarded = !entry.mask & !entry.readonly_mask;
        assert!(
            forwarded
                .to_le_bytes()
                .iter()
                .all(|byte| *byte == 0x00 || *byte == 0xff),
            "register {reg_idx:#x} leaves a byte part written by the guest: {forwarded:#010x}"
        );
    }

    fn add_nv_gpudirect_clique_cap(&mut self, cap_iter: u8, clique_id: u8) {
        // Turing, Ampere, Hopper, and Lovelace GPUs have dedicated space
        // at 0xD4 for this capability.
        let cap_offset = 0xd4u32;

        self.patch_reg(
            (cap_iter / 4) as usize,
            0x0000_ff00,
            cap_offset << 8,
            0x0000_ff00,
        );

        let reg_idx = (cap_offset / 4) as usize;
        self.patch_reg(reg_idx, 0xffff_ffff, 0x50080009u32, 0xffff_ffff);
        self.patch_reg(
            reg_idx + 1,
            0xffff_ffff,
            (u32::from(clique_id) << 19) | 0x5032,
            0xffff_ffff,
        );
    }

    fn present_as_integrated_endpoint(&mut self, cap_offset: u8) {
        let reg_idx = (u32::from(cap_offset) / 4) as usize;

        self.patch_reg(
            reg_idx,
            PCI_EXP_FLAGS_TYPE_MASK,
            PCI_EXP_TYPE_RC_END,
            0xffff_0000,
        );

        let clear_lnkctl_reg = |this: &mut Self, reg: u32| {
            this.patch_reg(reg_idx + (reg / 4) as usize, 0x0000_ffff, 0, 0xffff_ffff);
        };

        clear_lnkctl_reg(self, PCI_EXP_LNKCTL);

        let flags = self.vfio_wrapper.read_config_dword(u32::from(cap_offset));
        let version = (flags & PCI_EXP_FLAGS_VERS_MASK) >> PCI_EXP_FLAGS_VERS_SHIFT;

        if version > 1 {
            clear_lnkctl_reg(self, PCI_EXP_LNKCTL2);
        }
    }

    fn override_next_extended_cap(&mut self, offset: u32, next: u32) {
        self.patch_reg(
            (offset / 4) as usize,
            PCI_EXT_CAP_NEXT_MASK,
            next << PCI_EXT_CAP_NEXT_SHIFT,
            0xffff_ffff,
        );
    }

    fn add_extended_cap(
        &mut self,
        last_offset: u32,
        offset: u32,
        occupied: &[u32],
        cap: &dyn PciExpressCapability,
    ) -> Result<(), VfioPciError> {
        let end = offset.checked_add(cap.size());

        if last_offset >= offset
            || !offset.is_multiple_of(PCI_EXT_CAP_ALIGN)
            || offset < PCI_CONFIG_EXTENDED_CAPABILITY_OFFSET
            || end.is_none_or(|end| end > PCIE_CONFIG_SPACE_SIZE)
            || occupied
                .iter()
                .any(|used| (offset..offset + cap.size()).contains(used))
        {
            return Err(VfioPciError::ExtendedCapNoSpace(cap.id() as u16));
        }

        if cap.dwords().len() != cap.write_masks().len() {
            return Err(VfioPciError::ExtendedCapMismatchedWriteMasks(
                cap.id() as u16
            ));
        }

        self.override_next_extended_cap(last_offset, offset);

        let mut reg_idx = (offset / 4) as usize;
        self.patch_reg(
            reg_idx,
            0xffff_ffff,
            (cap.id() as u32) | (cap.version() << 16),
            0xffff_ffff,
        );

        for (dword, write_mask) in cap.dwords().iter().zip(cap.write_masks()) {
            reg_idx += 1;
            self.patch_reg(reg_idx, 0xffff_ffff, *dword, !*write_mask);
        }

        Ok(())
    }

    fn add_extended_caps(
        &mut self,
        last_offset: u32,
        occupied: &[u32],
    ) -> Result<(), VfioPciError> {
        let caps = self.extended_caps.clone();
        let total: u32 = caps.iter().map(|cap| cap.size()).sum();

        let mut offset = PCIE_CONFIG_SPACE_SIZE.saturating_sub(total);
        let mut last_offset = last_offset;

        for cap in caps {
            self.add_extended_cap(last_offset, offset, occupied, cap.as_ref())?;

            last_offset = offset;
            offset += cap.size();
        }

        Ok(())
    }

    fn parse_extended_capabilities(&mut self) -> Result<(), VfioPciError> {
        let mut current_offset = PCI_CONFIG_EXTENDED_CAPABILITY_OFFSET;
        let mut last_kept_offset: Option<u32> = None;
        let mut occupied = Vec::new();

        loop {
            occupied.push(current_offset);

            let ext_cap_hdr = self.vfio_wrapper.read_config_dword(current_offset);

            let cap_id: u16 = (ext_cap_hdr & 0xffff) as u16;
            let cap_next: u16 = ((ext_cap_hdr >> 20) & 0xfff) as u16;

            match PciExpressCapabilityId::from(cap_id) {
                PciExpressCapabilityId::AlternativeRoutingIdentificationInterpretation
                | PciExpressCapabilityId::ResizeableBar
                | PciExpressCapabilityId::SingleRootIoVirtualization => match last_kept_offset {
                    Some(offset) => self.override_next_extended_cap(offset, cap_next.into()),
                    None => self.patch_reg(
                        (PCI_CONFIG_EXTENDED_CAPABILITY_OFFSET / 4) as usize,
                        0xffff_ffff,
                        (PciExpressCapabilityId::NullCapability as u32)
                            | (u32::from(cap_next) << PCI_EXT_CAP_NEXT_SHIFT),
                        0xffff_ffff,
                    ),
                },
                _ => last_kept_offset = Some(current_offset),
            }

            if cap_next == 0 {
                break;
            }

            current_offset = cap_next.into();
        }

        self.add_extended_caps(
            last_kept_offset.unwrap_or(PCI_CONFIG_EXTENDED_CAPABILITY_OFFSET),
            &occupied,
        )
    }

    pub(crate) fn enable_intx(&mut self) -> Result<(), VfioPciError> {
        if let Some(intx) = &mut self.interrupt.intx
            && !intx.enabled
        {
            if let Some(eventfd) = intx.interrupt_source_group.notifier(0) {
                self.vfio_wrapper
                    .enable_irq(VFIO_PCI_INTX_IRQ_INDEX, vec![&eventfd])
                    .map_err(VfioPciError::EnableIntx)?;

                intx.enabled = true;
            } else {
                return Err(VfioPciError::MissingNotifier);
            }
        }

        Ok(())
    }

    pub(crate) fn disable_intx(&mut self) {
        if let Some(intx) = &mut self.interrupt.intx
            && intx.enabled
        {
            if let Err(e) = self.vfio_wrapper.disable_irq(VFIO_PCI_INTX_IRQ_INDEX) {
                error!("Could not disable INTx: {e}");
            } else {
                intx.enabled = false;
            }
        }
    }

    pub(crate) fn enable_msi(&self) -> Result<(), VfioPciError> {
        if let Some(msi) = &self.interrupt.msi {
            let mut irq_fds: Vec<EventFd> = Vec::new();
            for i in 0..msi.cfg.num_enabled_vectors() {
                if let Some(eventfd) = msi.interrupt_source_group.notifier(i as InterruptIndex) {
                    irq_fds.push(eventfd);
                } else {
                    return Err(VfioPciError::MissingNotifier);
                }
            }

            self.vfio_wrapper
                .enable_msi(irq_fds.iter().collect())
                .map_err(VfioPciError::EnableMsi)?;
        }

        Ok(())
    }

    pub(crate) fn disable_msi(&self) {
        if let Err(e) = self.vfio_wrapper.disable_msi() {
            error!("Could not disable MSI: {e}");
        }
    }

    pub(crate) fn enable_msix(&self) -> Result<(), VfioPciError> {
        if let Some(msix) = &self.interrupt.msix {
            let mut irq_fds: Vec<EventFd> = Vec::new();
            for i in 0..msix.bar.table_entries.len() {
                if let Some(eventfd) = msix.interrupt_source_group.notifier(i as InterruptIndex) {
                    irq_fds.push(eventfd);
                } else {
                    return Err(VfioPciError::MissingNotifier);
                }
            }

            self.vfio_wrapper
                .enable_msix(irq_fds.iter().collect())
                .map_err(VfioPciError::EnableMsix)?;
        }

        Ok(())
    }

    pub(crate) fn disable_msix(&self) {
        if let Err(e) = self.vfio_wrapper.disable_msix() {
            error!("Could not disable MSI-X: {e}");
        }
    }

    fn initialize_legacy_interrupt(&mut self) -> Result<(), VfioPciError> {
        if let Some(irq_info) = self.vfio_wrapper.get_irq_info(VFIO_PCI_INTX_IRQ_INDEX)
            && irq_info.count == 0
        {
            // A count of 0 means the INTx IRQ is not supported, therefore
            // it shouldn't be initialized.
            return Ok(());
        }

        if let Some(interrupt_source_group) = self.legacy_interrupt_group.clone() {
            self.interrupt.intx = Some(VfioIntx {
                interrupt_source_group,
                enabled: false,
            });

            self.enable_intx()?;
        }

        Ok(())
    }

    fn update_msi_capabilities(&mut self, offset: u64, data: &[u8]) -> Result<(), VfioPciError> {
        match self.interrupt.update_msi(offset, data) {
            Some(InterruptUpdateAction::EnableMsi) => {
                // Disable INTx before we can enable MSI
                self.disable_intx();
                self.enable_msi()?;
            }
            Some(InterruptUpdateAction::DisableMsi) => {
                // Fallback onto INTx when disabling MSI
                self.disable_msi();
                self.enable_intx()?;
            }
            _ => {}
        }

        Ok(())
    }

    fn update_msix_capabilities(&mut self, offset: u64, data: &[u8]) -> Result<(), VfioPciError> {
        match self.interrupt.update_msix(offset, data) {
            Some(InterruptUpdateAction::EnableMsix) => {
                // Disable INTx before we can enable MSI-X
                self.disable_intx();
                self.enable_msix()?;
            }
            Some(InterruptUpdateAction::DisableMsix) => {
                // Fallback onto INTx when disabling MSI-X
                self.disable_msix();
                self.enable_intx()?;
            }
            _ => {}
        }

        Ok(())
    }

    fn find_region(&self, addr: u64) -> Option<VfioBar> {
        for region in self.bars.iter() {
            if addr >= region.start.raw_value()
                && addr < region.start.unchecked_add(region.length).raw_value()
            {
                return Some(region.clone());
            }
        }
        None
    }

    fn is_nvidia_bar0_config_mirror(&self, region_index: u32, offset: u64) -> bool {
        self.vendor_id == VENDOR_NVIDIA
            && region_index == VFIO_PCI_BAR0_REGION_INDEX
            && (NVIDIA_BAR0_CONFIG_MIRROR_OFFSET
                ..NVIDIA_BAR0_CONFIG_MIRROR_OFFSET + NVIDIA_BAR0_CONFIG_MIRROR_SIZE)
                .contains(&offset)
    }

    pub(crate) fn read_bar(&mut self, base: u64, offset: u64, data: &mut [u8]) {
        let addr = base + offset;
        if let Some(region) = self.find_region(addr) {
            let offset = addr - region.start.raw_value();

            if self.interrupt.msix_table_accessed(region.index, offset) {
                self.interrupt.msix_read_table(offset, data);
            } else if self.is_nvidia_bar0_config_mirror(region.index, offset) {
                let config_offset = offset - NVIDIA_BAR0_CONFIG_MIRROR_OFFSET;
                let reg_idx = (config_offset / PCI_CONFIG_REGISTER_SIZE as u64) as usize;
                let reg_off = (config_offset % PCI_CONFIG_REGISTER_SIZE as u64) as usize;
                if matches!(data.len(), 1 | 2 | 4)
                    && reg_off + data.len() <= PCI_CONFIG_REGISTER_SIZE
                {
                    let val = self.read_config_register(reg_idx).to_le_bytes();
                    data.copy_from_slice(&val[reg_off..reg_off + data.len()]);
                }
            } else {
                self.vfio_wrapper.region_read(region.index, offset, data);
            }
        }

        // INTx EOI
        // The guest reading from the BAR potentially means the interrupt has
        // been received and can be acknowledged.
        if self.interrupt.intx_in_use()
            && let Err(e) = self.vfio_wrapper.unmask_irq(VFIO_PCI_INTX_IRQ_INDEX)
        {
            error!("Failed unmasking INTx IRQ: {e}");
        }
    }

    pub(crate) fn write_bar(
        &mut self,
        base: u64,
        offset: u64,
        data: &[u8],
    ) -> Option<Arc<Barrier>> {
        let addr = base + offset;
        if let Some(region) = self.find_region(addr) {
            let offset = addr - region.start.raw_value();

            // If the MSI-X table is written to, we need to update our cache.
            if self.interrupt.msix_table_accessed(region.index, offset) {
                self.interrupt.msix_write_table(offset, data);
            } else if self.is_nvidia_bar0_config_mirror(region.index, offset) {
                // Route writes to the NVIDIA BAR0 config space mirror through
                // write_config_register() so config patches, MSI/MSI-X updates,
                // and shadow synchronization apply consistently, while ignoring
                // writes to BAR registers to prevent guest BAR reprogramming via
                // the mirror.
                let config_offset = offset - NVIDIA_BAR0_CONFIG_MIRROR_OFFSET;
                let reg_idx = (config_offset / PCI_CONFIG_REGISTER_SIZE as u64) as usize;
                let reg_off = config_offset % PCI_CONFIG_REGISTER_SIZE as u64;
                if matches!(data.len(), 1 | 2 | 4)
                    && reg_off as usize + data.len() <= PCI_CONFIG_REGISTER_SIZE
                    && !(PCI_CONFIG_BAR0_INDEX..PCI_CONFIG_BAR0_INDEX + BAR_NUMS).contains(&reg_idx)
                    && reg_idx != PCI_ROM_EXP_BAR_INDEX
                {
                    let _ = self.write_config_register(reg_idx, reg_off, data);
                }
            } else {
                self.vfio_wrapper.region_write(region.index, offset, data);
            }
        }

        // INTx EOI
        // The guest writing to the BAR potentially means the interrupt has
        // been received and can be acknowledged.
        if self.interrupt.intx_in_use()
            && let Err(e) = self.vfio_wrapper.unmask_irq(VFIO_PCI_INTX_IRQ_INDEX)
        {
            error!("Failed unmasking INTx IRQ: {e}");
        }

        None
    }

    pub(crate) fn write_config_register(
        &mut self,
        reg_idx: usize,
        offset: u64,
        data: &[u8],
    ) -> (Vec<BarReprogrammingParams>, Option<Arc<Barrier>>) {
        // When the guest wants to write to a BAR, we trap it into
        // our local configuration space. We're not reprogramming
        // VFIO device.
        if (PCI_CONFIG_BAR0_INDEX..PCI_CONFIG_BAR0_INDEX + BAR_NUMS).contains(&reg_idx)
            || reg_idx == PCI_ROM_EXP_BAR_INDEX
        {
            // We keep our local cache updated with the BARs.
            // We'll read it back from there when the guest is asking
            // for BARs (see read_config_register()).
            return (
                self.configuration
                    .write_config_register(reg_idx, offset, data),
                None,
            );
        }

        let device_writes = match self.patches.get_mut(&reg_idx) {
            Some(patch) => {
                let device_writes = patch.write(offset, data);

                if patch.mask == 0xffff_ffff {
                    return (Vec::new(), None);
                }

                device_writes
            }
            None => vec![(offset, data)],
        };

        let reg = (reg_idx * PCI_CONFIG_REGISTER_SIZE) as u64;

        // If the MSI or MSI-X capabilities are accessed, we need to
        // update our local cache accordingly.
        // Depending on how the capabilities are modified, this could
        // trigger a VFIO MSI or MSI-X toggle.
        if let Some((cap_id, cap_base)) = self.interrupt.accessed(reg) {
            let cap_offset: u64 = reg - cap_base + offset;
            match cap_id {
                PciCapabilityId::MessageSignalledInterrupts => {
                    if let Err(e) = self.update_msi_capabilities(cap_offset, data) {
                        error!("Could not update MSI capabilities: {e}");
                    }
                }
                PciCapabilityId::MsiX => {
                    if let Err(e) = self.update_msix_capabilities(cap_offset, data) {
                        error!("Could not update MSI-X capabilities: {e}");
                    }
                }
                _ => {}
            }
        }

        // Make sure to write to the device's PCI config space after MSI/MSI-X
        // interrupts have been enabled/disabled. In case of MSI, when the
        // interrupts are enabled through VFIO (using VFIO_DEVICE_SET_IRQS),
        // the MSI Enable bit in the MSI capability structure found in the PCI
        // config space is disabled by default. That's why when the guest is
        // enabling this bit, we first need to enable the MSI interrupts with
        // VFIO through VFIO_DEVICE_SET_IRQS ioctl, and only after we can write
        // to the device region to update the MSI Enable bit.
        for (offset, data) in device_writes {
            self.vfio_wrapper.write_config((reg + offset) as u32, data);
        }

        // The non BAR write path goes directly to the VFIO device and not the shadow,
        // so the PciConfiguration shadow can get stale. Mirror the write into the
        // shadow here since snapshot() serializes it. Without this the shadow keeps its
        // device init values and a snapshot encodes PCI_COMMAND as zero.
        //
        // Use the raw write_* helpers rather than the PciConfiguration method
        // self.configuration.write_config_register(), which would otherwise drain
        // pending_bar_reprogram, owned by the BAR block below, and rerun MSI-X
        // set_msg_ctl, already done by update_msix_capabilities above.
        let byte_offset = reg_idx * PCI_CONFIG_REGISTER_SIZE + offset as usize;
        match data.len() {
            1 => self.configuration.write_byte(byte_offset, data[0]),
            2 => self
                .configuration
                .write_word(byte_offset, u16::from(data[0]) | (u16::from(data[1]) << 8)),
            4 => self.configuration.write_reg(
                reg_idx,
                u32::from_le_bytes(data.try_into().expect("data should be 4 bytes")),
            ),
            _ => {}
        }

        (self.configuration.drain_pending_bar_reprogram(), None)
    }

    pub(crate) fn read_config_register(&mut self, reg_idx: usize) -> u32 {
        // When reading the BARs, we trap it and return what comes
        // from our local configuration space. We want the guest to
        // use that and not the VFIO device BARs as it does not map
        // with the guest address space.
        if (PCI_CONFIG_BAR0_INDEX..PCI_CONFIG_BAR0_INDEX + BAR_NUMS).contains(&reg_idx)
            || reg_idx == PCI_ROM_EXP_BAR_INDEX
        {
            return self.configuration.read_reg(reg_idx);
        }

        if let Some(id) = self.get_msix_cap_idx()
            && let Some(msix) = &self.interrupt.msix
        {
            if reg_idx * 4 == id + 4 {
                return msix.cap.table;
            } else if reg_idx * 4 == id + 8 {
                return msix.cap.pba;
            }
        }

        // Since we don't support passing multi-functions devices, we should
        // mask the multi-function bit, bit 7 of the Header Type byte on the
        // register 3.
        let mask = if reg_idx == PCI_HEADER_TYPE_REG_INDEX {
            0xff7f_ffff
        } else {
            0xffff_ffff
        };

        // The config register read comes from the VFIO device itself.
        let mut value = self.vfio_wrapper.read_config_dword((reg_idx * 4) as u32) & mask;

        if let Some(config_patch) = self.patches.get(&reg_idx) {
            value = (value & !config_patch.mask) | config_patch.patch;
        }

        value
    }

    fn state(&self) -> VfioCommonState {
        let intx_state = self.interrupt.intx.as_ref().map(|intx| IntxState {
            enabled: intx.enabled,
        });

        let msi_state = self.interrupt.msi.as_ref().map(|msi| MsiState {
            cap: msi.cfg.cap,
            cap_offset: msi.cap_offset,
        });

        let msix_state = self.interrupt.msix.as_ref().map(|msix| MsixState {
            cap: msix.cap,
            cap_offset: msix.cap_offset,
            bdf: msix.bar.devid,
        });

        VfioCommonState {
            intx_state,
            msi_state,
            msix_state,
            patches: self.patches.clone(),
        }
    }

    fn set_state(
        &mut self,
        state: &VfioCommonState,
        msi_state: Option<MsiConfigState>,
        msix_state: Option<MsixConfigState>,
        migration_data: Option<VfioMigrationData>,
    ) -> Result<(), VfioPciError> {
        // A snapshot carrying VFIO migration state cannot be restored onto a
        // device without migration support.
        if migration_data.is_some() && self.migration_flags.is_none() {
            return Err(VfioPciError::RestoreMigration(anyhow!(
                "snapshot carries VFIO migration state but the device does not support migration"
            )));
        }

        if let (Some(intx), Some(interrupt_source_group)) =
            (&state.intx_state, self.legacy_interrupt_group.clone())
        {
            self.interrupt.intx = Some(VfioIntx {
                interrupt_source_group,
                enabled: false,
            });

            if intx.enabled {
                self.enable_intx()?;
            }
        }

        if let Some(msi) = &state.msi_state {
            self.initialize_msi(msi.cap.msg_ctl, msi.cap_offset, msi_state)?;
        }

        if let Some(msix) = &state.msix_state {
            self.initialize_msix(msix.cap, msix.cap_offset, msix.bdf.into(), msix_state)?;
        }

        // Replay the opaque device state captured at snapshot. The kernel walks
        // the intermediate STOP arc internally, so RESUMING is a single write.
        if let Some(mig) = migration_data {
            let blob = BASE64_STANDARD.decode(mig.blob.as_bytes()).map_err(|e| {
                VfioPciError::RestoreMigration(anyhow!(
                    "Failed to base64-decode migration blob: {e}"
                ))
            })?;
            self.load_migration_data(&blob)
                .context("Failed to load migration data for restoring VFIO device")
                .map_err(VfioPciError::RestoreMigration)?;
        }

        self.patches = state.patches.clone();

        self.sync_command_and_interrupts()?;

        Ok(())
    }

    fn sync_command_and_interrupts(&self) -> Result<(), VfioPciError> {
        // Push PCI_COMMAND to the device. State replay updates the shadow config
        // space but not the device, so memory decode and bus mastering would
        // otherwise stay disabled after restore.
        let cmd = (self.configuration.read_reg(COMMAND_REG) & 0xFFFF) as u16;
        self.vfio_wrapper.write_config(
            (COMMAND_REG * PCI_CONFIG_REGISTER_SIZE) as u32,
            &cmd.to_le_bytes(),
        );

        // Rearm the kernel interrupt eventfds. State replay restores only the
        // MSI or MSI-X state in memory, not the VFIO_DEVICE_SET_IRQS wiring.
        if let Some(msi) = &self.interrupt.msi
            && msi.cfg.enabled()
        {
            self.enable_msi()?;
        } else if let Some(msix) = &self.interrupt.msix
            && msix.bar.enabled()
        {
            self.enable_msix()?;
        }

        Ok(())
    }

    fn transition_migration_state(&self, target: VfioMigrationState) -> anyhow::Result<()> {
        debug!("VFIO migration transition -> {target:?}");
        self.vfio_wrapper
            .set_migration_state(target)
            .with_context(|| format!("VFIO set_migration_state({target:?}) failed"))
    }

    fn reset_and_rearm(&self) {
        self.vfio_wrapper.reset();
        // The reset returns the device to RUNNING. Reapply PCI_COMMAND and the
        // interrupt eventfds the same way the restore path does.
        if let Err(e) = self.sync_command_and_interrupts() {
            error!("VFIO device rearm after reset failed: {e}");
        }
    }

    // A failed set can leave the device anywhere along the transition path
    // including ERROR, where only a reset recovers. Attempt the recovery
    // state first when the caller names one, otherwise reset directly.
    // The original error is propagated either way.
    pub(crate) fn transition_migration_state_with_recovery(
        &self,
        target: VfioMigrationState,
        recover: Option<VfioMigrationState>,
    ) -> anyhow::Result<()> {
        let Err(err) = self.transition_migration_state(target) else {
            return Ok(());
        };

        if let Some(state) = recover
            && self.transition_migration_state(state).is_ok()
        {
            return Err(err);
        }

        warn!("VFIO device in indeterminate migration state, resetting");
        self.reset_and_rearm();
        Err(err)
    }

    pub(crate) fn save_migration_data(&self) -> Result<Vec<u8>, MigratableError> {
        self.transition_migration_state_with_recovery(
            VfioMigrationState::StopCopy,
            Some(VfioMigrationState::Stop),
        )
        .map_err(MigratableError::Snapshot)?;

        let data = self.vfio_wrapper.read_migration_data();

        // We entered STOP_COPY successfully, so the STOP_COPY to STOP arc is
        // valid whether or not the read succeeded. Return the device to STOP
        // either way and reset it if even that fails.
        let stop = self
            .transition_migration_state_with_recovery(VfioMigrationState::Stop, None)
            .map_err(MigratableError::Snapshot);

        let data = data
            .context("VFIO migration data read failed")
            .map_err(MigratableError::Snapshot)?;
        stop?;
        Ok(data)
    }

    pub(crate) fn load_migration_data(&self, data: &[u8]) -> Result<(), MigratableError> {
        // Leave the device in RESUMING and resume() drives it back to RUNNING.
        self.transition_migration_state_with_recovery(
            VfioMigrationState::Resuming,
            Some(VfioMigrationState::Stop),
        )
        .map_err(MigratableError::Restore)?;

        // A failed write leaves an incomplete RESUMING session, which the uAPI
        // only allows aborting with a reset, so reset directly.
        if let Err(e) = self.vfio_wrapper.write_migration_data(data) {
            self.reset_and_rearm();
            return Err(MigratableError::Restore(
                anyhow::Error::new(e).context("VFIO migration data write failed"),
            ));
        }
        Ok(())
    }

    // No op without ranges to track. page_size is a hint, the device reports
    // back the granularity it actually applied, kept for the report calls.
    pub(crate) fn start_dirty_log(
        &mut self,
        ranges: &[DmaLoggingRange],
        page_size: u64,
    ) -> Result<(), MigratableError> {
        if ranges.is_empty() {
            return Ok(());
        }
        let negotiated = self
            .vfio_wrapper
            .start_dma_logging(page_size, ranges)
            .context("VFIO start_dma_logging failed")
            .map_err(MigratableError::StartDirtyLog)?;
        debug!(
            "VFIO DMA logging started over {} range(s), requested page size {page_size:#x}, device granularity {negotiated:#x}",
            ranges.len()
        );
        self.dma_logging_page_size = Some(negotiated);
        Ok(())
    }

    pub(crate) fn stop_dirty_log(&mut self) -> Result<(), MigratableError> {
        if self.dma_logging_page_size.take().is_none() {
            return Ok(());
        }
        self.vfio_wrapper
            .stop_dma_logging()
            .context("VFIO stop_dma_logging failed")
            .map_err(MigratableError::StopDirtyLog)
    }

    // Reports per range dirty bitmaps from the kernel, merged into a single
    // MemoryRangeTable. Returns an empty table when logging is not active so
    // the caller can splice it into the union without a special case.
    pub(crate) fn dirty_log(
        &self,
        ranges: &[DmaLoggingRange],
    ) -> Result<MemoryRangeTable, MigratableError> {
        let Some(page_size) = self.dma_logging_page_size else {
            return Ok(MemoryRangeTable::default());
        };
        let mut table = MemoryRangeTable::default();
        for range in ranges {
            let range_table = self
                .vfio_wrapper
                .report_dma_logging(*range, page_size)
                .context("VFIO report_dma_logging failed")
                .map_err(MigratableError::DirtyLog)?;
            table.extend(range_table);
        }
        Ok(table)
    }
}

impl Pausable for VfioCommon {}

impl Snapshottable for VfioCommon {
    fn id(&self) -> String {
        String::from(VFIO_COMMON_ID)
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        let mut vfio_common_snapshot = Snapshot::new_from_state(&self.state())?;

        // Snapshot PciConfiguration
        vfio_common_snapshot.add_snapshot(self.configuration.id(), self.configuration.snapshot()?);

        // Snapshot MSI
        if let Some(msi) = &mut self.interrupt.msi {
            vfio_common_snapshot.add_snapshot(msi.cfg.id(), msi.cfg.snapshot()?);
        }

        // Snapshot MSI-X
        if let Some(msix) = &mut self.interrupt.msix {
            vfio_common_snapshot.add_snapshot(msix.bar.id(), msix.bar.snapshot()?);
        }

        if self.migration_flags.is_some() {
            let data = self.save_migration_data()?;
            let mig = VfioMigrationData {
                blob: BASE64_STANDARD.encode(&data),
            };
            vfio_common_snapshot.add_snapshot(
                VFIO_MIGRATION_ID.to_string(),
                Snapshot::new_from_state(&mig)?,
            );
        }

        Ok(vfio_common_snapshot)
    }
}

/// VfioPciDevice represents a VFIO PCI device.
/// This structure implements the BusDevice and PciDevice traits.
///
/// A VfioPciDevice is bound to a VfioDevice and is also a PCI device.
/// The VMM creates a VfioDevice, then assigns it to a VfioPciDevice,
/// which then gets added to the PCI bus.
pub struct VfioPciDevice {
    id: String,
    vm: Arc<dyn hypervisor::Vm>,
    device: Arc<VfioDevice>,
    vfio_ops: Arc<dyn VfioOps>,
    common: VfioCommon,
    iommu_attached: bool,
    // Whether to map VFIO device MMIO BARs into the host IOMMU address space.
    // Required for peer-to-peer DMA between VFIO devices.
    p2p_dma: bool,
    memory_slot_allocator: Arc<MemorySlotAllocator>,
    // Guest memory layout, used to enumerate the IOVA ranges to track when
    // programming VFIO DMA logging.
    memory: GuestMemoryAtomic<GuestMemory>,
    bdf: PciBdf,
    device_path: PathBuf,
}

impl VfioPciDevice {
    /// Constructs a new Vfio Pci device for the given Vfio device
    #[expect(clippy::too_many_arguments)]
    pub fn new(
        id: String,
        vm: Arc<dyn hypervisor::Vm>,
        device: Arc<VfioDevice>,
        vfio_ops: Arc<dyn VfioOps>,
        msi_interrupt_manager: Arc<dyn InterruptManager<GroupConfig = MsiIrqGroupConfig>>,
        legacy_interrupt_group: Option<Arc<dyn InterruptSourceGroup>>,
        iommu_attached: bool,
        p2p_dma: bool,
        bdf: PciBdf,
        memory_slot_allocator: Arc<MemorySlotAllocator>,
        memory: GuestMemoryAtomic<GuestMemory>,
        snapshot: Option<&Snapshot>,
        x_nv_gpudirect_clique: Option<u8>,
        x_exclude_mmap_bars: Vec<u8>,
        device_path: PathBuf,
        extended_caps: Vec<Arc<dyn PciExpressCapability + Send + Sync>>,
    ) -> Result<Self, VfioPciError> {
        let vfio_wrapper = VfioDeviceWrapper::new(Arc::clone(&device));

        let common = VfioCommon::new(
            msi_interrupt_manager,
            legacy_interrupt_group,
            Arc::new(vfio_wrapper) as Arc<dyn Vfio>,
            &PciVfioSubclass::VfioSubclass,
            bdf,
            vm_migration::snapshot_from_id(snapshot, VFIO_COMMON_ID),
            VfioCommonConfig {
                x_nv_gpudirect_clique,
                x_exclude_mmap_bars,
                extended_caps,
            },
        )?;

        let vfio_pci_device = VfioPciDevice {
            id,
            vm,
            device,
            vfio_ops,
            common,
            iommu_attached,
            p2p_dma,
            memory_slot_allocator,
            memory,
            bdf,
            device_path,
        };

        Ok(vfio_pci_device)
    }

    fn carve_out_sparse_areas(
        sparse_areas: &mut Vec<VfioRegionSparseMmapArea>,
        region_start: u64,
        region_size: u64,
        inter_ranges: &BTreeMap<u64, u64>,
    ) -> Result<(), VfioPciError> {
        if !is_4k_aligned(region_start) {
            error!("Region start address 0x{region_start:x} must be at least aligned on 4KiB");
            return Err(VfioPciError::RegionAlignment);
        }
        if !is_4k_multiple(region_size) {
            error!("Region size 0x{region_size:x} must be at least a multiple of 4KiB");
            return Err(VfioPciError::RegionSize);
        }

        let mut carved_areas = Vec::new();
        for area in sparse_areas.drain(..) {
            let area_start = area.offset;
            let area_end = area.offset + area.size;
            let mut current_offset = area_start;

            for (&range_offset, &range_size) in inter_ranges {
                let hole_start = range_offset;
                let hole_end = align_page_size_down(range_offset + range_size);
                if hole_end <= current_offset {
                    continue;
                }
                if hole_start >= area_end {
                    break;
                }
                if hole_start > current_offset {
                    carved_areas.push(VfioRegionSparseMmapArea {
                        offset: current_offset,
                        size: hole_start - current_offset,
                    });
                }
                current_offset = cmp::min(area_end, hole_end);
            }

            if area_end > current_offset {
                carved_areas.push(VfioRegionSparseMmapArea {
                    offset: current_offset,
                    size: area_end - current_offset,
                });
            }
        }
        *sparse_areas = carved_areas;
        Ok(())
    }

    fn update_sparse_areas_msix_mappable(
        sparse_areas: &mut Vec<VfioRegionSparseMmapArea>,
        region_index: u32,
        region_start: u64,
        region_size: u64,
        vfio_msix: Option<&VfioMsix>,
    ) -> Result<(), VfioPciError> {
        // In case the region contains the MSI-X vectors table or
        // the MSI-X PBA table, we must calculate the subregions
        // around them, leading to a list of sparse areas.
        // We want to make sure we will still trap MMIO accesses
        // to these MSI-X specific ranges. If these region don't align
        // with pagesize, we can achieve it by enlarging its range.
        //
        // Using a BtreeMap as the list provided through the iterator is sorted
        // by key. This ensures proper split of the whole region.
        let mut inter_ranges = BTreeMap::new();
        if let Some(msix) = vfio_msix {
            if region_index == msix.cap.table_bir() {
                let (offset, size) = msix.cap.table_range();
                let offset = align_page_size_down(offset);
                let size = align_page_size_up(size);
                // MSI-X mmap region safety: when a device has a non page
                // aligned MSI-X offset, fixup_msix_region() relocates MSI-X
                // to the upper half of an enlarged virtual BAR, causing the
                // offsets in msix.cap to exceed the physical BAR size. This
                // check skips carving a hole, preventing invalid offsets from
                // reaching the mmap path. With no holes,
                // generate_sparse_areas() returns a single sparse region
                // covering the entire physical BAR. The relocated MSI-X in
                // the virtual BAR remains trapped because its upper half has
                // no mmap backing. Exposing the physical MSI-X region through
                // mmap is safe when the kernel advertises
                // VFIO_REGION_INFO_CAP_MSIX_MAPPABLE. When MSI-X offsets are
                // already page aligned, fixup_msix_region() does not relocate
                // and this check is satisfied, so a hole is carved at the
                // intended offset as before.
                if offset < region_size {
                    inter_ranges.insert(offset, size);
                }
            }
            if region_index == msix.cap.pba_bir() {
                let (offset, size) = msix.cap.pba_range();
                let offset = align_page_size_down(offset);
                let size = align_page_size_up(size);
                // See MSI-X mmap safety comment above.
                if offset < region_size {
                    inter_ranges.insert(offset, size);
                }
            }
        }

        Self::carve_out_sparse_areas(sparse_areas, region_start, region_size, &inter_ranges)
    }

    fn update_sparse_areas_nvidia_mirror(
        sparse_areas: &mut Vec<VfioRegionSparseMmapArea>,
        region_start: u64,
        region_size: u64,
    ) -> Result<(), VfioPciError> {
        let start = align_page_size_down(NVIDIA_BAR0_CONFIG_MIRROR_OFFSET);
        let end =
            align_page_size_up(NVIDIA_BAR0_CONFIG_MIRROR_OFFSET + NVIDIA_BAR0_CONFIG_MIRROR_SIZE);
        let mut inter_ranges = BTreeMap::new();
        if start < region_size {
            inter_ranges.insert(start, end - start);
        }

        Self::carve_out_sparse_areas(sparse_areas, region_start, region_size, &inter_ranges)
    }

    fn generate_sparse_areas(
        caps: &[VfioRegionInfoCap],
        region_index: u32,
        region_start: u64,
        region_size: u64,
        vfio_msix: Option<&VfioMsix>,
        vendor_id: u16,
    ) -> Result<Vec<VfioRegionSparseMmapArea>, VfioPciError> {
        let mut sparse_areas = vec![VfioRegionSparseMmapArea {
            offset: 0,
            size: region_size,
        }];
        let mut msix_mappable = false;

        for cap in caps {
            match cap {
                VfioRegionInfoCap::SparseMmap(sparse_mmap) => {
                    sparse_areas.clone_from(&sparse_mmap.areas);
                }
                VfioRegionInfoCap::MsixMappable => {
                    msix_mappable = true;
                }
                _ => {}
            }
        }

        if msix_mappable {
            Self::update_sparse_areas_msix_mappable(
                &mut sparse_areas,
                region_index,
                region_start,
                region_size,
                vfio_msix,
            )?;
        }

        if vendor_id == VENDOR_NVIDIA && region_index == VFIO_PCI_BAR0_REGION_INDEX {
            Self::update_sparse_areas_nvidia_mirror(&mut sparse_areas, region_start, region_size)?;
        }

        Ok(sparse_areas)
    }

    /// Map MMIO regions into the guest, and avoid VM exits when the guest tries
    /// to reach those regions.
    ///
    /// # Arguments
    ///
    /// * `vm` - The VM object. It is used to set the VFIO MMIO regions
    ///   as user memory regions.
    /// * `mem_slot` - The closure to return a memory slot.
    pub fn map_mmio_regions(&mut self) -> Result<(), VfioPciError> {
        let fd = self.device.as_raw_fd();
        // SAFETY: fd is guaranteed valid
        let fd = unsafe { BorrowedFd::borrow_raw(fd) };
        for region in self.common.bars.iter_mut() {
            if self
                .common
                .x_exclude_mmap_bars
                .contains(&(region.index as u8))
            {
                info!(
                    "Skipping VFIO BAR mmap and P2P DMA mapping for device {} at {} BAR {} (size = 0x{:x})",
                    self.bdf,
                    self.device_path.display(),
                    region.index,
                    region.length
                );
                continue;
            }

            let region_flags = self.device.get_region_flags(region.index);
            if region_flags & VFIO_REGION_INFO_FLAG_MMAP != 0 {
                let mut prot = 0;
                if region_flags & VFIO_REGION_INFO_FLAG_READ != 0 {
                    prot |= libc::PROT_READ;
                }
                if region_flags & VFIO_REGION_INFO_FLAG_WRITE != 0 {
                    prot |= libc::PROT_WRITE;
                }

                // Retrieve the list of capabilities found on the region
                let caps = if region_flags & VFIO_REGION_INFO_FLAG_CAPS != 0 {
                    self.device.get_region_caps(region.index)
                } else {
                    Vec::new()
                };

                // Don't try to mmap the region if it contains MSI-X table or
                // MSI-X PBA subregion, and if we couldn't find MSIX_MAPPABLE
                // in the list of supported capabilities.
                if let Some(msix) = self.common.interrupt.msix.as_ref()
                    && (region.index == msix.cap.table_bir() || region.index == msix.cap.pba_bir())
                    && !caps.contains(&VfioRegionInfoCap::MsixMappable)
                {
                    continue;
                }

                let mmap_size = self.device.get_region_size(region.index);
                let mmap_offset = self.device.get_region_offset(region.index);

                let sparse_areas = Self::generate_sparse_areas(
                    &caps,
                    region.index,
                    region.start.0,
                    mmap_size,
                    self.common.interrupt.msix.as_ref(),
                    self.common.vendor_id,
                )?;

                let page_size = get_page_size();
                let map_p2p = self.p2p_dma && region.is_p2p_mappable();
                if self.p2p_dma && !map_p2p {
                    warn!(
                        "Skipping P2P DMA mapping of BAR {} of device {}: its size \
                         0x{:x} is smaller than the host page size 0x{page_size:x}",
                        region.index, self.bdf, region.length
                    );
                }

                for area in sparse_areas.iter() {
                    // KVM_SET_USER_MEMORY_REGION requires memory_size to be a
                    // multiple of the host page size. On aarch64 with 64K pages
                    // a device BAR can be smaller than a page (e.g. 16K NVMe
                    // BAR).
                    //
                    // The kernel only sets VFIO_REGION_INFO_FLAG_MMAP on sub-page
                    // BARs after verifying the physical BAR start is page-aligned
                    // and reserving the rest of the page. Expansion is only safe
                    // at offset 0 where the kernel reservation applies.
                    //
                    // fixup_msix_region() ensures MSI-X relocation at >= page_size
                    // offset, so the expanded mmap cannot overlap the trap region.
                    let mmap_len = if area.size < page_size {
                        if area.offset != 0 {
                            error!(
                                "BAR {}: sub-page sparse area at non-zero offset 0x{:x} \
                                 cannot be safely expanded to page size",
                                region.index, area.offset,
                            );
                            return Err(VfioPciError::MmapArea);
                        }
                        info!(
                            "BAR {}: expanding sub-page sparse area mmap from 0x{:x} to \
                             page size 0x{:x}",
                            region.index, area.size, page_size,
                        );
                        page_size
                    } else {
                        area.size
                    };
                    let offset = mmap_offset
                        .checked_add(area.offset)
                        .ok_or(VfioPciError::MmapArea)?;
                    let file = fd
                        .try_clone_to_owned()
                        .map_err(|_| VfioPciError::MmapArea)?;
                    let size = usize::try_from(mmap_len).map_err(|_| VfioPciError::MmapArea)?;
                    let mapping = GuestRegion::from_file(
                        vm_memory::FileOffset::new(file.into(), offset),
                        size,
                        find_alignment(size),
                        GuestAddress(region.start.0 + area.offset),
                        prot,
                        Arc::clone(&self.vm),
                        Arc::clone(&self.memory_slot_allocator),
                    )
                    .map_err(|e| {
                        error!("Could not mmap sparse area: {e}");
                        VfioPciError::MmapArea
                    })?;

                    mapping
                        .register()
                        .map_err(VfioPciError::CreateUserMemoryRegion)?;
                    let bar_memory_region = VfioBarMemoryRegion {
                        offset: area.offset,
                        region: Arc::new(Mutex::new(mapping)),
                        p2p_mapping: map_p2p.then(|| {
                            Arc::new(Mutex::new(VfioP2pMapping {
                                #[cfg(feature = "kvm")]
                                device: Arc::clone(&self.device),
                                vfio_ops: Arc::clone(&self.vfio_ops),
                                device_path: self.device_path.clone(),
                                bdf: self.bdf,
                                region_index: region.index,
                                mapped: false,
                                #[cfg(feature = "kvm")]
                                dma_buf: None,
                            }))
                        }),
                    };
                    // Map the MMIO BAR into the host IOMMU address space via VfioOps
                    // Only needed if p2p_dma is enabled.
                    if map_p2p {
                        bar_memory_region.map_for_p2p()?;
                    }
                    region.bar_memory_regions.push(bar_memory_region);
                }
            }
        }

        Ok(())
    }

    #[cfg(feature = "kvm")]
    fn is_memory_space_enabled(&mut self) -> bool {
        self.common.read_config_register(COMMAND_REG) & COMMAND_REG_MEMORY_SPACE_MASK
            == COMMAND_REG_MEMORY_SPACE_MASK
    }

    /// Based on memory space enable bit, map or unmap DMA buffers
    #[cfg(feature = "kvm")]
    fn update_dma_buffers(&mut self, last_memory_space_enabled: bool) {
        // The need for comparing the current memory space enable bit value
        // with the previous one comes from the fact a write in the middle
        // might have updated the value.
        // If the value didn't change, the mappings don't need to change.
        let memory_space_enabled = self.is_memory_space_enabled();
        if !self.p2p_dma || memory_space_enabled == last_memory_space_enabled {
            return;
        }

        let Some(vfio_iommufd) = self.vfio_ops.as_any().downcast_ref::<VfioIommufd>() else {
            return;
        };
        let (failed_action, success_action) = if memory_space_enabled {
            ("map", "Mapped")
        } else {
            ("unmap", "Unmapped")
        };

        for mmio_region in self.common.bars.iter_mut() {
            for bar_memory_region in mmio_region.bar_memory_regions.iter_mut() {
                let Some(p2p_mapping) = &bar_memory_region.p2p_mapping else {
                    continue;
                };
                let iova = bar_memory_region.start();
                let length = bar_memory_region.size() as u64;
                let mut p2p_mapping = p2p_mapping.lock().unwrap();
                let Some(dma_buf) = &p2p_mapping.dma_buf else {
                    continue;
                };

                let res = if memory_space_enabled {
                    vfio_iommufd
                        .ioas()
                        .map_file(dma_buf.as_raw_fd(), 0, length, iova, true)
                } else {
                    vfio_iommufd.ioas().unmap(iova, length)
                };

                match res {
                    Ok(()) => {
                        p2p_mapping.mapped = memory_space_enabled;
                        debug!(
                            "{success_action} region {} of device {} at 0x{iova:x} \
                         through its dma-buf",
                            mmio_region.index, self.bdf
                        );
                    }
                    Err(e) => error!(
                        "Could not {failed_action} region {} of device {} at 0x{iova:x}: {e}",
                        mmio_region.index, self.bdf
                    ),
                }
            }
        }
    }

    pub fn unmap_mmio_regions(&mut self) {
        for region in &mut self.common.bars {
            for bar_memory_region in region.bar_memory_regions.drain(..) {
                if let Err(e) = bar_memory_region.unmap_p2p() {
                    // The backing memory must remain alive while mapped for DMA.
                    error!("FATAL: Failed to remove P2P mapping: {e}");
                    process::exit(1);
                }
            }
        }
    }

    pub fn mmio_regions(&self) -> Vec<VfioBar> {
        self.common.bars.clone()
    }

    // IOVA ranges for DMA logging. Without a virtual IOMMU the device sees an
    // identity mapping of guest memory (iova == gpa), so these are the guest
    // memory regions. A virtual IOMMU is refused in start_migration, see
    // issue #8567.
    fn dirty_log_iova_ranges(&self) -> Vec<DmaLoggingRange> {
        let mem = self.memory.memory();
        mem.iter()
            .map(|region| DmaLoggingRange {
                iova: region.start_addr().raw_value(),
                length: region.len(),
            })
            .collect()
    }
}

impl Drop for VfioPciDevice {
    fn drop(&mut self) {
        self.unmap_mmio_regions();

        if let Some(msix) = &self.common.interrupt.msix
            && msix.bar.enabled()
        {
            self.common.disable_msix();
        }

        if let Some(msi) = &self.common.interrupt.msi
            && msi.cfg.enabled()
        {
            self.common.disable_msi();
        }

        if self.common.interrupt.intx_in_use() {
            self.common.disable_intx();
        }
    }
}

impl BusDevice for VfioPciDevice {
    fn read(&mut self, base: u64, offset: u64, data: &mut [u8]) {
        self.read_bar(base, offset, data);
    }

    fn write(&mut self, base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        self.write_bar(base, offset, data)
    }
}

// Offset of the 16-bit vendor ID register in the PCI configuration space.
const PCI_CONFIG_VENDOR_ID_OFFSET: u32 = 0x00;
// Offset of the 16-bit status register in the PCI configuration space.
const PCI_CONFIG_STATUS_OFFSET: u32 = 0x06;
// Status bit indicating the presence of a capabilities list.
const PCI_CONFIG_STATUS_CAPABILITIES_LIST: u16 = 1 << 4;
// First BAR offset in the PCI config space.
const PCI_CONFIG_BAR_OFFSET: u32 = 0x10;
// Capability register offset in the PCI config space.
const PCI_CONFIG_CAPABILITY_OFFSET: u32 = 0x34;
// The valid bits for the capabilities pointer.
const PCI_CONFIG_CAPABILITY_PTR_MASK: u8 = !0b11;
// Extended capabilities register offset in the PCI config space.
const PCI_CONFIG_EXTENDED_CAPABILITY_OFFSET: u32 = 0x100;
// IO BAR when first BAR bit is 1.
const PCI_CONFIG_IO_BAR: u32 = 0x1;
// 64-bit memory bar flag.
const PCI_CONFIG_MEMORY_BAR_64BIT: u32 = 0x4;
// Prefetchable BAR bit
const PCI_CONFIG_BAR_PREFETCHABLE: u32 = 0x8;
// PCI config register size (4 bytes).
const PCI_CONFIG_REGISTER_SIZE: usize = 4;
// Number of BARs for a PCI device
const BAR_NUMS: usize = 6;
// PCI Header Type register index
const PCI_HEADER_TYPE_REG_INDEX: usize = 3;
// First BAR register index
const PCI_CONFIG_BAR0_INDEX: usize = 4;
// PCI ROM expansion BAR register index
const PCI_ROM_EXP_BAR_INDEX: usize = 12;
// NVIDIA PCI Vendor ID.
const VENDOR_NVIDIA: u16 = 0x10de;
// Offset and size of the self-mirroring PCIe configuration space window
// (NV_PCFG, 0x88000..0x89000) within NVIDIA BAR0.
// Reference: NVIDIA open-gpu-kernel-modules (NV_PCFG in dev_nv_xve.h) and
// QEMU's vfio_probe_nvidia_bar0_quirk() in hw/vfio/pci-quirks.c.
const NVIDIA_BAR0_CONFIG_MIRROR_OFFSET: u64 = 0x88000;
const NVIDIA_BAR0_CONFIG_MIRROR_SIZE: u64 = 0x1000;

impl PciDevice for VfioPciDevice {
    fn allocate_bars(
        &mut self,
        allocator: &mut SystemAllocator,
        mmio32_allocator: &mut AddressAllocator,
        mmio64_allocator: &mut AddressAllocator,
        resources: Option<Vec<Resource>>,
    ) -> Result<Vec<PciBarConfiguration>, PciDeviceError> {
        self.common.allocate_bars(
            allocator,
            mmio32_allocator,
            mmio64_allocator,
            resources.as_deref(),
        )
    }

    fn free_bars(
        &mut self,
        allocator: &mut SystemAllocator,
        mmio32_allocator: &mut AddressAllocator,
        mmio64_allocator: &mut AddressAllocator,
    ) -> Result<(), PciDeviceError> {
        self.common
            .free_bars(allocator, mmio32_allocator, mmio64_allocator)
    }

    fn write_config_register(
        &mut self,
        reg_idx: usize,
        offset: u64,
        data: &[u8],
    ) -> (Vec<BarReprogrammingParams>, Option<Arc<Barrier>>) {
        #[cfg(feature = "kvm")]
        let memory_space_enabled = reg_idx == COMMAND_REG && self.is_memory_space_enabled();

        let ret = self.common.write_config_register(reg_idx, offset, data);

        #[cfg(feature = "kvm")]
        if reg_idx == COMMAND_REG {
            self.update_dma_buffers(memory_space_enabled);
        }

        ret
    }

    fn read_config_register(&mut self, reg_idx: usize) -> u32 {
        self.common.read_config_register(reg_idx)
    }

    fn read_bar(&mut self, base: u64, offset: u64, data: &mut [u8]) {
        self.common.read_bar(base, offset, data);
    }

    fn write_bar(&mut self, base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        self.common.write_bar(base, offset, data)
    }

    fn move_bar(&mut self, bar_idx: usize, new_base: u64) -> Result<(), io::Error> {
        self.common
            .move_bar(bar_idx, new_base)
            .map_err(io::Error::other)
    }

    fn restore_bar_addr(&mut self, params: &BarReprogrammingParams) {
        self.common.configuration.restore_bar_addr(params);
    }

    fn as_any_mut(&mut self) -> &mut dyn Any {
        self
    }

    fn id(&self) -> Option<String> {
        Some(self.id.clone())
    }

    fn bdf(&self) -> PciBdf {
        self.bdf
    }
}

impl Pausable for VfioPciDevice {
    fn pause(&mut self) -> result::Result<(), MigratableError> {
        if self.common.migration_flags.is_some() {
            self.common
                .transition_migration_state_with_recovery(VfioMigrationState::Stop, None)
                .map_err(MigratableError::Pause)?;
        }
        Ok(())
    }

    fn resume(&mut self) -> result::Result<(), MigratableError> {
        if self.common.migration_flags.is_some() {
            self.common
                .transition_migration_state_with_recovery(VfioMigrationState::Running, None)
                .map_err(MigratableError::Resume)?;
        }
        Ok(())
    }
}

impl Snapshottable for VfioPciDevice {
    fn id(&self) -> String {
        self.id.clone()
    }

    fn snapshot(&mut self) -> result::Result<Snapshot, MigratableError> {
        let mut vfio_pci_dev_snapshot = Snapshot::default();

        // Snapshot VfioCommon
        vfio_pci_dev_snapshot.add_snapshot(self.common.id(), self.common.snapshot()?);

        Ok(vfio_pci_dev_snapshot)
    }
}

impl Transportable for VfioPciDevice {}

impl Migratable for VfioPciDevice {
    fn notify_started_migration(&mut self) -> result::Result<(), MigratableError> {
        // Reject a device that does not implement migration v2 up front,
        // rather than silently skipping its state and dirty tracking.
        if self.common.migration_flags.is_none() {
            return Err(MigratableError::MigrateSend(anyhow!(
                "VFIO device does not support migration"
            )));
        }
        // Dirty tracking behind a virtual IOMMU needs IOVA to GPA translation
        // and would have to follow mappings the guest changes mid migration,
        // neither of which is implemented, see issue #8567.
        if self.iommu_attached {
            return Err(MigratableError::MigrateSend(anyhow!(
                "VFIO device live migration is not supported behind a virtual IOMMU"
            )));
        }
        Ok(())
    }

    fn start_dirty_log(&mut self) -> result::Result<(), MigratableError> {
        let ranges = self.dirty_log_iova_ranges();
        self.common.start_dirty_log(&ranges, get_page_size())
    }

    fn stop_dirty_log(&mut self) -> result::Result<(), MigratableError> {
        self.common.stop_dirty_log()
    }

    fn dirty_log(&mut self) -> result::Result<MemoryRangeTable, MigratableError> {
        let ranges = self.dirty_log_iova_ranges();
        self.common.dirty_log(&ranges)
    }
}

/// This structure implements the ExternalDmaMapping trait. It is meant to
/// be used when the caller tries to provide a way to update the mappings
/// associated with a specific VfioOps instance.
pub struct VfioDmaMapping<M: GuestAddressSpace> {
    vfio_ops: Arc<dyn VfioOps>,
    memory: Arc<M>,
    mmio_regions: Arc<Mutex<Vec<VfioBar>>>,
}

impl<M: GuestAddressSpace> VfioDmaMapping<M> {
    /// Create a DmaMapping object.
    /// # Parameters
    /// * `vfio_ops`: VfioOps instance.
    /// * `memory`: guest memory to mmap.
    /// * `mmio_regions`: mmio_regions to mmap.
    pub fn new(
        vfio_ops: Arc<dyn VfioOps>,
        memory: Arc<M>,
        mmio_regions: Arc<Mutex<Vec<VfioBar>>>,
    ) -> Self {
        VfioDmaMapping {
            vfio_ops,
            memory,
            mmio_regions,
        }
    }
}

impl<M: GuestAddressSpace + Sync + Send> ExternalDmaMapping for VfioDmaMapping<M>
where
    M::M: GuestMemoryBackend,
{
    fn map(&self, iova: u64, gpa: u64, size: u64) -> result::Result<(), ExternalDmaMappingError> {
        let mem = self.memory.memory();
        let guest_addr = GuestAddress(gpa);
        let user_addr = if mem.check_range(guest_addr, size as usize) {
            let slice = mem.get_slice(guest_addr, size as usize).map_err(|e| {
                ExternalDmaMappingError::Map {
                    iova,
                    gpa,
                    size,
                    source: e.into(),
                }
            })?;
            assert!(slice.len() >= size as usize);
            Ok(slice.ptr_guard_mut())
        } else {
            let mmio_regions = self.mmio_regions.lock().unwrap();
            if mmio_regions.check_range(gpa, size) {
                Err(mmio_regions.find_user_address(gpa, size).map_err(|e| {
                    ExternalDmaMappingError::Map {
                        iova,
                        gpa,
                        size,
                        source: e.into(),
                    }
                })?)
            } else {
                return Err(ExternalDmaMappingError::InvalidGuestRange { gpa, size });
            }
        };
        let user_addr = match user_addr {
            Ok(p) => p.as_ptr(),
            Err(p) => p,
        };

        // vfio_dma_map is unsound and ought to be marked as unsafe
        // SAFETY: find_user_address and GuestMemoryBackend::get_slice() guarantee that
        // the returned pointer is valid for up to `size` bytes.
        unsafe { self.vfio_ops.vfio_dma_map(iova, size as usize, user_addr) }.map_err(|e| {
            ExternalDmaMappingError::Map {
                iova,
                gpa,
                size,
                source: e.into(),
            }
        })
    }

    fn unmap(&self, iova: u64, size: u64) -> result::Result<(), ExternalDmaMappingError> {
        self.vfio_ops
            .vfio_dma_unmap(iova, size as usize)
            .map_err(|e| ExternalDmaMappingError::Unmap {
                iova,
                size,
                source: e.into(),
            })
    }
}

#[cfg(test)]
mod tests {
    use std::env::temp_dir;
    use std::sync::Mutex;
    #[cfg(feature = "kvm")]
    use std::sync::atomic::AtomicU32;

    use vmm_sys_util::tempfile::TempFile;

    use super::*;
    use crate::PasidCap;

    #[test]
    fn find_alignment_scales_with_length() {
        let page_size = get_page_size() as usize;

        // Sub-page and page-sized mappings only need page alignment.
        assert_eq!(find_alignment(1), page_size);
        assert_eq!(find_alignment(page_size), page_size);

        // Larger mappings round up to the next power of two.
        assert_eq!(
            find_alignment(page_size + 1),
            (page_size + 1).next_power_of_two()
        );
        assert!(find_alignment(page_size + 1) > page_size);

        // The alignment is capped at 1 GiB.
        assert_eq!(find_alignment(ONE_GIB), ONE_GIB);
        assert_eq!(find_alignment(ONE_GIB + 1), ONE_GIB);
        assert_eq!(find_alignment(2 * ONE_GIB), ONE_GIB);
    }

    #[test]
    fn move_region_preserves_backing() {
        let mut region = sparse_mmio_regions().remove(0);
        let entry = &mut region.bar_memory_regions[0];
        let mapping = Arc::clone(&entry.region);
        let host_address = entry.host_address();
        let size = entry.size();
        let slot = entry.region.lock().unwrap().slot();

        for address in [10 * get_page_size(), get_page_size()] {
            entry.move_region(address).unwrap();
            assert_eq!(mapping.lock().unwrap().start_addr(), GuestAddress(address));
            assert_eq!(entry.host_address(), host_address);
            assert_eq!(entry.size(), size);
            assert_eq!(entry.region.lock().unwrap().slot(), slot);
            assert!(!entry.region.lock().unwrap().is_registered());
        }
    }

    #[test]
    fn move_region_rejects_overflow_without_changing_mapping() {
        let mut region = sparse_mmio_regions().remove(0);
        let entry = &mut region.bar_memory_regions[0];
        let host_address = entry.host_address();
        let old_address = entry.region.lock().unwrap().start_addr();

        assert!(entry.move_region(u64::MAX).is_err());
        assert_eq!(entry.host_address(), host_address);
        let mapping = entry.region.try_lock().unwrap();
        assert_eq!(mapping.start_addr(), old_address);
        assert!(!mapping.is_registered());
    }

    #[cfg(feature = "kvm")]
    #[test]
    fn move_registered_region_keeps_slot_after_failed_relocation() {
        let page_size = get_page_size();
        let vm = hypervisor::new()
            .unwrap()
            .create_vm(hypervisor::HypervisorVmConfig::default())
            .unwrap();
        let slot_allocator = Arc::new(MemorySlotAllocator::new(
            Arc::new(AtomicU32::new(0)),
            Arc::new(Mutex::new(Vec::new())),
        ));
        let mut regions = Vec::new();
        for address in [page_size, 2 * page_size] {
            let mapping = GuestRegion::from_mmap(
                vm_memory::MmapRegion::new(page_size as usize).unwrap(),
                GuestAddress(address),
                Arc::clone(&vm),
                Arc::clone(&slot_allocator),
                false,
                false,
                false,
                hypervisor::MemoryVisibility::Shared,
            )
            .unwrap();
            mapping.register().unwrap();
            regions.push(VfioBarMemoryRegion {
                offset: 0,
                region: Arc::new(Mutex::new(mapping)),
                p2p_mapping: None,
            });
        }
        let slots = regions
            .iter()
            .map(|entry| entry.region.lock().unwrap().slot().unwrap())
            .collect::<Vec<_>>();
        let host_addresses = regions
            .iter()
            .map(VfioBarMemoryRegion::host_address)
            .collect::<Vec<_>>();

        regions[0].move_region(4 * page_size).unwrap();
        assert_eq!(regions[0].start(), 4 * page_size);
        assert!(regions[0].region.lock().unwrap().is_registered());

        // KVM rejects the second mapping at the first mapping's new address.
        regions[1].move_region(4 * page_size).unwrap_err();
        assert_eq!(regions[1].start(), 2 * page_size);
        assert!(!regions[1].region.lock().unwrap().is_registered());

        // A failed replacement reserves the slot for explicit restoration.
        regions[1].move_region(2 * page_size).unwrap();
        regions[1].region.lock().unwrap().register().unwrap();
        regions[0].move_region(page_size).unwrap();
        for (i, entry) in regions.iter().enumerate() {
            assert_eq!(entry.start(), (i as u64 + 1) * page_size);
            assert_eq!(entry.host_address(), host_addresses[i]);
            let mapping = entry.region.lock().unwrap();
            assert_eq!(mapping.slot(), Some(slots[i]));
            assert!(mapping.is_registered());
        }
    }

    #[cfg(feature = "kvm")]
    #[test]
    fn move_bar_restores_sparse_areas_after_failed_relocation() {
        let page_size = get_page_size();
        let vm = hypervisor::new()
            .unwrap()
            .create_vm(hypervisor::HypervisorVmConfig::default())
            .unwrap();
        let slot_allocator = Arc::new(MemorySlotAllocator::new(
            Arc::new(AtomicU32::new(0)),
            Arc::new(Mutex::new(Vec::new())),
        ));
        let mut regions = Vec::new();
        for address in [page_size, 3 * page_size, 6 * page_size] {
            let mapping = GuestRegion::from_mmap(
                vm_memory::MmapRegion::new(page_size as usize).unwrap(),
                GuestAddress(address),
                Arc::clone(&vm),
                Arc::clone(&slot_allocator),
                false,
                false,
                false,
                hypervisor::MemoryVisibility::Shared,
            )
            .unwrap();
            mapping.register().unwrap();
            regions.push(VfioBarMemoryRegion {
                offset: address - page_size,
                region: Arc::new(Mutex::new(mapping)),
                p2p_mapping: None,
            });
        }
        // The second area will collide with this slot after the first moves.
        let _blocker = regions.pop().unwrap();
        let slots: Vec<_> = regions
            .iter()
            .map(|entry| entry.region.lock().unwrap().slot().unwrap())
            .collect();
        let mut common = test_vfio_common(Arc::new(DefaultVfio), None);
        common.bars.push(VfioBar {
            start: GuestAddress(page_size),
            length: 3 * page_size,
            type_: PciBarRegionType::Memory32BitRegion,
            index: 0,
            bar_memory_regions: regions,
        });
        let lookup_regions = common.bars.clone();

        common.move_bar(0, 4 * page_size).unwrap_err();

        assert_eq!(common.bars[0].start, GuestAddress(page_size));
        for (i, entry) in common.bars[0].bar_memory_regions.iter().enumerate() {
            let address = page_size + entry.offset;
            let mapping = entry.region.lock().unwrap();
            assert_eq!(mapping.start_addr(), GuestAddress(address));
            assert_eq!(mapping.slot(), Some(slots[i]));
            assert!(mapping.is_registered());
        }
        assert!(lookup_regions.check_range(page_size, 3 * page_size));
        assert!(!lookup_regions.check_range(4 * page_size, page_size));
        lookup_regions
            .find_user_address(page_size, page_size)
            .unwrap();
        lookup_regions
            .find_user_address(3 * page_size, page_size)
            .unwrap();
    }

    fn sparse_mmio_regions() -> Vec<VfioBar> {
        let page_size = get_page_size();
        let file =
            TempFile::new_with_prefix(temp_dir().join("cloud-hypervisor-vfio-sparse-")).unwrap();
        file.as_file().set_len(2 * page_size).unwrap();

        let mapping_a = Arc::new(Mutex::new(
            vm_memory::GuestRegionMmap::from_range(
                GuestAddress(page_size),
                page_size as usize,
                Some(vm_memory::FileOffset::new(
                    file.as_file().try_clone().unwrap(),
                    0,
                )),
            )
            .unwrap()
            .into(),
        ));
        let mapping_b = Arc::new(Mutex::new(
            vm_memory::GuestRegionMmap::from_range(
                GuestAddress(3 * page_size),
                page_size as usize,
                Some(vm_memory::FileOffset::new(
                    file.as_file().try_clone().unwrap(),
                    page_size,
                )),
            )
            .unwrap()
            .into(),
        ));

        vec![VfioBar {
            start: GuestAddress(page_size),
            length: 4 * page_size,
            type_: PciBarRegionType::Memory32BitRegion,
            index: 0,
            bar_memory_regions: vec![
                VfioBarMemoryRegion {
                    offset: 0,
                    region: mapping_a,
                    p2p_mapping: None,
                },
                VfioBarMemoryRegion {
                    offset: 2 * page_size,
                    region: mapping_b,
                    p2p_mapping: None,
                },
            ],
        }]
    }

    #[test]
    fn dma_range_must_fit_single_mmap_area() {
        let page_size = get_page_size();
        let regions = sparse_mmio_regions();
        let guest_addr = page_size + page_size / 2;

        // The BAR spans [P, 5P), but the mmap-backed areas [P, 2P) and [3P, 4P)
        // are non-contiguous. [1.5P, 2.5P) fits the BAR but crosses the unmapped gap.
        let pointer = regions
            .find_user_address(guest_addr, page_size / 2)
            .unwrap();
        assert!(!pointer.is_null());

        assert!(regions.check_range(guest_addr, page_size));
        regions
            .find_user_address(guest_addr, page_size)
            .unwrap_err();
    }

    #[test]
    fn dma_lookup_through_cloned_bar_tracks_relocation() {
        let page_size = get_page_size();
        let mut common = test_vfio_common(Arc::new(DefaultVfio), None);
        common.bars = sparse_mmio_regions();
        let lookup_regions = common.bars.clone();
        let host_addresses = [
            lookup_regions
                .find_user_address(page_size, page_size)
                .unwrap(),
            lookup_regions
                .find_user_address(3 * page_size, page_size)
                .unwrap(),
        ];

        for new_base in [10 * page_size, page_size] {
            let old_base = common.bars[0].start.raw_value();
            common.move_bar(0, new_base).unwrap();

            // Only the shared mappings change in the cloned lookup records.
            assert_eq!(lookup_regions[0].start, GuestAddress(page_size));
            assert!(!lookup_regions.check_range(old_base, page_size));
            assert!(lookup_regions.check_range(new_base, 4 * page_size));
            for (i, offset) in [0, 2 * page_size].into_iter().enumerate() {
                lookup_regions
                    .find_user_address(old_base + offset, page_size)
                    .unwrap_err();
                assert_eq!(
                    lookup_regions
                        .find_user_address(new_base + offset, page_size)
                        .unwrap(),
                    host_addresses[i],
                );
            }
            // Relocation must preserve the unmapped gap between sparse areas.
            lookup_regions
                .find_user_address(new_base + page_size, page_size)
                .unwrap_err();
            lookup_regions
                .find_user_address(new_base + page_size / 2, page_size)
                .unwrap_err();
        }
    }

    // Trait default behavior and state enum round trip.

    #[test]
    fn vfio_migration_state_round_trips() {
        for state in [
            VfioMigrationState::Error,
            VfioMigrationState::Stop,
            VfioMigrationState::Running,
            VfioMigrationState::StopCopy,
            VfioMigrationState::Resuming,
            VfioMigrationState::RunningP2P,
            VfioMigrationState::PreCopy,
            VfioMigrationState::PreCopyP2P,
        ] {
            let raw = u32::from(state);
            assert_eq!(VfioMigrationState::try_from(raw).unwrap(), state);
        }
    }

    #[test]
    fn vfio_migration_state_invalid_errors() {
        match VfioMigrationState::try_from(999_u32) {
            Err(VfioError::InvalidMigrationState(999)) => {}
            other => panic!("expected InvalidMigrationState(999), got {other:?}"),
        }
    }

    struct DefaultVfio;
    impl Vfio for DefaultVfio {}

    #[test]
    fn default_migration_flags_returns_none() {
        assert!(matches!(DefaultVfio.migration_flags(), Ok(None)));
    }

    #[test]
    fn default_set_migration_state_errors() {
        assert!(matches!(
            DefaultVfio.set_migration_state(VfioMigrationState::Stop),
            Err(VfioError::NoMigrationSupport)
        ));
    }

    #[test]
    fn default_dma_logging_methods_error() {
        let range = DmaLoggingRange {
            iova: 0,
            length: 0x1000,
        };
        assert!(matches!(
            DefaultVfio.start_dma_logging(0x1000, &[range]),
            Err(VfioError::NoMigrationSupport)
        ));
        assert!(matches!(
            DefaultVfio.stop_dma_logging(),
            Err(VfioError::NoMigrationSupport)
        ));
        assert!(matches!(
            DefaultVfio.report_dma_logging(range, 0x1000),
            Err(VfioError::NoMigrationSupport)
        ));
    }

    // Save and load state machine flows, driven through a mock Vfio wrapper
    // that records state transitions and stores the migration data in memory.

    #[derive(Default)]
    struct MockVfioState {
        transitions: Vec<VfioMigrationState>,
        save_blob: Vec<u8>,
        loaded: Vec<u8>,
        fail_at: Vec<VfioMigrationState>,
        fail_read: bool,
        fail_write: bool,
        resets: u32,
        dma_logging_started: bool,
        dma_logging_page_size: u64,
        dma_logging_ranges: Vec<DmaLoggingRange>,
        dma_logging_bitmap: Vec<u64>,
        dma_logging_negotiated: Option<u64>,
    }

    struct MockVfio {
        state: Mutex<MockVfioState>,
    }

    impl MockVfio {
        fn with_state(state: MockVfioState) -> Arc<Self> {
            Arc::new(Self {
                state: Mutex::new(state),
            })
        }

        fn for_save(blob: Vec<u8>) -> Arc<Self> {
            Self::with_state(MockVfioState {
                save_blob: blob,
                ..Default::default()
            })
        }

        fn for_load() -> Arc<Self> {
            Self::with_state(MockVfioState::default())
        }

        fn failing_at(targets: &[VfioMigrationState]) -> Arc<Self> {
            Self::with_state(MockVfioState {
                fail_at: targets.to_vec(),
                ..Default::default()
            })
        }

        fn failing_read() -> Arc<Self> {
            Self::with_state(MockVfioState {
                fail_read: true,
                ..Default::default()
            })
        }

        fn for_dma_logging(bitmap: Vec<u64>) -> Arc<Self> {
            Self::with_state(MockVfioState {
                dma_logging_bitmap: bitmap,
                ..Default::default()
            })
        }

        fn transitions(&self) -> Vec<VfioMigrationState> {
            self.state.lock().unwrap().transitions.clone()
        }

        fn loaded(&self) -> Vec<u8> {
            self.state.lock().unwrap().loaded.clone()
        }

        fn resets(&self) -> u32 {
            self.state.lock().unwrap().resets
        }

        fn dma_logging_started(&self) -> bool {
            self.state.lock().unwrap().dma_logging_started
        }

        fn dma_logging_recorded(&self) -> (u64, Vec<DmaLoggingRange>) {
            let s = self.state.lock().unwrap();
            (s.dma_logging_page_size, s.dma_logging_ranges.clone())
        }
    }

    impl Vfio for MockVfio {
        fn set_migration_state(&self, state: VfioMigrationState) -> Result<(), VfioError> {
            let mut s = self.state.lock().unwrap();
            s.transitions.push(state);
            if s.fail_at.contains(&state) {
                return Err(VfioError::NoMigrationSupport);
            }
            Ok(())
        }

        fn read_migration_data(&self) -> Result<Vec<u8>, VfioError> {
            let s = self.state.lock().unwrap();
            if s.fail_read {
                return Err(VfioError::NoMigrationSupport);
            }
            Ok(s.save_blob.clone())
        }

        fn write_migration_data(&self, data: &[u8]) -> Result<(), VfioError> {
            let mut s = self.state.lock().unwrap();
            if s.fail_write {
                return Err(VfioError::NoMigrationSupport);
            }
            s.loaded.extend_from_slice(data);
            Ok(())
        }

        fn reset(&self) {
            self.state.lock().unwrap().resets += 1;
        }

        fn start_dma_logging(
            &self,
            page_size: u64,
            ranges: &[DmaLoggingRange],
        ) -> Result<u64, VfioError> {
            let mut s = self.state.lock().unwrap();
            s.dma_logging_started = true;
            s.dma_logging_page_size = page_size;
            s.dma_logging_ranges = ranges.to_vec();
            Ok(s.dma_logging_negotiated.unwrap_or(page_size))
        }

        fn stop_dma_logging(&self) -> Result<(), VfioError> {
            self.state.lock().unwrap().dma_logging_started = false;
            Ok(())
        }

        fn report_dma_logging(
            &self,
            range: DmaLoggingRange,
            page_size: u64,
        ) -> Result<MemoryRangeTable, VfioError> {
            let bitmap = self.state.lock().unwrap().dma_logging_bitmap.clone();
            Ok(MemoryRangeTable::from_dirty_bitmap(
                bitmap, range.iova, page_size,
            ))
        }

        fn region_write(&self, _index: u32, _offset: u64, _data: &[u8]) {}
    }

    struct MockMsiInterruptManager;
    impl InterruptManager for MockMsiInterruptManager {
        type GroupConfig = MsiIrqGroupConfig;
        fn create_group(&self, _: MsiIrqGroupConfig) -> io::Result<Arc<dyn InterruptSourceGroup>> {
            unimplemented!("not exercised by the migration-helper tests")
        }
    }

    fn test_vfio_common<V: Vfio + 'static>(
        vfio_wrapper: Arc<V>,
        migration_flags: Option<u64>,
    ) -> VfioCommon {
        let configuration = PciConfiguration::new(
            0,
            0,
            0,
            PciClassCode::Other,
            &PciVfioSubclass::VfioSubclass,
            None,
            PciHeaderType::Device,
            0,
            0,
            None,
            None,
        );
        VfioCommon {
            configuration,
            bars: Vec::new(),
            interrupt: Interrupt {
                intx: None,
                msi: None,
                msix: None,
            },
            msi_interrupt_manager: Arc::new(MockMsiInterruptManager),
            legacy_interrupt_group: None,
            vfio_wrapper,
            patches: HashMap::new(),
            vendor_id: 0,
            x_nv_gpudirect_clique: None,
            x_exclude_mmap_bars: Vec::new(),
            migration_flags,
            dma_logging_page_size: None,
            extended_caps: Vec::new(),
        }
    }

    #[test]
    fn save_migration_data_success_path() {
        let blob = b"hello migration".to_vec();
        let mock = MockVfio::for_save(blob.clone());
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let got = common.save_migration_data().unwrap();
        assert_eq!(got, blob);
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::StopCopy, VfioMigrationState::Stop]
        );
    }

    #[test]
    fn save_migration_data_stop_copy_failure_recovers_to_stop() {
        let mock = MockVfio::failing_at(&[VfioMigrationState::StopCopy]);
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.save_migration_data().unwrap_err();
        assert!(matches!(err, MigratableError::Snapshot(_)));
        // Entering STOP_COPY failed, so STOP is attempted as recovery.
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::StopCopy, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 0);
    }

    #[test]
    fn save_migration_data_stop_copy_and_stop_failure_resets() {
        let mock = MockVfio::failing_at(&[VfioMigrationState::StopCopy, VfioMigrationState::Stop]);
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.save_migration_data().unwrap_err();
        assert!(matches!(err, MigratableError::Snapshot(_)));
        // The recovery STOP failed too, so the device is reset.
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::StopCopy, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 1);
    }

    #[test]
    fn save_migration_data_read_failure_returns_to_stop() {
        let mock = MockVfio::failing_read();
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.save_migration_data().unwrap_err();
        assert!(matches!(err, MigratableError::Snapshot(_)));
        // STOP_COPY was entered, so the device is returned to STOP.
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::StopCopy, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 0);
    }

    #[test]
    fn save_migration_data_read_and_stop_failure_resets() {
        let mock = MockVfio::with_state(MockVfioState {
            fail_read: true,
            fail_at: vec![VfioMigrationState::Stop],
            ..Default::default()
        });
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.save_migration_data().unwrap_err();
        assert!(matches!(err, MigratableError::Snapshot(_)));
        // The return to STOP after the failed read has no recovery state,
        // so its failure resets the device directly.
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::StopCopy, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 1);
    }

    #[test]
    fn load_migration_data_success_path() {
        let blob = b"restore me".to_vec();
        let mock = MockVfio::for_load();
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        common.load_migration_data(&blob).unwrap();
        assert_eq!(mock.loaded(), blob);
        // Device is left in RESUMING so resume() can drive it to RUNNING.
        assert_eq!(mock.transitions(), vec![VfioMigrationState::Resuming]);
    }

    #[test]
    fn load_migration_data_recovers_on_failure() {
        let mock = MockVfio::failing_at(&[VfioMigrationState::Resuming]);
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.load_migration_data(b"ignored").unwrap_err();
        assert!(matches!(err, MigratableError::Restore(_)));
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::Resuming, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 0);
    }

    #[test]
    fn load_migration_data_resuming_and_stop_failure_resets() {
        let mock = MockVfio::failing_at(&[VfioMigrationState::Resuming, VfioMigrationState::Stop]);
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.load_migration_data(b"ignored").unwrap_err();
        assert!(matches!(err, MigratableError::Restore(_)));
        assert_eq!(
            mock.transitions(),
            vec![VfioMigrationState::Resuming, VfioMigrationState::Stop]
        );
        assert_eq!(mock.resets(), 1);
    }

    #[test]
    fn load_migration_data_write_failure_resets() {
        let mock = MockVfio::with_state(MockVfioState {
            fail_write: true,
            ..Default::default()
        });
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common.load_migration_data(b"ignored").unwrap_err();
        assert!(matches!(err, MigratableError::Restore(_)));
        // A RESUMING session can only be aborted by a reset, so a failed write
        // resets directly rather than attempting STOP.
        assert_eq!(mock.transitions(), vec![VfioMigrationState::Resuming]);
        assert_eq!(mock.resets(), 1);
    }

    #[test]
    fn start_dirty_log_skips_empty_ranges() {
        let mock = MockVfio::for_dma_logging(Vec::new());
        let mut common = test_vfio_common(Arc::clone(&mock), Some(1));

        // No ranges to track, so no logging session is opened and the
        // stop is a no op rather than an unbalanced kernel call.
        common.start_dirty_log(&[], 0x1000).unwrap();
        assert!(!mock.dma_logging_started());
        common.stop_dirty_log().unwrap();
    }

    #[test]
    fn start_stop_dirty_log_drives_mock_when_migration_enabled() {
        let mock = MockVfio::for_dma_logging(Vec::new());
        let mut common = test_vfio_common(Arc::clone(&mock), Some(1));
        let ranges = [DmaLoggingRange {
            iova: 0x4000,
            length: 0x2000,
        }];

        common.start_dirty_log(&ranges, 0x1000).unwrap();
        assert!(mock.dma_logging_started());
        let (page_size, recorded) = mock.dma_logging_recorded();
        assert_eq!(page_size, 0x1000);
        assert_eq!(recorded, ranges);

        common.stop_dirty_log().unwrap();
        assert!(!mock.dma_logging_started());
    }

    #[test]
    fn dirty_log_uses_negotiated_page_size() {
        // The mock negotiates 0x2000 against a requested 0x1000. With bit 0
        // set the reported range length equals the negotiated granularity.
        let mock = MockVfio::with_state(MockVfioState {
            dma_logging_bitmap: vec![0b1_u64],
            dma_logging_negotiated: Some(0x2000),
            ..Default::default()
        });
        let mut common = test_vfio_common(mock, Some(1));
        let ranges = [DmaLoggingRange {
            iova: 0x1_0000_0000,
            length: 0x2000 * 64,
        }];

        common.start_dirty_log(&ranges, 0x1000).unwrap();
        let table = common.dirty_log(&ranges).unwrap();
        let merged = table.ranges();
        assert_eq!(merged.len(), 1);
        assert_eq!(merged[0].gpa, 0x1_0000_0000);
        assert_eq!(merged[0].length, 0x2000);
    }

    #[test]
    fn dirty_log_merges_ranges_into_one_table() {
        // Mock returns the same canned bitmap for each report call. With
        // bit 0 set, each range contributes its first page.
        let bitmap = vec![0b1_u64];
        let mock = MockVfio::for_dma_logging(bitmap);
        let mut common = test_vfio_common(mock, Some(1));
        let page_size: u64 = 0x1000;
        let ranges = [
            DmaLoggingRange {
                iova: 0x1_0000_0000,
                length: page_size * 64,
            },
            DmaLoggingRange {
                iova: 0x2_0000_0000,
                length: page_size * 64,
            },
        ];

        common.start_dirty_log(&ranges, page_size).unwrap();
        let table = common.dirty_log(&ranges).unwrap();
        let merged = table.ranges();
        assert_eq!(merged.len(), 2);
        let mut starts: Vec<u64> = merged.iter().map(|r| r.gpa).collect();
        starts.sort();
        assert_eq!(starts, vec![0x1_0000_0000, 0x2_0000_0000]);
        assert!(merged.iter().all(|r| r.length == page_size));
    }

    // pause() and resume() name no recovery state, so a failed transition
    // resets the device directly.
    #[test]
    fn transition_without_recovery_state_resets() {
        let mock = MockVfio::failing_at(&[VfioMigrationState::Running]);
        let common = test_vfio_common(Arc::clone(&mock), Some(1));
        let err = common
            .transition_migration_state_with_recovery(VfioMigrationState::Running, None)
            .unwrap_err();
        assert!(err.to_string().contains("Running"));
        assert_eq!(mock.transitions(), vec![VfioMigrationState::Running]);
        assert_eq!(mock.resets(), 1);
    }

    // A snapshot with migration state restored onto a device without migration
    // support must fail rather than silently drop the device state.
    #[test]
    fn set_state_rejects_migration_data_without_support() {
        let mock = MockVfio::for_load();
        let mut common = test_vfio_common(mock, None);
        let state = VfioCommonState {
            intx_state: None,
            msi_state: None,
            msix_state: None,
            patches: HashMap::new(),
        };
        let mig = VfioMigrationData {
            blob: String::new(),
        };
        let err = common.set_state(&state, None, None, Some(mig)).unwrap_err();
        assert!(matches!(err, VfioPciError::RestoreMigration(_)));
    }

    // A guest write to a non BAR, non MSI config register must mirror into
    // the PciConfiguration shadow so a later snapshot() picks up the live
    // value.
    #[test]
    fn write_config_register_mirrors_non_bar_into_shadow() {
        let mock = MockVfio::for_load();
        let mut common = test_vfio_common(mock, Some(1));

        // PCI_COMMAND is reg index 1. Write the 16 bit command word only.
        let cmd: u16 = 0x0406;
        common.write_config_register(COMMAND_REG, 0, &cmd.to_le_bytes());

        let got = common.configuration.read_reg(COMMAND_REG) & 0xFFFF;
        assert_eq!(got as u16, cmd);
    }

    // Extended capability handling, driven through a mock Vfio wrapper backed
    // by an in memory PCI express config space.

    struct MockConfigSpace {
        space: Mutex<Vec<u8>>,
    }

    impl MockConfigSpace {
        fn new(caps: &[(u32, PciExpressCapabilityId, u32)]) -> Arc<Self> {
            let mut space = vec![0u8; PCIE_CONFIG_SPACE_SIZE as usize];

            for (offset, id, next) in caps {
                let header = (*id as u32) | (next << PCI_EXT_CAP_NEXT_SHIFT);
                let start = *offset as usize;
                space[start..start + 4].copy_from_slice(&header.to_le_bytes());
            }

            Arc::new(MockConfigSpace {
                space: Mutex::new(space),
            })
        }

        fn dword(&self, offset: u32) -> u32 {
            let space = self.space.lock().unwrap();
            let start = offset as usize;
            u32::from_le_bytes(space[start..start + 4].try_into().unwrap())
        }
    }

    impl Vfio for MockConfigSpace {
        fn region_read(&self, _index: u32, offset: u64, data: &mut [u8]) {
            let space = self.space.lock().unwrap();
            let start = offset as usize;
            data.copy_from_slice(&space[start..start + data.len()]);
        }

        fn region_write(&self, _index: u32, offset: u64, data: &[u8]) {
            let mut space = self.space.lock().unwrap();
            let start = offset as usize;
            space[start..start + data.len()].copy_from_slice(data);
        }
    }

    #[test]
    fn msix_capability_without_msix_interrupts_is_read_from_device() {
        // The device exposes an MSI-X capability, but MSI-X is not set up
        // because the device reports no MSI-X interrupts.
        let mock = MockConfigSpace::new(&[]);
        mock.region_write(
            VFIO_PCI_CONFIG_REGION_INDEX,
            PCI_CONFIG_STATUS_OFFSET.into(),
            &PCI_CONFIG_STATUS_CAPABILITIES_LIST.to_le_bytes(),
        );
        // Place the capability at 0x40, the first offset after the
        // 64-byte standard config header.
        mock.region_write(
            VFIO_PCI_CONFIG_REGION_INDEX,
            PCI_CONFIG_CAPABILITY_OFFSET.into(),
            &[0x40],
        );
        // Capability ID, next pointer 0 (end of list), message control 0,
        // then the Table Offset/BIR dword with an arbitrary marker 0xab.
        mock.region_write(
            VFIO_PCI_CONFIG_REGION_INDEX,
            0x40,
            &[PciCapabilityId::MsiX as u8, 0, 0, 0, 0xab, 0, 0, 0],
        );
        let mut common = test_vfio_common(mock, None);

        // Register index of the Table Offset/BIR dword at 0x40 + 4. With
        // MSI-X set up, this read would return the emulated table value
        // instead of the device's.
        assert_eq!(common.read_config_register(0x44 / 4), 0xab);
    }

    fn test_vfio_common_with_pasid(vfio_wrapper: Arc<MockConfigSpace>) -> VfioCommon {
        let mut common = test_vfio_common(vfio_wrapper, None);
        common.extended_caps = vec![Arc::new(PasidCap::new(16, false, false))];
        common
    }

    #[test]
    fn extended_capability_is_appended_to_the_chain() {
        let mock = MockConfigSpace::new(&[
            (
                0x100,
                PciExpressCapabilityId::SingleRootIoVirtualization,
                0x140,
            ),
            (0x140, PciExpressCapabilityId::AdvancedErrorReporting, 0x180),
            (0x180, PciExpressCapabilityId::ResizeableBar, 0),
        ]);
        let mut common = test_vfio_common_with_pasid(mock);

        common.parse_extended_capabilities().unwrap();

        // The chain must start at 0x100, so the hidden head becomes a null
        // capability pointing at the first capability left in the chain.
        let head = common.read_config_register(0x100 / 4);
        assert_eq!(head & 0xffff, PciExpressCapabilityId::NullCapability as u32);
        assert_eq!(head >> PCI_EXT_CAP_NEXT_SHIFT, 0x140);

        // The last capability kept from the device now points at the appended
        // one, which terminates the chain.
        let pasid = PasidCap::new(16, false, false);
        let offset = PCIE_CONFIG_SPACE_SIZE - pasid.size();

        let kept = common.read_config_register(0x140 / 4);
        assert_eq!(
            kept & 0xffff,
            PciExpressCapabilityId::AdvancedErrorReporting as u32
        );
        assert_eq!(kept >> PCI_EXT_CAP_NEXT_SHIFT, offset);

        let appended = common.read_config_register((offset / 4) as usize);
        assert_eq!(
            appended & 0xffff,
            PciExpressCapabilityId::ProcessAddressSpaceId as u32
        );
        assert_eq!(appended >> PCI_EXT_CAP_NEXT_SHIFT, 0);
        assert_eq!(
            common.read_config_register((offset / 4) as usize + 1),
            pasid.dwords()[0]
        );

        // With every capability of the device hidden, the null head is the one
        // pointing at the appended capability.
        let mock = MockConfigSpace::new(&[
            (
                0x100,
                PciExpressCapabilityId::SingleRootIoVirtualization,
                0x140,
            ),
            (0x140, PciExpressCapabilityId::ResizeableBar, 0),
        ]);
        let mut common = test_vfio_common_with_pasid(mock);

        common.parse_extended_capabilities().unwrap();

        let head = common.read_config_register(0x100 / 4);
        assert_eq!(head & 0xffff, PciExpressCapabilityId::NullCapability as u32);
        assert_eq!(head >> PCI_EXT_CAP_NEXT_SHIFT, offset);
    }

    #[test]
    fn extended_capability_without_free_space_is_rejected() {
        // The appended capability would overlap a capability provided by the
        // device, even though that one is hidden from the guest.
        let mock = MockConfigSpace::new(&[
            (0x100, PciExpressCapabilityId::AdvancedErrorReporting, 0xff8),
            (0xff8, PciExpressCapabilityId::SingleRootIoVirtualization, 0),
        ]);
        let mut common = test_vfio_common_with_pasid(mock);
        assert!(matches!(
            common.parse_extended_capabilities(),
            Err(VfioPciError::ExtendedCapNoSpace(_))
        ));

        // No space is left behind the last capability of the device's chain.
        let mock = MockConfigSpace::new(&[
            (0x100, PciExpressCapabilityId::AdvancedErrorReporting, 0xffc),
            (0xffc, PciExpressCapabilityId::AdvancedErrorReporting, 0),
        ]);
        let mut common = test_vfio_common_with_pasid(mock);
        assert!(matches!(
            common.parse_extended_capabilities(),
            Err(VfioPciError::ExtendedCapNoSpace(_))
        ));
    }

    #[test]
    fn only_fully_patched_registers_are_handled_locally() {
        let mock = MockConfigSpace::new(&[]);
        let mut common = test_vfio_common(Arc::clone(&mock), None);

        // A patch covering a few fields leaves the rest of the register to the
        // device, so the write reaches it where the write mask allows it.
        common.patch_reg(0x40 / 4, 0x0000_ffff, 0x1234, 0x0000_ffff);
        common.write_config_register(0x40 / 4, 0, &0xabcd_5678u32.to_le_bytes());
        assert_eq!(mock.dword(0x40), 0xabcd_0000);
        assert_eq!(common.read_config_register(0x40 / 4), 0xabcd_1234);

        // Without the write mask the device is left alone, so a patched
        // field answers reads while the rest stays read only.
        common.patch_reg(0x60 / 4, 0x0000_ffff, 0x1234, 0xffff_ffff);
        common.write_config_register(0x60 / 4, 0, &0xabcd_5678u32.to_le_bytes());
        assert_eq!(mock.dword(0x60), 0);
        assert_eq!(common.read_config_register(0x60 / 4), 0x0000_1234);

        // A patch covering the whole register describes a register the device
        // doesn't have, so the write only updates the writable fields.
        common.patch_reg(0x50 / 4, 0xffff_ffff, 0x0000_0001, 0xffff_ff00);
        common.write_config_register(0x50 / 4, 0, &0x1111_2222u32.to_le_bytes());
        assert_eq!(mock.dword(0x50), 0);
        assert_eq!(common.read_config_register(0x50 / 4), 0x0000_0022);
    }

    #[test]
    fn patches_are_restored_from_a_snapshot() {
        let mock = MockConfigSpace::new(&[]);
        let mut common = test_vfio_common(Arc::clone(&mock), None);
        common.patch_reg(0x40 / 4, 0x0000_ffff, 0x1234, 0xffff_ffff);

        let snapshot = Snapshot::new_from_state(&common.state()).unwrap();
        let state: VfioCommonState = snapshot.to_state().unwrap();

        let mut restored = test_vfio_common(mock, None);
        restored.set_state(&state, None, None, None).unwrap();

        assert_eq!(restored.read_config_register(0x40 / 4), 0x0000_1234);
    }

    struct MockNvidiaDevice {
        config_space: Mutex<Vec<u8>>,
        bar0: Mutex<Vec<u8>>,
    }

    impl MockNvidiaDevice {
        fn new() -> Arc<Self> {
            let mut config_space = vec![0u8; PCIE_CONFIG_SPACE_SIZE as usize];
            // Vendor ID = 0x10de (NVIDIA), Device ID = 0x307e
            config_space[0..4].copy_from_slice(&0x307e_10deu32.to_le_bytes());
            // Physical BAR0 in hardware config space (different from guest virtual BAR0)
            config_space[0x10..0x14].copy_from_slice(&0xdead_0000u32.to_le_bytes());

            let mut bar0 = vec![0u8; 0x10_0000];
            // Put raw physical BAR0 values in the 0x88000 window and neighboring offsets
            bar0[0x80000..0x80004].copy_from_slice(&0x1122_3344u32.to_le_bytes());
            bar0[0x88010..0x88014].copy_from_slice(&0xdead_0000u32.to_le_bytes());
            bar0[0x89000..0x89004].copy_from_slice(&0x5566_7788u32.to_le_bytes());

            Arc::new(Self {
                config_space: Mutex::new(config_space),
                bar0: Mutex::new(bar0),
            })
        }

        fn config_dword(&self, offset: usize) -> u32 {
            let space = self.config_space.lock().unwrap();
            u32::from_le_bytes(space[offset..offset + 4].try_into().unwrap())
        }

        fn bar0_dword(&self, offset: usize) -> u32 {
            let bar0 = self.bar0.lock().unwrap();
            u32::from_le_bytes(bar0[offset..offset + 4].try_into().unwrap())
        }
    }

    impl Vfio for MockNvidiaDevice {
        fn region_read(&self, index: u32, offset: u64, data: &mut [u8]) {
            let start = offset as usize;
            if index == VFIO_PCI_CONFIG_REGION_INDEX {
                let space = self.config_space.lock().unwrap();
                data.copy_from_slice(&space[start..start + data.len()]);
            } else if index == VFIO_PCI_BAR0_REGION_INDEX {
                let bar0 = self.bar0.lock().unwrap();
                data.copy_from_slice(&bar0[start..start + data.len()]);
            }
        }

        fn region_write(&self, index: u32, offset: u64, data: &[u8]) {
            let start = offset as usize;
            if index == VFIO_PCI_CONFIG_REGION_INDEX {
                let mut space = self.config_space.lock().unwrap();
                space[start..start + data.len()].copy_from_slice(data);
            } else if index == VFIO_PCI_BAR0_REGION_INDEX {
                let mut bar0 = self.bar0.lock().unwrap();
                bar0[start..start + data.len()].copy_from_slice(data);
            }
        }
    }

    #[test]
    fn nvidia_bar0_config_mirror_mediates_reads_and_writes() {
        let mock = MockNvidiaDevice::new();
        let mut common = test_vfio_common(Arc::clone(&mock), None);
        common.vendor_id = VENDOR_NVIDIA;

        let bar0_gpa: u64 = 0xc000_0000;
        let bar0_size: u64 = 0x10_0000;
        let bar_cfg = PciBarConfiguration::default()
            .set_index(VFIO_PCI_BAR0_REGION_INDEX as usize)
            .set_address(bar0_gpa)
            .set_size(bar0_size)
            .set_region_type(PciBarRegionType::Memory32BitRegion)
            .set_prefetchable(PciBarPrefetchable::NotPrefetchable);
        common.configuration.add_pci_bar(&bar_cfg).unwrap();
        common.bars.push(VfioBar {
            start: GuestAddress(bar0_gpa),
            length: bar0_size,
            type_: PciBarRegionType::Memory32BitRegion,
            index: VFIO_PCI_BAR0_REGION_INDEX,
            bar_memory_regions: Vec::new(),
        });

        // Add a read-only config patch at offset 0x50
        common.patch_reg(0x50 / 4, 0xffff_ffff, 0xcafe_babe, 0xffff_ffff);

        // 1. Reading BAR0 + 0x88010 (BAR0 config register) returns the virtualized
        // guest BAR0 GPA (0xc000_0000), not the physical BAR0 (0xdead_0000).
        let mut buf = [0u8; 4];
        common.read_bar(bar0_gpa, 0x88010, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), bar0_gpa as u32);

        // 2. Reading BAR0 + 0x88050 returns the patched virtual capability value.
        common.read_bar(bar0_gpa, 0x88050, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), 0xcafe_babe);

        // 3. Writing to BAR0 + 0x88010 (a BAR register) is ignored and never
        // modifies the virtualized BAR0, physical BAR0 register, or physical BAR0 MMIO.
        common.write_bar(bar0_gpa, 0x88010, &0xbeef_0000u32.to_le_bytes());
        assert_eq!(mock.config_dword(0x10), 0xdead_0000);
        assert_eq!(mock.bar0_dword(0x88010), 0xdead_0000);
        common.read_bar(bar0_gpa, 0x88010, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), bar0_gpa as u32);

        // 4. Writing to a read-only patched capability at BAR0 + 0x88050 is blocked.
        common.write_bar(bar0_gpa, 0x88050, &0x1234_5678u32.to_le_bytes());
        assert_eq!(mock.config_dword(0x50), 0);
        common.read_bar(bar0_gpa, 0x88050, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), 0xcafe_babe);

        // 5. Writing to a writable non-BAR config register at BAR0 + 0x88040 is
        // routed through write_config_register() to the VFIO config region.
        common.write_bar(bar0_gpa, 0x88040, &0xabcd_ef01u32.to_le_bytes());
        assert_eq!(mock.config_dword(0x40), 0xabcd_ef01);
        assert_eq!(mock.bar0_dword(0x88040), 0);
        common.read_bar(bar0_gpa, 0x88040, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), 0xabcd_ef01);

        // 6. Neighboring offsets on the same 64 KiB page (0x80000 and 0x89000)
        // continue to fall through to BAR0 region_read / region_write.
        common.read_bar(bar0_gpa, 0x80000, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), 0x1122_3344);
        common.read_bar(bar0_gpa, 0x89000, &mut buf);
        assert_eq!(u32::from_le_bytes(buf), 0x5566_7788);

        common.write_bar(bar0_gpa, 0x80000, &0x99aa_bbccu32.to_le_bytes());
        assert_eq!(mock.bar0_dword(0x80000), 0x99aa_bbcc);
    }

    #[test]
    fn generate_sparse_areas_carves_out_nvidia_bar0_config_mirror() {
        let region_size: u64 = 0x400_0000; // 64 MiB BAR0
        let hole_start = align_page_size_down(NVIDIA_BAR0_CONFIG_MIRROR_OFFSET);
        let hole_end =
            align_page_size_up(NVIDIA_BAR0_CONFIG_MIRROR_OFFSET + NVIDIA_BAR0_CONFIG_MIRROR_SIZE);

        // 1. NVIDIA BAR0 without capabilities still carves out the mirror window.
        let areas = VfioPciDevice::generate_sparse_areas(
            &[],
            VFIO_PCI_BAR0_REGION_INDEX,
            0x1_0000_0000,
            region_size,
            None,
            VENDOR_NVIDIA,
        )
        .unwrap();
        assert_eq!(areas.len(), 2);
        assert_eq!(areas[0].offset, 0);
        assert_eq!(areas[0].size, hole_start);
        assert_eq!(areas[1].offset, hole_end);
        assert_eq!(areas[1].size, region_size - hole_end);

        // 2. Non-NVIDIA BAR0 without capabilities maps the entire region.
        let non_nv = VfioPciDevice::generate_sparse_areas(
            &[],
            VFIO_PCI_BAR0_REGION_INDEX,
            0x1_0000_0000,
            region_size,
            None,
            0x8086,
        )
        .unwrap();
        assert_eq!(non_nv.len(), 1);
        assert_eq!(non_nv[0].offset, 0);
        assert_eq!(non_nv[0].size, region_size);

        // 3. NVIDIA non-BAR0 (e.g. BAR2) without capabilities maps the entire region.
        let nv_bar2 = VfioPciDevice::generate_sparse_areas(
            &[],
            VFIO_PCI_BAR2_REGION_INDEX,
            0x1_0000_0000,
            region_size,
            None,
            VENDOR_NVIDIA,
        )
        .unwrap();
        assert_eq!(nv_bar2.len(), 1);
        assert_eq!(nv_bar2[0].offset, 0);
        assert_eq!(nv_bar2[0].size, region_size);

        // 4. NVIDIA BAR0 with SparseMmap capability still carves out the mirror window.
        let sparse_cap = VfioRegionInfoCap::SparseMmap(vfio_ioctls::VfioRegionInfoCapSparseMmap {
            areas: vec![VfioRegionSparseMmapArea {
                offset: 0,
                size: region_size,
            }],
        });
        let sparse_areas = VfioPciDevice::generate_sparse_areas(
            &[sparse_cap],
            VFIO_PCI_BAR0_REGION_INDEX,
            0x1_0000_0000,
            region_size,
            None,
            VENDOR_NVIDIA,
        )
        .unwrap();
        assert_eq!(sparse_areas.len(), 2);
        assert_eq!(sparse_areas[0].offset, 0);
        assert_eq!(sparse_areas[0].size, hole_start);
        assert_eq!(sparse_areas[1].offset, hole_end);
        assert_eq!(sparse_areas[1].size, region_size - hole_end);
    }
}
