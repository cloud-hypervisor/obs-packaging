// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: Apache-2.0
//

use std::collections::{BTreeSet, HashMap, HashSet};
#[cfg(feature = "ivshmem")]
use std::fs;
use std::mem::discriminant;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd, RawFd};
use std::path::PathBuf;
use std::str::FromStr;
use std::{io, result};

use arch::CpuProfileConfig;
#[cfg(target_arch = "x86_64")]
use arch::CpuidOverride;
use block::ImageType;
use log::warn;
#[cfg(target_arch = "x86_64")]
use option_parser::split_commas;
use option_parser::{
    ByteSized, IntegerList, OptionParser, OptionParserError, StringList, Toggle, Tuple, TupleList,
};
use pci::NUM_DEVICE_IDS;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use virtio_bindings::virtio_blk::VIRTIO_BLK_ID_BYTES;
use virtio_bindings::virtio_ids::*;
use virtio_devices::block::MINIMUM_BLOCK_QUEUE_SIZE;
use virtio_devices::vhost_user::VIRTIO_FS_TAG_LEN;
use virtio_devices::{RateLimiterConfig, TokenBucketConfig, net, vhost_user};

use crate::external_fds::{ExternalFds, Target, UpdateFdsError};
use crate::landlock::LandlockAccess;
use crate::vm_config::*;

const MAX_NUM_PCI_SEGMENTS: u16 = 96;
const MAX_IOMMU_ADDRESS_WIDTH_BITS: u8 = 64;
const MIN_PHYS_BITS: u8 = 32;
const MAX_PHYS_BITS: u8 = 64;

// Maximum queue size is largest power of 2 that fits into a u16
const VIRTIO_MAX_QUEUE_SIZE: u16 = 32768;

#[cfg(all(feature = "kvm", target_arch = "x86_64"))]
const MAX_SUPPORTED_CPUS: u32 = 8192;
#[cfg(all(feature = "kvm", target_arch = "aarch64"))]
const MAX_SUPPORTED_CPUS: u32 = 4096;
#[cfg(not(all(feature = "kvm", any(target_arch = "x86_64", target_arch = "aarch64"))))]
const MAX_SUPPORTED_CPUS: u32 = 255;

/// Errors associated with VM configuration parameters.
#[derive(Debug, Error)]
pub enum Error {
    // TODO(fd): Remove after the deprecation period for the legacy FD fields.
    #[error("Cannot combine external_fds with legacy FD fields")]
    MixedFdFormats,
    #[error("Inherited file descriptor {0} is specified more than once")]
    DuplicateInheritedFd(RawFd),
    #[error("Invalid inherited file descriptor")]
    InheritedFd(#[source] io::Error),
    /// Filesystem tag is missing
    #[error("Error parsing --fs: tag missing")]
    ParseFsTagMissing,
    /// Filesystem tag is too long
    #[error("Error parsing --fs: max tag length is {VIRTIO_FS_TAG_LEN}")]
    ParseFsTagTooLong,
    /// Filesystem socket is missing
    #[error("Error parsing --fs: socket missing")]
    ParseFsSockMissing,
    /// Generic vhost-user device type is invalid
    #[error(
        "Error parsing --generic-vhost-user: device_type {0:?} invalid (leading zeros or unknown string)"
    )]
    ParseGenericVhostUserVirtioIdInvalid(String),
    /// Generic vhost-user device type is unsupported
    #[error(
        "Error parsing --generic-vhost-user: device with device_type {0:?} cannot be implemented via vhost-user"
    )]
    ParseGenericVhostUserVirtioIdUnsupported(String),
    /// Generic vhost-user socket is missing
    #[error("Error parsing --generic-vhost-user: socket missing")]
    ParseGenericVhostUserSockMissing,
    /// Generic vhost-user device type is missing
    #[error("Error parsing --generic-vhost-user: device_type missing")]
    ParseGenericVhostUserVirtioIdMissing,
    /// Generic vhost-user queue size missing
    #[error("Error parsing --generic-vhost-user: queue size missing")]
    ParseGenericVhostUserQueueSizeMissing,
    /// Missing persistent memory file parameter.
    #[error("Error parsing --pmem: file missing")]
    ParsePmemFileMissing,
    /// Missing vsock socket path parameter.
    #[error("Error parsing --vsock: socket missing")]
    ParseVsockSockMissing,
    /// Missing vsock cid parameter.
    #[error("Error parsing --vsock: cid missing")]
    ParseVsockCidMissing,
    /// Missing restore source_url parameter.
    #[error("Error parsing --restore: source_url missing")]
    ParseRestoreSourceUrlMissing,
    /// Error parsing CPU options
    #[error("Error parsing --cpus")]
    ParseCpus(#[source] OptionParserError),
    #[error("Error parsing --cpus profile")]
    ParseCpuProfile(#[source] arch::ParseCpuProfileError),
    /// Invalid CPU features
    #[error("Invalid feature in --cpus features list: {0}")]
    InvalidCpuFeatures(String),
    /// Error parsing memory options
    #[error("Error parsing --memory")]
    ParseMemory(#[source] OptionParserError),
    /// Error parsing memory zone options
    #[error("Error parsing --memory-zone")]
    ParseMemoryZone(#[source] OptionParserError),
    /// Missing 'id' from memory zone
    #[error("Error parsing --memory-zone: id missing")]
    ParseMemoryZoneIdMissing,
    /// Error parsing rate-limiter group options
    #[error("Error parsing --rate-limit-group")]
    ParseRateLimiterGroup(#[source] OptionParserError),
    /// Error parsing disk options
    #[error("Error parsing --disk")]
    ParseDisk(#[source] OptionParserError),
    /// Error parsing network options
    #[error("Error parsing --net")]
    ParseNetwork(#[source] OptionParserError),
    /// Error parsing RNG options
    #[error("Error parsing --rng")]
    ParseRng(#[source] OptionParserError),
    /// Error parsing RTC options
    #[error("Error parsing --rtc")]
    ParseRtc(#[source] OptionParserError),
    /// Error parsing balloon options
    #[error("Error parsing --balloon")]
    ParseBalloon(#[source] OptionParserError),
    /// Error parsing filesystem parameters
    #[error("Error parsing --fs")]
    ParseFileSystem(#[source] OptionParserError),
    /// Error parsing persistent memory parameters
    #[error("Error parsing --pmem")]
    ParsePersistentMemory(#[source] OptionParserError),
    /// Error parsing generic vhost-user parameters
    #[error("Error parsing --generic-vhost-user")]
    ParseGenericVhostUser(#[source] OptionParserError),
    /// Failed parsing console parameters
    #[error("Error parsing --console")]
    ParseConsole(#[source] OptionParserError),
    /// Failed parsing serial parameters
    #[error("Error parsing --serial")]
    ParseSerial(#[source] OptionParserError),
    #[error("Cannot resolve TCP console address {address:?}")]
    ResolveConsoleTcpAddress {
        address: String,
        #[source]
        source: io::Error,
    },
    /// No mode given for console
    #[error("Error parsing --console: invalid console mode given")]
    ParseConsoleInvalidModeGiven,
    /// Failed parsing device parameters
    #[error("Error parsing --device")]
    ParseDevice(#[source] OptionParserError),
    /// Failed parsing vsock parameters
    #[error("Error parsing --vsock")]
    ParseVsock(#[source] OptionParserError),
    /// Failed parsing restore parameters
    #[error("Error parsing --restore")]
    ParseRestore(#[source] OptionParserError),
    /// Failed parsing NUMA parameters
    #[error("Error parsing --numa")]
    ParseNuma(#[source] OptionParserError),
    /// Failed validating configuration
    #[error("Error validating configuration")]
    Validation(#[source] ValidationError),
    /// Failed parsing userspace device
    #[error("Error parsing --user-device")]
    ParseUserDevice(#[source] OptionParserError),
    /// Missing socket for userspace device
    #[error("Error parsing --user-device: socket missing")]
    ParseUserDeviceSocketMissing,
    /// Error parsing pci segment options
    #[error("Error parsing --pci-segment")]
    ParsePciSegment(#[source] OptionParserError),
    /// Failed parsing platform parameters
    #[error("Error parsing --platform")]
    ParsePlatform(#[source] OptionParserError),
    /// Failed parsing vDPA device
    #[error("Error parsing --vdpa")]
    ParseVdpa(#[source] OptionParserError),
    /// Missing path for vDPA device
    #[error("Error parsing --vdpa: path missing")]
    ParseVdpaPathMissing,
    /// Failed parsing TPM device
    #[error("Error parsing --tpm")]
    ParseTpm(#[source] OptionParserError),
    #[cfg(feature = "ivshmem")]
    /// Failed parsing ivsmem device
    #[error("Error parsing --ivshmem")]
    ParseIvshmem(#[source] OptionParserError),
    /// Missing path for TPM device
    #[error("Error parsing --tpm: path missing")]
    ParseTpmPathMissing,
    #[cfg(feature = "ivshmem")]
    /// Missing path for ivsmem device
    #[error("Error parsing --ivshmem: path missing")]
    ParseIvshmemPathMissing,
    /// Error parsing Landlock rules
    #[error("Error parsing --landlock-rules")]
    ParseLandlockRules(#[source] OptionParserError),
    /// Missing fields in Landlock rules
    #[error("Error parsing --landlock-rules: path/access field missing")]
    ParseLandlockMissingFields,
    #[cfg(feature = "fw_cfg")]
    /// Failed Parsing FwCfgItem config
    #[error("Error parsing --fw-cfg-config items")]
    ParseFwCfgItem(#[source] OptionParserError),
    #[error("Error parsing common PCI device config")]
    ParsePciDeviceCommonConfig(#[source] OptionParserError),
    #[cfg(target_arch = "x86_64")]
    #[error("Error parsing CPUID overrides")]
    InvalidCpuidOverride(#[source] CpuidOverrideParseError),
}

#[derive(Debug, PartialEq, Eq, Error)]
pub enum ValidationError {
    /// Missing file value for console
    #[error("Path missing when using file console mode")]
    ConsoleFileMissing,
    /// Missing socket path for console
    #[error("Path missing when using socket console mode")]
    ConsoleSocketPathMissing,
    /// Missing address for TCP console mode
    #[error("Address missing when using TCP console mode")]
    ConsoleTcpAddressMissing,
    #[error("Server is only valid when using TCP console mode")]
    ConsoleTcpServerUnexpected,
    #[error("TCP console client mode is not supported")]
    ConsoleTcpClientUnsupported,
    #[error("TCP console port must not be zero")]
    ConsoleTcpPortZero,
    /// More than one new output was given for the same console
    #[error("More than one new output given for console {0}")]
    ConsoleOutputUpdateAmbiguous(String),
    /// A new console output must keep the mode of the current one
    #[error("Cannot change console output {0:?} to {1:?} with a different mode")]
    ConsoleOutputUpdateModeMismatch(ConsoleOutput, ConsoleOutput),
    /// Boot has no vCPUs
    #[error("Number of boot vCPUs must be greater than 0")]
    CpusBootZero,
    /// Max is less than boot
    #[error("Max CPUs ({0}) lower than boot CPUs ({1})")]
    CpusMaxLowerThanBoot(u32 /* max vCPUs */, u32 /* boot vCPUs */),
    /// Too many CPUs.
    #[error("Too many CPUs: specified {0} but {MAX_SUPPORTED_CPUS} is the limit")]
    TooManyCpus(u32 /* specified CPUs */),
    /// Maximum physical address bits outside the supported range
    #[error(
        "Maximum physical address bits must be between {MIN_PHYS_BITS} and {MAX_PHYS_BITS}: {0}"
    )]
    InvalidMaxPhysBits(u8 /* specified bits */),
    #[cfg(target_arch = "aarch64")]
    /// The GICv3 layout does not fit this many CPUs.
    #[error("Too many CPUs for the GICv3 layout: specified {0} but {1} is the limit")]
    TooManyCpusForGic(u32 /* specified CPUs */, u64 /* limit */),
    /// Requested CPU affinity matches or exceeds the size the libc accepts.
    #[error("Requested CPU affinity {0} must be below {1}")]
    CpuAffinityExceedsMax(
        usize, /* specified affinity */
        usize, /* maximum affinity */
    ),
    /// kvm_hint_realtime conflicts with kvm_hyperv
    #[error("`kvm_hint_realtime=on` cannot be combined with `kvm_hyperv=on`")]
    KvmHintRealtimeWithKvmHyperv,
    /// Both socket and path specified
    #[error("Disk path and vhost socket both provided")]
    DiskSocketAndPath,
    /// No image type specified for virtio-block
    #[error("Image type required for disk")]
    ImageTypeRequired,
    /// Using vhost user requires shared memory
    #[error("Using vhost-user requires using shared memory or huge pages")]
    VhostUserRequiresSharedMemory,
    /// No socket provided for vhost_use
    #[error("No socket provided when using vhost-user")]
    VhostUserMissingSocket,
    /// CPU topology count doesn't match max
    #[error("Product of CPU topology parts does not match maximum vCPU")]
    CpuTopologyCount,
    /// CPU topology uses too many threads per core
    #[error("CPU topology supports at most 2 threads per core")]
    CpuTopologyThreadsPerCore,
    /// One part of the CPU topology was zero
    #[error("No part of the CPU topology can be zero")]
    CpuTopologyZeroPart,
    #[cfg(target_arch = "aarch64")]
    /// Dies per package must be 1
    #[error("Dies per package must be 1")]
    CpuTopologyDiesPerPackage,
    /// Virtio needs a min of 2 queues
    #[error("Number of queues ({0}) to virtio_net should be higher than 2")]
    VnetQueueLowerThan2(u16),
    /// Virtio-net queues come in RX/TX pairs
    #[error("Number of queues ({0}) to virtio_net must be even")]
    VnetQueueOdd(u16),
    /// The input queue number for virtio_net must match the number of input fds
    #[error("Number of queues ({0}) to virtio_net does not match the number of FDs ({1})")]
    VnetQueueFdMismatch(u16 /* num of queues */, usize /* FD num */),
    /// Using reserved fd
    #[error("Reserved fd number (<= 2): {0}")]
    VnetReservedFd(RawFd),
    /// Hardware checksum offload is disabled.
    #[error("\"offload_tso\" and \"offload_ufo\" depend on \"offload_csum\"")]
    NoHardwareChecksumOffload,
    /// Hugepages not turned on
    #[error("Huge page size specified but huge pages not enabled")]
    HugePageSizeWithoutHugePages,
    /// Huge page size is not power of 2
    #[error("Huge page size is not power of 2: {0}")]
    InvalidHugePageSize(u64),
    /// Invalid number of queues
    #[error("Invalid number of queues: {0}")]
    InvalidNumQueues(usize),
    /// Insufficient vCPUs for queues
    #[error("Queue count ({0}) must not exceed boot vCPUs ({1})")]
    TooManyQueues(u16 /* queues */, usize /* vCPUs */),
    /// Queue size is not a power of 2 within the spec-permitted range
    #[error("Queue size must be a power of 2 no greater than {VIRTIO_MAX_QUEUE_SIZE}: {0}")]
    InvalidQueueSize(u16),
    /// Block queue size too small to advertise a usable seg_max
    #[error("Block queue size must be greater than {MINIMUM_BLOCK_QUEUE_SIZE}: {0}")]
    BlockQueueSizeTooSmall(u16),
    /// Disk queue affinity refers to a queue the disk does not have
    #[error("Queue affinity refers to queue {0}, but the disk has {1} queues")]
    InvalidQueueAffinity(u16 /* queue index */, u16 /* queues */),
    /// Disk guest_block_size is not a power of 2 within the supported range
    #[error("Disk guest_block_size must be a power of 2 between 512 and 65536: {0}")]
    InvalidGuestBlockSize(u32),
    /// Need shared memory for vfio-user
    #[error("Using user devices requires using shared memory or huge pages")]
    UserDevicesRequireSharedMemory,
    /// VSOCK Context Identifier has a special meaning, unsuitable for a VM.
    #[error("{0} is a special VSOCK CID")]
    VsockSpecialCid(u32),
    /// Memory zone is reused across NUMA nodes
    #[error("Memory zone: {0} belongs to multiple NUMA nodes: {1} and {2}")]
    MemoryZoneReused(String, u32, u32),
    /// Invalid number of PCI segments
    #[error("Number of PCI segments ({0}) not in range of 1 to {MAX_NUM_PCI_SEGMENTS}")]
    InvalidNumPciSegments(u16),
    /// Invalid PCI segment id
    #[error("Invalid PCI segment id: {0}")]
    InvalidPciSegment(u16),
    /// Invalid PCI segment aperture weight
    #[error("Invalid PCI segment aperture weight: {0}")]
    InvalidPciSegmentApertureWeight(u32),
    /// Invalid VFIO excluded-mmap BAR index
    #[error("Invalid VFIO excluded-mmap BAR index: {0}")]
    InvalidDeviceExcludeMmapBar(u64),
    /// Invalid IOMMU address width in bits
    #[error(
        "IOMMU address width in bits ({0}) should be less than or equal to {MAX_IOMMU_ADDRESS_WIDTH_BITS}"
    )]
    InvalidIommuAddressWidthBits(u8),
    /// Balloon too big
    #[error("Balloon size ({0}) greater than RAM ({1})")]
    BalloonLargerThanRam(u64, u64),
    /// On a IOMMU segment but not behind IOMMU
    #[error("Device is on an IOMMU PCI segment ({0}) but not placed behind IOMMU")]
    OnIommuSegment(u16),
    /// GPUDirect clique requires P2P DMA
    #[error("Device with x_nv_gpudirect_clique requires vfio_p2p_dma=on")]
    GpuDirectCliqueRequiresP2pDma,
    // Identifier is not unique
    #[error("Identifier {0} is not unique")]
    IdentifierNotUnique(String),
    /// Invalid identifier
    #[error("Identifier {0} is not valid")]
    InvalidIdentifier(String),
    /// Placing the device behind a virtual IOMMU is not supported
    #[error("Device does not support being placed behind IOMMU")]
    IommuNotSupported,
    /// Duplicated device path (device added twice)
    #[error("Duplicated device path: {0}")]
    DuplicateDevicePath(String),
    /// A DeviceConfig specified neither `path` nor `fd`.
    #[error("VFIO device config must specify `path=` or `fd=`")]
    VfioDeviceNeitherPathNorFd,
    /// A DeviceConfig specified both `path` and `fd`.
    #[error("VFIO device config must specify at most one of `path=` or `fd=`")]
    VfioDeviceBothPathAndFd,
    /// FD-based VFIO requires an externally-supplied iommufd FD so the
    /// cdev's bind state can survive across an in-process VM reboot.
    #[error("VFIO device `fd=` requires platform `iommufd_fd=<fd>`")]
    VfioFdRequiresIommufdFd,
    /// `iommufd_fd` was provided without also enabling the iommufd backend.
    #[error("Platform `iommufd_fd=<fd>` requires `iommufd=on`")]
    IommufdFdRequiresIommufd,
    /// The SMMUv3 was requested on a build that cannot provide it.
    #[error("`iommu=smmuv3` is only supported on aarch64 with KVM")]
    IommuSmmuv3NotSupported,
    /// The SMMUv3 was requested without the iommufd backend.
    #[error("`iommu=smmuv3` requires platform `iommufd=on`")]
    IommuSmmuv3RequiresIommufd,
    /// The SMMUv3 was requested for a device that cannot sit behind it.
    #[error("`iommu=smmuv3` is only supported for passthrough devices")]
    IommuSmmuv3NotPassthrough,
    /// Devices asked for different types of virtual IOMMU.
    #[error("Devices cannot be attached to different types of virtual IOMMU")]
    MixedIommuTypes,
    /// Provided MTU is lower than what the VIRTIO specification expects
    #[error("Provided MTU {0} is lower than 1280 (expected by VIRTIO specification)")]
    InvalidMtu(u16),
    /// PCI segment is reused across NUMA nodes
    #[error("PCI segment: {0} belongs to multiple NUMA nodes {1} and {2}")]
    PciSegmentReused(u16, u32, u32),
    /// Default PCI segment is assigned to NUMA node other than 0.
    #[error("Default PCI segment assigned to non-zero NUMA node {0}")]
    DefaultPciSegmentInvalidNode(u32),
    /// Invalid rate-limiter group
    #[error("Invalid rate-limiter group")]
    InvalidRateLimiterGroup,
    /// A burst duration requires a burst rate
    #[error("Rate limiter burst duration {0} seconds requires a burst rate")]
    RateLimiterBurstSecondsWithoutRate(u64),
    /// Burst rate and duration must be positive
    #[error("Rate limiter burst rate {0} and duration {1} seconds must be positive")]
    RateLimiterBurstZero(u64, u64),
    /// A bounded burst cannot be combined with a one-time burst
    #[error("Rate limiter burst rate {0} cannot be combined with one-time burst {1}")]
    RateLimiterBurstWithOneTimeBurst(u64, u64),
    /// A bounded burst requires an enabled sustained bucket
    #[error("Rate limiter burst rate {0} requires nonzero size {1} and refill time {2} ms")]
    RateLimiterBurstDisabledBucket(u64, u64, u64),
    /// Burst rate cannot be below the sustained rate
    #[error("Rate limiter burst rate {0} is below the sustained rate of {1} tokens per {2} ms")]
    RateLimiterBurstBelowSustained(u64, u64, u64),
    /// Burst capacity must fit in a u64
    #[error("Rate limiter burst rate {0} times duration {1} seconds overflows token capacity")]
    RateLimiterBurstCapacityOverflow(u64, u64),
    /// A recharge duration requires a bounded burst
    #[error("Rate limiter burst recharge time {0} seconds requires a burst rate")]
    RateLimiterBurstRechargeWithoutRate(u64),
    /// Recharge must take longer than refilling the base meter
    #[error(
        "Rate limiter burst recharge time {0} seconds must be at least {1} seconds to exceed the base refill time"
    )]
    RateLimiterBurstRechargeTooShort(u64, u128),
    /// Recharge only applies to burst credit above the base capacity
    #[error(
        "Rate limiter burst recharge time {0} seconds has no effect: burst capacity {1} does not exceed the base capacity {2}"
    )]
    RateLimiterBurstRechargeWithoutCredit(u64, u64, u128),
    /// Rate limiting is not supported with vhost-user
    #[error("Rate limiting is not supported with vhost-user")]
    VhostUserRateLimiterNotSupported,
    /// The vhost-user backend provides the virtio config space
    #[error("guest_block_size is not supported with vhost-user")]
    VhostUserGuestBlockSizeNotSupported,
    /// The specified I/O port was invalid. It should be provided in hex, such as `0xe9`.
    #[cfg(target_arch = "x86_64")]
    #[error("The IO port was not properly provided in hex or a `0x` prefix is missing: {0}")]
    InvalidIoPortHex(String),
    #[cfg(feature = "sev_snp")]
    #[error("Invalid host data format")]
    InvalidHostData,
    #[cfg(feature = "sev_snp")]
    #[error("SEV-SNP requires an IGVM payload (--igvm <path>)")]
    SevSnpRequiresIgvm,
    #[cfg(all(feature = "kvm", feature = "sev_snp"))]
    #[error("SEV-SNP on KVM requires ACPI tables supplied through fw_cfg")]
    SevSnpRequiresFwCfgAcpi,
    /// Memory hotplug is not supported with SEV-SNP
    #[cfg(feature = "sev_snp")]
    #[error("Memory hotplug is not supported with SEV-SNP")]
    SevSnpNoMemoryHotplug,
    /// CPU hotplug is not supported with SEV-SNP on MSHV
    #[cfg(feature = "sev_snp")]
    #[error("CPU hotplug is not supported with SEV-SNP on MSHV")]
    SevSnpNoCpuHotplug,
    /// Huge pages are not supported with SEV-SNP
    #[cfg(feature = "sev_snp")]
    #[error("Huge pages are not supported with SEV-SNP")]
    SevSnpNoHugePages,
    /// A virtual IOMMU is not supported with SEV-SNP
    #[cfg(feature = "sev_snp")]
    #[error("Virtual IOMMU is not supported with SEV-SNP")]
    SevSnpNoViommu,
    /// vDPA devices are not supported with SEV-SNP
    #[cfg(feature = "sev_snp")]
    #[error("vDPA devices are not supported with SEV-SNP")]
    SevSnpNoVdpa,
    /// Passthrough devices require iommufd with SEV-SNP
    #[cfg(feature = "sev_snp")]
    #[error("Passthrough devices require --platform iommufd=on with SEV-SNP")]
    SevSnpRequiresIommufd,
    /// Prefault requires the eager-copy restore mode
    #[error("'prefault' requires 'memory_restore_mode=copy'")]
    InvalidRestorePrefaultWithOnDemand,
    /// Postcopy and on-demand restore are not supported with some devices
    #[error("Postcopy and on-demand restore are not supported with {0} devices")]
    PostcopyIncompatibleDevice(String),
    /// Path provided in landlock-rules doesn't exist
    #[error("Path {0:?} provided in landlock-rules does not exist")]
    LandlockPathDoesNotExist(PathBuf),
    /// Access provided in landlock-rules in invalid
    #[error("Invalid landlock access: {0}")]
    InvalidLandlockAccess(String),
    /// Invalid block device serial length
    #[error("Block device serial length ({0}) exceeds maximum allowed length ({1})")]
    InvalidSerialLength(usize, usize),
    #[cfg(feature = "ivshmem")]
    /// Invalid Ivshmem input size
    #[error("Invalid ivshmem input size: {0}")]
    InvalidIvshmemInputSize(u64),
    #[cfg(feature = "ivshmem")]
    /// Invalid Ivshmem backend file size
    #[error("Invalid ivshmem backend file size: {0}")]
    InvalidIvshmemSize(u64),
    #[cfg(feature = "ivshmem")]
    /// Invalid Ivshmem backend file path
    #[error("Invalid ivshmem backend file path")]
    InvalidIvshmemPath,
    #[error("Payload configuration is not bootable")]
    PayloadError(#[from] PayloadConfigError),
    #[error("Mask provided without an IP")]
    MaskProvidedWithoutIp,
    #[error("IP provided without a mask")]
    IpProvidedWithoutMask,
    /// Invalid NUMA Configuration
    #[error("Invalid NUMA configuration: {0}")]
    InvalidNumaConfig(String),
    /// The supplied PCI ID was greater then the max. supported number
    /// of devices per Bus
    #[error("Given PCI device ID ({0}) is out of the supported range of 0..{NUM_DEVICE_IDS}")]
    InvalidPciDeviceId(u8),
    /// The supplied PCI ID is reserved
    #[error("Given PCI device ID ({0}) is reserved")]
    ReservedPciDeviceId(u8),
    /// Invalid to set both 'mergeable' and 'shared' for memory
    #[error("Invalid to set both 'mergeable' and 'shared' for memory")]
    InvalidSharedMemoryWithMergeable,
    /// More than one update was specified for one or more MemoryZone
    #[error("Multiple updates for the same zone defined")]
    MultipleMemoryZoneUpdates,
    /// More than one update was specified that contains an empty memory zone ID
    #[error("At least one memory zone update with an empty ID was defined")]
    MemoryZoneUpdatesEmptyId,
    /// A memory size of 0 requires memory zones
    #[error("Memory zones are required when the memory size is 0")]
    MemoryZonesMissing,
    #[error("Invalid file descriptors")]
    Fd(#[from] UpdateFdsError),
}

type ValidationResult<T> = result::Result<T, ValidationError>;

#[cfg(target_arch = "aarch64")]
fn validate_gic_layout(max_vcpus: u32) -> ValidationResult<()> {
    if u64::from(max_vcpus) > arch::layout::GIC_V3_LAYOUT_MAX_VCPUS {
        return Err(ValidationError::TooManyCpusForGic(
            max_vcpus,
            arch::layout::GIC_V3_LAYOUT_MAX_VCPUS,
        ));
    }
    Ok(())
}

pub fn add_to_config<T>(items: &mut Option<Vec<T>>, item: T) {
    if let Some(items) = items {
        items.push(item);
    } else {
        *items = Some(vec![item]);
    }
}

/// Check that the PCI device supplied is neither out of range nor does
/// it use any reserved device ID.
fn validate_pci_device_id(device_id: u8, segment_id: u16) -> ValidationResult<()> {
    if device_id >= pci::NUM_DEVICE_IDS {
        // Check the given ID is not out of range
        return Err(ValidationError::InvalidPciDeviceId(device_id));
    } else if device_id == pci::PCI_ROOT_DEVICE_ID && segment_id == 0 {
        // Check the ID isn't any reserved one. Currently, only the device ID
        // for the root device is reserved.
        return Err(ValidationError::ReservedPciDeviceId(device_id));
    }

    Ok(())
}

/// Reject a virtio queue size that is not a power of 2 as required by the
/// spec. The `u16` type already handles the maximum queue size.
fn validate_queue_size(queue_size: u16) -> ValidationResult<()> {
    if !queue_size.is_power_of_two() {
        return Err(ValidationError::InvalidQueueSize(queue_size));
    }

    Ok(())
}

pub type Result<T> = result::Result<T, Error>;

pub struct VmParams<'a> {
    pub cpus: &'a str,
    pub memory: &'a str,
    pub memory_zones: Option<Vec<&'a str>>,
    pub firmware: Option<&'a str>,
    pub kernel: Option<&'a str>,
    pub initramfs: Option<&'a str>,
    pub cmdline: Option<&'a str>,
    pub rate_limit_groups: Option<Vec<&'a str>>,
    pub disks: Option<Vec<&'a str>>,
    pub net: Option<Vec<&'a str>>,
    pub rng: &'a str,
    pub balloon: Option<&'a str>,
    pub fs: Option<Vec<&'a str>>,
    pub generic_vhost_user: Option<Vec<&'a str>>,
    pub pmem: Option<Vec<&'a str>>,
    pub serial: &'a str,
    pub console: &'a str,
    #[cfg(target_arch = "x86_64")]
    pub debug_console: &'a str,
    pub devices: Option<Vec<&'a str>>,
    pub user_devices: Option<Vec<&'a str>>,
    pub vdpa: Option<Vec<&'a str>>,
    pub vsock: Option<&'a str>,
    #[cfg(feature = "pvmemcontrol")]
    pub pvmemcontrol: bool,
    pub pvpanic: bool,
    pub numa: Option<Vec<&'a str>>,
    pub watchdog: bool,
    pub rtc: Option<&'a str>,
    #[cfg(feature = "guest_debug")]
    pub gdb: bool,
    pub pci_segments: Option<Vec<&'a str>>,
    pub platform: Option<&'a str>,
    pub tpm: Option<&'a str>,
    #[cfg(feature = "igvm")]
    pub igvm: Option<&'a str>,
    #[cfg(feature = "sev_snp")]
    pub host_data: Option<&'a str>,
    pub landlock_enable: bool,
    pub landlock_rules: Option<Vec<&'a str>>,
    #[cfg(feature = "fw_cfg")]
    pub fw_cfg_config: Option<&'a str>,
    #[cfg(feature = "ivshmem")]
    pub ivshmem: Option<&'a str>,
}

#[derive(Debug)]
pub enum ParseHotplugMethodError {
    InvalidValue(String),
}

impl FromStr for HotplugMethod {
    type Err = ParseHotplugMethodError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "acpi" => Ok(HotplugMethod::Acpi),
            "virtio-mem" => Ok(HotplugMethod::VirtioMem),
            _ => Err(ParseHotplugMethodError::InvalidValue(s.to_owned())),
        }
    }
}

pub enum ParseCoreSchedulingError {
    InvalidValue(String),
}

impl FromStr for CoreScheduling {
    type Err = ParseCoreSchedulingError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "vm" => Ok(CoreScheduling::Vm),
            "vcpu" => Ok(CoreScheduling::Vcpu),
            "off" => Ok(CoreScheduling::Off),
            _ => Err(ParseCoreSchedulingError::InvalidValue(s.to_owned())),
        }
    }
}

pub enum CpuTopologyParseError {
    InvalidValue(String),
}

impl FromStr for CpuTopology {
    type Err = CpuTopologyParseError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        let parts: Vec<&str> = s.split(':').collect();

        if parts.len() != 4 {
            return Err(Self::Err::InvalidValue(s.to_owned()));
        }

        let t = CpuTopology {
            threads_per_core: parts[0]
                .parse()
                .map_err(|_| Self::Err::InvalidValue(s.to_owned()))?,
            cores_per_die: parts[1]
                .parse()
                .map_err(|_| Self::Err::InvalidValue(s.to_owned()))?,
            dies_per_package: parts[2]
                .parse()
                .map_err(|_| Self::Err::InvalidValue(s.to_owned()))?,
            packages: parts[3]
                .parse()
                .map_err(|_| Self::Err::InvalidValue(s.to_owned()))?,
        };

        Ok(t)
    }
}

#[cfg(target_arch = "x86_64")]
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct CpuidOverrides(Vec<CpuidOverride>);

#[cfg(target_arch = "x86_64")]
#[derive(Debug, Error, PartialEq, Eq)]
pub enum CpuidOverrideParseError {
    #[error("Expected a bracketed list '[...]', got {0:?}")]
    MissingBrackets(String),
    #[error("Expected a bracketed entry '[leaf,subleaf,eax,ebx,ecx,edx]', got {0:?}")]
    MalformedEntry(String),
    #[error(
        "Expected 6 comma-separated fields (leaf,subleaf,eax,ebx,ecx,edx), got {count} in {entry:?}"
    )]
    FieldCount { count: usize, entry: String },
    #[error("Invalid 32-bit value {0:?} (use 0x-prefixed hex)")]
    InvalidValue(String),
}

#[cfg(target_arch = "x86_64")]
impl FromStr for CpuidOverrides {
    type Err = CpuidOverrideParseError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        let body = s
            .trim()
            .strip_prefix('[')
            .and_then(|inner| inner.strip_suffix(']'))
            .ok_or_else(|| CpuidOverrideParseError::MissingBrackets(s.to_owned()))?
            .trim();

        if body.is_empty() {
            return Ok(CpuidOverrides(Vec::new()));
        }

        let overrides = split_commas(body)
            .map_err(|_| CpuidOverrideParseError::MalformedEntry(body.to_owned()))?
            .iter()
            .map(|entry| parse_cpuid_override_entry(entry.trim()))
            .collect::<result::Result<Vec<_>, _>>()?;

        Ok(CpuidOverrides(overrides))
    }
}

#[cfg(target_arch = "x86_64")]
fn parse_cpuid_override_entry(
    entry: &str,
) -> result::Result<CpuidOverride, CpuidOverrideParseError> {
    let values = entry
        .strip_prefix('[')
        .and_then(|inner| inner.strip_suffix(']'))
        .ok_or_else(|| CpuidOverrideParseError::MalformedEntry(entry.to_owned()))?
        .split(',')
        .map(|field| {
            let field = field.trim();
            field
                .strip_prefix("0x")
                .and_then(|hex| u32::from_str_radix(hex, 16).ok())
                .ok_or_else(|| CpuidOverrideParseError::InvalidValue(field.to_owned()))
        })
        .collect::<result::Result<Vec<_>, _>>()?;

    let [leaf, subleaf, eax, ebx, ecx, edx] = values[..] else {
        return Err(CpuidOverrideParseError::FieldCount {
            count: values.len(),
            entry: entry.to_owned(),
        });
    };

    Ok(CpuidOverride {
        leaf,
        subleaf,
        eax,
        ebx,
        ecx,
        edx,
    })
}

impl CpusConfig {
    pub const SYNTAX: &'static str = "CPU parameters \
        \"boot=<boot_vcpus>,max=<max_vcpus>,\
        topology=<threads_per_core>:<cores_per_die>:<dies_per_package>:<packages>,\
        kvm_hyperv=on|off,kvm_hint_realtime=on|off,\
        max_phys_bits=<maximum_number_of_physical_bits>,\
        affinity=<list_of_vcpus_with_their_associated_cpuset>,\
        features=<list_of_features_to_enable>,\
        nested=on|off,core_scheduling=vm|vcpu|off,\
        profile=host|path:<file>,\
        x-cpuid-overrides=[[<leaf>,<subleaf>,<eax>,<ebx>,<ecx>,<edx>],...]\"";

    pub fn parse(cpus: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("boot")
            .add("max")
            .add("topology")
            .add("kvm_hyperv")
            .add("max_phys_bits")
            .add("affinity")
            .add("features")
            .add("nested")
            .add("core_scheduling")
            .add("profile");
        #[cfg(target_arch = "x86_64")]
        parser.add("x-cpuid-overrides");
        #[cfg(target_arch = "x86_64")]
        parser.add("kvm_hint_realtime");
        parser.parse(cpus).map_err(Error::ParseCpus)?;

        let boot_vcpus: u32 = parser
            .convert("boot")
            .map_err(Error::ParseCpus)?
            .unwrap_or(DEFAULT_VCPUS);
        let max_vcpus: u32 = parser
            .convert("max")
            .map_err(Error::ParseCpus)?
            .unwrap_or(boot_vcpus);
        let topology = parser.convert("topology").map_err(Error::ParseCpus)?;
        let kvm_hyperv = parser
            .convert::<Toggle>("kvm_hyperv")
            .map_err(Error::ParseCpus)?
            .unwrap_or(Toggle(false))
            .0;
        #[cfg(target_arch = "x86_64")]
        let kvm_hint_realtime = parser
            .convert::<Toggle>("kvm_hint_realtime")
            .map_err(Error::ParseCpus)?
            .unwrap_or(Toggle(false))
            .0;
        let max_phys_bits = parser
            .convert::<u8>("max_phys_bits")
            .map_err(Error::ParseCpus)?
            .unwrap_or(DEFAULT_MAX_PHYS_BITS);
        let affinity = parser
            .convert::<TupleList<u32, Vec<usize>>>("affinity")
            .map_err(Error::ParseCpus)?
            .map(|v| {
                v.0.iter()
                    .map(|Tuple(e1, e2)| CpuAffinity {
                        vcpu: *e1,
                        host_cpus: e2.clone().into_boxed_slice(),
                    })
                    .collect()
            });

        let profile = parser
            .get("profile")
            .map(|profile| profile.parse::<CpuProfileConfig>())
            .transpose()
            .map_err(Error::ParseCpuProfile)?
            .unwrap_or_default();

        #[cfg(target_arch = "x86_64")]
        let cpuid_overrides = parser
            .get("x-cpuid-overrides")
            .map(|value| value.parse::<CpuidOverrides>())
            .transpose()
            .map_err(Error::InvalidCpuidOverride)?
            .map(|overrides| overrides.0)
            .unwrap_or_default();

        let features_list = parser
            .convert::<StringList>("features")
            .map_err(Error::ParseCpus)?
            .unwrap_or_default();

        #[allow(unused_mut)]
        let mut features = CpuFeatures::default();
        {
            #[cfg(target_arch = "x86_64")]
            for feature in features_list.0 {
                match feature.as_str() {
                    "amx" => features.amx = true,
                    _ => return Err(Error::InvalidCpuFeatures(feature)),
                }
            }

            #[cfg(not(target_arch = "x86_64"))]
            if let Some(feature) = features_list.0.into_iter().next() {
                return Err(Error::InvalidCpuFeatures(feature));
            }
        }

        let nested = parser
            .convert::<Toggle>("nested")
            .map_err(Error::ParseCpus)?
            .is_some_and(|toggle| toggle.0);

        let core_scheduling = parser
            .convert("core_scheduling")
            .map_err(Error::ParseCpus)?
            .unwrap_or(CoreScheduling::Vm);

        Ok(CpusConfig {
            boot_vcpus,
            max_vcpus,
            topology,
            kvm_hyperv,
            #[cfg(target_arch = "x86_64")]
            kvm_hint_realtime,
            max_phys_bits,
            affinity,
            features,
            nested,
            core_scheduling,
            profile,
            #[cfg(target_arch = "x86_64")]
            cpuid_overrides,
        })
    }
}

impl PciSegmentConfig {
    pub const SYNTAX: &'static str = "PCI Segment parameters \
        \"pci_segment=<segment_id>,mmio32_aperture_weight=<scale>,\
        mmio64_aperture_weight=<scale>\"";

    pub fn parse(disk: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("mmio32_aperture_weight")
            .add("mmio64_aperture_weight")
            .add("pci_segment");
        parser.parse(disk).map_err(Error::ParsePciSegment)?;

        let pci_segment = parser
            .convert("pci_segment")
            .map_err(Error::ParsePciSegment)?
            .unwrap_or_default();
        let mmio32_aperture_weight = parser
            .convert("mmio32_aperture_weight")
            .map_err(Error::ParsePciSegment)?
            .unwrap_or(DEFAULT_PCI_SEGMENT_APERTURE_WEIGHT);
        let mmio64_aperture_weight = parser
            .convert("mmio64_aperture_weight")
            .map_err(Error::ParsePciSegment)?
            .unwrap_or(DEFAULT_PCI_SEGMENT_APERTURE_WEIGHT);

        Ok(PciSegmentConfig {
            pci_segment,
            mmio32_aperture_weight,
            mmio64_aperture_weight,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        let num_pci_segments = match &vm_config.platform {
            Some(platform_config) => platform_config.num_pci_segments,
            None => 1,
        };

        if self.pci_segment >= num_pci_segments {
            return Err(ValidationError::InvalidPciSegment(self.pci_segment));
        }

        if self.mmio32_aperture_weight == 0 {
            return Err(ValidationError::InvalidPciSegmentApertureWeight(
                self.mmio32_aperture_weight,
            ));
        }

        if self.mmio64_aperture_weight == 0 {
            return Err(ValidationError::InvalidPciSegmentApertureWeight(
                self.mmio64_aperture_weight,
            ));
        }

        Ok(())
    }
}

// Shared by both variants of `PlatformConfig::SYNTAX`.
macro_rules! platform_syntax {
    ($($extra:literal)?) => {
        concat!(
            "Platform configuration parameters \
                \"num_pci_segments=<num_pci_segments>,iommu_segments=<list_of_segments>,\
                iommu_address_width=<bits>,iommufd=on|off,iommufd_fd=<fd>,vfio_p2p_dma=on|off,\
                system_manufacturer=<dmi_system_manufacturer>,\
                system_product_name=<dmi_system_product_name>,system_version=<dmi_system_version>,\
                system_serial_number=<dmi_system_serial_number>,system_uuid=<dmi_system_uuid>,\
                system_sku_number=<dmi_system_sku_number>,system_family=<dmi_system_family>,\
                oem_strings=<list_of_strings>,chassis_asset_tag=<dmi_chassis_asset_tag>",
            $($extra,)?
            "\""
        )
    };
}

impl PlatformConfig {
    #[cfg(feature = "sev_snp")]
    pub const SYNTAX: &'static str = platform_syntax!(",sev_snp=on|off");
    #[cfg(not(feature = "sev_snp"))]
    pub const SYNTAX: &'static str = platform_syntax!();

    /// # Safety
    /// Live FDs named in the input must be exclusively owned by the caller.
    /// Referenced descriptors may be consumed even if parsing fails.
    pub unsafe fn parse(platform: &str) -> Result<Self> {
        validate_inherited_fds([platform])?;
        struct StringField {
            key: &'static str,
            apply: fn(&mut PlatformConfig, String),
        }

        const SMBIOS_STRING_FIELDS: &[StringField] = &[
            StringField {
                key: "system_manufacturer",
                apply: |config, value| config.system_manufacturer = Some(value),
            },
            StringField {
                key: "system_product_name",
                apply: |config, value| config.system_product_name = Some(value),
            },
            StringField {
                key: "system_version",
                apply: |config, value| config.system_version = Some(value),
            },
            StringField {
                key: "system_serial_number",
                apply: |config, value| config.system_serial_number = Some(value),
            },
            StringField {
                key: "system_uuid",
                apply: |config, value| config.system_uuid = Some(value),
            },
            StringField {
                key: "system_sku_number",
                apply: |config, value| config.system_sku_number = Some(value),
            },
            StringField {
                key: "system_family",
                apply: |config, value| config.system_family = Some(value),
            },
            StringField {
                key: "chassis_asset_tag",
                apply: |config, value| config.chassis_asset_tag = Some(value),
            },
        ];

        let mut parser = OptionParser::new();
        parser
            .add("num_pci_segments")
            .add("iommu_segments")
            .add("iommu_address_width")
            .add("oem_strings")
            .add("iommufd")
            .add("iommufd_fd")
            .add("vfio_p2p_dma");
        for field in SMBIOS_STRING_FIELDS {
            parser.add(field.key);
        }
        #[cfg(feature = "sev_snp")]
        parser.add("sev_snp");
        parser.parse(platform).map_err(Error::ParsePlatform)?;

        let num_pci_segments: u16 = parser
            .convert("num_pci_segments")
            .map_err(Error::ParsePlatform)?
            .unwrap_or(DEFAULT_NUM_PCI_SEGMENTS);
        let iommu_segments = parser
            .convert::<IntegerList>("iommu_segments")
            .map_err(Error::ParsePlatform)?
            .map(|v| v.0.iter().map(|e| *e as u16).collect());
        let iommu_address_width_bits: u8 = parser
            .convert("iommu_address_width")
            .map_err(Error::ParsePlatform)?
            .unwrap_or(MAX_IOMMU_ADDRESS_WIDTH_BITS);
        let oem_strings = parser
            .convert::<StringList>("oem_strings")
            .map_err(Error::ParsePlatform)?
            .map(|v| v.0.into_boxed_slice());
        let iommufd_fd = parser
            .convert::<RawFd>("iommufd_fd")
            .map_err(Error::ParsePlatform)?
            // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
            .map(|fd| unsafe { take_inherited_fd(fd) })
            .transpose()?
            .unwrap_or_default();
        // `iommufd_fd=<n>` implies `iommufd=on` unless the user explicitly set the value.
        let iommufd = parser
            .convert::<Toggle>("iommufd")
            .map_err(Error::ParsePlatform)?
            .map_or(iommufd_fd.is_some(), |Toggle(v)| v);
        let vfio_p2p_dma = parser
            .convert::<Toggle>("vfio_p2p_dma")
            .map_err(Error::ParsePlatform)?
            .unwrap_or(Toggle(true))
            .0;
        #[cfg(feature = "sev_snp")]
        let sev_snp = parser
            .convert::<Toggle>("sev_snp")
            .map_err(Error::ParsePlatform)?
            .unwrap_or(Toggle(false))
            .0;

        let mut platform_config = PlatformConfig {
            num_pci_segments,
            iommu_segments,
            iommu_address_width_bits,
            system_serial_number: None,
            system_uuid: None,
            oem_strings,
            system_manufacturer: None,
            system_product_name: None,
            system_version: None,
            system_family: None,
            system_sku_number: None,
            chassis_asset_tag: None,
            iommufd,
            iommufd_fd,
            #[cfg(feature = "sev_snp")]
            sev_snp,
            vfio_p2p_dma,
        };

        for field in SMBIOS_STRING_FIELDS {
            if let Some(value) = parser
                .convert::<String>(field.key)
                .map_err(Error::ParsePlatform)?
            {
                (field.apply)(&mut platform_config, value);
            }
        }

        Ok(platform_config)
    }

    pub fn validate(&self) -> ValidationResult<()> {
        if self.num_pci_segments == 0 || self.num_pci_segments > MAX_NUM_PCI_SEGMENTS {
            return Err(ValidationError::InvalidNumPciSegments(
                self.num_pci_segments,
            ));
        }

        if let Some(iommu_segments) = &self.iommu_segments {
            for segment in iommu_segments {
                if *segment >= self.num_pci_segments {
                    return Err(ValidationError::InvalidPciSegment(*segment));
                }
            }
        }

        if self.iommu_address_width_bits > MAX_IOMMU_ADDRESS_WIDTH_BITS {
            return Err(ValidationError::InvalidIommuAddressWidthBits(
                self.iommu_address_width_bits,
            ));
        }

        if self.iommufd_fd.is_some() && !self.iommufd {
            return Err(ValidationError::IommufdFdRequiresIommufd);
        }

        Ok(())
    }
}

impl MemoryZoneConfig {
    pub const SYNTAX: &'static str = "User defined memory zone parameters \
        \"size=<guest_memory_region_size>,file=<backing_file>,\
        shared=on|off,\
        hugepages=on|off,hugepage_size=<hugepage_size>,\
        host_numa_node=<node_id>,\
        id=<zone_identifier>,hotplug_size=<hotpluggable_memory_size>,\
        hotplugged_size=<hotplugged_memory_size>,\
        prefault=on|off,reserve=on|off\"";
}

impl MemoryConfig {
    pub const SYNTAX: &'static str = "Memory parameters \
        \"size=<guest_memory_size>,mergeable=on|off,shared=on|off,\
        hugepages=on|off,hugepage_size=<hugepage_size>,\
        hotplug_method=acpi|virtio-mem,\
        hotplug_size=<hotpluggable_memory_size>,\
        hotplugged_size=<hotplugged_memory_size>,\
        prefault=on|off,reserve=on|off,thp=on|off\" \
        (ACPI memory hotplug is deprecated: use hotplug_method=virtio-mem)";

    #[expect(clippy::needless_pass_by_value)]
    pub fn parse(memory: &str, memory_zones: Option<Vec<&str>>) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("size")
            .add("mergeable")
            .add("hotplug_method")
            .add("hotplug_size")
            .add("hotplugged_size")
            .add("shared")
            .add("hugepages")
            .add("hugepage_size")
            .add("prefault")
            .add("reserve")
            .add("thp");
        parser.parse(memory).map_err(Error::ParseMemory)?;

        let size = parser
            .convert::<ByteSized>("size")
            .map_err(Error::ParseMemory)?
            .unwrap_or(ByteSized(DEFAULT_MEMORY_MB << 20))
            .0;
        let mergeable = parser
            .convert::<Toggle>("mergeable")
            .map_err(Error::ParseMemory)?
            .unwrap_or(Toggle(false))
            .0;
        let hotplug_method = parser
            .convert("hotplug_method")
            .map_err(Error::ParseMemory)?
            .unwrap_or_default();
        let hotplug_size = parser
            .convert::<ByteSized>("hotplug_size")
            .map_err(Error::ParseMemory)?
            .map(|v| v.0);
        let hotplugged_size = parser
            .convert::<ByteSized>("hotplugged_size")
            .map_err(Error::ParseMemory)?
            .map(|v| v.0);
        let shared = parser
            .convert::<Toggle>("shared")
            .map_err(Error::ParseMemory)?
            .unwrap_or(Toggle(false))
            .0;
        let hugepages = parser
            .convert::<Toggle>("hugepages")
            .map_err(Error::ParseMemory)?
            .unwrap_or(Toggle(false))
            .0;
        let hugepage_size = parser
            .convert::<ByteSized>("hugepage_size")
            .map_err(Error::ParseMemory)?
            .map(|v| v.0);
        let prefault = parser
            .convert::<Toggle>("prefault")
            .map_err(Error::ParseMemory)?
            .unwrap_or(Toggle(false))
            .0;
        let reserve = parser
            .convert::<Toggle>("reserve")
            .map_err(Error::ParseMemory)?
            .map(|t| t.0);
        let thp = parser
            .convert::<Toggle>("thp")
            .map_err(Error::ParseMemory)?
            .unwrap_or(Toggle(true))
            .0;

        let zones: Option<Vec<MemoryZoneConfig>> = if let Some(memory_zones) = &memory_zones {
            let mut zones = Vec::new();
            for memory_zone in memory_zones.iter() {
                let mut parser = OptionParser::new();
                parser
                    .add("id")
                    .add("size")
                    .add("file")
                    .add("shared")
                    .add("hugepages")
                    .add("hugepage_size")
                    .add("host_numa_node")
                    .add("hotplug_size")
                    .add("hotplugged_size")
                    .add("prefault")
                    .add("reserve")
                    .add("mergeable");
                parser.parse(memory_zone).map_err(Error::ParseMemoryZone)?;

                let id = parser.get("id").ok_or(Error::ParseMemoryZoneIdMissing)?;
                let size = parser
                    .convert::<ByteSized>("size")
                    .map_err(Error::ParseMemoryZone)?
                    .unwrap_or(ByteSized(DEFAULT_MEMORY_MB << 20))
                    .0;
                let file = parser.get("file").map(PathBuf::from);
                let shared = parser
                    .convert::<Toggle>("shared")
                    .map_err(Error::ParseMemoryZone)?
                    .unwrap_or(Toggle(false))
                    .0;
                let hugepages = parser
                    .convert::<Toggle>("hugepages")
                    .map_err(Error::ParseMemoryZone)?
                    .unwrap_or(Toggle(false))
                    .0;
                let hugepage_size = parser
                    .convert::<ByteSized>("hugepage_size")
                    .map_err(Error::ParseMemoryZone)?
                    .map(|v| v.0);

                let host_numa_node = parser
                    .convert::<u32>("host_numa_node")
                    .map_err(Error::ParseMemoryZone)?;
                let hotplug_size = parser
                    .convert::<ByteSized>("hotplug_size")
                    .map_err(Error::ParseMemoryZone)?
                    .map(|v| v.0);
                let hotplugged_size = parser
                    .convert::<ByteSized>("hotplugged_size")
                    .map_err(Error::ParseMemoryZone)?
                    .map(|v| v.0);
                let prefault = parser
                    .convert::<Toggle>("prefault")
                    .map_err(Error::ParseMemoryZone)?
                    .unwrap_or(Toggle(false))
                    .0;
                let reserve = parser
                    .convert::<Toggle>("reserve")
                    .map_err(Error::ParseMemoryZone)?
                    .map(|t| t.0);
                let mergeable = parser
                    .convert::<Toggle>("mergeable")
                    .map_err(Error::ParseMemoryZone)?
                    .unwrap_or(Toggle(mergeable))
                    .0;

                zones.push(MemoryZoneConfig {
                    id,
                    size,
                    file,
                    shared,
                    hugepages,
                    hugepage_size,
                    host_numa_node,
                    hotplug_size,
                    hotplugged_size,
                    prefault,
                    reserve,
                    mergeable,
                });
            }
            Some(zones)
        } else {
            None
        };

        Ok(MemoryConfig {
            size,
            mergeable,
            hotplug_method,
            hotplug_size,
            hotplugged_size,
            shared,
            hugepages,
            hugepage_size,
            prefault,
            reserve,
            zones,
            thp,
        })
    }

    pub fn total_size(&self) -> u64 {
        self.size
            + self
                .zones
                .iter()
                .flatten()
                .map(|zone| zone.size)
                .sum::<u64>()
            + self.hotplugged_size()
    }

    pub fn hotplugged_size(&self) -> u64 {
        self.hotplugged_size.unwrap_or(0)
            + self
                .zones
                .iter()
                .flatten()
                .filter_map(|zone| zone.hotplugged_size)
                .sum::<u64>()
    }

    pub fn hotplug_size(&self) -> u64 {
        self.hotplug_size.unwrap_or(0)
            + self
                .zones
                .iter()
                .flatten()
                .filter_map(|zone| zone.hotplug_size)
                .sum::<u64>()
    }

    pub fn hugepages_enabled(&self) -> bool {
        self.hugepages
            || self.hugepage_size.is_some()
            || self
                .zones
                .iter()
                .flatten()
                .any(|zone| zone.hugepages || zone.hugepage_size.is_some())
    }
}

const RATE_LIMITER_OPTIONS: &[&str] = &[
    "bw_size",
    "bw_one_time_burst",
    "bw_refill_time",
    "bw_burst_rate",
    "bw_burst_seconds",
    "bw_burst_recharge_seconds",
    "ops_size",
    "ops_one_time_burst",
    "ops_refill_time",
    "ops_burst_rate",
    "ops_burst_seconds",
    "ops_burst_recharge_seconds",
];

fn parse_rate_limiter_config(
    parser: &OptionParser,
) -> result::Result<RateLimiterConfig, OptionParserError> {
    let bandwidth = TokenBucketConfig {
        size: parser.convert("bw_size")?.unwrap_or_default(),
        one_time_burst: Some(parser.convert("bw_one_time_burst")?.unwrap_or_default()),
        refill_time: parser.convert("bw_refill_time")?.unwrap_or_default(),
        burst_rate: parser.convert("bw_burst_rate")?,
        burst_seconds: parser.convert("bw_burst_seconds")?,
        burst_recharge_seconds: parser.convert("bw_burst_recharge_seconds")?,
    };
    let ops = TokenBucketConfig {
        size: parser.convert("ops_size")?.unwrap_or_default(),
        one_time_burst: Some(parser.convert("ops_one_time_burst")?.unwrap_or_default()),
        refill_time: parser.convert("ops_refill_time")?.unwrap_or_default(),
        burst_rate: parser.convert("ops_burst_rate")?,
        burst_seconds: parser.convert("ops_burst_seconds")?,
        burst_recharge_seconds: parser.convert("ops_burst_recharge_seconds")?,
    };
    let [bandwidth, ops] = [bandwidth, ops].map(|bucket| {
        ((bucket.size != 0 && bucket.refill_time != 0)
            || bucket.burst_rate.is_some()
            || bucket.burst_seconds.is_some()
            || bucket.burst_recharge_seconds.is_some())
        .then_some(bucket)
    });
    Ok(RateLimiterConfig { bandwidth, ops })
}

fn validate_rate_limiter_config(cfg: &RateLimiterConfig) -> ValidationResult<()> {
    for bucket in [cfg.bandwidth, cfg.ops].into_iter().flatten() {
        let Some(rate) = bucket.burst_rate else {
            if let Some(seconds) = bucket.burst_seconds {
                return Err(ValidationError::RateLimiterBurstSecondsWithoutRate(seconds));
            }
            if let Some(recharge) = bucket.burst_recharge_seconds {
                return Err(ValidationError::RateLimiterBurstRechargeWithoutRate(
                    recharge,
                ));
            }
            continue;
        };
        let seconds = bucket.burst_seconds.unwrap_or(1);
        if rate == 0 || seconds == 0 {
            return Err(ValidationError::RateLimiterBurstZero(rate, seconds));
        }
        if let Some(burst) = bucket.one_time_burst
            && burst > 0
        {
            return Err(ValidationError::RateLimiterBurstWithOneTimeBurst(
                rate, burst,
            ));
        }
        if bucket.size == 0 || bucket.refill_time == 0 {
            return Err(ValidationError::RateLimiterBurstDisabledBucket(
                rate,
                bucket.size,
                bucket.refill_time,
            ));
        }
        if u128::from(rate) * u128::from(bucket.refill_time) < u128::from(bucket.size) * 1000 {
            return Err(ValidationError::RateLimiterBurstBelowSustained(
                rate,
                bucket.size,
                bucket.refill_time,
            ));
        }
        if rate.checked_mul(seconds).is_none() {
            return Err(ValidationError::RateLimiterBurstCapacityOverflow(
                rate, seconds,
            ));
        }
        if let Some(recharge) = bucket.burst_recharge_seconds {
            let sustained = u128::from(bucket.size) * 1000;
            let refill_time = u128::from(bucket.refill_time);
            let base_depth = sustained.div_ceil(refill_time);
            let base_refill_seconds = base_depth * refill_time / sustained;
            let capacity = rate * seconds;
            if u128::from(capacity) <= base_depth {
                return Err(ValidationError::RateLimiterBurstRechargeWithoutCredit(
                    recharge, capacity, base_depth,
                ));
            }
            if u128::from(recharge) <= base_refill_seconds {
                return Err(ValidationError::RateLimiterBurstRechargeTooShort(
                    recharge,
                    base_refill_seconds + 1,
                ));
            }
        }
    }
    Ok(())
}

impl RateLimiterGroupConfig {
    pub const SYNTAX: &'static str = "Rate Limit Group parameters \
        \"bw_size=<bytes>,bw_one_time_burst=<bytes>,bw_refill_time=<ms>,\
        bw_burst_rate=<bytes_per_second>,bw_burst_seconds=<seconds>,\
        bw_burst_recharge_seconds=<seconds>,\
        ops_size=<io_ops>,ops_one_time_burst=<io_ops>,ops_refill_time=<ms>,\
        ops_burst_rate=<io_ops_per_second>,ops_burst_seconds=<seconds>,\
        ops_burst_recharge_seconds=<seconds>,\
        id=<device_id>\"";

    pub fn parse(rate_limit_group: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add_all(RATE_LIMITER_OPTIONS).add("id");
        parser
            .parse(rate_limit_group)
            .map_err(Error::ParseRateLimiterGroup)?;

        let id = parser.get("id").unwrap_or_default();
        Ok(RateLimiterGroupConfig {
            id,
            rate_limiter_config: parse_rate_limiter_config(&parser)
                .map_err(Error::ParseRateLimiterGroup)?,
        })
    }

    pub fn validate(&self, _vm_config: &VmConfig) -> ValidationResult<()> {
        if self.rate_limiter_config.bandwidth.is_none() && self.rate_limiter_config.ops.is_none() {
            return Err(ValidationError::InvalidRateLimiterGroup);
        }

        if self.id.is_empty() {
            return Err(ValidationError::InvalidRateLimiterGroup);
        }

        validate_rate_limiter_config(&self.rate_limiter_config)?;

        Ok(())
    }
}

impl PciDeviceCommonConfig {
    const OPTIONS: &[&str] = &["id", "pci_segment", "pci_device_id"];
    const OPTIONS_IOMMU: &[&str] = &["id", "iommu", "pci_segment", "pci_device_id"];

    pub fn parse(input: &str) -> Result<Self> {
        let mut parser = OptionParser::new();

        parser.add_all(Self::OPTIONS_IOMMU);

        parser
            .parse_subset(input)
            .map_err(Error::ParsePciDeviceCommonConfig)?;

        let id = parser.get("id");
        let iommu = parser
            .convert::<IommuType>("iommu")
            .map_err(Error::ParsePciDeviceCommonConfig)?
            .unwrap_or_default();
        let pci_segment = parser
            .convert("pci_segment")
            .map_err(Error::ParsePciDeviceCommonConfig)?
            .unwrap_or_default();
        let pci_device_id = parser
            .convert::<u8>("pci_device_id")
            .map_err(Error::ParsePciDeviceCommonConfig)?;

        Ok(Self {
            id,
            iommu,
            pci_segment,
            pci_device_id,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig, virtio_iommu_only: bool) -> ValidationResult<()> {
        if virtio_iommu_only && self.iommu == IommuType::Smmuv3 {
            return Err(ValidationError::IommuSmmuv3NotPassthrough);
        }

        let num_pci_segments = vm_config
            .platform
            .as_ref()
            .map_or(DEFAULT_NUM_PCI_SEGMENTS, |platform_config| {
                platform_config.num_pci_segments
            });

        if self.pci_segment >= num_pci_segments {
            return Err(ValidationError::InvalidPciSegment(self.pci_segment));
        }

        if let Some(platform_config) = vm_config.platform.as_ref()
            && let Some(iommu_segments) = platform_config.iommu_segments.as_ref()
            && iommu_segments.contains(&self.pci_segment)
            && !self.iommu.attached()
        {
            return Err(ValidationError::OnIommuSegment(self.pci_segment));
        }

        if let Some(device_id) = self.pci_device_id {
            validate_pci_device_id(device_id, self.pci_segment)?;
        }

        Ok(())
    }
}

impl DiskConfig {
    pub const SYNTAX: &'static str = "Disk parameters \
        \"path=<disk_image_path>,readonly=on|off,direct=on|off,iommu=off|virtio,\
        num_queues=<number_of_queues>,queue_size=<size_of_each_queue>,\
        vhost_user=on|off,socket=<vhost_user_socket_path>,\
        bw_size=<bytes>,bw_one_time_burst=<bytes>,bw_refill_time=<ms>,\
        bw_burst_rate=<bytes_per_second>,bw_burst_seconds=<seconds>,\
        bw_burst_recharge_seconds=<seconds>,\
        ops_size=<io_ops>,ops_one_time_burst=<io_ops>,ops_refill_time=<ms>,\
        ops_burst_rate=<io_ops_per_second>,ops_burst_seconds=<seconds>,\
        ops_burst_recharge_seconds=<seconds>,\
        id=<device_id>,pci_segment=<segment_id>,pci_device_id=<pci_slot>,\
        rate_limit_group=<group_id>,\
        queue_affinity=<list_of_queue_indices_with_their_associated_cpuset>,\
        serial=<serial_number>,backing_files=on|off,sparse=on|off,\
        image_type=<raw,qcow2,vhd,vhdx,vmdk>,lock_granularity=byte-range|full,\
        guest_block_size=<size_in_bytes>\"";

    pub fn parse(disk: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("path")
            .add("readonly")
            .add("direct")
            .add("queue_size")
            .add("num_queues")
            .add("vhost_user")
            .add("socket")
            .add_all(RATE_LIMITER_OPTIONS)
            .add("_disable_io_uring")
            .add("_disable_aio")
            .add("serial")
            .add("rate_limit_group")
            .add("queue_affinity")
            .add("backing_files")
            .add("sparse")
            .add("image_type")
            .add("lock_granularity")
            .add("guest_block_size")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);

        parser.parse(disk).map_err(Error::ParseDisk)?;

        let path = parser.get("path").map(PathBuf::from);
        let readonly = parser
            .convert::<Toggle>("readonly")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;
        let direct = parser
            .convert::<Toggle>("direct")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;
        let queue_size = parser
            .convert("queue_size")
            .map_err(Error::ParseDisk)?
            .unwrap_or_else(default_diskconfig_queue_size);
        let num_queues = parser
            .convert("num_queues")
            .map_err(Error::ParseDisk)?
            .unwrap_or_else(default_diskconfig_num_queues);
        let vhost_user = parser
            .convert::<Toggle>("vhost_user")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;
        let vhost_socket = parser.get("socket");
        let disable_io_uring = parser
            .convert::<Toggle>("_disable_io_uring")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;
        let disable_aio = parser
            .convert::<Toggle>("_disable_aio")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;
        let rate_limit_group = parser.get("rate_limit_group");
        let rate_limiter_config = parse_rate_limiter_config(&parser).map_err(Error::ParseDisk)?;
        let serial = parser.get("serial");
        let queue_affinity = parser
            .convert::<TupleList<u16, Vec<usize>>>("queue_affinity")
            .map_err(Error::ParseDisk)?
            .map(|v| {
                v.0.iter()
                    .map(|Tuple(e1, e2)| VirtQueueAffinity {
                        queue_index: *e1,
                        host_cpus: e2.clone().into_boxed_slice(),
                    })
                    .collect()
            });

        let backing_files = parser
            .convert::<Toggle>("backing_files")
            .map_err(Error::ParseDisk)?
            .unwrap_or(Toggle(false))
            .0;

        let image_type = if vhost_socket.is_none() {
            parser
                .convert::<ImageType>("image_type")
                .map_err(Error::ParseDisk)?
                .unwrap_or(ImageType::Unknown)
        } else {
            ImageType::Unknown
        };

        let lock_granularity = parser
            .convert::<LockGranularityChoice>("lock_granularity")
            .map_err(Error::ParseDisk)?
            .unwrap_or_default();

        let guest_block_size = parser
            .convert::<u32>("guest_block_size")
            .map_err(Error::ParseDisk)?;

        let rate_limiter_config = (rate_limiter_config.bandwidth.is_some()
            || rate_limiter_config.ops.is_some())
        .then_some(rate_limiter_config);
        let sparse = parser
            .convert::<Toggle>("sparse")
            .map_err(Error::ParseDisk)?
            .unwrap_or_else(|| Toggle(default_diskconfig_sparse()))
            .0;

        let pci_common = PciDeviceCommonConfig::parse(disk)?;

        Ok(DiskConfig {
            pci_common,
            path,
            readonly,
            direct,
            num_queues,
            queue_size,
            vhost_user,
            vhost_socket,
            rate_limit_group,
            rate_limiter_config,
            disable_io_uring,
            disable_aio,
            serial,
            queue_affinity,
            backing_files,
            sparse,
            image_type,
            lock_granularity,
            guest_block_size,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)?;

        if self.num_queues == 0 {
            return Err(ValidationError::InvalidNumQueues(self.num_queues.into()));
        }

        if self.num_queues as u32 > vm_config.cpus.boot_vcpus {
            return Err(ValidationError::TooManyQueues(
                self.num_queues,
                vm_config.cpus.boot_vcpus as usize,
            ));
        }

        validate_queue_size(self.queue_size)?;

        if self.queue_size <= MINIMUM_BLOCK_QUEUE_SIZE {
            return Err(ValidationError::BlockQueueSizeTooSmall(self.queue_size));
        }

        if let Some(affinity) = self.queue_affinity.as_ref()
            && let Some(invalid) = affinity.iter().find(|a| a.queue_index >= self.num_queues)
        {
            return Err(ValidationError::InvalidQueueAffinity(
                invalid.queue_index,
                self.num_queues,
            ));
        }

        if self.vhost_user && self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }

        if self.vhost_user && self.rate_limiter_config.is_some() {
            return Err(ValidationError::VhostUserRateLimiterNotSupported);
        }

        if self.vhost_user && self.rate_limit_group.is_some() {
            return Err(ValidationError::VhostUserRateLimiterNotSupported);
        }

        if self.vhost_user && self.guest_block_size.is_some() {
            return Err(ValidationError::VhostUserGuestBlockSizeNotSupported);
        }

        if self.rate_limiter_config.is_some() && self.rate_limit_group.is_some() {
            return Err(ValidationError::InvalidRateLimiterGroup);
        }

        if let Some(cfg) = &self.rate_limiter_config {
            validate_rate_limiter_config(cfg)?;
        }

        // Check Block device serial length
        if let Some(ref serial) = self.serial
            && serial.len() > VIRTIO_BLK_ID_BYTES as usize
        {
            return Err(ValidationError::InvalidSerialLength(
                serial.len(),
                VIRTIO_BLK_ID_BYTES as usize,
            ));
        }

        if !self.vhost_user && self.image_type == ImageType::Unknown {
            return Err(ValidationError::ImageTypeRequired);
        }

        if let Some(guest_block_size) = self.guest_block_size
            && (!guest_block_size.is_power_of_two() || !(512..=65536).contains(&guest_block_size))
        {
            return Err(ValidationError::InvalidGuestBlockSize(guest_block_size));
        }

        Ok(())
    }
}

#[derive(Debug)]
pub enum ParseVhostModeError {
    InvalidValue(String),
}

impl FromStr for VhostMode {
    type Err = ParseVhostModeError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "client" => Ok(VhostMode::Client),
            "server" => Ok(VhostMode::Server),
            _ => Err(ParseVhostModeError::InvalidValue(s.to_owned())),
        }
    }
}

#[derive(Debug, Error)]
pub enum ParseIommuTypeError {
    #[error("Invalid IOMMU type: {0}")]
    InvalidValue(String),
}

impl FromStr for IommuType {
    type Err = ParseIommuTypeError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "" | "off" | "false" => Ok(IommuType::Off),
            "on" | "true" => {
                warn!("'iommu=on' is deprecated: use 'iommu=virtio' instead");
                Ok(IommuType::Virtio)
            }
            "virtio" => Ok(IommuType::Virtio),
            "smmuv3" => Ok(IommuType::Smmuv3),
            _ => Err(ParseIommuTypeError::InvalidValue(s.to_owned())),
        }
    }
}

impl NetConfig {
    pub const SYNTAX: &'static str = "Network parameters \
        \"tap=<if_name>,ip=<ip_addr>,mask=<net_mask>,mac=<mac_addr>,host_mac=<host_mac_addr>,\
        fd=<[fd1,fd2,...]>,iommu=off|virtio,mtu=<mtu>,num_queues=<number_of_queues>,\
        queue_size=<size_of_each_queue>,id=<device_id>,\
        vhost_user=<vhost_user_enable>,socket=<vhost_user_socket_path>,vhost_mode=client|server,\
        bw_size=<bytes>,bw_one_time_burst=<bytes>,bw_refill_time=<ms>,\
        bw_burst_rate=<bytes_per_second>,bw_burst_seconds=<seconds>,\
        bw_burst_recharge_seconds=<seconds>,\
        ops_size=<io_ops>,ops_one_time_burst=<io_ops>,ops_refill_time=<ms>,\
        ops_burst_rate=<io_ops_per_second>,ops_burst_seconds=<seconds>,\
        ops_burst_recharge_seconds=<seconds>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>,\
        offload_tso=on|off,offload_ufo=on|off,offload_csum=on|off\"";

    /// # Safety
    /// Live FDs named in the input must be exclusively owned by the caller.
    /// Referenced descriptors may be consumed even if parsing fails.
    pub unsafe fn parse(net: &str) -> Result<Self> {
        validate_inherited_fds([net])?;
        let mut parser = OptionParser::new();

        parser
            .add("tap")
            .add("ip")
            .add("mask")
            .add("mac")
            .add("host_mac")
            .add("offload_tso")
            .add("offload_ufo")
            .add("offload_csum")
            .add("mtu")
            .add("queue_size")
            .add("num_queues")
            .add("vhost_user")
            .add("socket")
            .add("vhost_mode")
            .add("fd")
            .add_all(RATE_LIMITER_OPTIONS)
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(net).map_err(Error::ParseNetwork)?;

        let tap = parser.get("tap");
        let ip = parser.convert("ip").map_err(Error::ParseNetwork)?;
        let mask = parser.convert("mask").map_err(Error::ParseNetwork)?;

        let mac = parser.convert("mac").map_err(Error::ParseNetwork)?;
        let host_mac = parser.convert("host_mac").map_err(Error::ParseNetwork)?;
        let offload_tso = parser
            .convert::<Toggle>("offload_tso")
            .map_err(Error::ParseNetwork)?
            .unwrap_or(Toggle(false))
            .0;
        let offload_ufo = parser
            .convert::<Toggle>("offload_ufo")
            .map_err(Error::ParseNetwork)?
            .unwrap_or(Toggle(false))
            .0;
        let offload_csum = parser
            .convert::<Toggle>("offload_csum")
            .map_err(Error::ParseNetwork)?
            .unwrap_or(Toggle(false))
            .0;
        let mtu = parser.convert("mtu").map_err(Error::ParseNetwork)?;
        let queue_size = parser
            .convert("queue_size")
            .map_err(Error::ParseNetwork)?
            .unwrap_or_else(default_netconfig_queue_size);
        let num_queues = parser
            .convert("num_queues")
            .map_err(Error::ParseNetwork)?
            .unwrap_or_else(default_netconfig_num_queues);
        let vhost_user = parser
            .convert::<Toggle>("vhost_user")
            .map_err(Error::ParseNetwork)?
            .unwrap_or(Toggle(false))
            .0;
        let vhost_socket = parser.get("socket");
        let vhost_mode = parser
            .convert("vhost_mode")
            .map_err(Error::ParseNetwork)?
            .unwrap_or_default();
        let fds = parser
            .convert::<IntegerList>("fd")
            .map_err(Error::ParseNetwork)?
            .map(|v| {
                v.0.into_iter()
                    // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
                    .map(|fd| unsafe { take_inherited_fd(fd) })
                    .collect::<Result<Vec<_>>>()
            })
            .transpose()?;
        let rate_limiter_config =
            parse_rate_limiter_config(&parser).map_err(Error::ParseNetwork)?;
        let rate_limiter_config = (rate_limiter_config.bandwidth.is_some()
            || rate_limiter_config.ops.is_some())
        .then_some(rate_limiter_config);

        let pci_common = PciDeviceCommonConfig::parse(net)?;

        let config = NetConfig {
            pci_common,
            tap,
            ip,
            mask,
            mac,
            host_mac,
            mtu,
            num_queues,
            queue_size,
            vhost_user,
            vhost_socket,
            vhost_mode,
            fds,
            rate_limiter_config,
            offload_tso,
            offload_ufo,
            offload_csum,
        };
        Ok(config)
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)?;

        if self.num_queues < 2 {
            return Err(ValidationError::VnetQueueLowerThan2(self.num_queues));
        }

        if !self.num_queues.is_multiple_of(2) {
            return Err(ValidationError::VnetQueueOdd(self.num_queues));
        }

        if let Some(fds) = &self.fds {
            let actual_queues = fds.len() * 2;
            if actual_queues != self.num_queues as usize {
                return Err(ValidationError::VnetQueueFdMismatch(
                    self.num_queues,
                    actual_queues,
                ));
            }

            for fd in fds {
                let fd = fd.as_ref().map_or(-1, |fd| fd.as_raw_fd());
                if fd <= 2 {
                    return Err(ValidationError::VnetReservedFd(fd));
                }
            }
        }

        if (self.num_queues / 2) as u32 > vm_config.cpus.boot_vcpus {
            return Err(ValidationError::TooManyQueues(
                self.num_queues,
                vm_config.cpus.boot_vcpus as usize,
            ));
        }

        validate_queue_size(self.queue_size)?;

        if self.vhost_user && self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }

        if self.vhost_user && self.rate_limiter_config.is_some() {
            return Err(ValidationError::VhostUserRateLimiterNotSupported);
        }

        if let Some(cfg) = &self.rate_limiter_config {
            validate_rate_limiter_config(cfg)?;
        }

        if let Some(mtu) = self.mtu
            && mtu < net::MIN_MTU
        {
            return Err(ValidationError::InvalidMtu(mtu));
        }

        if !self.offload_csum && (self.offload_tso || self.offload_ufo) {
            return Err(ValidationError::NoHardwareChecksumOffload);
        }

        if self.mask.is_some() && self.ip.is_none() {
            return Err(ValidationError::MaskProvidedWithoutIp);
        }

        if self.ip.is_some() && self.mask.is_none() {
            return Err(ValidationError::IpProvidedWithoutMask);
        }

        Ok(())
    }
}

impl RngConfig {
    pub const SYNTAX: &'static str = "Random number generator parameters \
        \"src=<entropy_source_path>,iommu=off|virtio,pci_segment=<segment_id>,\
        pci_device_id=<pci_slot>\"";

    pub fn parse(rng: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("src")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(rng).map_err(Error::ParseRng)?;

        let src = PathBuf::from(
            parser
                .get("src")
                .unwrap_or_else(|| Self::DEFAULT_RNG_SOURCE.to_owned()),
        );

        let pci_common = PciDeviceCommonConfig::parse(rng)?;

        Ok(RngConfig { src, pci_common })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)
    }
}

impl RtcConfig {
    pub const SYNTAX: &'static str = "Virtio RTC parameters \
        \"iommu=off|virtio,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\". \
        Passing --rtc with no arguments enables the device with default \
        settings.";

    pub fn parse(rtc: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(rtc).map_err(Error::ParseRtc)?;

        let pci_common = PciDeviceCommonConfig::parse(rtc)?;

        Ok(RtcConfig { pci_common })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)
    }
}

impl BalloonConfig {
    pub const SYNTAX: &'static str = "Balloon parameters \
        \"size=<balloon_size>,deflate_on_oom=on|off,\
        free_page_reporting=on|off,iommu=off|virtio,id=<device_id>,pci_segment=<segment_id>,\
        pci_device_id=<pci_slot>\"";

    pub fn parse(balloon: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("size");
        parser.add("deflate_on_oom");
        parser.add("free_page_reporting");
        parser.add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(balloon).map_err(Error::ParseBalloon)?;

        let size = parser
            .convert::<ByteSized>("size")
            .map_err(Error::ParseBalloon)?
            .map_or(0, |v| v.0);

        let deflate_on_oom = parser
            .convert::<Toggle>("deflate_on_oom")
            .map_err(Error::ParseBalloon)?
            .unwrap_or(Toggle(false))
            .0;

        let free_page_reporting = parser
            .convert::<Toggle>("free_page_reporting")
            .map_err(Error::ParseBalloon)?
            .unwrap_or(Toggle(false))
            .0;

        let pci_common = PciDeviceCommonConfig::parse(balloon)?;

        Ok(BalloonConfig {
            pci_common,
            size,
            deflate_on_oom,
            free_page_reporting,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)
    }
}

impl GenericVhostUserConfig {
    pub const SYNTAX: &'static str = "generic vhost-user parameters \
        \"device_type=<ID number for virtio device type (FS, block, net, etc) or symbolic name>,\
        socket=<socket_path>,\
        queue_sizes=<list of queue sizes>,\
        id=<device_id>,pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(vhost_user: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("device_type")
            .add("queue_sizes")
            .add("socket")
            .add_all(PciDeviceCommonConfig::OPTIONS);
        parser
            .parse(vhost_user)
            .map_err(Error::ParseGenericVhostUser)?;

        let socket = parser
            .get("socket")
            .ok_or(Error::ParseGenericVhostUserSockMissing)?;

        let IntegerList(queue_sizes) = parser
            .convert::<IntegerList<u16>>("queue_sizes")
            .map_err(Error::ParseGenericVhostUser)?
            .ok_or(Error::ParseGenericVhostUserQueueSizeMissing)?;
        let device_type_str = parser
            .convert::<String>("device_type")
            .map_err(Error::ParseGenericVhostUser)?
            .ok_or(Error::ParseGenericVhostUserVirtioIdMissing)?;
        let device_type = match device_type_str.as_bytes() {
            b"net" => VIRTIO_ID_NET,
            b"block" => VIRTIO_ID_BLOCK,
            b"console" => VIRTIO_ID_CONSOLE,
            b"rng" => VIRTIO_ID_RNG,
            b"balloon" => VIRTIO_ID_BALLOON,
            b"iomem" => VIRTIO_ID_IOMEM,
            b"rpmsg" => VIRTIO_ID_RPMSG,
            b"scsi" => VIRTIO_ID_SCSI,
            b"9p" => VIRTIO_ID_9P,
            b"mac80211_wlan" => VIRTIO_ID_MAC80211_WLAN,
            b"rproc_serial" => VIRTIO_ID_RPROC_SERIAL,
            b"caif" => VIRTIO_ID_CAIF,
            b"memory_balloon" => VIRTIO_ID_MEMORY_BALLOON,
            b"gpu" => VIRTIO_ID_GPU,
            b"clock" => VIRTIO_ID_CLOCK,
            b"input" => VIRTIO_ID_INPUT,
            b"vsock" => VIRTIO_ID_VSOCK,
            b"crypto" => VIRTIO_ID_CRYPTO,
            b"signal_dist" => VIRTIO_ID_SIGNAL_DIST,
            b"pstore" => VIRTIO_ID_PSTORE,
            b"iommu" => VIRTIO_ID_IOMMU,
            b"mem" => VIRTIO_ID_MEM,
            b"sound" => VIRTIO_ID_SOUND,
            b"fs" => VIRTIO_ID_FS,
            b"pmem" => VIRTIO_ID_PMEM,
            b"rpmb" => VIRTIO_ID_RPMB,
            b"mac80211_hwsim" => VIRTIO_ID_MAC80211_HWSIM,
            b"video_encoder" => VIRTIO_ID_VIDEO_ENCODER,
            b"video_decoder" => VIRTIO_ID_VIDEO_DECODER,
            b"scmi" => VIRTIO_ID_SCMI,
            b"nitro_sec_mod" => VIRTIO_ID_NITRO_SEC_MOD,
            b"i2c" => VIRTIO_ID_I2C_ADAPTER,
            b"watchdog" => VIRTIO_ID_WATCHDOG,
            b"can" => VIRTIO_ID_CAN,
            b"dmabuf" => VIRTIO_ID_DMABUF,
            b"param_serv" => VIRTIO_ID_PARAM_SERV,
            b"audio_policy" => VIRTIO_ID_AUDIO_POLICY,
            b"bt" => VIRTIO_ID_BT,
            b"gpio" => VIRTIO_ID_GPIO,
            b"rdma" => 42,
            b"camera" => 43,
            b"ism" => 44,
            b"spi" => 45,
            b"tee" => 46,
            b"cpu_balloon" => 47,
            b"media" => 48,
            b"usb" => 49,
            [b'1'..=b'9', ..] => match device_type_str.parse() {
                Ok(id) => id,
                Err(_) => return Err(Error::ParseGenericVhostUserVirtioIdInvalid(device_type_str)),
            },
            _ => return Err(Error::ParseGenericVhostUserVirtioIdInvalid(device_type_str)),
        };
        match device_type {
            // vhost-user devices of these types definitely cannot work.
            // Cloud Hypervisor needs to know if an IOMMU exists so that it
            // can perform address translation, and a vhost-user device has
            // no supported way to reset the guest.
            VIRTIO_ID_WATCHDOG | VIRTIO_ID_IOMMU => {
                return Err(Error::ParseGenericVhostUserVirtioIdUnsupported(
                    device_type_str,
                ));
            }
            _ => {}
        }
        let pci_common = PciDeviceCommonConfig::parse(vhost_user)?;

        Ok(GenericVhostUserConfig {
            pci_common,
            socket: socket.into(),
            device_type,
            queue_sizes,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        if self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }

        for &queue_size in &self.queue_sizes {
            validate_queue_size(queue_size)?;
        }

        self.pci_common.validate(vm_config, true)
    }
}

impl FsConfig {
    pub const SYNTAX: &'static str = "virtio-fs parameters \
        \"tag=<tag_name>,socket=<socket_path>,num_queues=<number_of_queues>,\
        queue_size=<size_of_each_queue>,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(fs: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("tag")
            .add("queue_size")
            .add("num_queues")
            .add("socket")
            .add_all(PciDeviceCommonConfig::OPTIONS);
        parser.parse(fs).map_err(Error::ParseFileSystem)?;

        let tag = parser.get("tag").ok_or(Error::ParseFsTagMissing)?;
        if tag.len() > vhost_user::VIRTIO_FS_TAG_LEN {
            return Err(Error::ParseFsTagTooLong);
        }
        let socket = PathBuf::from(parser.get("socket").ok_or(Error::ParseFsSockMissing)?);

        let queue_size = parser
            .convert("queue_size")
            .map_err(Error::ParseFileSystem)?
            .unwrap_or_else(default_fsconfig_queue_size);
        let num_queues = parser
            .convert("num_queues")
            .map_err(Error::ParseFileSystem)?
            .unwrap_or_else(default_fsconfig_num_queues);

        let pci_common = PciDeviceCommonConfig::parse(fs)?;

        Ok(FsConfig {
            pci_common,
            tag,
            socket,
            num_queues,
            queue_size,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        if self.num_queues == 0 {
            return Err(ValidationError::InvalidNumQueues(self.num_queues.into()));
        }

        if self.num_queues as u32 > vm_config.cpus.boot_vcpus {
            return Err(ValidationError::TooManyQueues(
                self.num_queues,
                vm_config.cpus.boot_vcpus as usize,
            ));
        }

        validate_queue_size(self.queue_size)?;

        if self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }

        self.pci_common.validate(vm_config, true)
    }
}

#[cfg(feature = "fw_cfg")]
impl FwCfgConfig {
    pub const SYNTAX: &'static str = "Boot params to pass to FW CFG device \
        \"e820=on|off,kernel=on|off,cmdline=on|off,initramfs=on|off,acpi_table=on|off,\
        items=[name=<item_name>,file=<file_path>:name=<item_name>,string=<string_value>]\"";
    pub fn parse(fw_cfg_config: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("e820")
            .add("kernel")
            .add("cmdline")
            .add("initramfs")
            .add("acpi_table")
            .add("items");
        parser.parse(fw_cfg_config).map_err(Error::ParseFwCfgItem)?;
        let e820 = parser
            .convert::<Toggle>("e820")
            .map_err(Error::ParseFwCfgItem)?
            .unwrap_or(Toggle(cfg!(target_arch = "x86_64")))
            .0;
        let kernel = parser
            .convert::<Toggle>("kernel")
            .map_err(Error::ParseFwCfgItem)?
            .unwrap_or(Toggle(true))
            .0;
        let cmdline = parser
            .convert::<Toggle>("cmdline")
            .map_err(Error::ParseFwCfgItem)?
            .unwrap_or(Toggle(true))
            .0;
        let initramfs = parser
            .convert::<Toggle>("initramfs")
            .map_err(Error::ParseFwCfgItem)?
            .unwrap_or(Toggle(true))
            .0;
        let acpi_tables = parser
            .convert::<Toggle>("acpi_table")
            .map_err(Error::ParseFwCfgItem)?
            .unwrap_or(Toggle(true))
            .0;
        let items = if parser.is_set("items") {
            Some(
                parser
                    .convert::<FwCfgItemList>("items")
                    .map_err(Error::ParseFwCfgItem)?
                    .unwrap(),
            )
        } else {
            None
        };

        Ok(FwCfgConfig {
            e820,
            kernel,
            cmdline,
            initramfs,
            acpi_tables,
            items,
        })
    }
    pub fn validate(&self, payload: &PayloadConfig) -> result::Result<(), PayloadConfigError> {
        if self.kernel && payload.kernel.is_none() {
            return Err(PayloadConfigError::FwCfgMissingKernel);
        } else if self.cmdline && payload.cmdline.is_none() {
            return Err(PayloadConfigError::FwCfgMissingCmdline);
        } else if self.initramfs && payload.initramfs.is_none() {
            return Err(PayloadConfigError::FwCfgMissingInitramfs);
        }

        if let Some(items) = &self.items {
            for item in &items.item_list {
                if item.file.is_some() == item.string.is_some() {
                    return Err(PayloadConfigError::FwCfgInvalidItem(item.name.clone()));
                }
            }
        }

        Ok(())
    }
}

#[cfg(feature = "fw_cfg")]
impl FwCfgItem {
    pub fn parse(fw_cfg: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("name").add("file").add("string");
        parser.parse(fw_cfg).map_err(Error::ParseFwCfgItem)?;

        let name =
            parser
                .get("name")
                .ok_or(Error::ParseFwCfgItem(OptionParserError::InvalidValue(
                    "missing FwCfgItem name".to_string(),
                )))?;
        let file = parser.get("file").map(PathBuf::from);
        let string = parser.get("string");
        Ok(FwCfgItem { name, file, string })
    }
}

impl PmemConfig {
    pub const SYNTAX: &'static str = "Persistent memory parameters \
        \"file=<backing_file_path>,size=<persistent_memory_size>,iommu=off|virtio,\
        discard_writes=on|off,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(pmem: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("size")
            .add("file")
            .add("discard_writes")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(pmem).map_err(Error::ParsePersistentMemory)?;

        let pci_common = PciDeviceCommonConfig::parse(pmem)?;
        let file = PathBuf::from(parser.get("file").ok_or(Error::ParsePmemFileMissing)?);
        let size = parser
            .convert::<ByteSized>("size")
            .map_err(Error::ParsePersistentMemory)?
            .map(|v| v.0);
        let discard_writes = parser
            .convert::<Toggle>("discard_writes")
            .map_err(Error::ParsePersistentMemory)?
            .unwrap_or(Toggle(false))
            .0;

        Ok(PmemConfig {
            pci_common,
            file,
            size,
            discard_writes,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)
    }
}

impl ConsoleOutput {
    const VALUELESS_OPTIONS: &[&str] = &["off", "pty", "tty", "null"];
    const VALUE_OPTIONS: &[&str] = &["file", "socket", "tcp", "server"];

    fn parse(console: &str, map_err: impl Fn(OptionParserError) -> Error) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add_all_valueless(Self::VALUELESS_OPTIONS)
            .add_all(Self::VALUE_OPTIONS);
        parser.parse_subset(console).map_err(&map_err)?;

        let output = if parser.is_set("off") {
            ConsoleOutput::Off
        } else if parser.is_set("pty") {
            ConsoleOutput::Pty { file: None }
        } else if parser.is_set("tty") {
            ConsoleOutput::Tty
        } else if parser.is_set("null") {
            ConsoleOutput::Null
        } else if parser.is_set("file") {
            let file = parser
                .get("file")
                .ok_or(Error::Validation(ValidationError::ConsoleFileMissing))?;
            ConsoleOutput::File {
                file: PathBuf::from(file),
            }
        } else if parser.is_set("socket") {
            let socket = parser
                .get("socket")
                .ok_or(Error::Validation(ValidationError::ConsoleSocketPathMissing))?;
            ConsoleOutput::Socket {
                socket: PathBuf::from(socket),
            }
        } else if parser.is_set("tcp") {
            let address = parser
                .get("tcp")
                .ok_or(Error::Validation(ValidationError::ConsoleTcpAddressMissing))?;
            let server = parser
                .convert::<Toggle>("server")
                .map_err(&map_err)?
                .unwrap_or(Toggle(true))
                .0;
            if !server {
                return Err(Error::Validation(
                    ValidationError::ConsoleTcpClientUnsupported,
                ));
            }
            ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: parse_tcp_address(&address)
                        .map_err(|source| Error::ResolveConsoleTcpAddress { address, source })?,
                    server,
                },
            }
        } else {
            return Err(Error::ParseConsoleInvalidModeGiven);
        };

        if parser.is_set("server") && !matches!(output, ConsoleOutput::Tcp { .. }) {
            return Err(Error::Validation(
                ValidationError::ConsoleTcpServerUnexpected,
            ));
        }

        Ok(output)
    }

    pub fn validate(&self) -> ValidationResult<()> {
        if let ConsoleOutput::Tcp { tcp } = self {
            if !tcp.server {
                return Err(ValidationError::ConsoleTcpClientUnsupported);
            }
            if tcp.address.port() == 0 {
                return Err(ValidationError::ConsoleTcpPortZero);
            }
        }
        Ok(())
    }

    pub(crate) const UPDATE_OPTIONS: &[&str] = &[
        "console_file",
        "console_socket",
        "console_tcp",
        "serial_file",
        "serial_socket",
        "serial_tcp",
    ];

    pub(crate) fn parse_update(parser: &OptionParser, component: &str) -> Result<Option<Self>> {
        let get_if_set = |mode: &str, missing: ValidationError| -> Result<Option<String>> {
            let option = format!("{component}_{mode}");
            if !parser.is_set(&option) {
                return Ok(None);
            }
            parser
                .get(&option)
                .map(Some)
                .ok_or(Error::Validation(missing))
        };
        let file = get_if_set("file", ValidationError::ConsoleFileMissing)?;
        let socket = get_if_set("socket", ValidationError::ConsoleSocketPathMissing)?;
        let tcp = get_if_set("tcp", ValidationError::ConsoleTcpAddressMissing)?;

        let output = match (file, socket, tcp) {
            (None, None, None) => return Ok(None),
            (Some(file), None, None) => Self::File {
                file: PathBuf::from(file),
            },
            (None, Some(socket), None) => Self::Socket {
                socket: PathBuf::from(socket),
            },
            (None, None, Some(address)) => Self::Tcp {
                tcp: TcpConsoleConfig {
                    address: parse_tcp_address(&address)
                        .map_err(|source| Error::ResolveConsoleTcpAddress { address, source })?,
                    server: true,
                },
            },
            _ => {
                return Err(Error::Validation(
                    ValidationError::ConsoleOutputUpdateAmbiguous(component.to_owned()),
                ));
            }
        };

        Ok(Some(output))
    }

    fn update(&mut self, new: &Self) -> ValidationResult<()> {
        if discriminant(self) != discriminant(new) {
            return Err(ValidationError::ConsoleOutputUpdateModeMismatch(
                self.clone(),
                new.clone(),
            ));
        }
        new.validate()?;
        self.clone_from(new);
        Ok(())
    }
}

impl ConsoleConfig {
    pub fn parse(console: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add_all_valueless(ConsoleOutput::VALUELESS_OPTIONS)
            .add_all(ConsoleOutput::VALUE_OPTIONS)
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(console).map_err(Error::ParseConsole)?;

        let output = ConsoleOutput::parse(console, Error::ParseConsole)?;
        let pci_common = PciDeviceCommonConfig::parse(console)?;

        Ok(Self { output, pci_common })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.output.validate()?;
        self.pci_common.validate(vm_config, true)
    }
}

impl SerialConfig {
    pub fn parse(serial: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add_all_valueless(ConsoleOutput::VALUELESS_OPTIONS)
            .add_all(ConsoleOutput::VALUE_OPTIONS);
        parser.parse(serial).map_err(Error::ParseSerial)?;

        let output = ConsoleOutput::parse(serial, Error::ParseSerial)?;
        Ok(Self { output })
    }

    pub fn validate(&self) -> ValidationResult<()> {
        self.output.validate()
    }
}

#[cfg(target_arch = "x86_64")]
impl DebugConsoleConfig {
    pub const SYNTAX: &'static str = "Debug console: \
        \"off|null|pty|tty|file=<path>,iobase=<port in hex>\"";

    pub fn parse(debug_console_ops: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add_valueless("off")
            .add_valueless("pty")
            .add_valueless("tty")
            .add_valueless("null")
            .add("file")
            .add("iobase");
        parser
            .parse(debug_console_ops)
            .map_err(Error::ParseConsole)?;

        let output = ConsoleOutput::parse(debug_console_ops, Error::ParseConsole)?;
        let mut iobase: Option<u16> = None;

        if parser.is_set("iobase")
            && let Some(iobase_opt) = parser.get("iobase")
        {
            if !iobase_opt.starts_with("0x") {
                return Err(Error::Validation(ValidationError::InvalidIoPortHex(
                    iobase_opt,
                )));
            }
            iobase =
                Some(u16::from_str_radix(&iobase_opt[2..], 16).map_err(|_| {
                    Error::Validation(ValidationError::InvalidIoPortHex(iobase_opt))
                })?);
        }

        Ok(Self { output, iobase })
    }
}

impl DeviceConfig {
    pub const SYNTAX: &'static str = "Direct device assignment parameters \
        \"path=<device_path>,fd=<vfio_cdev_fd>,iommu=off|virtio|smmuv3,\
        id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>,\
        x_nv_gpudirect_clique=<clique_id>,\
        x_exclude_mmap_bars=[<bar>...]\"";

    /// # Safety
    /// Live FDs named in the input must be exclusively owned by the caller.
    /// Referenced descriptors may be consumed even if parsing fails.
    pub unsafe fn parse(device: &str) -> Result<Self> {
        validate_inherited_fds([device])?;
        let mut parser = OptionParser::new();
        parser
            .add("path")
            .add("fd")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU)
            .add("x_nv_gpudirect_clique")
            .add("x_exclude_mmap_bars");
        parser.parse(device).map_err(Error::ParseDevice)?;

        let pci_common = PciDeviceCommonConfig::parse(device)?;
        let path = parser.get("path").map(PathBuf::from);
        let fd = parser
            .convert::<RawFd>("fd")
            .map_err(Error::ParseDevice)?
            // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
            .map(|fd| unsafe { take_inherited_fd(fd) })
            .transpose()?
            .unwrap_or_default();
        let x_nv_gpudirect_clique = parser
            .convert::<u8>("x_nv_gpudirect_clique")
            .map_err(Error::ParseDevice)?;
        let x_exclude_mmap_bars = parser
            .convert::<IntegerList>("x_exclude_mmap_bars")
            .map_err(Error::ParseDevice)?
            .map(|bars| bars.0)
            .unwrap_or_default();
        Ok(DeviceConfig {
            pci_common,
            path,
            fd,
            x_nv_gpudirect_clique,
            x_exclude_mmap_bars,
            iommufd_dev_id: None,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, false)?;

        #[cfg(not(all(target_arch = "aarch64", feature = "kvm")))]
        if self.pci_common.iommu == IommuType::Smmuv3 {
            return Err(ValidationError::IommuSmmuv3NotSupported);
        }

        if self.pci_common.iommu == IommuType::Smmuv3
            && !vm_config.platform.as_ref().is_some_and(|p| p.iommufd)
        {
            return Err(ValidationError::IommuSmmuv3RequiresIommufd);
        }

        match (&self.path, self.fd.as_ref()) {
            (None, None) => return Err(ValidationError::VfioDeviceNeitherPathNorFd),
            (Some(_), Some(_)) => return Err(ValidationError::VfioDeviceBothPathAndFd),
            (None, Some(_)) => {
                let iommufd_fd_set = vm_config
                    .platform
                    .as_ref()
                    .is_some_and(|p| p.iommufd_fd.is_some());
                if !iommufd_fd_set {
                    return Err(ValidationError::VfioFdRequiresIommufdFd);
                }
            }
            (Some(_), None) => {}
        }

        if self.x_nv_gpudirect_clique.is_some() {
            let vfio_p2p_dma = vm_config.platform.as_ref().is_none_or(|p| p.vfio_p2p_dma);
            if !vfio_p2p_dma {
                return Err(ValidationError::GpuDirectCliqueRequiresP2pDma);
            }
        }

        // PCI devices expose six BARs, so only BAR indices 0 through 5 are valid here.
        for bar in &self.x_exclude_mmap_bars {
            if *bar > 5 {
                return Err(ValidationError::InvalidDeviceExcludeMmapBar(*bar));
            }
        }

        Ok(())
    }
}

impl UserDeviceConfig {
    pub const SYNTAX: &'static str = "Userspace device \
        \"socket=<socket_path>,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(user_device: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("socket").add_all(PciDeviceCommonConfig::OPTIONS);
        parser.parse(user_device).map_err(Error::ParseUserDevice)?;

        let pci_common = PciDeviceCommonConfig::parse(user_device)?;
        let socket = parser
            .get("socket")
            .map(PathBuf::from)
            .ok_or(Error::ParseUserDeviceSocketMissing)?;

        Ok(UserDeviceConfig { pci_common, socket })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        if self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }

        self.pci_common.validate(vm_config, true)
    }
}

impl VdpaConfig {
    pub const SYNTAX: &'static str = "vDPA device \
        \"path=<device_path>,num_queues=<number_of_queues>,iommu=off|virtio,\
        id=<device_id>,pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(vdpa: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("path")
            .add("num_queues")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(vdpa).map_err(Error::ParseVdpa)?;

        let pci_common = PciDeviceCommonConfig::parse(vdpa)?;
        let path = parser
            .get("path")
            .map(PathBuf::from)
            .ok_or(Error::ParseVdpaPathMissing)?;
        let num_queues = parser
            .convert("num_queues")
            .map_err(Error::ParseVdpa)?
            .unwrap_or_else(default_vdpaconfig_num_queues);

        Ok(VdpaConfig {
            pci_common,
            path,
            num_queues,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)?;

        if self.num_queues == 0 {
            return Err(ValidationError::InvalidNumQueues(self.num_queues.into()));
        }

        Ok(())
    }
}

impl VsockConfig {
    pub const SYNTAX: &'static str = "Virtio VSOCK parameters \
        \"cid=<context_id>,socket=<socket_path>,socket_type=stream|seqpacket,iommu=off|virtio,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\"";

    pub fn parse(vsock: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("socket")
            .add("cid")
            .add("socket_type")
            .add_all(PciDeviceCommonConfig::OPTIONS_IOMMU);
        parser.parse(vsock).map_err(Error::ParseVsock)?;

        let pci_common = PciDeviceCommonConfig::parse(vsock)?;
        let socket = parser
            .get("socket")
            .map(PathBuf::from)
            .ok_or(Error::ParseVsockSockMissing)?;
        let cid = parser
            .convert("cid")
            .map_err(Error::ParseVsock)?
            .ok_or(Error::ParseVsockCidMissing)?;

        Ok(VsockConfig {
            pci_common,
            cid,
            socket,
            socket_type: parser
                .convert("socket_type")
                .map_err(Error::ParseVsock)?
                .unwrap_or_default(),
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        self.pci_common.validate(vm_config, true)
    }
}

impl NumaConfig {
    pub const SYNTAX: &'static str = "Settings related to a given NUMA node \
        \"guest_numa_id=<node_id>,cpus=<cpus_id>,\
        distances=<list_of_distances_to_destination_nodes>,device_id=<device_id>,\
        memory_zones=<list_of_memory_zones>,\
        pci_segments=<list_of_pci_segments>\"";

    pub fn parse(numa: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser
            .add("guest_numa_id")
            .add("cpus")
            .add("distances")
            .add("device_id")
            .add("memory_zones")
            .add("pci_segments");

        parser.parse(numa).map_err(Error::ParseNuma)?;

        let guest_numa_id = parser
            .convert::<u32>("guest_numa_id")
            .map_err(Error::ParseNuma)?
            .ok_or_else(|| {
                Error::ParseNuma(OptionParserError::InvalidValue(
                    "guest_numa_id is required for all NUMA nodes".to_string(),
                ))
            })?;
        let cpus = parser
            .convert::<IntegerList>("cpus")
            .map_err(Error::ParseNuma)?
            .map(|v| v.0.iter().map(|e| *e as u32).collect());
        let distances = parser
            .convert::<TupleList<u64, u64>>("distances")
            .map_err(Error::ParseNuma)?
            .map(|v| {
                v.0.iter()
                    .map(|Tuple(e1, e2)| NumaDistance {
                        destination: *e1 as u32,
                        distance: *e2 as u8,
                    })
                    .collect()
            });
        let device_id = parser.get("device_id");
        let memory_zones = parser
            .convert::<StringList>("memory_zones")
            .map_err(Error::ParseNuma)?
            .map(|v| v.0.into_boxed_slice());
        let pci_segments = parser
            .convert::<IntegerList>("pci_segments")
            .map_err(Error::ParseNuma)?
            .map(|v| v.0.iter().map(|e| *e as u16).collect());
        if device_id.is_some() && (cpus.is_some() || memory_zones.is_some()) {
            return Err(Error::ParseNuma(OptionParserError::InvalidValue(
                "device_id in numa config cannot be used with cpus or memory zones".to_string(),
            )));
        }
        Ok(NumaConfig {
            guest_numa_id,
            cpus,
            distances,
            device_id,
            memory_zones,
            pci_segments,
        })
    }

    pub fn is_generic_initiator(&self) -> bool {
        self.device_id.is_some()
    }

    /// Validates NumaConfig
    pub fn validate(&self) -> result::Result<(), ValidationError> {
        match (&self.device_id, &self.cpus, &self.memory_zones) {
            (Some(device_id), None, None) => {
                // Valid generic initiator case
                if device_id.is_empty() {
                    return Err(ValidationError::InvalidNumaConfig(
                        "device_id in numa config cannot be empty".to_string(),
                    ));
                }
                Ok(())
            }
            (None, Some(cpus), _) => {
                // Standard NUMA with cpus
                if cpus.is_empty() {
                    return Err(ValidationError::InvalidNumaConfig(
                        "cpus list in numa config cannot be empty".to_string(),
                    ));
                }
                Ok(())
            }
            (None, _, Some(memory_zones)) => {
                // Standard NUMA with memory_zones (cpus is None here)
                if memory_zones.is_empty() {
                    return Err(ValidationError::InvalidNumaConfig(
                        "memory_zones in numa config cannot be empty".to_string(),
                    ));
                }
                Ok(())
            }
            _ => {
                // Default handles all error cases
                if self.device_id.is_some() && (self.cpus.is_some() || self.memory_zones.is_some())
                {
                    Err(ValidationError::InvalidNumaConfig(
                        "device_id in numa config is mutually exclusive with cpus and memory_zones"
                            .to_string(),
                    ))
                } else {
                    Err(ValidationError::InvalidNumaConfig(
                        "numa config must specify either device_id or cpus/memory_zones"
                            .to_string(),
                    ))
                }
            }
        }
    }
}

#[serde_with::skip_serializing_none]
#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize, Default)]
pub struct RestoredNetConfig {
    pub id: String,
    #[serde(default)]
    pub num_fds: usize,
    // Deserialization keeps the FD count for restore.
    #[serde(default)]
    pub fds: Option<Vec<ExternalFd>>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize, Serialize, Default)]
pub enum MemoryRestoreMode {
    /// Restore by eagerly copying the snapshot into guest RAM before resume.
    #[default]
    Copy,
    /// Restore lazily by faulting snapshot pages into guest RAM on demand.
    OnDemand,
    OnDemandNoBackgroundFetchPages,
    /// Restore by mapping the snapshot memory file copy-on-write, sharing the
    /// page cache across VMs restored from the same snapshot.
    CopyOnWrite,
}

#[derive(Debug, Error)]
pub enum MemoryRestoreModeParseError {
    #[error("Invalid value: {0}")]
    InvalidValue(String),
}

impl FromStr for MemoryRestoreMode {
    type Err = MemoryRestoreModeParseError;

    fn from_str(s: &str) -> result::Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "copy" => Ok(Self::Copy),
            "ondemand" => Ok(Self::OnDemand),
            "ondemand_no_background_fetch_pages" => Ok(Self::OnDemandNoBackgroundFetchPages),
            "copyonwrite" => Ok(Self::CopyOnWrite),
            _ => Err(MemoryRestoreModeParseError::InvalidValue(s.to_owned())),
        }
    }
}

#[derive(Clone, Deserialize, Serialize, Debug, Eq, PartialEq)]
/// Data required for updating memory zone <-> host NUMA node mappings.
pub struct VmMemoryZoneUpdateData {
    /// Id of the MemoryZone to update
    pub id: String,
    /// Host NUMA node to relocate the MemoryZone to
    pub host_numa_node: u32,
}

#[serde_with::skip_serializing_none]
#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize, Default)]
pub struct RestoredVfioConfig {
    pub id: String,
    // Deserialized FDs are discarded.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub fd: ExternalFd,
}

#[serde_with::skip_serializing_none]
#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize, Default)]
pub struct RestoreConfig {
    pub source_url: PathBuf,
    #[serde(default)]
    pub prefault: bool,
    #[serde(default)]
    pub memory_restore_mode: MemoryRestoreMode,
    /// Deprecated: use `external_fds` with network targets instead.
    #[serde(default)]
    pub net_fds: Option<Vec<RestoredNetConfig>>,
    /// Deprecated: use `external_fds` with VFIO targets instead.
    #[serde(default)]
    pub vfio_fds: Option<Vec<RestoredVfioConfig>>,
    /// Deprecated: use `external_fds` with an IOMMU target instead.
    // Deserialized FDs are discarded.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub iommufd_fd: ExternalFd,
    #[serde(default)]
    pub resume: bool,
    #[serde(default)]
    pub zone_updates: Vec<VmMemoryZoneUpdateData>,
    #[serde(default)]
    pub serial: Option<ConsoleOutput>,
    #[serde(default)]
    pub console: Option<ConsoleOutput>,
    #[serde(default, flatten)]
    pub(crate) external_fds: ExternalFds,
}

impl RestoreConfig {
    pub const SYNTAX: &'static str = "Restore from a VM snapshot.\
        \nRestore parameters \"source_url=<source_url>,prefault=on|off,\
        memory_restore_mode=copy|ondemand|ondemand_no_background_fetch_pages|copyonwrite,\
        external_fds=[net(<id>)@[<fd>,...],vfio(<id>)@[<fd>],iommu@[<fd>]],resume=true|false,\
        zone_updates=<list_of_updates>,\
        serial_file=<path>|serial_socket=<path>|serial_tcp=<ip>:<port>,\
        console_file=<path>|console_socket=<path>|console_tcp=<ip>:<port>\"\n\
        \n`source_url` should be a valid URL (e.g file:///foo/bar or tcp://192.168.1.10/foo)\
        \n`prefault` controls eager prefaulting for the copy-based restore path \
        (disabled by default)\
        \n`memory_restore_mode=copy` preserves the existing eager read-copy restore behavior, \
        `memory_restore_mode=ondemand` enables lazy demand paging and fails restore if userfaultfd \
        support is unavailable, `memory_restore_mode=ondemand_no_background_fetch_pages` does the \
        same without prefaulting pages in the background, and `memory_restore_mode=copyonwrite` \
        maps the snapshot file copy-on-write (plain private RAM only; falls back to copy otherwise)\
        \n`external_fds` provides replacement file descriptors. `net(<id>)` entries replace \
        the FDs of network devices, `vfio(<id>)` entries replace VFIO cdev FDs, and `iommu` \
        provides the iommufd FD. \
        Do not combine `external_fds` with legacy FD fields.\
        \n`net_fds=<list_of_net_ids_with_their_associated_fds>`, \
        `vfio_fds=<list_of_vfio_ids_with_their_associated_fd>` and \
        `iommufd_fd=<fd>` are deprecated; use `external_fds` instead.\
        \n`resume` controls whether the VM will be directly resumed after restore\
        \n`zone_updates` can be used to update NUMA memory zones. \
        Expects a list of elements in the form `id@host_numa_node`";

    /// # Safety
    /// Live FDs named in the input must be exclusively owned by the caller.
    /// Referenced descriptors may be consumed even if parsing fails.
    pub unsafe fn parse(restore: &str) -> Result<Self> {
        validate_inherited_fds([restore])?;
        let mut parser = OptionParser::new();
        parser
            .add("source_url")
            .add("prefault")
            .add("memory_restore_mode")
            .add("net_fds")
            .add("vfio_fds")
            .add("iommufd_fd")
            .add("resume")
            .add("zone_updates")
            .add_all(ConsoleOutput::UPDATE_OPTIONS)
            .add("external_fds");
        parser.parse(restore).map_err(Error::ParseRestore)?;

        for field in ["net_fds", "vfio_fds", "iommufd_fd"] {
            if parser.get(field).is_some() {
                warn!("The '{field}' option is deprecated; use 'external_fds' instead");
            }
        }

        let source_url = parser
            .get("source_url")
            .map(PathBuf::from)
            .ok_or(Error::ParseRestoreSourceUrlMissing)?;
        let prefault = parser
            .convert::<Toggle>("prefault")
            .map_err(Error::ParseRestore)?
            .unwrap_or(Toggle(false))
            .0;
        let memory_restore_mode = parser
            .convert::<MemoryRestoreMode>("memory_restore_mode")
            .map_err(Error::ParseRestore)?
            .unwrap_or_default();
        let mut net_fds = parser
            .convert::<TupleList<String, Vec<u64>>>("net_fds")
            .map_err(Error::ParseRestore)?
            .map(|v| {
                v.0.into_iter()
                    .map(|Tuple(id, fds)| {
                        Ok(RestoredNetConfig {
                            id,
                            num_fds: fds.len(),
                            fds: Some(
                                fds.into_iter()
                                    .map(|fd| {
                                        // SAFETY: The caller transfers the inherited descriptors.
                                        unsafe { take_inherited_fd(fd) }
                                    })
                                    .collect::<Result<Vec<_>>>()?,
                            ),
                        })
                    })
                    .collect::<Result<Vec<_>>>()
            })
            .transpose()?;
        let mut vfio_fds = parser
            .convert::<TupleList<String, u64>>("vfio_fds")
            .map_err(Error::ParseRestore)?
            .map(|v| {
                v.0.into_iter()
                    .map(|Tuple(id, fd)| {
                        Ok(RestoredVfioConfig {
                            id,
                            // SAFETY: The caller transfers the inherited descriptor.
                            fd: unsafe { take_inherited_fd(fd) }?,
                        })
                    })
                    .collect::<Result<Vec<_>>>()
            })
            .transpose()?;
        let mut iommufd_fd = parser
            .convert::<RawFd>("iommufd_fd")
            .map_err(Error::ParseRestore)?
            // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
            .map(|fd| unsafe { take_inherited_fd(fd) })
            .transpose()?
            .unwrap_or_default();
        let resume = parser
            .convert::<Toggle>("resume")
            .map_err(Error::ParseRestore)?
            .unwrap_or(Toggle(false))
            .0;

        let zone_updates: Vec<VmMemoryZoneUpdateData> = parser
            .convert::<TupleList<String, u32>>("zone_updates")
            .map_err(Error::ParseRestore)?
            .map_or(Vec::new(), |v| {
                v.0.into_iter()
                    .map(|Tuple(id, host_numa_node)| VmMemoryZoneUpdateData { id, host_numa_node })
                    .collect()
            });
        let mut external_fds: ExternalFds = parser
            .convert::<TupleList<Target, Vec<u64>>>("external_fds")
            .map_err(Error::ParseRestore)?
            .map(|v| {
                // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
                unsafe { ExternalFds::from_cli(v) }
            })
            .transpose()?
            .unwrap_or_default();
        // TODO(fd): Remove after the deprecation period for the legacy FD fields.
        if !external_fds.is_empty()
            && (net_fds.is_some() || vfio_fds.is_some() || iommufd_fd.is_some())
        {
            return Err(Error::MixedFdFormats);
        }
        external_fds.import_restored_iommufd_fd(&mut iommufd_fd, false);
        external_fds.import_restored_vfio_configs(&mut vfio_fds);
        external_fds.import_restored_net_configs(&mut net_fds);

        let serial = ConsoleOutput::parse_update(&parser, "serial")?;
        let console = ConsoleOutput::parse_update(&parser, "console")?;

        Ok(RestoreConfig {
            source_url,
            prefault,
            memory_restore_mode,
            net_fds,
            vfio_fds,
            iommufd_fd,
            resume,
            zone_updates,
            serial,
            console,
            external_fds,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        if self.memory_restore_mode != MemoryRestoreMode::Copy && self.prefault {
            return Err(ValidationError::InvalidRestorePrefaultWithOnDemand);
        }

        if matches!(
            self.memory_restore_mode,
            MemoryRestoreMode::OnDemand | MemoryRestoreMode::OnDemandNoBackgroundFetchPages
        ) {
            vm_config.check_postcopy_incompatible_device()?;
        }

        vm_config.validate_fds(&self.external_fds)?;

        let unique_zones = self
            .zone_updates
            .iter()
            .map(|update| update.id.as_str())
            .collect::<HashSet<_>>();
        if self.zone_updates.len() != unique_zones.len() {
            return Err(ValidationError::MultipleMemoryZoneUpdates);
        }
        if unique_zones.contains("") {
            return Err(ValidationError::MemoryZoneUpdatesEmptyId);
        }

        Ok(())
    }
}

impl TpmConfig {
    pub const SYNTAX: &'static str = "TPM device \
        \"(UNIX Domain Socket from swtpm) socket=</path/to/a/socket>\"";

    pub fn parse(tpm: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("socket");
        parser.parse(tpm).map_err(Error::ParseTpm)?;
        let socket = parser
            .get("socket")
            .map(PathBuf::from)
            .ok_or(Error::ParseTpmPathMissing)?;
        Ok(TpmConfig { socket })
    }
}

impl LandlockConfig {
    pub const SYNTAX: &'static str = "Landlock parameters \
        \"path=<path/to/{file/dir}>,access=[rw]\"";

    pub fn parse(landlock_rule: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("path").add("access");
        parser
            .parse(landlock_rule)
            .map_err(Error::ParseLandlockRules)?;

        let path = parser
            .get("path")
            .map(PathBuf::from)
            .ok_or(Error::ParseLandlockMissingFields)?;

        let access = parser
            .get("access")
            .ok_or(Error::ParseLandlockMissingFields)?;

        if access.chars().count() > 2 {
            return Err(Error::ParseLandlockRules(OptionParserError::InvalidValue(
                access.to_string(),
            )));
        }

        Ok(LandlockConfig { path, access })
    }

    pub fn validate(&self) -> ValidationResult<()> {
        if !self.path.exists() {
            return Err(ValidationError::LandlockPathDoesNotExist(self.path.clone()));
        }
        self.access
            .parse::<LandlockAccess>()
            .map_err(|e| ValidationError::InvalidLandlockAccess(e.to_string()))?;
        Ok(())
    }
}

#[cfg(feature = "ivshmem")]
impl IvshmemConfig {
    pub const SYNTAX: &'static str = "Ivshmem device. Specify the backend file path and size \
        for the shared memory: \"path=</path/to/a/file>,size=<file_size>,id=<device_id>,\
        pci_segment=<segment_id>,pci_device_id=<pci_slot>\"\
        \nThe <file_size> must be a power of 2 (e.g., 2M, 4M, etc.), as it represents the size \
        of the memory region mapped to the guest. Default size is 128M.";
    pub fn parse(ivshmem: &str) -> Result<Self> {
        let mut parser = OptionParser::new();
        parser.add("path").add("size");
        parser.add_all(PciDeviceCommonConfig::OPTIONS);
        parser.parse(ivshmem).map_err(Error::ParseIvshmem)?;
        let path = parser
            .get("path")
            .map(PathBuf::from)
            .ok_or(Error::ParseIvshmemPathMissing)?;
        let size = parser
            .convert::<ByteSized>("size")
            .map_err(Error::ParseIvshmem)?
            .unwrap_or(ByteSized((DEFAULT_IVSHMEM_SIZE << 20) as u64))
            .0;
        let pci_common = PciDeviceCommonConfig::parse(ivshmem)?;
        Ok(IvshmemConfig {
            pci_common,
            path,
            size: size as usize,
        })
    }

    pub fn validate(&self, vm_config: &VmConfig) -> ValidationResult<()> {
        if self.pci_common.iommu.attached() {
            return Err(ValidationError::IommuNotSupported);
        }
        self.pci_common.validate(vm_config, true)?;

        let size = self.size as u64;
        let path = &self.path;
        // size must = 2^n
        if !size.is_power_of_two() {
            return Err(ValidationError::InvalidIvshmemInputSize(size));
        }
        let metadata = fs::metadata(path.to_str().unwrap())
            .map_err(|_| ValidationError::InvalidIvshmemPath)?;
        if metadata.len() < size {
            return Err(ValidationError::InvalidIvshmemSize(metadata.len()));
        }
        Ok(())
    }
}

impl VmConfig {
    pub(crate) fn update_console_outputs(
        &mut self,
        serial: Option<&ConsoleOutput>,
        console: Option<&ConsoleOutput>,
    ) -> ValidationResult<()> {
        if let Some(serial) = serial {
            self.serial.output.update(serial)?;
        }
        if let Some(console) = console {
            self.console.output.update(console)?;
        }
        Ok(())
    }

    fn validate_identifier(
        id_list: &mut BTreeSet<String>,
        id: &Option<String>,
    ) -> ValidationResult<()> {
        if let Some(id) = id.as_ref() {
            if id.starts_with("__") {
                return Err(ValidationError::InvalidIdentifier(id.clone()));
            }

            if !id_list.insert(id.clone()) {
                return Err(ValidationError::IdentifierNotUnique(id.clone()));
            }
        }

        Ok(())
    }

    pub fn backed_by_shared_memory(&self) -> bool {
        if self.memory.shared || self.memory.hugepages {
            return true;
        }

        if self.memory.size == 0 {
            for zone in self.memory.zones.as_ref().unwrap() {
                if !zone.shared && !zone.hugepages {
                    return false;
                }
            }
            true
        } else {
            false
        }
    }

    pub fn check_postcopy_incompatible_device(&self) -> ValidationResult<()> {
        if self.devices.as_ref().is_some_and(|d| !d.is_empty()) {
            return Err(ValidationError::PostcopyIncompatibleDevice(
                "VFIO".to_owned(),
            ));
        }
        if self.vdpa.as_ref().is_some_and(|d| !d.is_empty()) {
            return Err(ValidationError::PostcopyIncompatibleDevice(
                "vDPA".to_owned(),
            ));
        }
        if self.user_devices.as_ref().is_some_and(|d| !d.is_empty()) {
            return Err(ValidationError::PostcopyIncompatibleDevice(
                "vfio-user".to_owned(),
            ));
        }
        Ok(())
    }

    /// Identify if an emulated SMMUv3 is required based on configuration from every device
    pub fn smmuv3_attached(&self) -> bool {
        self.devices
            .iter()
            .flatten()
            .any(|d| d.pci_common.iommu == IommuType::Smmuv3)
    }

    /// Identify if a virtio-iommu IOMMU is required based on configuration from every device
    pub fn virtio_iommu_attached(&self) -> bool {
        let attached = |common: &PciDeviceCommonConfig| common.iommu == IommuType::Virtio;

        self.disks.iter().flatten().any(|d| attached(&d.pci_common))
            || self.net.iter().flatten().any(|n| attached(&n.pci_common))
            || self.pmem.iter().flatten().any(|p| attached(&p.pci_common))
            || self.vdpa.iter().flatten().any(|v| attached(&v.pci_common))
            || self
                .devices
                .iter()
                .flatten()
                .any(|d| attached(&d.pci_common))
            || attached(&self.rng.pci_common)
            || attached(&self.console.pci_common)
            || self.rtc.as_ref().is_some_and(|r| attached(&r.pci_common))
            || self
                .balloon
                .as_ref()
                .is_some_and(|b| attached(&b.pci_common))
            || self.vsock.as_ref().is_some_and(|v| attached(&v.pci_common))
            || self
                .platform
                .as_ref()
                .is_some_and(|p| p.iommu_segments.is_some())
    }

    // Also enables virtio-iommu if the config needs it
    // Returns the list of unique identifiers provided through the
    // configuration.
    pub fn validate(&mut self) -> ValidationResult<BTreeSet<String>> {
        let mut id_list = BTreeSet::new();

        if self.virtio_iommu_attached() && self.smmuv3_attached() {
            return Err(ValidationError::MixedIommuTypes);
        }

        // Is the payload configuration bootable?
        self.payload
            .as_mut()
            .ok_or(ValidationError::PayloadError(
                PayloadConfigError::MissingBootitem,
            ))?
            .validate()?;

        #[cfg(feature = "sev_snp")]
        {
            let sev_snp_enabled = self.platform.as_ref().is_some_and(|p| p.sev_snp);
            if sev_snp_enabled {
                let host_data_opt = &self.payload.as_ref().unwrap().host_data;
                if let Some(host_data) = host_data_opt
                    && host_data.len() != 64
                {
                    return Err(ValidationError::InvalidHostData);
                }
                // KVM SEV-SNP requires an IGVM payload to initialise the VMSA.
                // Without IGVM the vCPU register state is undefined and VM entry fails.
                #[cfg(feature = "igvm")]
                if self
                    .payload
                    .as_ref()
                    .and_then(|p| p.igvm.as_ref())
                    .is_none()
                {
                    return Err(ValidationError::SevSnpRequiresIgvm);
                }

                #[cfg(feature = "kvm")]
                {
                    #[cfg(feature = "fw_cfg")]
                    let acpi_tables_supplied = self
                        .payload
                        .as_ref()
                        .unwrap()
                        .fw_cfg_config
                        .as_ref()
                        .is_some_and(|fw_cfg| fw_cfg.acpi_tables);
                    #[cfg(not(feature = "fw_cfg"))]
                    let acpi_tables_supplied = false;

                    if !acpi_tables_supplied {
                        return Err(ValidationError::SevSnpRequiresFwCfgAcpi);
                    }
                }

                if self.memory.hotplug_size() > 0 || self.memory.hotplugged_size() > 0 {
                    return Err(ValidationError::SevSnpNoMemoryHotplug);
                }

                #[cfg(not(feature = "kvm"))]
                if self.cpus.max_vcpus != self.cpus.boot_vcpus {
                    return Err(ValidationError::SevSnpNoCpuHotplug);
                }

                if self.memory.hugepages_enabled() {
                    return Err(ValidationError::SevSnpNoHugePages);
                }

                if self.vdpa.as_ref().is_some_and(|d| !d.is_empty()) {
                    return Err(ValidationError::SevSnpNoVdpa);
                }

                if self.devices.as_ref().is_some_and(|d| !d.is_empty())
                    && !self.platform.as_ref().is_some_and(|p| p.iommufd)
                {
                    return Err(ValidationError::SevSnpRequiresIommufd);
                }
            }
        }
        // The 'conflict' check is introduced in commit 24438e0390d3
        // (vm-virtio: Enable the vmm support for virtio-console).
        //
        // Allow simultaneously set serial and console as TTY mode, for
        // someone want to use virtio console for better performance, and
        // want to keep legacy serial to catch boot stage logs for debug.
        // Using such double tty mode, you need to configure the kernel
        // properly, such as:
        // "console=hvc0 earlyprintk=ttyS0"

        let mut tty_consoles = Vec::new();
        if self.console.output == ConsoleOutput::Tty {
            tty_consoles.push("virtio-console");
        }
        if self.serial.output == ConsoleOutput::Tty {
            tty_consoles.push("serial-console");
        }
        #[cfg(target_arch = "x86_64")]
        if self.debug_console.output == ConsoleOutput::Tty {
            tty_consoles.push("debug-console");
        }
        if tty_consoles.len() > 1 {
            warn!("Using TTY output for multiple consoles: {tty_consoles:?}");
        }

        if self.cpus.boot_vcpus == 0 {
            return Err(ValidationError::CpusBootZero);
        }

        if self.cpus.max_vcpus < self.cpus.boot_vcpus {
            return Err(ValidationError::CpusMaxLowerThanBoot(
                self.cpus.max_vcpus,
                self.cpus.boot_vcpus,
            ));
        }

        #[cfg(target_arch = "x86_64")]
        if self.cpus.kvm_hint_realtime && self.cpus.kvm_hyperv {
            return Err(ValidationError::KvmHintRealtimeWithKvmHyperv);
        }

        if !(MIN_PHYS_BITS..=MAX_PHYS_BITS).contains(&self.cpus.max_phys_bits) {
            return Err(ValidationError::InvalidMaxPhysBits(self.cpus.max_phys_bits));
        }

        if self.cpus.max_vcpus > MAX_SUPPORTED_CPUS {
            // Note: historically, Cloud Hypervisor did not support more than 255(254 on x64)
            // vCPUs: self.cpus.max_vcpus was of type u8, so 255 was the maximum;
            // on x86_64, the legacy mptable/apic was limited to 254 CPUs.
            //
            // Now the limit is lifted on x86_64 and aarch64 with KVM. Other
            // targets/archs: TBD.
            return Err(ValidationError::TooManyCpus(self.cpus.max_vcpus));
        }

        #[cfg(target_arch = "aarch64")]
        validate_gic_layout(self.cpus.max_vcpus)?;

        if let Some(affinity) = &self.cpus.affinity {
            for affinity in affinity.iter().flat_map(|affinity| &affinity.host_cpus) {
                let max_affinity = 8 * size_of::<libc::cpu_set_t>();

                if *affinity >= max_affinity {
                    return Err(ValidationError::CpuAffinityExceedsMax(
                        *affinity,
                        max_affinity,
                    ));
                }
            }
        }

        if self.memory.size == 0 && self.memory.zones.is_none() {
            return Err(ValidationError::MemoryZonesMissing);
        }

        if let Some(rate_limit_groups) = &self.rate_limit_groups {
            for rate_limit_group in rate_limit_groups {
                rate_limit_group.validate(self)?;

                Self::validate_identifier(&mut id_list, &Some(rate_limit_group.id.clone()))?;
            }
        }

        if let Some(disks) = &self.disks {
            for disk in disks {
                if disk.vhost_socket.as_ref().and(disk.path.as_ref()).is_some() {
                    return Err(ValidationError::DiskSocketAndPath);
                }
                if disk.vhost_user && !self.backed_by_shared_memory() {
                    return Err(ValidationError::VhostUserRequiresSharedMemory);
                }
                if disk.vhost_user && disk.vhost_socket.is_none() {
                    return Err(ValidationError::VhostUserMissingSocket);
                }
                if disk.vhost_user
                    && (disk.rate_limiter_config.is_some() || disk.rate_limit_group.is_some())
                {
                    return Err(ValidationError::VhostUserRateLimiterNotSupported);
                }
                if let Some(rate_limit_group) = &disk.rate_limit_group {
                    if let Some(rate_limit_groups) = &self.rate_limit_groups {
                        if !rate_limit_groups
                            .iter()
                            .any(|cfg| &cfg.id == rate_limit_group)
                        {
                            return Err(ValidationError::InvalidRateLimiterGroup);
                        }
                    } else {
                        return Err(ValidationError::InvalidRateLimiterGroup);
                    }
                }

                disk.validate(self)?;

                Self::validate_identifier(&mut id_list, &disk.pci_common.id)?;
            }
        }

        if let Some(nets) = &self.net {
            for net in nets {
                if net.vhost_user && !self.backed_by_shared_memory() {
                    return Err(ValidationError::VhostUserRequiresSharedMemory);
                }
                if net.vhost_user && net.vhost_socket.is_none() {
                    return Err(ValidationError::VhostUserMissingSocket);
                }
                if net.vhost_user && net.rate_limiter_config.is_some() {
                    return Err(ValidationError::VhostUserRateLimiterNotSupported);
                }
                net.validate(self)?;

                Self::validate_identifier(&mut id_list, &net.pci_common.id)?;
            }
        }

        if let Some(fses) = &self.fs {
            if !fses.is_empty() && !self.backed_by_shared_memory() {
                return Err(ValidationError::VhostUserRequiresSharedMemory);
            }
            for fs in fses {
                fs.validate(self)?;

                Self::validate_identifier(&mut id_list, &fs.pci_common.id)?;
            }
        }

        if let Some(generic_vhost_user_devices) = &self.generic_vhost_user {
            if !generic_vhost_user_devices.is_empty() && !self.backed_by_shared_memory() {
                return Err(ValidationError::VhostUserRequiresSharedMemory);
            }
            for generic_vhost_user_device in generic_vhost_user_devices {
                generic_vhost_user_device.validate(self)?;

                Self::validate_identifier(&mut id_list, &generic_vhost_user_device.pci_common.id)?;
            }
        }

        if let Some(pmems) = &self.pmem {
            for pmem in pmems {
                pmem.validate(self)?;

                Self::validate_identifier(&mut id_list, &pmem.pci_common.id)?;
            }
        }

        self.rng.validate(self)?;
        Self::validate_identifier(&mut id_list, &self.rng.pci_common.id)?;

        if let Some(rtc) = &self.rtc {
            rtc.validate(self)?;
            Self::validate_identifier(&mut id_list, &rtc.pci_common.id)?;
        }

        self.console.validate(self)?;
        Self::validate_identifier(&mut id_list, &self.console.pci_common.id)?;

        self.serial.validate()?;

        if let Some(t) = &self.cpus.topology {
            if t.threads_per_core == 0
                || t.cores_per_die == 0
                || t.dies_per_package == 0
                || t.packages == 0
            {
                return Err(ValidationError::CpuTopologyZeroPart);
            }

            #[cfg(target_arch = "x86_64")]
            if t.threads_per_core > 2 {
                return Err(ValidationError::CpuTopologyThreadsPerCore);
            }

            // The setting of dies doesn't apply on AArch64.
            // Only '1' value is accepted, so its impact on the vcpu topology
            // setting can be ignored.
            #[cfg(target_arch = "aarch64")]
            if t.dies_per_package != 1 {
                return Err(ValidationError::CpuTopologyDiesPerPackage);
            }

            for count in [
                t.threads_per_core,
                t.cores_per_die,
                t.dies_per_package,
                t.packages,
            ] {
                if u32::from(count) > MAX_SUPPORTED_CPUS {
                    return Err(ValidationError::TooManyCpus(u32::from(count)));
                }
            }

            let total = u64::from(t.threads_per_core)
                * u64::from(t.cores_per_die)
                * u64::from(t.dies_per_package)
                * u64::from(t.packages);
            if total != u64::from(self.cpus.max_vcpus) {
                return Err(ValidationError::CpuTopologyCount);
            }
        }

        if let Some(hugepage_size) = &self.memory.hugepage_size {
            if !self.memory.hugepages {
                return Err(ValidationError::HugePageSizeWithoutHugePages);
            }
            if !hugepage_size.is_power_of_two() {
                return Err(ValidationError::InvalidHugePageSize(*hugepage_size));
            }
        }

        if self.memory.shared && self.memory.mergeable {
            return Err(ValidationError::InvalidSharedMemoryWithMergeable);
        }

        if let Some(zones) = &self.memory.zones {
            for zone in zones {
                if zone.shared && zone.mergeable {
                    return Err(ValidationError::InvalidSharedMemoryWithMergeable);
                }

                if let Some(hugepage_size) = &zone.hugepage_size {
                    if !zone.hugepages {
                        return Err(ValidationError::HugePageSizeWithoutHugePages);
                    }
                    if !hugepage_size.is_power_of_two() {
                        return Err(ValidationError::InvalidHugePageSize(*hugepage_size));
                    }
                }
            }
        }

        if let Some(user_devices) = &self.user_devices {
            if !user_devices.is_empty() && !self.backed_by_shared_memory() {
                return Err(ValidationError::UserDevicesRequireSharedMemory);
            }

            for user_device in user_devices {
                user_device.validate(self)?;

                Self::validate_identifier(&mut id_list, &user_device.pci_common.id)?;
            }
        }

        if let Some(vdpa_devices) = &self.vdpa {
            for vdpa_device in vdpa_devices {
                vdpa_device.validate(self)?;

                Self::validate_identifier(&mut id_list, &vdpa_device.pci_common.id)?;
            }
        }

        if let Some(vsock) = &self.vsock
            && [!0, 0, 1, 2].contains(&vsock.cid)
        {
            return Err(ValidationError::VsockSpecialCid(vsock.cid));
        }

        if let Some(balloon) = &self.balloon {
            balloon.validate(self)?;
            Self::validate_identifier(&mut id_list, &balloon.pci_common.id)?;

            let ram_size = self.memory.total_size();
            if balloon.size >= ram_size {
                return Err(ValidationError::BalloonLargerThanRam(
                    balloon.size,
                    ram_size,
                ));
            }
        }

        if let Some(devices) = &self.devices {
            let mut device_paths = BTreeSet::new();
            for device in devices {
                if let Some(path) = device.path.as_deref()
                    && !device_paths.insert(path.to_string_lossy())
                {
                    return Err(ValidationError::DuplicateDevicePath(
                        path.to_string_lossy().to_string(),
                    ));
                }

                device.validate(self)?;

                Self::validate_identifier(&mut id_list, &device.pci_common.id)?;
            }
        }

        if let Some(vsock) = &self.vsock {
            vsock.validate(self)?;

            Self::validate_identifier(&mut id_list, &vsock.pci_common.id)?;
        }

        let num_pci_segments = match &self.platform {
            Some(platform_config) => platform_config.num_pci_segments,
            None => 1,
        };
        if let Some(numa) = &self.numa {
            let mut used_numa_node_memory_zones = HashMap::new();
            let mut used_pci_segments = HashMap::new();
            for numa_node in numa.iter() {
                numa_node.validate()?;
                if let Some(memory_zones) = &numa_node.memory_zones {
                    for memory_zone in memory_zones.iter() {
                        if let Some(previous_node) = used_numa_node_memory_zones.get(memory_zone) {
                            return Err(ValidationError::MemoryZoneReused(
                                memory_zone.to_string(),
                                *previous_node,
                                numa_node.guest_numa_id,
                            ));
                        }
                        used_numa_node_memory_zones
                            .insert(memory_zone.to_string(), numa_node.guest_numa_id);
                    }
                }

                if let Some(pci_segments) = &numa_node.pci_segments {
                    for pci_segment in pci_segments.iter() {
                        if *pci_segment >= num_pci_segments {
                            return Err(ValidationError::InvalidPciSegment(*pci_segment));
                        }
                        if *pci_segment == 0 && numa_node.guest_numa_id != 0 {
                            return Err(ValidationError::DefaultPciSegmentInvalidNode(
                                numa_node.guest_numa_id,
                            ));
                        }
                        if let Some(previous_node) = used_pci_segments.get(pci_segment) {
                            return Err(ValidationError::PciSegmentReused(
                                *pci_segment,
                                *previous_node,
                                numa_node.guest_numa_id,
                            ));
                        }
                        used_pci_segments.insert(*pci_segment, numa_node.guest_numa_id);
                    }
                }
            }
        }

        if let Some(zones) = &self.memory.zones {
            for zone in zones.iter() {
                let id = zone.id.clone();
                Self::validate_identifier(&mut id_list, &Some(id))?;
            }
        }

        if let Some(pci_segments) = &self.pci_segments {
            for pci_segment in pci_segments {
                pci_segment.validate(self)?;
            }
        }

        self.platform.as_ref().map(|p| p.validate()).transpose()?;
        self.iommu = self.virtio_iommu_attached();

        #[cfg(feature = "sev_snp")]
        if self.virtio_iommu_attached() && self.platform.as_ref().is_some_and(|p| p.sev_snp) {
            return Err(ValidationError::SevSnpNoViommu);
        }

        if let Some(landlock_rules) = &self.landlock_rules {
            for landlock_rule in landlock_rules {
                landlock_rule.validate()?;
            }
        }
        #[cfg(feature = "ivshmem")]
        if let Some(ivshmem_config) = &self.ivshmem {
            ivshmem_config.validate(self)?;
            Self::validate_identifier(&mut id_list, &ivshmem_config.pci_common.id)?;
        }

        Ok(id_list)
    }

    /// # Safety
    /// Live FDs named in the input must be exclusively owned by the caller.
    /// Referenced descriptors may be consumed even if parsing fails.
    pub unsafe fn parse(vm_params: VmParams) -> Result<Self> {
        validate_inherited_fds(
            vm_params
                .net
                .iter()
                .flatten()
                .copied()
                .chain(vm_params.devices.iter().flatten().copied())
                .chain(vm_params.platform),
        )?;

        let mut rate_limit_groups: Option<Box<[RateLimiterGroupConfig]>> = None;
        if let Some(rate_limit_group_list) = &vm_params.rate_limit_groups {
            let mut rate_limit_group_config_list = Vec::new();
            for item in rate_limit_group_list.iter() {
                let rate_limit_group_config = RateLimiterGroupConfig::parse(item)?;
                rate_limit_group_config_list.push(rate_limit_group_config);
            }
            rate_limit_groups = Some(rate_limit_group_config_list.into_boxed_slice());
        }

        let mut disks: Option<Vec<DiskConfig>> = None;
        if let Some(disk_list) = &vm_params.disks {
            let mut disk_config_list = Vec::new();
            for item in disk_list.iter() {
                let disk_config = DiskConfig::parse(item)?;
                disk_config_list.push(disk_config);
            }
            disks = Some(disk_config_list);
        }

        #[cfg(feature = "fw_cfg")]
        let fw_cfg_config = if let Some(fw_cfg_config_str) = vm_params.fw_cfg_config {
            let fw_cfg_config = FwCfgConfig::parse(fw_cfg_config_str)?;
            Some(fw_cfg_config)
        } else {
            None
        };

        let mut net: Option<Vec<NetConfig>> = None;
        if let Some(net_list) = &vm_params.net {
            let mut net_config_list = Vec::new();
            for item in net_list.iter() {
                // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
                let net_config = unsafe { NetConfig::parse(item) }?;
                net_config_list.push(net_config);
            }
            net = Some(net_config_list);
        }

        let rng = RngConfig::parse(vm_params.rng)?;

        let mut rtc: Option<RtcConfig> = None;
        if let Some(rtc_params) = &vm_params.rtc {
            rtc = Some(RtcConfig::parse(rtc_params)?);
        }

        let mut balloon: Option<BalloonConfig> = None;
        if let Some(balloon_params) = &vm_params.balloon {
            balloon = Some(BalloonConfig::parse(balloon_params)?);
        }

        #[cfg(feature = "pvmemcontrol")]
        let pvmemcontrol: Option<PvmemcontrolConfig> = vm_params
            .pvmemcontrol
            .then_some(PvmemcontrolConfig::default());

        let mut fs: Option<Vec<FsConfig>> = None;
        if let Some(fs_list) = &vm_params.fs {
            let mut fs_config_list = Vec::new();
            for item in fs_list.iter() {
                fs_config_list.push(FsConfig::parse(item)?);
            }
            fs = Some(fs_config_list);
        }

        let mut generic_vhost_user: Option<Vec<GenericVhostUserConfig>> = None;
        if let Some(generic_vhost_user_list) = &vm_params.generic_vhost_user {
            let mut generic_vhost_user_config_list = Vec::new();
            for item in generic_vhost_user_list.iter() {
                generic_vhost_user_config_list.push(GenericVhostUserConfig::parse(item)?);
            }
            generic_vhost_user = Some(generic_vhost_user_config_list);
        }

        let mut pmem: Option<Vec<PmemConfig>> = None;
        if let Some(pmem_list) = &vm_params.pmem {
            let mut pmem_config_list = Vec::new();
            for item in pmem_list.iter() {
                let pmem_config = PmemConfig::parse(item)?;
                pmem_config_list.push(pmem_config);
            }
            pmem = Some(pmem_config_list);
        }

        let console = ConsoleConfig::parse(vm_params.console)?;
        let serial = SerialConfig::parse(vm_params.serial)?;
        #[cfg(target_arch = "x86_64")]
        let debug_console = DebugConsoleConfig::parse(vm_params.debug_console)?;

        let mut devices: Option<Vec<DeviceConfig>> = None;
        if let Some(device_list) = &vm_params.devices {
            let mut device_config_list = Vec::new();
            for item in device_list.iter() {
                // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
                let device_config = unsafe { DeviceConfig::parse(item) }?;
                device_config_list.push(device_config);
            }
            devices = Some(device_config_list);
        }

        let mut user_devices: Option<Vec<UserDeviceConfig>> = None;
        if let Some(user_device_list) = &vm_params.user_devices {
            let mut user_device_config_list = Vec::new();
            for item in user_device_list.iter() {
                let user_device_config = UserDeviceConfig::parse(item)?;
                user_device_config_list.push(user_device_config);
            }
            user_devices = Some(user_device_config_list);
        }

        let mut vdpa: Option<Vec<VdpaConfig>> = None;
        if let Some(vdpa_list) = &vm_params.vdpa {
            let mut vdpa_config_list = Vec::new();
            for item in vdpa_list.iter() {
                let vdpa_config = VdpaConfig::parse(item)?;
                vdpa_config_list.push(vdpa_config);
            }
            vdpa = Some(vdpa_config_list);
        }

        let mut vsock: Option<VsockConfig> = None;
        if let Some(vs) = &vm_params.vsock {
            let vsock_config = VsockConfig::parse(vs)?;
            vsock = Some(vsock_config);
        }

        let mut pci_segments: Option<Box<[PciSegmentConfig]>> = None;
        if let Some(pci_segment_list) = &vm_params.pci_segments {
            let mut pci_segment_config_list = Vec::new();
            for item in pci_segment_list.iter() {
                let pci_segment_config = PciSegmentConfig::parse(item)?;
                pci_segment_config_list.push(pci_segment_config);
            }
            pci_segments = Some(pci_segment_config_list.into_boxed_slice());
        }

        let platform = vm_params
            .platform
            // SAFETY: The caller transfers ownership of the inherited CLI descriptors.
            .map(|platform| unsafe { PlatformConfig::parse(platform) })
            .transpose()?;

        let mut numa: Option<Box<[NumaConfig]>> = None;
        if let Some(numa_list) = &vm_params.numa {
            let mut numa_config_list = Vec::new();
            for item in numa_list.iter() {
                let numa_config = NumaConfig::parse(item)?;
                numa_config_list.push(numa_config);
            }
            numa = Some(numa_config_list.into_boxed_slice());
        }

        #[cfg(not(feature = "igvm"))]
        let payload_present = vm_params.kernel.is_some() || vm_params.firmware.is_some();

        #[cfg(feature = "igvm")]
        let payload_present =
            vm_params.kernel.is_some() || vm_params.firmware.is_some() || vm_params.igvm.is_some();

        let payload = if payload_present {
            Some(PayloadConfig {
                kernel: vm_params.kernel.map(PathBuf::from),
                initramfs: vm_params.initramfs.map(PathBuf::from),
                cmdline: vm_params.cmdline.map(|s| s.to_string()),
                firmware: vm_params.firmware.map(PathBuf::from),
                #[cfg(feature = "igvm")]
                igvm: vm_params.igvm.map(PathBuf::from),
                #[cfg(feature = "sev_snp")]
                host_data: vm_params.host_data.map(|s| s.to_string()),
                #[cfg(feature = "fw_cfg")]
                fw_cfg_config,
            })
        } else {
            None
        };

        let mut tpm: Option<TpmConfig> = None;
        if let Some(tc) = vm_params.tpm {
            let tpm_conf = TpmConfig::parse(tc)?;
            tpm = Some(TpmConfig {
                socket: tpm_conf.socket,
            });
        }

        #[cfg(feature = "guest_debug")]
        let gdb = vm_params.gdb;

        let mut landlock_rules: Option<Box<[LandlockConfig]>> = None;
        if let Some(ll_rules) = vm_params.landlock_rules {
            landlock_rules = Some(
                ll_rules
                    .iter()
                    .map(|rule| LandlockConfig::parse(rule))
                    .collect::<Result<Vec<LandlockConfig>>>()?
                    .into_boxed_slice(),
            );
        }

        #[cfg(feature = "ivshmem")]
        let mut ivshmem: Option<IvshmemConfig> = None;
        #[cfg(feature = "ivshmem")]
        if let Some(iv) = vm_params.ivshmem {
            let ivshmem_conf = IvshmemConfig::parse(iv)?;
            ivshmem = Some(ivshmem_conf);
        }

        let mut config = VmConfig {
            cpus: CpusConfig::parse(vm_params.cpus)?,
            memory: MemoryConfig::parse(vm_params.memory, vm_params.memory_zones)?,
            payload,
            rate_limit_groups,
            disks,
            net,
            rng,
            balloon,
            generic_vhost_user,
            fs,
            pmem,
            serial,
            console,
            #[cfg(target_arch = "x86_64")]
            debug_console,
            devices,
            user_devices,
            vdpa,
            vsock,
            #[cfg(feature = "pvmemcontrol")]
            pvmemcontrol,
            pvpanic: vm_params.pvpanic,
            iommu: false, // updated in VmConfig::validate()
            numa,
            watchdog: vm_params.watchdog,
            rtc,
            #[cfg(feature = "guest_debug")]
            gdb,
            pci_segments,
            platform,
            tpm,
            landlock_enable: vm_params.landlock_enable,
            landlock_rules,
            #[cfg(feature = "ivshmem")]
            ivshmem,
        };
        config.validate().map_err(Error::Validation)?;
        Ok(config)
    }

    pub fn remove_device(&mut self, id: &str) -> bool {
        let mut removed = false;

        // Remove if VFIO device
        if let Some(devices) = self.devices.as_mut() {
            let len = devices.len();
            devices.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= devices.len() != len;
        }

        // Remove if VFIO user device
        if let Some(user_devices) = self.user_devices.as_mut() {
            let len = user_devices.len();
            user_devices.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= user_devices.len() != len;
        }

        // Remove if disk device
        if let Some(disks) = self.disks.as_mut() {
            let len = disks.len();
            disks.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= disks.len() != len;
        }

        // Remove if fs device
        if let Some(fs) = self.fs.as_mut() {
            let len = fs.len();
            fs.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= fs.len() != len;
        }

        // Remove if generic vhost-user device
        if let Some(generic_vhost_user) = self.generic_vhost_user.as_mut() {
            let len = generic_vhost_user.len();
            generic_vhost_user.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= generic_vhost_user.len() != len;
        }

        // Remove if net device
        if let Some(net) = self.net.as_mut() {
            let len = net.len();
            net.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= net.len() != len;
        }

        // Remove if pmem device
        if let Some(pmem) = self.pmem.as_mut() {
            let len = pmem.len();
            pmem.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= pmem.len() != len;
        }

        // Remove if vDPA device
        if let Some(vdpa) = self.vdpa.as_mut() {
            let len = vdpa.len();
            vdpa.retain(|dev| dev.pci_common.id.as_deref() != Some(id));
            removed |= vdpa.len() != len;
        }

        // Remove if vsock device
        removed |= self
            .vsock
            .take_if(|vsock| vsock.pci_common.id.as_deref() == Some(id))
            .is_some();

        removed
    }

    #[cfg(feature = "sev_snp")]
    pub fn is_sev_snp_enabled(&self) -> bool {
        self.platform.as_ref().is_some_and(|p| p.sev_snp)
    }
}

/// # Safety
/// A live fd must be exclusively owned by the caller, which transfers it here.
pub(crate) unsafe fn take_inherited_fd(fd: impl TryInto<RawFd>) -> Result<ExternalFd> {
    let fd = fd
        .try_into()
        .map_err(|_| Error::InheritedFd(io::Error::from_raw_os_error(libc::EBADF)))?;
    // SAFETY: F_GETFD takes no pointer arguments and rejects invalid FDs.
    if fd < 3 || unsafe { libc::fcntl(fd, libc::F_GETFD) } < 0 {
        return Err(Error::InheritedFd(io::Error::from_raw_os_error(
            libc::EBADF,
        )));
    }
    // SAFETY: The caller transfers exclusive ownership of the validated FD.
    Ok(unsafe { OwnedFd::from_raw_fd(fd) }.into())
}

// Check all references before taking ownership so repeated CLI FDs cannot
// create two owners for the same FD.
pub(crate) fn validate_inherited_fds<'a>(configs: impl IntoIterator<Item = &'a str>) -> Result<()> {
    let mut seen = HashSet::new();
    for config in configs {
        let mut parser = OptionParser::new();
        parser
            .add("fd")
            .add("iommufd_fd")
            .add("net_fds")
            .add("vfio_fds")
            .add("external_fds");
        // The regular config parser reports malformed values.
        if parser.parse_subset(config).is_err() {
            continue;
        }
        let mut fds = parser
            .convert::<IntegerList>("fd")
            .ok()
            .flatten()
            .map_or_else(
                || {
                    parser
                        .convert::<u64>("fd")
                        .ok()
                        .flatten()
                        .into_iter()
                        .collect()
                },
                |fds| fds.0,
            );
        fds.extend(parser.convert::<u64>("iommufd_fd").ok().flatten());
        if let Some(pairs) = parser
            .convert::<TupleList<String, Vec<u64>>>("net_fds")
            .ok()
            .flatten()
        {
            fds.extend(pairs.0.into_iter().flat_map(|Tuple(_, fds)| fds));
        }
        if let Some(pairs) = parser
            .convert::<TupleList<String, u64>>("vfio_fds")
            .ok()
            .flatten()
        {
            fds.extend(pairs.0.into_iter().map(|Tuple(_, fd)| fd));
        }
        if let Some(pairs) = parser
            .convert::<TupleList<Target, Vec<u64>>>("external_fds")
            .ok()
            .flatten()
        {
            fds.extend(pairs.0.into_iter().flat_map(|Tuple(_, fds)| fds));
        }
        for fd in fds {
            if let Ok(fd) = RawFd::try_from(fd)
                && !seen.insert(fd)
            {
                return Err(Error::DuplicateInheritedFd(fd));
            }
        }
    }
    Ok(())
}

#[cfg(test)]
pub(crate) mod tests {
    use std::fs::File;
    use std::os::unix::io::AsRawFd;
    #[cfg(target_arch = "x86_64")]
    use std::{env, fs};

    use net_util::MacAddr;

    use super::*;
    use crate::external_fds::tests::{net_target, vfio_target};
    use crate::tests::test_fd;

    #[test]
    fn test_vfio_binding_state_is_runtime_only() {
        let fd: ExternalFd = test_fd().into();

        let mut config: VmConfig = serde_json::from_str("{}").unwrap();
        let mut device = device_fixture();
        device.fd = fd.clone();
        assert!(device.iommufd_dev_id.is_none());
        device.iommufd_dev_id = Some(7);
        config.devices = Some(vec![device]);
        assert_eq!(
            config.clone().devices.as_ref().unwrap()[0].iommufd_dev_id,
            Some(7)
        );

        let json = serde_json::to_string(&config).unwrap();
        assert!(!json.contains("iommufd_dev_id"));
        let restored: VmConfig = serde_json::from_str(&json).unwrap();
        assert!(
            restored.devices.as_ref().unwrap()[0]
                .iommufd_dev_id
                .is_none()
        );
    }

    #[test]
    fn test_take_inherited_fd() {
        use std::os::fd::IntoRawFd;

        // SAFETY: These values cannot name live descriptors.
        unsafe {
            take_inherited_fd(-1).unwrap_err();
            take_inherited_fd(u64::MAX).unwrap_err();
        }
        let fd = test_fd().into_raw_fd();
        assert_eq!(
            // SAFETY: into_raw_fd transferred exclusive ownership of the descriptor.
            unsafe { take_inherited_fd(fd) }
                .unwrap()
                .as_ref()
                .unwrap()
                .as_raw_fd(),
            fd
        );
        for input in [
            vec!["fd=[3,3]"],
            vec!["fd=3", "iommufd_fd=3"],
            vec!["net_fds=[net0@[3,4]],vfio_fds=[vfio0@4]"],
            vec!["fd= [3,3]"],
        ] {
            assert!(matches!(
                validate_inherited_fds(input),
                Err(Error::DuplicateInheritedFd(_))
            ));
        }
        validate_inherited_fds(["fd=[3,4]", "fd=5", "iommufd_fd=6"]).unwrap();
    }

    #[test]
    fn test_validate_inherited_external_fds() {
        for input in [
            vec!["external_fds=[net(net0)@[3,3]]"],
            vec!["external_fds=[net(net0)@[3,4],vfio(vfio0)@[3]]"],
            vec!["external_fds=[vfio(vfio0)@[3],iommu@[3]]"],
            vec!["net_fds=[net0@[3,4]],external_fds=[net(net1)@[3]]"],
            vec!["vfio_fds=[vfio0@3],external_fds=[vfio(vfio1)@[3]]"],
            vec!["iommufd_fd=3,external_fds=[iommu@[3]]"],
            vec!["fd=3", "external_fds=[net(net0)@[3]]"],
            vec![
                "external_fds=[net(net0)@[3]]",
                "external_fds=[net(net1)@[3]]",
            ],
        ] {
            assert!(matches!(
                validate_inherited_fds(input),
                Err(Error::DuplicateInheritedFd(3))
            ));
        }
        validate_inherited_fds([
            "fd=3",
            "net_fds=[net0@[4,5]],vfio_fds=[vfio0@6],iommufd_fd=7,external_fds=[net(net1)@[8,9],vfio(vfio1)@[10],iommu@[11]]",
        ])
        .unwrap();
    }

    #[cfg(target_arch = "aarch64")]
    #[test]
    fn test_validate_gic_layout() {
        let floor = arch::layout::UEFI_START.0 + arch::layout::UEFI_SIZE;
        let its_base = |n: u64| {
            arch::layout::GIC_V3_DIST_START.0
                - n * arch::layout::GIC_V3_REDIST_SIZE
                - arch::layout::GIC_V3_ITS_SIZE
        };
        let mut last = 0;
        while its_base(last + 1) >= floor {
            last += 1;
        }
        let last = u32::try_from(last).unwrap();

        validate_gic_layout(last).unwrap();
        assert_eq!(
            validate_gic_layout(last + 1),
            Err(ValidationError::TooManyCpusForGic(last + 1, last.into()))
        );
    }

    #[cfg(target_arch = "x86_64")]
    #[test]
    fn test_cpuid_override_parsing_and_serialization() {
        let config = CpusConfig::parse(
            "boot=2,x-cpuid-overrides=[[0x7,0x0,0x1,0x2,0x3,0x4], [0x80000001, 0x0, 0x0, 0x0, 0xFFFFFFFF, 0x0]],max=4",
        )
        .unwrap();
        assert_eq!(config.boot_vcpus, 2);
        assert_eq!(config.max_vcpus, 4);
        assert_eq!(
            config.cpuid_overrides,
            vec![
                CpuidOverride {
                    leaf: 7,
                    subleaf: 0,
                    eax: 1,
                    ebx: 2,
                    ecx: 3,
                    edx: 4,
                },
                CpuidOverride {
                    leaf: 0x80000001,
                    subleaf: 0,
                    eax: 0,
                    ebx: 0,
                    ecx: u32::MAX,
                    edx: 0,
                },
            ]
        );
        let json = serde_json::to_string(&config).unwrap();
        assert_eq!(serde_json::from_str::<CpusConfig>(&json).unwrap(), config);
        assert_eq!(
            serde_json::to_value(&config).unwrap()["x-cpuid-overrides"][1]["ecx"],
            "0xffffffff"
        );
        assert_eq!(
            CpusConfig::parse("x-cpuid-overrides=[]").unwrap(),
            CpusConfig::default()
        );
        assert!(
            serde_json::to_value(CpusConfig::default())
                .unwrap()
                .get("x-cpuid-overrides")
                .is_none()
        );
        assert_eq!(
            serde_json::from_str::<CpusConfig>(r#"{"boot_vcpus":1,"max_vcpus":1}"#).unwrap(),
            CpusConfig::default()
        );
    }

    #[cfg(target_arch = "x86_64")]
    #[test]
    fn test_cpuid_override_invalid_input() {
        for value in [
            "0x7",
            "[0x7,0x0,0x0,0x0,0x0,0x0]",
            "[[0x7,0x0,0x0,0x0,0x0]]",
            "[[0x7,0x0,0x0,0x0,0x0,0x0,0x0]]",
            "[[7,0x0,0x0,0x0,0x0,0x0]]",
            "[[0x100000000,0x0,0x0,0x0,0x0,0x0]]",
            "[[0x7,0x0,0x0,0x0,0x0,0xZZ]]",
            "[[0x7,0x0,0x0,0x0,0x0,0x0],]",
            "[[0x7,0x0,0x0,0x0,0x0,0x0]",
        ] {
            assert!(
                CpusConfig::parse(&format!("x-cpuid-overrides={value}")).is_err(),
                "{value}"
            );
        }
        for value in [
            r#"{"leaf":"0x100000000","subleaf":"0x0","eax":"0x0","ebx":"0x0","ecx":"0x0","edx":"0x0"}"#,
            r#"{"leaf":7,"subleaf":"0x0","eax":"0x0","ebx":"0x0","ecx":"0x0","edx":"0x0"}"#,
            r#"{"leaf":"7","subleaf":"0x0","eax":"0x0","ebx":"0x0","ecx":"0x0","edx":"0x0"}"#,
        ] {
            assert!(
                serde_json::from_str::<CpuidOverride>(value).is_err(),
                "{value}"
            );
        }
    }

    #[test]
    fn test_cpu_parsing() -> Result<()> {
        assert_eq!(CpusConfig::parse("")?, CpusConfig::default());
        for host in ["host", "Host", "HOST"] {
            assert_eq!(
                CpusConfig::parse(&format!("profile={host}"))?,
                CpusConfig::default()
            );
        }
        assert_eq!(CpusConfig::parse("profile=")?, CpusConfig::default());
        assert!(CpusConfig::parse("nested=on")?.nested);
        assert!(!CpusConfig::parse("nested=off")?.nested);

        assert_eq!(
            CpusConfig::parse("boot=1")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                ..Default::default()
            }
        );
        assert_eq!(
            CpusConfig::parse("boot=1,max=2")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 2,
                ..Default::default()
            }
        );
        assert_eq!(
            CpusConfig::parse("boot=8,topology=2:2:1:2")?,
            CpusConfig {
                boot_vcpus: 8,
                max_vcpus: 8,
                topology: Some(CpuTopology {
                    threads_per_core: 2,
                    cores_per_die: 2,
                    dies_per_package: 1,
                    packages: 2
                }),
                ..Default::default()
            }
        );

        CpusConfig::parse("boot=8,topology=2:2:1").unwrap_err();
        CpusConfig::parse("boot=8,topology=2:2:1:x").unwrap_err();
        assert_eq!(
            CpusConfig::parse("boot=1,kvm_hyperv=on")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                kvm_hyperv: true,
                ..Default::default()
            }
        );
        #[cfg(target_arch = "x86_64")]
        {
            assert_eq!(
                CpusConfig::parse("boot=1,kvm_hint_realtime=on")?,
                CpusConfig {
                    boot_vcpus: 1,
                    max_vcpus: 1,
                    kvm_hint_realtime: true,
                    ..Default::default()
                }
            );
            assert!(!CpusConfig::parse("boot=1")?.kvm_hint_realtime);
            CpusConfig::parse("boot=1,kvm_hint_realtime=maybe").unwrap_err();
        }
        assert_eq!(
            CpusConfig::parse("boot=2,affinity=[0@[0,2],1@[1,3]]")?,
            CpusConfig {
                boot_vcpus: 2,
                max_vcpus: 2,
                affinity: Some(Box::new([
                    CpuAffinity {
                        vcpu: 0,
                        host_cpus: Box::new([0, 2]),
                    },
                    CpuAffinity {
                        vcpu: 1,
                        host_cpus: Box::new([1, 3]),
                    }
                ])),
                ..Default::default()
            },
        );

        // Test core_scheduling parsing
        assert_eq!(
            CpusConfig::parse("boot=1,core_scheduling=vm")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                core_scheduling: CoreScheduling::Vm,
                ..Default::default()
            }
        );
        assert_eq!(
            CpusConfig::parse("boot=1,core_scheduling=vcpu")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                core_scheduling: CoreScheduling::Vcpu,
                ..Default::default()
            }
        );
        assert_eq!(
            CpusConfig::parse("boot=1,core_scheduling=off")?,
            CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                core_scheduling: CoreScheduling::Off,
                ..Default::default()
            }
        );
        // Default (no core_scheduling specified) should be Vm
        assert_eq!(
            CpusConfig::parse("boot=1")?.core_scheduling,
            CoreScheduling::Vm
        );
        // Invalid value should error
        CpusConfig::parse("boot=1,core_scheduling=invalid").unwrap_err();

        Ok(())
    }

    #[cfg(target_arch = "x86_64")]
    #[test]
    fn test_cpu_profile_file_parsing() -> Result<()> {
        use vmm_sys_util::tempfile::TempFile;

        let (input, config) = {
            let file = TempFile::new_with_prefix(
                env::temp_dir().join("cpu profile:with,commas[and]=signs-"),
            )
            .unwrap();
            // Parsing the selector must not read or validate the file contents.
            fs::write(file.as_path(), "invalid json").unwrap();
            let input = format!(
                r#"boot=2,profile="path:{}",max=4"#,
                file.as_path().display()
            );
            let config = CpusConfig::parse(&input)?;
            assert_eq!(
                config.profile,
                CpuProfileConfig::File(file.as_path().to_owned())
            );
            (input, config)
        };

        assert_eq!(CpusConfig::parse(&input)?, config);
        Ok(())
    }

    #[test]
    fn test_mem_zone_parsing() -> Result<()> {
        // mergeable defaults to false
        assert_eq!(
            MemoryConfig::parse("size=0", Some(vec!["id=mem0,size=1G"]))?,
            MemoryConfig {
                size: 0,
                zones: Some(vec![MemoryZoneConfig {
                    id: "mem0".to_string(),
                    size: 1 << 30,
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        // mergeable=on
        assert_eq!(
            MemoryConfig::parse("size=0", Some(vec!["id=mem0,size=1G,mergeable=on"]))?,
            MemoryConfig {
                size: 0,
                zones: Some(vec![MemoryZoneConfig {
                    id: "mem0".to_string(),
                    size: 1 << 30,
                    mergeable: true,
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        // mergeable=off is explicit false
        assert_eq!(
            MemoryConfig::parse("size=0", Some(vec!["id=mem0,size=1G,mergeable=off"]))?,
            MemoryConfig {
                size: 0,
                zones: Some(vec![MemoryZoneConfig {
                    id: "mem0".to_string(),
                    size: 1 << 30,
                    mergeable: false,
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        // per-zone mergeable independent of global mergeable
        assert_eq!(
            MemoryConfig::parse(
                "size=1G,mergeable=off",
                Some(vec!["id=hotplug,size=0,hotplug_size=4G,mergeable=on"])
            )?,
            MemoryConfig {
                size: 1 << 30,
                mergeable: false,
                hotplug_method: HotplugMethod::Acpi,
                zones: Some(vec![MemoryZoneConfig {
                    id: "hotplug".to_string(),
                    size: 0,
                    hotplug_size: Some(4 << 30),
                    mergeable: true,
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        // global mergeable=on inherited by zone with no explicit mergeable
        assert_eq!(
            MemoryConfig::parse("size=0,mergeable=on", Some(vec!["id=mem0,size=1G"]))?,
            MemoryConfig {
                size: 0,
                mergeable: true,
                zones: Some(vec![MemoryZoneConfig {
                    id: "mem0".to_string(),
                    size: 1 << 30,
                    mergeable: true,
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        // reserve=on on a zone
        assert_eq!(
            MemoryConfig::parse("size=0", Some(vec!["id=mem0,size=1G,reserve=on"]))?,
            MemoryConfig {
                size: 0,
                zones: Some(vec![MemoryZoneConfig {
                    id: "mem0".to_string(),
                    size: 1 << 30,
                    reserve: Some(true),
                    ..Default::default()
                }]),
                ..Default::default()
            }
        );
        Ok(())
    }

    #[test]
    fn test_mem_parsing() -> Result<()> {
        assert_eq!(MemoryConfig::parse("", None)?, MemoryConfig::default());
        MemoryConfig::parse("size=512M,file=/some/file", None).unwrap_err();
        // Default string
        assert_eq!(
            MemoryConfig::parse("size=512M", None)?,
            MemoryConfig::default()
        );
        assert_eq!(
            MemoryConfig::parse("size=512M,mergeable=on", None)?,
            MemoryConfig {
                size: 512 << 20,
                mergeable: true,
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("mergeable=on", None)?,
            MemoryConfig {
                mergeable: true,
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("size=1G,mergeable=off", None)?,
            MemoryConfig {
                size: 1 << 30,
                mergeable: false,
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("hotplug_method=acpi", None)?,
            MemoryConfig {
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("hotplug_method=acpi,hotplug_size=512M", None)?,
            MemoryConfig {
                hotplug_size: Some(512 << 20),
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("hotplug_method=virtio-mem,hotplug_size=512M", None)?,
            MemoryConfig {
                hotplug_size: Some(512 << 20),
                hotplug_method: HotplugMethod::VirtioMem,
                ..Default::default()
            }
        );
        assert_eq!(
            MemoryConfig::parse("hugepages=on,size=1G,hugepage_size=2M", None)?,
            MemoryConfig {
                hugepage_size: Some(2 << 20),
                size: 1 << 30,
                hugepages: true,
                ..Default::default()
            }
        );
        // reserve=on opts out of MAP_NORESERVE
        assert_eq!(
            MemoryConfig::parse("size=1G,hugepages=on,reserve=on", None)?,
            MemoryConfig {
                size: 1 << 30,
                hugepages: true,
                reserve: Some(true),
                ..Default::default()
            }
        );
        Ok(())
    }

    #[test]
    fn test_rate_limit_group_parsing() -> Result<()> {
        assert_eq!(
            RateLimiterGroupConfig::parse("id=group0,bw_size=1000,bw_refill_time=100")?,
            RateLimiterGroupConfig {
                id: "group0".to_string(),
                rate_limiter_config: RateLimiterConfig {
                    bandwidth: Some(TokenBucketConfig {
                        size: 1000,
                        one_time_burst: Some(0),
                        refill_time: 100,
                        burst_rate: None,
                        burst_seconds: None,
                        burst_recharge_seconds: None,
                    }),
                    ops: None,
                }
            }
        );
        assert_eq!(
            RateLimiterGroupConfig::parse("id=group0,ops_size=1000,ops_refill_time=100")?,
            RateLimiterGroupConfig {
                id: "group0".to_string(),
                rate_limiter_config: RateLimiterConfig {
                    bandwidth: None,
                    ops: Some(TokenBucketConfig {
                        size: 1000,
                        one_time_burst: Some(0),
                        refill_time: 100,
                        burst_rate: None,
                        burst_seconds: None,
                        burst_recharge_seconds: None,
                    }),
                }
            }
        );
        Ok(())
    }

    fn parse_rate_limiter_configs(options: &str) -> [RateLimiterConfig; 3] {
        [
            DiskConfig::parse(options)
                .unwrap()
                .rate_limiter_config
                .unwrap(),
            // SAFETY: These test inputs contain no inherited descriptors.
            unsafe { NetConfig::parse(options) }
                .unwrap()
                .rate_limiter_config
                .unwrap(),
            RateLimiterGroupConfig::parse(options)
                .unwrap()
                .rate_limiter_config,
        ]
    }

    #[test]
    fn test_rate_limiter_burst_parsing() {
        let options = "bw_size=1000,bw_refill_time=1000,bw_burst_rate=2000,bw_burst_seconds=3,\
            ops_size=100,ops_refill_time=1000,ops_burst_rate=400,ops_burst_seconds=2";
        let expected = RateLimiterConfig {
            bandwidth: Some(TokenBucketConfig {
                size: 1000,
                one_time_burst: Some(0),
                refill_time: 1000,
                burst_rate: Some(2000),
                burst_seconds: Some(3),
                burst_recharge_seconds: None,
            }),
            ops: Some(TokenBucketConfig {
                size: 100,
                one_time_burst: Some(0),
                refill_time: 1000,
                burst_rate: Some(400),
                burst_seconds: Some(2),
                burst_recharge_seconds: None,
            }),
        };
        for config in parse_rate_limiter_configs(options) {
            assert_eq!(config, expected);
        }

        let options = "bw_size=1000,bw_refill_time=1000,bw_burst_rate=2000,\
            ops_size=100,ops_refill_time=1000,ops_burst_rate=400";
        let expected = RateLimiterConfig {
            bandwidth: expected.bandwidth.map(|b| TokenBucketConfig {
                burst_seconds: None,
                ..b
            }),
            ops: expected.ops.map(|b| TokenBucketConfig {
                burst_seconds: None,
                ..b
            }),
        };
        for config in parse_rate_limiter_configs(options) {
            assert_eq!(config, expected);
        }
    }

    #[test]
    fn test_rate_limiter_burst_recharge_parsing() {
        let options = "bw_size=1000,bw_refill_time=1000,bw_burst_rate=2000,bw_burst_seconds=3,\
            bw_burst_recharge_seconds=4,ops_size=100,ops_refill_time=1000,ops_burst_rate=400,\
            ops_burst_seconds=2,ops_burst_recharge_seconds=5";
        let expected = RateLimiterConfig {
            bandwidth: Some(TokenBucketConfig {
                size: 1000,
                one_time_burst: Some(0),
                refill_time: 1000,
                burst_rate: Some(2000),
                burst_seconds: Some(3),
                burst_recharge_seconds: Some(4),
            }),
            ops: Some(TokenBucketConfig {
                size: 100,
                one_time_burst: Some(0),
                refill_time: 1000,
                burst_rate: Some(400),
                burst_seconds: Some(2),
                burst_recharge_seconds: Some(5),
            }),
        };
        for config in parse_rate_limiter_configs(options) {
            assert_eq!(config, expected);
            for result in rate_limiter_validation_results(config) {
                result.unwrap();
            }
        }
    }

    #[test]
    fn test_rate_limiter_plain_parsing() {
        let options = "bw_size=1000,bw_refill_time=100,bw_one_time_burst=2000,\
            ops_size=100,ops_refill_time=100,ops_one_time_burst=200";
        let expected = RateLimiterConfig {
            bandwidth: Some(TokenBucketConfig {
                size: 1000,
                one_time_burst: Some(2000),
                refill_time: 100,
                burst_rate: None,
                burst_seconds: None,
                burst_recharge_seconds: None,
            }),
            ops: Some(TokenBucketConfig {
                size: 100,
                one_time_burst: Some(200),
                refill_time: 100,
                burst_rate: None,
                burst_seconds: None,
                burst_recharge_seconds: None,
            }),
        };
        for config in parse_rate_limiter_configs(options) {
            assert_eq!(config, expected);
        }

        for config in parse_rate_limiter_configs(
            "bw_size=1000,bw_refill_time=100,ops_size=100,ops_refill_time=100",
        ) {
            assert_eq!(
                config,
                RateLimiterConfig {
                    bandwidth: expected.bandwidth.map(|b| TokenBucketConfig {
                        one_time_burst: Some(0),
                        ..b
                    }),
                    ops: expected.ops.map(|b| TokenBucketConfig {
                        one_time_burst: Some(0),
                        ..b
                    }),
                }
            );
        }

        for options in ["", "bw_size=1000", "ops_refill_time=100"] {
            assert_eq!(
                DiskConfig::parse(options).unwrap().rate_limiter_config,
                None
            );
            assert_eq!(
                // SAFETY: These test inputs contain no inherited descriptors.
                unsafe { NetConfig::parse(options) }
                    .unwrap()
                    .rate_limiter_config,
                None
            );
            assert_eq!(
                RateLimiterGroupConfig::parse(options)
                    .unwrap()
                    .rate_limiter_config,
                RateLimiterConfig::default()
            );
        }
    }

    fn rate_limiter_validation_results(cfg: RateLimiterConfig) -> [ValidationResult<()>; 3] {
        let vm_config: VmConfig = serde_json::from_str("{}").unwrap();
        let mut disk = raw_disk_fixture();
        disk.rate_limiter_config = Some(cfg);
        let mut net = net_fixture();
        net.rate_limiter_config = Some(cfg);
        let group = RateLimiterGroupConfig {
            id: "group0".to_string(),
            rate_limiter_config: cfg,
        };
        [
            disk.validate(&vm_config),
            net.validate(&vm_config),
            group.validate(&vm_config),
        ]
    }

    #[test]
    fn test_rate_limiter_burst_disabled_parsing() {
        for (options, expected) in [
            (
                "bw_burst_rate=2000",
                ValidationError::RateLimiterBurstDisabledBucket(2000, 0, 0),
            ),
            (
                "ops_burst_rate=2000",
                ValidationError::RateLimiterBurstDisabledBucket(2000, 0, 0),
            ),
            (
                "bw_burst_seconds=2",
                ValidationError::RateLimiterBurstSecondsWithoutRate(2),
            ),
            (
                "ops_burst_seconds=2",
                ValidationError::RateLimiterBurstSecondsWithoutRate(2),
            ),
            (
                "bw_burst_recharge_seconds=4",
                ValidationError::RateLimiterBurstRechargeWithoutRate(4),
            ),
            (
                "ops_burst_recharge_seconds=4",
                ValidationError::RateLimiterBurstRechargeWithoutRate(4),
            ),
            (
                "bw_burst_recharge_seconds=0",
                ValidationError::RateLimiterBurstRechargeWithoutRate(0),
            ),
            (
                "ops_burst_recharge_seconds=0",
                ValidationError::RateLimiterBurstRechargeWithoutRate(0),
            ),
        ] {
            for cfg in parse_rate_limiter_configs(options) {
                for result in rate_limiter_validation_results(cfg) {
                    assert_eq!(result.unwrap_err(), expected);
                }
            }
        }
    }

    #[test]
    fn test_rate_limiter_burst_validation() {
        let bucket = TokenBucketConfig {
            size: 1000,
            one_time_burst: Some(0),
            refill_time: 1000,
            burst_rate: Some(2000),
            burst_seconds: Some(2),
            burst_recharge_seconds: None,
        };
        let invalid = [
            (
                TokenBucketConfig {
                    burst_rate: None,
                    ..bucket
                },
                ValidationError::RateLimiterBurstSecondsWithoutRate(2),
            ),
            (
                TokenBucketConfig {
                    burst_rate: Some(0),
                    ..bucket
                },
                ValidationError::RateLimiterBurstZero(0, 2),
            ),
            (
                TokenBucketConfig {
                    burst_seconds: Some(0),
                    ..bucket
                },
                ValidationError::RateLimiterBurstZero(2000, 0),
            ),
            (
                TokenBucketConfig {
                    one_time_burst: Some(1),
                    ..bucket
                },
                ValidationError::RateLimiterBurstWithOneTimeBurst(2000, 1),
            ),
            (
                TokenBucketConfig { size: 0, ..bucket },
                ValidationError::RateLimiterBurstDisabledBucket(2000, 0, 1000),
            ),
            (
                TokenBucketConfig {
                    refill_time: 0,
                    ..bucket
                },
                ValidationError::RateLimiterBurstDisabledBucket(2000, 1000, 0),
            ),
            (
                TokenBucketConfig {
                    size: 1001,
                    burst_rate: Some(1000),
                    ..bucket
                },
                ValidationError::RateLimiterBurstBelowSustained(1000, 1001, 1000),
            ),
            (
                TokenBucketConfig {
                    burst_rate: Some(u64::MAX),
                    ..bucket
                },
                ValidationError::RateLimiterBurstCapacityOverflow(u64::MAX, 2),
            ),
        ];
        for (bucket, expected) in invalid {
            for cfg in [
                RateLimiterConfig {
                    bandwidth: Some(bucket),
                    ops: None,
                },
                RateLimiterConfig {
                    bandwidth: None,
                    ops: Some(bucket),
                },
            ] {
                for result in rate_limiter_validation_results(cfg) {
                    assert_eq!(result.unwrap_err(), expected);
                }
            }
        }

        for bucket in [
            bucket,
            TokenBucketConfig {
                one_time_burst: None,
                burst_seconds: None,
                ..bucket
            },
            // Depth can be smaller than size: size/refill_time defines only the rate.
            TokenBucketConfig {
                size: 10_000,
                refill_time: 10_000,
                burst_rate: Some(1000),
                burst_seconds: Some(1),
                ..bucket
            },
            TokenBucketConfig {
                size: u64::MAX,
                refill_time: u64::MAX,
                burst_rate: Some(u64::MAX),
                burst_seconds: Some(1),
                ..bucket
            },
            // No new validation is applied to plain buckets.
            TokenBucketConfig {
                one_time_burst: Some(2000),
                burst_rate: None,
                burst_seconds: None,
                ..bucket
            },
        ] {
            for result in rate_limiter_validation_results(RateLimiterConfig {
                bandwidth: Some(bucket),
                ops: Some(bucket),
            }) {
                result.unwrap();
            }
        }
    }

    #[test]
    fn test_rate_limiter_burst_recharge_validation() {
        let bucket = TokenBucketConfig {
            size: 1,
            one_time_burst: Some(0),
            refill_time: 2000,
            burst_rate: Some(2),
            burst_seconds: Some(2),
            burst_recharge_seconds: Some(3),
        };
        let invalid = [
            (
                TokenBucketConfig {
                    burst_rate: None,
                    burst_seconds: None,
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeWithoutRate(3),
            ),
            (
                TokenBucketConfig {
                    burst_recharge_seconds: Some(0),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeTooShort(0, 3),
            ),
            (
                TokenBucketConfig {
                    burst_recharge_seconds: Some(1),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeTooShort(1, 3),
            ),
            (
                TokenBucketConfig {
                    burst_recharge_seconds: Some(2),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeTooShort(2, 3),
            ),
            (
                TokenBucketConfig {
                    size: 3,
                    burst_recharge_seconds: Some(1),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeTooShort(1, 2),
            ),
            (
                TokenBucketConfig {
                    refill_time: u64::MAX,
                    burst_recharge_seconds: Some(u64::MAX / 1000),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeTooShort(
                    u64::MAX / 1000,
                    u128::from(u64::MAX / 1000) + 1,
                ),
            ),
            (
                TokenBucketConfig {
                    burst_rate: Some(1),
                    burst_seconds: Some(1),
                    burst_recharge_seconds: Some(10),
                    ..bucket
                },
                ValidationError::RateLimiterBurstRechargeWithoutCredit(10, 1, 1),
            ),
        ];
        for (bucket, expected) in invalid {
            for cfg in [
                RateLimiterConfig {
                    bandwidth: Some(bucket),
                    ops: None,
                },
                RateLimiterConfig {
                    bandwidth: None,
                    ops: Some(bucket),
                },
            ] {
                for result in rate_limiter_validation_results(cfg) {
                    assert_eq!(result.unwrap_err(), expected);
                }
            }
        }

        for bucket in [
            bucket,
            TokenBucketConfig {
                size: 3,
                burst_recharge_seconds: Some(2),
                ..bucket
            },
            TokenBucketConfig {
                size: u64::MAX,
                refill_time: u64::MAX,
                burst_rate: Some(u64::MAX),
                burst_seconds: Some(1),
                burst_recharge_seconds: Some(u64::MAX),
                ..bucket
            },
            TokenBucketConfig {
                size: 2_000_000_001,
                refill_time: 4_000_000_000_000,
                burst_rate: Some(1),
                burst_seconds: Some(10),
                burst_recharge_seconds: Some(2),
                ..bucket
            },
            TokenBucketConfig {
                refill_time: u64::MAX,
                burst_recharge_seconds: Some(u64::MAX / 1000 + 1),
                ..bucket
            },
        ] {
            for result in rate_limiter_validation_results(RateLimiterConfig {
                bandwidth: Some(bucket),
                ops: Some(bucket),
            }) {
                result.unwrap();
            }
        }
    }

    #[test]
    fn test_rate_limiter_burst_serde() {
        let old_json = r#"{"size":1000,"one_time_burst":0,"refill_time":1000}"#;
        let plain: TokenBucketConfig = serde_json::from_str(old_json).unwrap();
        assert_eq!(plain.burst_rate, None);
        assert_eq!(plain.burst_seconds, None);
        assert_eq!(plain.burst_recharge_seconds, None);
        assert_eq!(serde_json::to_string(&plain).unwrap(), old_json);
        let old_config_json = format!(r#"{{"bandwidth":{old_json},"ops":null}}"#);
        let plain_config: RateLimiterConfig = serde_json::from_str(&old_config_json).unwrap();
        assert_eq!(plain_config.bandwidth, Some(plain));
        assert_eq!(
            serde_json::to_string(&plain_config).unwrap(),
            old_config_json
        );

        let burst = TokenBucketConfig {
            burst_rate: Some(2000),
            burst_seconds: Some(3),
            ..plain
        };
        let json = serde_json::to_string(&burst).unwrap();
        assert_eq!(
            serde_json::from_str::<TokenBucketConfig>(&json).unwrap(),
            burst
        );
        let config = RateLimiterConfig {
            bandwidth: Some(burst),
            ops: Some(burst),
        };
        let json = serde_json::to_string(&config).unwrap();
        assert_eq!(
            serde_json::from_str::<RateLimiterConfig>(&json).unwrap(),
            config
        );

        let recharge = TokenBucketConfig {
            burst_recharge_seconds: Some(4),
            ..burst
        };
        let json = serde_json::to_string(&recharge).unwrap();
        let value: serde_json::Value = serde_json::from_str(&json).unwrap();
        assert_eq!(value["burst_recharge_seconds"], 4);
        assert_eq!(
            serde_json::from_str::<TokenBucketConfig>(&json).unwrap(),
            recharge
        );
        let config = RateLimiterConfig {
            bandwidth: Some(recharge),
            ops: Some(recharge),
        };
        let json = serde_json::to_string(&config).unwrap();
        assert_eq!(
            serde_json::from_str::<RateLimiterConfig>(&json).unwrap(),
            config
        );
    }

    #[test]
    fn test_rate_limiter_token_bucket_config() {
        let plain = TokenBucketConfig {
            size: 1000,
            one_time_burst: Some(2000),
            refill_time: 100,
            burst_rate: None,
            burst_seconds: None,
            burst_recharge_seconds: None,
        };
        let bucket = plain.token_bucket().unwrap();
        assert_eq!(bucket.capacity(), 1000);
        assert_eq!(bucket.one_time_burst(), 2000);
        assert_eq!(bucket.refill_time_ms(), 100);
        assert_eq!(bucket.budget(), 1000);

        let burst = TokenBucketConfig {
            one_time_burst: Some(0),
            burst_rate: Some(20_000),
            ..plain
        };
        let bucket = burst.token_bucket().unwrap();
        assert_eq!(bucket.capacity(), 20_000);
        assert_eq!(bucket.one_time_burst(), 0);
        assert_eq!(bucket.refill_time_ms(), 100);
        let bucket = TokenBucketConfig {
            burst_seconds: Some(3),
            ..burst
        }
        .token_bucket()
        .unwrap();
        assert_eq!(bucket.capacity(), 60_000);
        let bucket = TokenBucketConfig {
            burst_seconds: Some(3),
            burst_recharge_seconds: Some(4),
            ..burst
        }
        .token_bucket()
        .unwrap();
        assert_eq!(bucket.capacity(), 60_000);
        assert_eq!(bucket.budget(), 60_000);
    }

    #[test]
    fn test_pci_segment_parsing() -> Result<()> {
        assert_eq!(
            PciSegmentConfig::parse("pci_segment=0")?,
            PciSegmentConfig {
                pci_segment: 0,
                mmio32_aperture_weight: 1,
                mmio64_aperture_weight: 1,
            }
        );
        assert_eq!(
            PciSegmentConfig::parse(
                "pci_segment=0,mmio32_aperture_weight=1,mmio64_aperture_weight=1"
            )?,
            PciSegmentConfig {
                pci_segment: 0,
                mmio32_aperture_weight: 1,
                mmio64_aperture_weight: 1,
            }
        );
        assert_eq!(
            PciSegmentConfig::parse("pci_segment=0,mmio32_aperture_weight=2")?,
            PciSegmentConfig {
                pci_segment: 0,
                mmio32_aperture_weight: 2,
                mmio64_aperture_weight: 1,
            }
        );
        assert_eq!(
            PciSegmentConfig::parse("pci_segment=0,mmio64_aperture_weight=2")?,
            PciSegmentConfig {
                pci_segment: 0,
                mmio32_aperture_weight: 1,
                mmio64_aperture_weight: 2,
            }
        );

        Ok(())
    }

    fn disk_fixture() -> DiskConfig {
        DiskConfig {
            pci_common: PciDeviceCommonConfig::default(),
            path: Some(PathBuf::from("/path/to_file")),
            readonly: false,
            direct: false,
            num_queues: 1,
            queue_size: 128,
            vhost_user: false,
            vhost_socket: None,
            disable_io_uring: false,
            disable_aio: false,
            rate_limit_group: None,
            rate_limiter_config: None,
            serial: None,
            queue_affinity: None,
            backing_files: false,
            sparse: true,
            image_type: ImageType::Unknown,
            lock_granularity: LockGranularityChoice::default(),
            guest_block_size: None,
        }
    }

    fn raw_disk_fixture() -> DiskConfig {
        DiskConfig {
            image_type: ImageType::Raw,
            ..disk_fixture()
        }
    }

    #[test]
    fn test_disk_parsing() -> Result<()> {
        assert_eq!(
            DiskConfig::parse("path=/path/to_file")?,
            DiskConfig { ..disk_fixture() }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,id=mydisk0")?,
            DiskConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("mydisk0".to_owned()),
                    ..Default::default()
                },
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("vhost_user=true,socket=/tmp/sock")?,
            DiskConfig {
                path: None,
                vhost_socket: Some(String::from("/tmp/sock")),
                vhost_user: true,
                image_type: ImageType::Unknown,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,iommu=on")?,
            DiskConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,iommu=on,queue_size=256")?,
            DiskConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                queue_size: 256,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,iommu=on,queue_size=256,num_queues=4")?,
            DiskConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                queue_size: 256,
                num_queues: 4,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,direct=on")?,
            DiskConfig {
                direct: true,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,serial=test")?,
            DiskConfig {
                serial: Some(String::from("test")),
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,rate_limit_group=group0")?,
            DiskConfig {
                rate_limit_group: Some("group0".to_string()),
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,lock_granularity=full")?,
            DiskConfig {
                lock_granularity: LockGranularityChoice::Full,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,lock_granularity=byte-range")?,
            DiskConfig {
                lock_granularity: LockGranularityChoice::ByteRange,
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,queue_affinity=[0@[1],1@[2],2@[3,4],3@[5-8]]")?,
            DiskConfig {
                queue_affinity: Some(Box::new([
                    VirtQueueAffinity {
                        queue_index: 0,
                        host_cpus: Box::new([1]),
                    },
                    VirtQueueAffinity {
                        queue_index: 1,
                        host_cpus: Box::new([2]),
                    },
                    VirtQueueAffinity {
                        queue_index: 2,
                        host_cpus: Box::new([3, 4]),
                    },
                    VirtQueueAffinity {
                        queue_index: 3,
                        host_cpus: Box::new([5, 6, 7, 8]),
                    }
                ])),
                ..disk_fixture()
            }
        );
        assert_eq!(
            DiskConfig::parse("path=/path/to_file,guest_block_size=4096")?,
            DiskConfig {
                guest_block_size: Some(4096),
                ..disk_fixture()
            }
        );
        DiskConfig::parse("path=/path/to_file,guest_block_size=abc").unwrap_err();
        Ok(())
    }

    pub(crate) fn net_fixture() -> NetConfig {
        NetConfig {
            pci_common: PciDeviceCommonConfig::default(),
            tap: None,
            ip: None,
            mask: None,
            mac: Some(MacAddr::parse_str("de:ad:be:ef:12:34").unwrap()),
            host_mac: Some(MacAddr::parse_str("12:34:de:ad:be:ef").unwrap()),
            mtu: None,
            num_queues: 2,
            queue_size: 256,
            vhost_user: false,
            vhost_socket: None,
            vhost_mode: VhostMode::Client,
            fds: None,
            rate_limiter_config: None,
            offload_tso: false,
            offload_ufo: false,
            offload_csum: false,
        }
    }

    #[test]
    fn test_net_parsing() -> Result<()> {
        use std::os::fd::IntoRawFd;

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { NetConfig::parse("mac=de:ad:be:ef:12:34,host_mac=12:34:de:ad:be:ef") }?,
            net_fixture(),
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                NetConfig::parse("mac=de:ad:be:ef:12:34,host_mac=12:34:de:ad:be:ef,id=mynet0")
            }?,
            NetConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("mynet0".to_owned()),
                    ..Default::default()
                },
                ..net_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                NetConfig::parse(
                    "mac=de:ad:be:ef:12:34,host_mac=12:34:de:ad:be:ef,tap=tap0,ip=192.168.100.1,mask=255.255.255.128",
                )
            }?,
            NetConfig {
                tap: Some("tap0".to_owned()),
                ip: Some("192.168.100.1".parse().unwrap()),
                mask: Some("255.255.255.128".parse().unwrap()),
                ..net_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                NetConfig::parse(
                    "mac=de:ad:be:ef:12:34,host_mac=12:34:de:ad:be:ef,vhost_user=true,socket=/tmp/sock",
                )
            }?,
            NetConfig {
                vhost_user: true,
                vhost_socket: Some("/tmp/sock".to_owned()),
                ..net_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                NetConfig::parse(
                    "mac=de:ad:be:ef:12:34,host_mac=12:34:de:ad:be:ef,num_queues=4,queue_size=1024,iommu=on",
                )
            }?,
            NetConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                num_queues: 4,
                queue_size: 1024,
                ..net_fixture()
            }
        );

        let files = [test_fd(), test_fd()];
        let [fd0, fd1] = files.map(IntoRawFd::into_raw_fd);
        // SAFETY: The files transferred exclusive ownership to us.
        let config = unsafe {
            NetConfig::parse(&format!(
                "mac=de:ad:be:ef:12:34,fd=[{fd0},{fd1}],num_queues=4"
            ))
        }?;
        let fds = config.fds.as_ref().unwrap();
        assert_eq!(fds[0].as_ref().unwrap().as_raw_fd(), fd0);
        assert_eq!(fds[1].as_ref().unwrap().as_raw_fd(), fd1);
        assert_eq!(
            config,
            NetConfig {
                host_mac: None,
                fds: config.fds.clone(),
                num_queues: 4,
                ..net_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { NetConfig::parse("mac=de:ad:be:ef:12:34,mask=255.255.255.0") }?,
            NetConfig {
                mask: Some("255.255.255.0".parse().unwrap()),
                host_mac: None,
                ..net_fixture()
            }
        );

        Ok(())
    }

    #[test]
    fn test_parse_rng() -> Result<()> {
        assert_eq!(RngConfig::parse("")?, RngConfig::default());
        assert_eq!(
            RngConfig::parse("src=/dev/random")?,
            RngConfig {
                src: PathBuf::from("/dev/random"),
                ..Default::default()
            }
        );
        assert_eq!(
            RngConfig::parse("src=/dev/random,iommu=on,pci_segment=1,pci_device_id=7")?,
            RngConfig {
                src: PathBuf::from("/dev/random"),
                pci_common: PciDeviceCommonConfig {
                    id: None,
                    iommu: IommuType::Virtio,
                    pci_segment: 1,
                    pci_device_id: Some(7),
                },
            }
        );
        assert_eq!(
            RngConfig::parse("iommu=on")?,
            RngConfig {
                pci_common: PciDeviceCommonConfig {
                    id: None,
                    iommu: IommuType::Virtio,
                    pci_segment: 0,
                    pci_device_id: None,
                },
                ..Default::default()
            }
        );
        Ok(())
    }

    #[test]
    fn test_parse_balloon() -> Result<()> {
        assert_eq!(
            BalloonConfig::parse(
                "size=128M,deflate_on_oom=on,free_page_reporting=on,pci_segment=1,pci_device_id=7"
            )?,
            BalloonConfig {
                pci_common: PciDeviceCommonConfig {
                    pci_segment: 1,
                    pci_device_id: Some(7),
                    ..Default::default()
                },
                size: 128 << 20,
                deflate_on_oom: true,
                free_page_reporting: true,
            }
        );

        assert_eq!(
            BalloonConfig::parse("size=0,iommu=on")?,
            BalloonConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                size: 0,
                deflate_on_oom: false,
                free_page_reporting: false,
            }
        );

        Ok(())
    }

    #[test]
    #[cfg(feature = "ivshmem")]
    fn test_parse_ivshmem() -> Result<()> {
        assert_eq!(
            IvshmemConfig::parse("path=/tmp/ivshmem.data,size=2M,pci_segment=1,pci_device_id=7")?,
            IvshmemConfig {
                pci_common: PciDeviceCommonConfig {
                    pci_segment: 1,
                    pci_device_id: Some(7),
                    ..Default::default()
                },
                path: PathBuf::from("/tmp/ivshmem.data"),
                size: 2 << 20,
            }
        );

        Ok(())
    }

    fn fs_fixture() -> FsConfig {
        FsConfig {
            pci_common: PciDeviceCommonConfig::default(),
            socket: PathBuf::from("/tmp/sock"),
            tag: "mytag".to_owned(),
            num_queues: 1,
            queue_size: 1024,
        }
    }

    #[test]
    fn test_parse_fs() -> Result<()> {
        // "tag" and "socket" must be supplied
        FsConfig::parse("").unwrap_err();
        FsConfig::parse("tag=mytag").unwrap_err();
        FsConfig::parse("socket=/tmp/sock").unwrap_err();
        assert_eq!(FsConfig::parse("tag=mytag,socket=/tmp/sock")?, fs_fixture());
        assert_eq!(
            FsConfig::parse("tag=mytag,socket=/tmp/sock,num_queues=4,queue_size=1024")?,
            FsConfig {
                num_queues: 4,
                queue_size: 1024,
                ..fs_fixture()
            }
        );

        Ok(())
    }

    #[track_caller]
    fn make_vhost_user_config(
        socket: &str,
        virtio_id: u64,
        id: &str,
        pci_segment: u64,
        queue_sizes: &IntegerList,
    ) {
        assert!(!socket.contains(",[]\n\r\0\""));
        assert!(!id.contains(",[]\n\r\0\""));
        let config = GenericVhostUserConfig::parse(&format!(
            "device_type={virtio_id},socket=\"{socket}\",\
id=\"{id}\",pci_segment={pci_segment},queue_sizes={queue_sizes}"
        ));
        if pci_segment <= u16::MAX.into()
            && virtio_id <= u32::MAX.into()
            && virtio_id != u64::from(VIRTIO_ID_BALLOON)
            && virtio_id != u64::from(VIRTIO_ID_WATCHDOG)
            && virtio_id != u64::from(VIRTIO_ID_IOMMU)
            && queue_sizes.0.iter().all(|&f| f <= u16::MAX.into())
        {
            assert_eq!(
                config.unwrap(),
                GenericVhostUserConfig {
                    pci_common: PciDeviceCommonConfig {
                        id: Some(id.to_owned()),
                        pci_segment: u16::try_from(pci_segment).unwrap(),
                        ..Default::default()
                    },
                    socket: socket.into(),
                    device_type: u32::try_from(virtio_id).unwrap(),
                    queue_sizes: queue_sizes
                        .0
                        .iter()
                        .map(|&f| u16::try_from(f).unwrap())
                        .collect(),
                }
            );
        } else {
            config.unwrap_err();
        }
    }

    #[test]
    fn test_parse_vhost_user() -> Result<()> {
        // all parameters must be supplied, except pci_segment
        GenericVhostUserConfig::parse("").unwrap_err();
        GenericVhostUserConfig::parse("device_type=1").unwrap_err();
        GenericVhostUserConfig::parse("queue_size=1").unwrap_err();
        GenericVhostUserConfig::parse("socket=/tmp/sock").unwrap_err();
        GenericVhostUserConfig::parse("id=1").unwrap_err();
        make_vhost_user_config(
            "/dev/null/doesnotexist",
            100,
            "Something",
            10,
            &IntegerList(vec![u16::MAX.into(), 20u16.into()]),
        );
        make_vhost_user_config(
            "/dev/null/doesnotexist",
            100,
            "Something",
            10,
            &IntegerList(vec![u16::MAX.into()]),
        );
        make_vhost_user_config(
            "/dev/null/doesnotexist",
            u64::from(u32::MAX) + 1,
            "Something",
            10,
            &IntegerList(vec![20u64]),
        );
        make_vhost_user_config(
            "/dev/null/doesnotexist",
            u64::from(u32::MAX) + 1,
            "Something",
            10,
            &IntegerList(vec![20u64]),
        );
        make_vhost_user_config(
            "/dev/null/doesnotexist",
            u64::from(u32::MAX) + 1,
            "Something",
            10,
            &IntegerList(vec![20u64]),
        );

        for config in [
            "virtio_id=26,socket=/tmp/sock,queue_sizes=[1024]",
            "device_type=26,virtio_id=26,socket=/tmp/sock,queue_sizes=[1024]",
        ] {
            assert!(matches!(
                GenericVhostUserConfig::parse(config),
                Err(Error::ParseGenericVhostUser(OptionParserError::UnknownOption(key)))
                    if key == "virtio_id"
            ));
        }
        Ok(())
    }

    fn pmem_fixture() -> PmemConfig {
        PmemConfig {
            pci_common: PciDeviceCommonConfig::default(),
            file: PathBuf::from("/tmp/pmem"),
            size: Some(128 << 20),
            discard_writes: false,
        }
    }

    #[test]
    fn test_pmem_parsing() -> Result<()> {
        // Must always give a file and size
        PmemConfig::parse("").unwrap_err();
        PmemConfig::parse("size=128M").unwrap_err();
        assert_eq!(
            PmemConfig::parse("file=/tmp/pmem,size=128M")?,
            pmem_fixture()
        );
        assert_eq!(
            PmemConfig::parse("file=/tmp/pmem,size=128M,id=mypmem0")?,
            PmemConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("mypmem0".to_owned()),
                    ..Default::default()
                },
                ..pmem_fixture()
            }
        );
        assert_eq!(
            PmemConfig::parse("file=/tmp/pmem,size=128M,iommu=on,discard_writes=on")?,
            PmemConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                discard_writes: true,
                ..pmem_fixture()
            }
        );

        Ok(())
    }

    #[test]
    fn test_console_parsing() -> Result<()> {
        let console_config = |output, iommu| ConsoleConfig {
            output,
            pci_common: PciDeviceCommonConfig {
                iommu,
                ..Default::default()
            },
        };

        ConsoleConfig::parse("").unwrap_err();
        ConsoleConfig::parse("badmode").unwrap_err();
        assert_eq!(
            ConsoleConfig::parse("off")?,
            console_config(ConsoleOutput::Off, IommuType::Off)
        );
        assert_eq!(
            ConsoleConfig::parse("pty")?,
            console_config(ConsoleOutput::Pty { file: None }, IommuType::Off)
        );
        assert_eq!(
            ConsoleConfig::parse("tty")?,
            console_config(ConsoleOutput::Tty, IommuType::Off)
        );
        assert_eq!(
            ConsoleConfig::parse("null")?,
            console_config(ConsoleOutput::Null, IommuType::Off)
        );
        assert_eq!(
            ConsoleConfig::parse("file=/tmp/console")?,
            console_config(
                ConsoleOutput::File {
                    file: PathBuf::from("/tmp/console"),
                },
                IommuType::Off
            )
        );
        assert_eq!(
            ConsoleConfig::parse("null,iommu=on")?,
            console_config(ConsoleOutput::Null, IommuType::Virtio)
        );
        assert_eq!(
            ConsoleConfig::parse("file=/tmp/console,iommu=on")?,
            console_config(
                ConsoleOutput::File {
                    file: PathBuf::from("/tmp/console"),
                },
                IommuType::Virtio
            )
        );
        assert_eq!(
            ConsoleConfig::parse("socket=/tmp/serial.sock,iommu=on")?,
            console_config(
                ConsoleOutput::Socket {
                    socket: PathBuf::from("/tmp/serial.sock"),
                },
                IommuType::Virtio
            )
        );
        assert_eq!(
            ConsoleConfig::parse("tcp=127.0.0.1:4444")?.output,
            ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: "127.0.0.1:4444".parse().unwrap(),
                    server: true,
                },
            }
        );
        assert_eq!(
            ConsoleConfig::parse("tcp=[::1]:4444")?.output,
            ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: "[::1]:4444".parse().unwrap(),
                    server: true,
                },
            }
        );
        SerialConfig::parse("tcp=localhost:4444").unwrap_err();
        for options in ["tcp=127.0.0.1:4444", "tcp=127.0.0.1:4444,server=on"] {
            let serial = SerialConfig::parse(options)?;
            let console = ConsoleConfig::parse(options)?;
            assert_eq!(serial.output, console.output);
            assert!(matches!(
                serial.output,
                ConsoleOutput::Tcp {
                    tcp: TcpConsoleConfig { server: true, .. }
                }
            ));
            serial.validate().unwrap();
            console.output.validate().unwrap();
        }
        for options in ["tcp=127.0.0.1:4444,server=invalid", "null,server=on"] {
            ConsoleConfig::parse(options).unwrap_err();
            SerialConfig::parse(options).unwrap_err();
        }
        assert!(matches!(
            SerialConfig::parse("tcp=127.0.0.1:4444,server=off"),
            Err(Error::Validation(
                ValidationError::ConsoleTcpClientUnsupported
            ))
        ));
        assert!(matches!(
            ConsoleConfig::parse("tcp=127.0.0.1:4444,server=off"),
            Err(Error::Validation(
                ValidationError::ConsoleTcpClientUnsupported
            ))
        ));
        Ok(())
    }

    #[test]
    fn test_console_output_parse_update() {
        let parse = |input: &str, device: &str| {
            let mut parser = OptionParser::new();
            parser.add_all(ConsoleOutput::UPDATE_OPTIONS);
            parser.parse(input).unwrap();
            ConsoleOutput::parse_update(&parser, device)
        };

        assert_eq!(parse("", "serial").unwrap(), None);
        assert_eq!(
            parse("serial_file=/tmp/serial.log", "serial").unwrap(),
            Some(ConsoleOutput::File {
                file: PathBuf::from("/tmp/serial.log"),
            })
        );
        assert_eq!(
            parse("console_socket=/tmp/console.sock", "console").unwrap(),
            Some(ConsoleOutput::Socket {
                socket: PathBuf::from("/tmp/console.sock"),
            })
        );
        assert_eq!(
            parse("serial_tcp=127.0.0.1:4444", "serial").unwrap(),
            Some(ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: "127.0.0.1:4444".parse().unwrap(),
                    server: true,
                },
            })
        );

        // Options of the other console must not leak into this one.
        assert_eq!(parse("console_tcp=127.0.0.1:4444", "serial").unwrap(), None);
        // Two outputs for different consoles are fine, two for one are not.
        parse("serial_file=/tmp/a,console_file=/tmp/b", "serial").unwrap();
        assert!(matches!(
            parse("serial_file=/tmp/a,serial_tcp=127.0.0.1:4444", "serial"),
            Err(Error::Validation(
                ValidationError::ConsoleOutputUpdateAmbiguous(_)
            ))
        ));
        assert!(matches!(
            parse("serial_tcp=localhost:4444", "serial"),
            Err(Error::ResolveConsoleTcpAddress { .. })
        ));

        // An option without a value must be rejected.
        assert!(matches!(
            parse("serial_file=", "serial"),
            Err(Error::Validation(ValidationError::ConsoleFileMissing))
        ));
        assert!(matches!(
            parse("console_socket=", "console"),
            Err(Error::Validation(ValidationError::ConsoleSocketPathMissing))
        ));
        assert!(matches!(
            parse("serial_tcp=", "serial"),
            Err(Error::Validation(ValidationError::ConsoleTcpAddressMissing))
        ));
    }

    #[test]
    fn test_console_output_update() {
        let tcp = |address: &str| ConsoleOutput::Tcp {
            tcp: TcpConsoleConfig {
                address: address.parse().unwrap(),
                server: true,
            },
        };
        let file = ConsoleOutput::File {
            file: PathBuf::from("/tmp/console.log"),
        };

        let mut output = tcp("127.0.0.1:4444");
        output
            .update(&tcp("127.0.0.1:5555"))
            .expect("should accept a new address in the same mode");
        assert_eq!(output, tcp("127.0.0.1:5555"));

        // Rejected updates must leave the output unchanged.
        assert_eq!(
            output.update(&file),
            Err(ValidationError::ConsoleOutputUpdateModeMismatch(
                tcp("127.0.0.1:5555"),
                file.clone()
            ))
        );
        assert_eq!(
            output.update(&tcp("127.0.0.1:0")),
            Err(ValidationError::ConsoleTcpPortZero)
        );
        assert_eq!(output, tcp("127.0.0.1:5555"));
    }

    #[test]
    fn test_console_output_update_requires_same_mode() {
        let outputs = [
            ConsoleOutput::Off,
            ConsoleOutput::Pty { file: None },
            ConsoleOutput::Tty,
            ConsoleOutput::File {
                file: PathBuf::from("/tmp/console.log"),
            },
            ConsoleOutput::Socket {
                socket: PathBuf::from("/tmp/console.sock"),
            },
            ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: "127.0.0.1:4444".parse().unwrap(),
                    server: true,
                },
            },
            ConsoleOutput::Null,
        ];

        for (current_index, current) in outputs.iter().enumerate() {
            for (new_index, new) in outputs.iter().enumerate() {
                let mut output = current.clone();
                if current_index == new_index {
                    assert_eq!(output.update(new), Ok(()));
                } else {
                    assert_eq!(
                        output.update(new),
                        Err(ValidationError::ConsoleOutputUpdateModeMismatch(
                            current.clone(),
                            new.clone()
                        ))
                    );
                    assert_eq!(output, *current);
                }
            }
        }
    }

    #[test]
    fn test_tcp_console_port_zero_validation() {
        for address in ["127.0.0.1:0", "[::1]:0"] {
            let options = format!("tcp={address}");
            let serial = SerialConfig::parse(&options).unwrap();
            let console = ConsoleConfig::parse(&options).unwrap();
            assert_eq!(
                serial.validate().unwrap_err(),
                ValidationError::ConsoleTcpPortZero
            );
            assert_eq!(
                console.output.validate().unwrap_err(),
                ValidationError::ConsoleTcpPortZero
            );

            let config = serde_json::json!({
                "mode": "Tcp",
                "tcp": { "address": address }
            });
            let serial: SerialConfig = serde_json::from_value(config.clone()).unwrap();
            let console: ConsoleConfig = serde_json::from_value(config).unwrap();
            assert_eq!(
                serial.validate().unwrap_err(),
                ValidationError::ConsoleTcpPortZero
            );
            assert_eq!(
                console.output.validate().unwrap_err(),
                ValidationError::ConsoleTcpPortZero
            );
        }
    }

    #[test]
    fn test_tcp_console_deserialization() {
        let config = serde_json::json!({
            "mode": "Tcp",
            "tcp": { "address": "127.0.0.1:4444" }
        });
        let serial: SerialConfig = serde_json::from_value(config.clone()).unwrap();
        let console: ConsoleConfig = serde_json::from_value(config.clone()).unwrap();
        let expected = ConsoleOutput::Tcp {
            tcp: TcpConsoleConfig {
                address: "127.0.0.1:4444".parse().unwrap(),
                server: true,
            },
        };
        assert_eq!(serial.output, expected);
        assert_eq!(console.output, expected);
        serial.validate().unwrap();
        console.output.validate().unwrap();

        let mut hostname = config.clone();
        hostname["tcp"]["address"] = serde_json::json!("localhost:4444");
        serde_json::from_value::<SerialConfig>(hostname.clone()).unwrap_err();
        serde_json::from_value::<ConsoleConfig>(hostname).unwrap_err();

        let mut explicit = config.clone();
        explicit["tcp"]["server"] = serde_json::json!(true);
        assert_eq!(
            serde_json::from_value::<SerialConfig>(explicit.clone()).unwrap(),
            serial
        );
        assert_eq!(
            serde_json::from_value::<ConsoleConfig>(explicit.clone()).unwrap(),
            console
        );
        explicit["tcp"]["server"] = serde_json::json!(false);
        let serial: SerialConfig = serde_json::from_value(explicit.clone()).unwrap();
        let console: ConsoleConfig = serde_json::from_value(explicit).unwrap();
        assert_eq!(
            serial.validate().unwrap_err(),
            ValidationError::ConsoleTcpClientUnsupported
        );
        assert_eq!(
            console.output.validate().unwrap_err(),
            ValidationError::ConsoleTcpClientUnsupported
        );
    }

    // The HTTP API, snapshots, and migration rely on this JSON format.
    #[test]
    fn test_console_output_json_format() {
        let tcp = TcpConsoleConfig {
            address: "127.0.0.1:4444".parse().unwrap(),
            server: true,
        };
        let cases = [
            (serde_json::json!({ "mode": "Off" }), ConsoleOutput::Off),
            (
                serde_json::json!({ "mode": "Pty" }),
                ConsoleOutput::Pty { file: None },
            ),
            (
                serde_json::json!({ "mode": "Pty", "file": "/dev/pts/3" }),
                ConsoleOutput::Pty {
                    file: Some(PathBuf::from("/dev/pts/3")),
                },
            ),
            (serde_json::json!({ "mode": "Tty" }), ConsoleOutput::Tty),
            (
                serde_json::json!({ "mode": "File", "file": "/tmp/console" }),
                ConsoleOutput::File {
                    file: PathBuf::from("/tmp/console"),
                },
            ),
            (
                serde_json::json!({ "mode": "Socket", "socket": "/tmp/console.sock" }),
                ConsoleOutput::Socket {
                    socket: PathBuf::from("/tmp/console.sock"),
                },
            ),
            (
                serde_json::json!({
                    "mode": "Tcp",
                    "tcp": { "address": "127.0.0.1:4444", "server": true }
                }),
                ConsoleOutput::Tcp { tcp },
            ),
            (serde_json::json!({ "mode": "Null" }), ConsoleOutput::Null),
        ];
        for (json, output) in cases {
            let config = SerialConfig { output };
            assert_eq!(
                serde_json::from_value::<SerialConfig>(json.clone()).unwrap(),
                config
            );
            assert_eq!(serde_json::to_value(&config).unwrap(), json);
        }

        // Versions before v53 serialized unset paths as null.
        let config: SerialConfig = serde_json::from_value(serde_json::json!({
            "mode": "Socket",
            "file": null,
            "socket": "/tmp/console.sock"
        }))
        .unwrap();
        assert_eq!(
            config.output,
            ConsoleOutput::Socket {
                socket: PathBuf::from("/tmp/console.sock"),
            }
        );

        for mode in ["File", "Socket", "Tcp"] {
            serde_json::from_value::<SerialConfig>(serde_json::json!({ "mode": mode }))
                .unwrap_err();
        }
    }

    #[cfg(target_arch = "x86_64")]
    #[test]
    fn test_debug_console_config() {
        let config = DebugConsoleConfig {
            output: ConsoleOutput::File {
                file: PathBuf::from("/tmp/console"),
            },
            iobase: Some(0xe9),
        };
        assert_eq!(
            DebugConsoleConfig::parse("file=/tmp/console,iobase=0xe9").unwrap(),
            config
        );

        let json = serde_json::json!({
            "mode": "File",
            "file": "/tmp/console",
            "iobase": 0xe9
        });
        assert_eq!(
            serde_json::from_value::<DebugConsoleConfig>(json.clone()).unwrap(),
            config
        );
        assert_eq!(serde_json::to_value(&config).unwrap(), json);

        // The debug console has no socket or TCP backend.
        for options in ["socket=/tmp/console.sock", "tcp=127.0.0.1:4444"] {
            DebugConsoleConfig::parse(options).unwrap_err();
        }
    }

    fn device_fixture() -> DeviceConfig {
        DeviceConfig {
            pci_common: PciDeviceCommonConfig::default(),
            path: Some(PathBuf::from("/path/to/device")),
            fd: Default::default(),
            x_nv_gpudirect_clique: None,
            x_exclude_mmap_bars: Vec::new(),
            iommufd_dev_id: None,
        }
    }

    #[test]
    fn test_device_parsing() -> Result<()> {
        use std::os::fd::IntoRawFd;

        // The "path or fd is
        // required" rule is enforced by VmConfig::validate.
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("") }?,
            DeviceConfig {
                path: None,
                ..device_fixture()
            }
        );
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device") }?,
            device_fixture()
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device,iommu=on") }?,
            DeviceConfig {
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                ..device_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device,iommu=on,id=mydevice0") }?,
            DeviceConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("mydevice0".to_owned()),
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                ..device_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device,x_exclude_mmap_bars=[2]") }?,
            DeviceConfig {
                x_exclude_mmap_bars: vec![2],
                ..device_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device,x_exclude_mmap_bars=[0,2,5]") }?,
            DeviceConfig {
                x_exclude_mmap_bars: vec![0, 2, 5],
                ..device_fixture()
            }
        );

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { DeviceConfig::parse("path=/path/to/device,x_exclude_mmap_bars=[6]") }?,
            DeviceConfig {
                x_exclude_mmap_bars: vec![6],
                ..device_fixture()
            }
        );

        // `fd=` is accepted alongside or in place of `path=`; exclusivity
        // is enforced by DeviceConfig::validate, not by the parser.
        let fd = test_fd().into_raw_fd();
        // SAFETY: The file transferred exclusive ownership to us.
        let config = unsafe { DeviceConfig::parse(&format!("fd={fd}")) }?;
        assert_eq!(config.fd.as_ref().unwrap().as_raw_fd(), fd);
        assert_eq!(
            config,
            DeviceConfig {
                path: None,
                fd: config.fd.clone(),
                ..device_fixture()
            }
        );
        let fd = test_fd().into_raw_fd();
        // SAFETY: The file transferred exclusive ownership to us.
        let config = unsafe { DeviceConfig::parse(&format!("path=/path/to/device,fd={fd}")) }?;
        assert_eq!(config.fd.as_ref().unwrap().as_raw_fd(), fd);
        assert_eq!(
            config,
            DeviceConfig {
                fd: config.fd.clone(),
                ..device_fixture()
            }
        );
        // Non-integer fd fails at parse time.
        // SAFETY: This input contains no inherited descriptors.
        unsafe { DeviceConfig::parse("fd=notanint") }.unwrap_err();

        Ok(())
    }

    fn vdpa_fixture() -> VdpaConfig {
        VdpaConfig {
            pci_common: PciDeviceCommonConfig::default(),
            path: PathBuf::from("/dev/vhost-vdpa"),
            num_queues: 1,
        }
    }

    #[test]
    fn test_vdpa_parsing() -> Result<()> {
        // path is required
        VdpaConfig::parse("").unwrap_err();
        assert_eq!(VdpaConfig::parse("path=/dev/vhost-vdpa")?, vdpa_fixture());
        assert_eq!(
            VdpaConfig::parse("path=/dev/vhost-vdpa,num_queues=2,id=my_vdpa")?,
            VdpaConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("my_vdpa".to_owned()),
                    ..Default::default()
                },
                num_queues: 2,
                ..vdpa_fixture()
            }
        );
        Ok(())
    }

    #[test]
    fn test_tpm_parsing() -> Result<()> {
        // path is required
        TpmConfig::parse("").unwrap_err();
        assert_eq!(
            TpmConfig::parse("socket=/var/run/tpm.sock")?,
            TpmConfig {
                socket: PathBuf::from("/var/run/tpm.sock"),
            }
        );
        Ok(())
    }

    #[test]
    fn test_platform_smbios_parsing() -> Result<()> {
        let config =
            // SAFETY: This test input contains no inherited descriptors.
            unsafe { PlatformConfig::parse("system_serial_number=serial,system_uuid=uuid") }?;
        assert_eq!(config.system_serial_number.as_deref(), Some("serial"));
        assert_eq!(config.system_uuid.as_deref(), Some("uuid"));

        let json = serde_json::to_value(&config).unwrap();
        assert_eq!(json["system_serial_number"], "serial");
        assert_eq!(json["system_uuid"], "uuid");
        assert_eq!(
            serde_json::from_value::<PlatformConfig>(json).unwrap(),
            config
        );

        for key in ["serial_number", "uuid"] {
            for prefix in ["", "system_serial_number=serial,system_uuid=uuid,"] {
                assert!(matches!(
                    // SAFETY: This test input contains no inherited descriptors.
                    unsafe { PlatformConfig::parse(&format!("{prefix}{key}=legacy")) },
                    Err(Error::ParsePlatform(OptionParserError::UnknownOption(option)))
                        if option == key
                ));
            }
        }

        // Unrecognized JSON fields are ignored, as for other configuration options.
        let legacy: PlatformConfig =
            serde_json::from_str(r#"{"serial_number":"legacy","uuid":"legacy"}"#).unwrap();
        assert_eq!(legacy.system_serial_number, None);
        assert_eq!(legacy.system_uuid, None);

        Ok(())
    }

    #[test]
    fn test_platform_iommufd_fd_parsing() -> Result<()> {
        // SAFETY: This input contains no inherited descriptors.
        let platform = unsafe { PlatformConfig::parse("") }?;
        assert!(!platform.iommufd);
        assert!(platform.iommufd_fd.is_none());

        use std::os::fd::IntoRawFd;
        for prefix in ["", "iommufd=on,"] {
            let file = test_fd();
            let fd = file.into_raw_fd();
            // SAFETY: The file transferred exclusive ownership to us.
            let platform = unsafe { PlatformConfig::parse(&format!("{prefix}iommufd_fd={fd}")) }?;
            assert!(platform.iommufd);
            assert_eq!(platform.iommufd_fd.as_ref().unwrap().as_raw_fd(), fd);
            platform.validate().unwrap();
        }
        Ok(())
    }

    #[test]
    fn test_vsock_parsing() -> Result<()> {
        // socket and cid is required
        VsockConfig::parse("").unwrap_err();
        assert_eq!(
            VsockConfig::parse("socket=/tmp/sock,cid=3")?,
            VsockConfig {
                socket_type: SocketType::Stream,
                pci_common: PciDeviceCommonConfig::default(),
                cid: 3,
                socket: PathBuf::from("/tmp/sock"),
            }
        );
        assert_eq!(
            VsockConfig::parse("socket=/tmp/sock,cid=3,iommu=on")?,
            VsockConfig {
                socket_type: SocketType::Stream,
                pci_common: PciDeviceCommonConfig {
                    iommu: IommuType::Virtio,
                    ..Default::default()
                },
                cid: 3,
                socket: PathBuf::from("/tmp/sock"),
            }
        );
        Ok(())
    }

    #[test]
    fn test_remove_vsock_device() {
        let mut config: VmConfig = serde_json::from_str("{}").unwrap();
        assert!(!config.remove_device("vsock0"));

        config.vsock = Some(VsockConfig::parse("cid=3,socket=/tmp/vsock,id=vsock0").unwrap());
        assert!(!config.remove_device("vsock1"));
        assert_eq!(
            config.vsock.as_ref().unwrap().pci_common.id.as_deref(),
            Some("vsock0")
        );
        assert!(config.remove_device("vsock0"));
        assert!(config.vsock.is_none());
        assert!(!config.remove_device("vsock0"));

        config.vsock = Some(VsockConfig::parse("cid=3,socket=/tmp/vsock").unwrap());
        assert!(!config.remove_device("vsock0"));
        assert!(config.vsock.is_some());
    }

    #[test]
    fn test_numa_config_parsing() -> Result<()> {
        // Error when device_id and cpu/memory are present
        let invalid_input = "guest_numa_id=0,cpus=[0,1],distances=[0@25,1@20],\
                                device_id=vfio0,memory_zones=[mem1],pci_segments=[0]";
        NumaConfig::parse(invalid_input).unwrap_err();
        // Successful numa config parsing
        let standard_input = "guest_numa_id=1,cpus=[2,3],distances=[0@20],\
                                memory_zones=[mem0],pci_segments=[0]";
        let expected_standard = NumaConfig {
            guest_numa_id: 1,
            cpus: Some(Box::new([2, 3])),
            distances: Some(Box::new([NumaDistance {
                destination: 0,
                distance: 20,
            }])),
            device_id: None,
            memory_zones: Some(Box::new(["mem0".to_string()])),
            pci_segments: Some(Box::new([0])),
        };
        assert_eq!(NumaConfig::parse(standard_input)?, expected_standard);
        // Successful generic initiator config parse
        let gi_input = "guest_numa_id=2,device_id=vfio1,distances=[0@30],pci_segments=[1]";
        let expected_gi = NumaConfig {
            guest_numa_id: 2,
            cpus: None,
            distances: Some(Box::new([NumaDistance {
                destination: 0,
                distance: 30,
            }])),
            device_id: Some("vfio1".to_string()),
            memory_zones: None,
            pci_segments: Some(Box::new([1])),
        };
        assert_eq!(NumaConfig::parse(gi_input)?, expected_gi);
        Ok(())
    }

    #[test]
    fn test_numa_config_generic_initiator_valid() {
        // device_id specified, no cpus/memory_zones
        let config = NumaConfig {
            guest_numa_id: 0,
            cpus: None,
            distances: Some(Box::new([NumaDistance {
                destination: 1,
                distance: 20,
            }])),
            memory_zones: None,
            device_id: Some("vfio0".to_string()),
            pci_segments: None,
        };
        config.validate().unwrap();
        assert!(config.is_generic_initiator());
    }

    #[test]
    fn test_numa_config_invalid_device_id() {
        // empty device_id
        let config = NumaConfig {
            guest_numa_id: 0,
            cpus: None,
            distances: None,
            memory_zones: None,
            device_id: Some(String::new()),
            pci_segments: None,
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn test_numa_config_invalid_both_device_cpus() {
        // device_id and cpus specified
        let config = NumaConfig {
            guest_numa_id: 0,
            cpus: Some(Box::new([0, 1])),
            distances: None,
            device_id: Some("vfio0".to_string()),
            memory_zones: None,
            pci_segments: None,
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn test_numa_config_invalid_both_device_memory() {
        // device_id and memory zones specified
        let config = NumaConfig {
            guest_numa_id: 0,
            cpus: None,
            distances: None,
            device_id: Some("vfio0".to_string()),
            memory_zones: Some(Box::new(["mem0".to_string()])),
            pci_segments: None,
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn test_numa_config_standard_valid() {
        // No device_id
        let config = NumaConfig {
            guest_numa_id: 0,
            cpus: Some(Box::new([0, 1])),
            distances: Some(Box::new([NumaDistance {
                destination: 1,
                distance: 20,
            }])),
            device_id: None,
            memory_zones: Some(Box::new(["mem0".to_string()])),
            pci_segments: None,
        };
        config.validate().unwrap();
    }

    #[test]
    fn test_restore_parsing() -> Result<()> {
        use std::array;
        use std::os::fd::IntoRawFd;

        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { RestoreConfig::parse("source_url=/path/to/snapshot") }?,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                ..Default::default()
            }
        );
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                RestoreConfig::parse(
                    "source_url=/path/to/snapshot,serial_file=/tmp/s,console_socket=/tmp/c",
                )
            }?,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                serial: Some(ConsoleOutput::File {
                    file: PathBuf::from("/tmp/s"),
                }),
                console: Some(ConsoleOutput::Socket {
                    socket: PathBuf::from("/tmp/c"),
                }),
                ..Default::default()
            }
        );
        assert!(matches!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                RestoreConfig::parse("source_url=/path/to/snapshot,serial_file=/a,serial_socket=/b")
            },
            Err(Error::Validation(
                ValidationError::ConsoleOutputUpdateAmbiguous(_)
            ))
        ));
        assert!(matches!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe { RestoreConfig::parse("source_url=/path/to/snapshot,console_tcp=localhost:1") },
            Err(Error::ResolveConsoleTcpAddress { .. })
        ));
        let files: [File; 6] = array::from_fn(|_| test_fd());
        let [fd0, fd1, fd2, fd3, fd4, fd5] = files.map(IntoRawFd::into_raw_fd);
        // SAFETY: The files transferred exclusive ownership to us.
        let config = unsafe {
            RestoreConfig::parse(&format!(
                "source_url=/path/to/snapshot,prefault=off,net_fds=[net0@[{fd0},{fd1}],net1@[{fd2},{fd3},{fd4},{fd5}]]"
            ))
        }?;
        assert!(config.net_fds.is_none());
        let nets = config.external_fds.entries();
        let fds: Vec<_> = nets
            .iter()
            .flat_map(|(_, _, fds)| fds.iter())
            .map(|fd| fd.as_ref().unwrap().as_raw_fd())
            .collect();
        assert_eq!(fds, [fd0, fd1, fd2, fd3, fd4, fd5]);
        assert_eq!(
            config,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                external_fds: vec![
                    (net_target("net0"), nets[0].2.clone()),
                    (net_target("net1"), nets[1].2.clone()),
                ]
                .into(),
                ..Default::default()
            }
        );
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                RestoreConfig::parse("source_url=/path/to/snapshot,memory_restore_mode=ondemand")
            }?,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                memory_restore_mode: MemoryRestoreMode::OnDemand,
                ..Default::default()
            }
        );
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                RestoreConfig::parse(
                    "source_url=/path/to/snapshot,memory_restore_mode=ondemand_no_background_fetch_pages",
                )
            }?,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                memory_restore_mode: MemoryRestoreMode::OnDemandNoBackgroundFetchPages,
                ..Default::default()
            }
        );
        assert_eq!(
            // SAFETY: This input contains no inherited descriptors.
            unsafe {
                RestoreConfig::parse(
                    "source_url=/path/to/snapshot,resume=on,zone_updates=[zone1@1]",
                )
            }?,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                resume: true,
                zone_updates: vec![VmMemoryZoneUpdateData {
                    host_numa_node: 1,
                    id: "zone1".to_string(),
                }],
                ..Default::default()
            }
        );
        let vfio0 = test_fd();
        let vfio1 = test_fd();
        let iommu = test_fd();
        let fd0 = vfio0.into_raw_fd();
        let fd1 = vfio1.into_raw_fd();
        let fd2 = iommu.into_raw_fd();
        // SAFETY: The files transferred exclusive ownership to us.
        let config = unsafe {
            RestoreConfig::parse(&format!(
                "source_url=/path/to/snapshot,vfio_fds=[vfio0@{fd0},vfio1@{fd1}],iommufd_fd={fd2}"
            ))
        }?;
        assert!(config.vfio_fds.is_none());
        assert!(config.iommufd_fd.is_none());
        let entries = config.external_fds.entries();
        assert_eq!(entries[0].2[0].as_ref().unwrap().as_raw_fd(), fd0);
        assert_eq!(entries[1].2[0].as_ref().unwrap().as_raw_fd(), fd1);
        assert_eq!(entries[2].2[0].as_ref().unwrap().as_raw_fd(), fd2);
        assert_eq!(
            config,
            RestoreConfig {
                source_url: PathBuf::from("/path/to/snapshot"),
                external_fds: vec![
                    (vfio_target("vfio0"), entries[0].2.clone()),
                    (vfio_target("vfio1"), entries[1].2.clone()),
                    (Target::Iommu, entries[2].2.clone()),
                ]
                .into(),
                ..Default::default()
            }
        );
        // Parsing should fail as source_url is a required field
        // SAFETY: This input contains no inherited descriptors.
        unsafe { RestoreConfig::parse("prefault=off") }.unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe { RestoreConfig::parse("source_url=/path/to/snapshot,memory_restore_mode=bogus") }
            .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe { RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=[@1]") }
            .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe { RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=[@]") }
            .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe {
            RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=[id1@]")
        }
        .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe {
            RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=[id1 1]")
        }
        .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe {
            RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=[[id1@1]]")
        }
        .unwrap_err();
        // SAFETY: This input contains no inherited descriptors.
        unsafe {
            RestoreConfig::parse("source_url=/path/to/snapshot,resume=on,zone_updates=id1@1")
        }
        .unwrap_err();
        Ok(())
    }

    #[test]
    fn test_restore_config_serde() {
        assert_eq!(
            serde_json::from_str::<RestoreConfig>(r#"{"source_url":"/path/to/snapshot"}"#)
                .unwrap()
                .memory_restore_mode,
            MemoryRestoreMode::Copy
        );
        assert_eq!(
            serde_json::from_str::<RestoreConfig>(
                r#"{"source_url":"/path/to/snapshot","memory_restore_mode":"OnDemand"}"#
            )
            .unwrap()
            .memory_restore_mode,
            MemoryRestoreMode::OnDemand
        );
        assert_eq!(
            serde_json::from_str::<RestoreConfig>(
                r#"{"source_url":"/path/to/snapshot","memory_restore_mode":"OnDemandNoBackgroundFetchPages"}"#
            )
            .unwrap()
            .memory_restore_mode,
            MemoryRestoreMode::OnDemandNoBackgroundFetchPages
        );
        assert_eq!(
            serde_json::from_str::<RestoreConfig>(
                r#"{"source_url":"/path/to/snapshot","zone_updates":[{"id": "zone1", "host_numa_node": 1}]}"#
            )
            .unwrap()
            .zone_updates,
            vec![VmMemoryZoneUpdateData {
                    host_numa_node: 1,
                    id: "zone1".to_string(),
                }],
        );

        let config = serde_json::from_str::<RestoreConfig>(
            r#"{"source_url":"/path/to/snapshot",
                "serial":{"mode":"Tcp","tcp":{"address":"127.0.0.1:4444"}},
                "console":{"mode":"File","file":"/tmp/console.log"}}"#,
        )
        .unwrap();
        assert_eq!(
            config.serial,
            Some(ConsoleOutput::Tcp {
                tcp: TcpConsoleConfig {
                    address: "127.0.0.1:4444".parse().unwrap(),
                    server: true,
                },
            })
        );
        assert_eq!(
            config.console,
            Some(ConsoleOutput::File {
                file: PathBuf::from("/tmp/console.log"),
            })
        );
    }

    #[test]
    fn test_iommu_type() {
        // Configurations older than the type stored a boolean here.
        assert_eq!(
            serde_json::from_str::<IommuType>("true").unwrap(),
            IommuType::Virtio
        );
        assert_eq!(
            serde_json::from_str::<IommuType>("false").unwrap(),
            IommuType::Off
        );
        assert_eq!(
            serde_json::from_str::<IommuType>(r#""Virtio""#).unwrap(),
            IommuType::Virtio
        );
        assert_eq!(
            serde_json::from_str::<IommuType>(r#""Smmuv3""#).unwrap(),
            IommuType::Smmuv3
        );
        serde_json::from_str::<IommuType>(r#""Nope""#).unwrap_err();

        // "on" and "off" predate the type on the command line.
        assert_eq!("on".parse::<IommuType>().unwrap(), IommuType::Virtio);
        assert_eq!("off".parse::<IommuType>().unwrap(), IommuType::Off);
        assert_eq!("virtio".parse::<IommuType>().unwrap(), IommuType::Virtio);
        assert_eq!("smmuv3".parse::<IommuType>().unwrap(), IommuType::Smmuv3);
        "nope".parse::<IommuType>().unwrap_err();
    }

    #[test]
    fn test_restore_config_validation() {
        let fd: ExternalFd = test_fd().into();

        // interested in only VmConfig.net, so set rest to default values
        let mut snapshot_vm_config = VmConfig {
            cpus: CpusConfig::default(),
            memory: MemoryConfig::default(),
            payload: None,
            rate_limit_groups: None,
            disks: None,
            rng: RngConfig::default(),
            generic_vhost_user: None,
            balloon: None,
            fs: None,
            pmem: None,
            serial: SerialConfig::default(),
            console: ConsoleConfig::default(),
            #[cfg(target_arch = "x86_64")]
            debug_console: DebugConsoleConfig::default(),
            devices: None,
            user_devices: None,
            vdpa: None,
            vsock: None,
            #[cfg(feature = "pvmemcontrol")]
            pvmemcontrol: None,
            pvpanic: false,
            iommu: false,
            numa: None,
            watchdog: false,
            rtc: None,
            #[cfg(feature = "guest_debug")]
            gdb: false,
            pci_segments: None,
            platform: None,
            tpm: None,
            net: Some(vec![
                NetConfig {
                    pci_common: PciDeviceCommonConfig {
                        id: Some("net0".to_owned()),
                        ..Default::default()
                    },
                    num_queues: 2,
                    fds: Some(vec![ExternalFd::default(); 4]),
                    ..net_fixture()
                },
                NetConfig {
                    pci_common: PciDeviceCommonConfig {
                        id: Some("net1".to_owned()),
                        ..Default::default()
                    },
                    num_queues: 1,
                    fds: Some(vec![ExternalFd::default(); 2]),
                    ..net_fixture()
                },
                NetConfig {
                    pci_common: PciDeviceCommonConfig {
                        id: Some("net2".to_owned()),
                        ..Default::default()
                    },
                    fds: None,
                    ..net_fixture()
                },
            ]),
            landlock_enable: false,
            landlock_rules: None,
            #[cfg(feature = "ivshmem")]
            ivshmem: None,
        };

        let valid_config = RestoreConfig {
            source_url: PathBuf::from("/path/to/snapshot"),
            prefault: false,
            memory_restore_mode: MemoryRestoreMode::Copy,
            external_fds: vec![
                (net_target("net0"), vec![fd.clone(); 4]),
                (net_target("net1"), vec![fd.clone(); 2]),
            ]
            .into(),
            resume: false,
            zone_updates: vec![],
            ..Default::default()
        };
        valid_config.validate(&snapshot_vm_config).unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.external_fds = vec![(net_target("netx"), vec![fd.clone(); 4])].into();
        assert_eq!(
            invalid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::MissingFds(net_target(
                "net0"
            ))))
        );

        invalid_config.external_fds = vec![
            (net_target("net0"), vec![fd.clone(); 4]),
            (net_target("net0"), vec![fd.clone(); 4]),
        ]
        .into();
        assert_eq!(
            invalid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::DuplicatedTargetEntry(
                net_target("net0")
            )))
        );

        invalid_config.external_fds = vec![(net_target("net0"), vec![fd.clone(); 4])].into();
        assert_eq!(
            invalid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::MissingFds(net_target(
                "net1"
            ))))
        );

        invalid_config.external_fds = vec![(net_target("net0"), vec![fd.clone(); 2])].into();
        assert_eq!(
            invalid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::FdAmountMismatch {
                target: net_target("net0"),
                expected: 4,
                actual: 2,
            }))
        );

        let another_valid_config = RestoreConfig {
            source_url: PathBuf::from("/path/to/snapshot"),
            prefault: false,
            memory_restore_mode: MemoryRestoreMode::Copy,
            resume: false,
            zone_updates: vec![],
            ..Default::default()
        };
        snapshot_vm_config.net = Some(vec![NetConfig {
            pci_common: PciDeviceCommonConfig {
                id: Some("net2".to_owned()),
                ..Default::default()
            },
            fds: None,
            ..net_fixture()
        }]);
        another_valid_config.validate(&snapshot_vm_config).unwrap();

        let invalid_restore_mode = RestoreConfig {
            source_url: PathBuf::from("/path/to/snapshot"),
            prefault: true,
            memory_restore_mode: MemoryRestoreMode::OnDemand,
            resume: false,
            zone_updates: vec![],
            ..Default::default()
        };
        assert_eq!(
            invalid_restore_mode.validate(&snapshot_vm_config),
            Err(ValidationError::InvalidRestorePrefaultWithOnDemand)
        );

        // It is invalid to submit more than one update for a single zone.
        let mut invalid_config_zone_updates = another_valid_config.clone();
        invalid_config_zone_updates.zone_updates = vec![
            VmMemoryZoneUpdateData {
                id: "id1".to_string(),
                host_numa_node: 0,
            },
            VmMemoryZoneUpdateData {
                id: "id1".to_string(),
                host_numa_node: 20,
            },
        ];
        assert_eq!(
            invalid_config_zone_updates.validate(&snapshot_vm_config),
            Err(ValidationError::MultipleMemoryZoneUpdates)
        );

        // It is invalid to submit an update without referring to a memory zone by specifying an ID.
        let mut invalid_config_zone_updates = another_valid_config.clone();
        invalid_config_zone_updates.zone_updates = vec![VmMemoryZoneUpdateData {
            id: String::new(),
            host_numa_node: 0,
        }];
        assert_eq!(
            invalid_config_zone_updates.validate(&snapshot_vm_config),
            Err(ValidationError::MemoryZoneUpdatesEmptyId)
        );

        let invalid_cow_prefault = RestoreConfig {
            source_url: PathBuf::from("/path/to/snapshot"),
            prefault: true,
            memory_restore_mode: MemoryRestoreMode::CopyOnWrite,
            resume: false,
            zone_updates: vec![],
            ..Default::default()
        };
        assert_eq!(
            invalid_cow_prefault.validate(&snapshot_vm_config),
            Err(ValidationError::InvalidRestorePrefaultWithOnDemand)
        );
    }

    #[test]
    fn test_restore_config_vfio_fds_validation() {
        let fd: ExternalFd = test_fd().into();

        // interested in only VmConfig.devices and platform, so set rest to
        // default values
        let mut snapshot_vm_config = VmConfig {
            cpus: CpusConfig::default(),
            memory: MemoryConfig::default(),
            payload: None,
            rate_limit_groups: None,
            disks: None,
            rng: RngConfig::default(),
            generic_vhost_user: None,
            balloon: None,
            fs: None,
            pmem: None,
            serial: SerialConfig::default(),
            console: ConsoleConfig::default(),
            #[cfg(target_arch = "x86_64")]
            debug_console: DebugConsoleConfig::default(),
            devices: Some(vec![DeviceConfig {
                pci_common: PciDeviceCommonConfig {
                    id: Some("vfio0".to_owned()),
                    ..Default::default()
                },
                // recv_vm_config removes source paths before restore validation.
                path: None,
                fd: Default::default(),
                x_nv_gpudirect_clique: None,
                x_exclude_mmap_bars: Vec::new(),
                iommufd_dev_id: None,
            }]),
            user_devices: None,
            vdpa: None,
            vsock: None,
            #[cfg(feature = "pvmemcontrol")]
            pvmemcontrol: None,
            pvpanic: false,
            iommu: false,
            numa: None,
            watchdog: false,
            rtc: None,
            #[cfg(feature = "guest_debug")]
            gdb: false,
            pci_segments: None,
            platform: Some(PlatformConfig {
                iommufd: true,
                ..platform_fixture()
            }),
            tpm: None,
            net: None,
            landlock_enable: false,
            landlock_rules: None,
            #[cfg(feature = "ivshmem")]
            ivshmem: None,
        };

        let valid_config = RestoreConfig {
            source_url: PathBuf::from("/path/to/snapshot"),
            prefault: false,
            memory_restore_mode: MemoryRestoreMode::Copy,
            resume: false,
            zone_updates: vec![],
            external_fds: vec![
                (vfio_target("vfio0"), vec![fd.clone()]),
                (Target::Iommu, vec![fd.clone()]),
            ]
            .into(),
            ..Default::default()
        };
        valid_config.validate(&snapshot_vm_config).unwrap();

        let missing_iommufd = RestoreConfig {
            external_fds: vec![(vfio_target("vfio0"), vec![fd.clone()])].into(),
            ..valid_config.clone()
        };
        assert_eq!(
            missing_iommufd.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::VfioFdsWithoutIommuFd))
        );

        let unknown_id = RestoreConfig {
            external_fds: vec![
                (vfio_target("vfio0"), vec![fd.clone()]),
                (vfio_target("missing"), vec![fd.clone()]),
                (Target::Iommu, vec![fd.clone()]),
            ]
            .into(),
            ..valid_config.clone()
        };
        assert_eq!(
            unknown_id.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::SuperfluousFds(vec![
                vfio_target("missing")
            ])))
        );

        let duplicate_id = RestoreConfig {
            external_fds: vec![
                (vfio_target("vfio0"), vec![fd.clone()]),
                (vfio_target("vfio0"), vec![fd.clone()]),
            ]
            .into(),
            ..valid_config.clone()
        };
        assert_eq!(
            duplicate_id.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::DuplicatedTargetEntry(
                vfio_target("vfio0")
            )))
        );

        let no_substitution = RestoreConfig {
            vfio_fds: None,
            iommufd_fd: Default::default(),
            external_fds: Default::default(),
            ..valid_config.clone()
        };
        assert_eq!(
            no_substitution.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::MissingFds(
                vfio_target("vfio0")
            )))
        );

        // Every device requires a replacement after source paths are removed.
        let mut second_device = snapshot_vm_config.devices.as_ref().unwrap()[0].clone();
        second_device.pci_common.id = Some("vfio1".to_string());
        snapshot_vm_config
            .devices
            .as_mut()
            .unwrap()
            .push(second_device);
        assert_eq!(
            valid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::MissingFds(
                vfio_target("vfio1")
            )))
        );
        let mut complete_substitution = valid_config.clone();
        complete_substitution.external_fds = vec![
            (vfio_target("vfio0"), vec![fd.clone()]),
            (vfio_target("vfio1"), vec![fd.clone()]),
            (Target::Iommu, vec![fd.clone()]),
        ]
        .into();
        complete_substitution.validate(&snapshot_vm_config).unwrap();
        snapshot_vm_config.devices.as_mut().unwrap().pop();

        snapshot_vm_config.devices.as_mut().unwrap()[0].path = None;
        snapshot_vm_config.devices.as_mut().unwrap()[0].fd = Default::default();
        assert_eq!(
            no_substitution.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(UpdateFdsError::MissingFds(
                vfio_target("vfio0")
            )))
        );

        // The iommufd backend must be enabled in the snapshot config.
        snapshot_vm_config.platform = Some(platform_fixture());
        assert_eq!(
            valid_config.validate(&snapshot_vm_config),
            Err(ValidationError::Fd(
                UpdateFdsError::IommufdFdRequiresIommufdBackend
            ))
        );
    }

    pub(crate) fn platform_fixture() -> PlatformConfig {
        PlatformConfig {
            num_pci_segments: MAX_NUM_PCI_SEGMENTS,
            iommu_segments: None,
            iommu_address_width_bits: MAX_IOMMU_ADDRESS_WIDTH_BITS,
            system_serial_number: None,
            system_uuid: None,
            oem_strings: None,
            iommufd: false,
            iommufd_fd: Default::default(),
            vfio_p2p_dma: default_platformconfig_vfio_p2p_dma(),
            system_manufacturer: None,
            system_product_name: None,
            system_version: None,
            system_family: None,
            system_sku_number: None,
            chassis_asset_tag: None,
            #[cfg(feature = "sev_snp")]
            sev_snp: false,
        }
    }

    fn numa_fixture() -> NumaConfig {
        NumaConfig {
            guest_numa_id: 0,
            cpus: None,
            distances: None,
            device_id: None,
            memory_zones: None,
            pci_segments: None,
        }
    }

    #[test]
    #[cfg(all(feature = "kvm", feature = "sev_snp"))]
    fn test_sev_snp_fw_cfg_validation() {
        let mut config: VmConfig = serde_json::from_value(serde_json::json!({
            "platform": { "sev_snp": true },
            "payload": { "igvm": "/path/to/igvm" },
        }))
        .unwrap();
        assert_eq!(
            config.validate(),
            Err(ValidationError::SevSnpRequiresFwCfgAcpi)
        );

        #[cfg(feature = "fw_cfg")]
        {
            config.payload.as_mut().unwrap().fw_cfg_config = Some(FwCfgConfig {
                kernel: false,
                cmdline: false,
                initramfs: false,
                acpi_tables: false,
                ..Default::default()
            });
            assert_eq!(
                config.validate(),
                Err(ValidationError::SevSnpRequiresFwCfgAcpi)
            );
            config.platform.as_mut().unwrap().sev_snp = false;
            config.validate().unwrap();
            config.platform.as_mut().unwrap().sev_snp = true;
            config
                .payload
                .as_mut()
                .unwrap()
                .fw_cfg_config
                .as_mut()
                .unwrap()
                .acpi_tables = true;
            config.validate().unwrap();
        }
    }

    #[test]
    fn test_config_validation() {
        let fd: ExternalFd = test_fd().into();

        let mut valid_config = VmConfig {
            cpus: CpusConfig {
                boot_vcpus: 1,
                max_vcpus: 1,
                ..Default::default()
            },
            memory: MemoryConfig {
                size: 536_870_912,
                mergeable: false,
                hotplug_method: HotplugMethod::Acpi,
                hotplug_size: None,
                hotplugged_size: None,
                shared: false,
                hugepages: false,
                hugepage_size: None,
                prefault: false,
                reserve: None,
                zones: None,
                thp: true,
            },
            payload: Some(PayloadConfig {
                kernel: Some(PathBuf::from("/path/to/kernel")),
                firmware: None,
                cmdline: None,
                initramfs: None,
                #[cfg(feature = "igvm")]
                igvm: None,
                #[cfg(feature = "sev_snp")]
                host_data: Some(
                    "243eb7dc1a21129caa91dcbb794922b933baecb5823a377eb431188673288c07".to_string(),
                ),
                #[cfg(feature = "fw_cfg")]
                fw_cfg_config: None,
            }),
            rate_limit_groups: None,
            disks: None,
            net: None,
            rng: RngConfig {
                src: PathBuf::from("/dev/urandom"),
                pci_common: PciDeviceCommonConfig::default(),
            },
            balloon: None,
            fs: None,
            generic_vhost_user: None,
            pmem: None,
            serial: SerialConfig {
                output: ConsoleOutput::Null,
            },
            console: ConsoleConfig {
                output: ConsoleOutput::Tty,
                pci_common: PciDeviceCommonConfig::default(),
            },
            #[cfg(target_arch = "x86_64")]
            debug_console: DebugConsoleConfig::default(),
            devices: None,
            user_devices: None,
            vdpa: None,
            vsock: None,
            #[cfg(feature = "pvmemcontrol")]
            pvmemcontrol: None,
            pvpanic: false,
            iommu: false,
            numa: None,
            watchdog: false,
            rtc: None,
            #[cfg(feature = "guest_debug")]
            gdb: false,
            pci_segments: None,
            platform: None,
            tpm: None,
            landlock_enable: false,
            landlock_rules: None,
            #[cfg(feature = "ivshmem")]
            ivshmem: None,
        };

        valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            image_type: ImageType::Unknown,
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::ImageTypeRequired)
        );

        for max_phys_bits in [0, 31, 65, u8::MAX] {
            let mut invalid_config = valid_config.clone();
            invalid_config.cpus.max_phys_bits = max_phys_bits;
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::InvalidMaxPhysBits(max_phys_bits))
            );
        }

        for max_phys_bits in [MIN_PHYS_BITS, MAX_PHYS_BITS] {
            let mut valid_phys_config = valid_config.clone();
            valid_phys_config.cpus.max_phys_bits = max_phys_bits;
            valid_phys_config.validate().unwrap();
        }

        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            num_queues: 0,
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidNumQueues(0))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.vdpa = Some(vec![VdpaConfig {
            pci_common: PciDeviceCommonConfig::default(),
            path: PathBuf::from("/dev/vhost-vdpa-0"),
            num_queues: 0,
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidNumQueues(0))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.fs = Some(vec![FsConfig {
            pci_common: PciDeviceCommonConfig::default(),
            tag: "test".to_string(),
            socket: PathBuf::from("/tmp/fs.sock"),
            num_queues: 0,
            queue_size: 1024,
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidNumQueues(0))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.serial.output = ConsoleOutput::Tty;
        invalid_config.console.output = ConsoleOutput::Tty;
        valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.payload = None;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::PayloadError(
                PayloadConfigError::MissingBootitem
            ))
        );

        #[cfg(feature = "fw_cfg")]
        {
            let mut firmware_kernel_config = valid_config.clone();
            if let Some(payload) = firmware_kernel_config.payload.as_mut() {
                payload.firmware = Some(PathBuf::from("/path/to/firmware"));
                payload.cmdline = Some("console=hvc0".to_string());
                payload.fw_cfg_config = Some(FwCfgConfig {
                    initramfs: false,
                    ..Default::default()
                });
            }
            firmware_kernel_config.validate().unwrap();

            let mut firmware_kernel_without_fw_cfg = valid_config.clone();
            if let Some(payload) = firmware_kernel_without_fw_cfg.payload.as_mut() {
                payload.firmware = Some(PathBuf::from("/path/to/firmware"));
            }
            assert_eq!(
                firmware_kernel_without_fw_cfg.validate(),
                Err(ValidationError::PayloadError(
                    PayloadConfigError::FirmwarePlusOtherPayloads
                ))
            );

            let mut firmware_kernel_disabled = firmware_kernel_config.clone();
            if let Some(payload) = firmware_kernel_disabled.payload.as_mut() {
                payload.fw_cfg_config.as_mut().unwrap().kernel = false;
            }
            assert_eq!(
                firmware_kernel_disabled.validate(),
                Err(ValidationError::PayloadError(
                    PayloadConfigError::FirmwarePlusOtherPayloads
                ))
            );

            let mut invalid_config = valid_config.clone();
            if let Some(payload) = invalid_config.payload.as_mut() {
                payload.fw_cfg_config = Some(FwCfgConfig {
                    e820: cfg!(target_arch = "x86_64"),
                    kernel: false,
                    cmdline: false,
                    initramfs: false,
                    acpi_tables: true,
                    items: Some(FwCfgItemList {
                        item_list: vec![FwCfgItem {
                            name: "opt/org.test/invalid".to_string(),
                            file: None,
                            string: None,
                        }],
                    }),
                });
            }
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::PayloadError(
                    PayloadConfigError::FwCfgInvalidItem("opt/org.test/invalid".to_string())
                ))
            );

            #[cfg(target_arch = "aarch64")]
            {
                assert!(!FwCfgConfig::default().e820);
                assert!(!FwCfgConfig::parse("kernel=off").unwrap().e820);
            }
        }

        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.max_vcpus = 0;
        invalid_config.cpus.boot_vcpus = 0;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::CpusBootZero)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.max_vcpus = 16;
        invalid_config.cpus.boot_vcpus = 32;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::CpusMaxLowerThanBoot(16, 32))
        );

        #[cfg(target_arch = "x86_64")]
        {
            let mut hint_config = valid_config.clone();
            hint_config.cpus.kvm_hint_realtime = true;
            hint_config.validate().unwrap();
            hint_config.cpus.kvm_hyperv = true;
            assert_eq!(
                hint_config.validate(),
                Err(ValidationError::KvmHintRealtimeWithKvmHyperv)
            );
        }

        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.max_vcpus = 16;
        invalid_config.cpus.boot_vcpus = 16;
        invalid_config.cpus.topology = Some(CpuTopology {
            threads_per_core: 2,
            cores_per_die: 8,
            dies_per_package: 1,
            packages: 2,
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::CpuTopologyCount)
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.cpus.max_vcpus = 8;
        still_valid_config.cpus.boot_vcpus = 8;
        still_valid_config.cpus.topology = Some(CpuTopology {
            threads_per_core: 1,
            cores_per_die: 8,
            dies_per_package: 1,
            packages: 1,
        });
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.cpus.max_vcpus = 8;
        still_valid_config.cpus.boot_vcpus = 8;
        still_valid_config.cpus.topology = Some(CpuTopology {
            threads_per_core: 2,
            cores_per_die: 4,
            dies_per_package: 1,
            packages: 1,
        });
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.boot_vcpus = 1;
        invalid_config.cpus.max_vcpus = 1;
        invalid_config.cpus.topology = Some(CpuTopology {
            threads_per_core: 2,
            cores_per_die: 65535,
            dies_per_package: 1,
            packages: 1,
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::TooManyCpus(65535))
        );

        // Don't test MAX_SUPPORTED_CPUS because it's not guaranteed
        // as other limitation might come in earlier.
        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.max_vcpus = MAX_SUPPORTED_CPUS + 1;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::TooManyCpus(MAX_SUPPORTED_CPUS + 1))
        );

        #[cfg(target_arch = "x86_64")]
        {
            let mut invalid_config = valid_config.clone();
            invalid_config.cpus.max_vcpus = 6;
            invalid_config.cpus.boot_vcpus = 6;
            invalid_config.cpus.topology = Some(CpuTopology {
                threads_per_core: 3,
                cores_per_die: 2,
                dies_per_package: 1,
                packages: 1,
            });
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::CpuTopologyThreadsPerCore)
            );
        }

        let mut invalid_config = valid_config.clone();
        invalid_config.cpus.affinity = Some(Box::new([CpuAffinity {
            vcpu: 0,
            host_cpus: Box::new([1024]),
        }]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::CpuAffinityExceedsMax(1024, 1024))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            vhost_socket: Some("/path/to/sock".to_owned()),
            path: Some(PathBuf::from("/path/to/image")),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::DiskSocketAndPath)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            ..disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserMissingSocket)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            ..disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRequiresSharedMemory)
        );

        // Checking for shared memory must not assume memory zones.
        invalid_config.memory.size = 0;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::MemoryZonesMissing)
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            ..disk_fixture()
        }]);
        still_valid_config.memory.shared = true;
        still_valid_config.validate().unwrap();

        // guest_block_size cannot take effect when the vhost-user backend
        // provides the virtio config space.
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            guest_block_size: Some(4096),
            ..disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserGuestBlockSizeNotSupported)
        );

        // A queue affinity for a queue the disk does not have is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            queue_affinity: Some(Box::new([VirtQueueAffinity {
                queue_index: 1,
                host_cpus: Box::new([0]),
            }])),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidQueueAffinity(1, 1))
        );

        // A block queue size that is not a power of 2 is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            queue_size: 100,
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidQueueSize(100))
        );

        // A power-of-2 block queue size too small for a usable seg_max is
        // rejected with the block-specific error.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            queue_size: MINIMUM_BLOCK_QUEUE_SIZE,
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::BlockQueueSizeTooSmall(
                MINIMUM_BLOCK_QUEUE_SIZE
            ))
        );

        // A disk logical block size that is not a power of 2 is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            guest_block_size: Some(1000),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidGuestBlockSize(1000))
        );

        // A disk logical block size below 512 is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            guest_block_size: Some(256),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidGuestBlockSize(256))
        );

        // A disk logical block size above the 64KiB limit is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            guest_block_size: Some(131072),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidGuestBlockSize(131072))
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.disks = Some(vec![DiskConfig {
            guest_block_size: Some(4096),
            ..raw_disk_fixture()
        }]);
        still_valid_config.validate().unwrap();

        // The override is backend agnostic and accepted for non raw images.
        let mut still_valid_config = valid_config.clone();
        still_valid_config.disks = Some(vec![DiskConfig {
            image_type: ImageType::Qcow2,
            guest_block_size: Some(4096),
            ..disk_fixture()
        }]);
        still_valid_config.validate().unwrap();

        // A net queue size that is not a power of 2 is rejected.
        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            queue_size: 100,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidQueueSize(100))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            vhost_user: true,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRequiresSharedMemory)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.net = Some(vec![NetConfig {
            vhost_user: true,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserMissingSocket)
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.net = Some(vec![NetConfig {
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            ..net_fixture()
        }]);
        still_valid_config.memory.shared = true;
        still_valid_config.validate().unwrap();

        // Test vhost_user with rate limiting for disk
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            rate_limiter_config: Some(RateLimiterConfig::default()),
            ..disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRateLimiterNotSupported)
        );

        // Test vhost_user with rate_limit_group for disk
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.disks = Some(vec![DiskConfig {
            path: None,
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            rate_limit_group: Some("group0".to_string()),
            ..disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRateLimiterNotSupported)
        );

        // Test vhost_user with rate limiting for net
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.net = Some(vec![NetConfig {
            vhost_user: true,
            vhost_socket: Some("/path/to/sock".to_owned()),
            rate_limiter_config: Some(RateLimiterConfig::default()),
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRateLimiterNotSupported)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            num_queues: 3,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VnetQueueOdd(3))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            fds: Some(vec![ExternalFd::default(); 1]),
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VnetReservedFd(-1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            offload_tso: true,
            offload_ufo: true,
            offload_csum: false,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::NoHardwareChecksumOffload)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            ip: None,
            mask: Some("255.255.255.0".parse().unwrap()),
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::MaskProvidedWithoutIp)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.net = Some(vec![NetConfig {
            ip: Some("192.1.33.7".parse().unwrap()),
            mask: None,
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::IpProvidedWithoutMask)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.fs = Some(vec![fs_fixture()]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::VhostUserRequiresSharedMemory)
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.memory.shared = true;
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.memory.hugepages = true;
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.memory.hugepages = true;
        still_valid_config.memory.hugepage_size = Some(2 << 20);
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.hugepages = false;
        invalid_config.memory.hugepage_size = Some(2 << 20);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::HugePageSizeWithoutHugePages)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.hugepages = true;
        invalid_config.memory.hugepage_size = Some(3 << 20);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidHugePageSize(3 << 20))
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.memory.zones = Some(vec![MemoryZoneConfig {
            id: "mem0".to_string(),
            size: 1 << 30,
            hugepages: true,
            hugepage_size: Some(2 << 20),
            ..Default::default()
        }]);
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.zones = Some(vec![MemoryZoneConfig {
            id: "mem0".to_string(),
            size: 1 << 30,
            hugepage_size: Some(2 << 20),
            ..Default::default()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::HugePageSizeWithoutHugePages)
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.zones = Some(vec![MemoryZoneConfig {
            id: "mem0".to_string(),
            size: 1 << 30,
            hugepages: true,
            hugepage_size: Some(0),
            ..Default::default()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidHugePageSize(0))
        );

        // Test mergeable and shared validation for global memory
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.memory.mergeable = true;
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidSharedMemoryWithMergeable)
        );

        // Test mergeable and shared validation for memory zones
        let mut invalid_config = valid_config.clone();
        invalid_config.memory.zones = Some(vec![MemoryZoneConfig {
            id: "mem0".to_string(),
            size: 1 << 30,
            shared: true,
            mergeable: true,
            ..Default::default()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidSharedMemoryWithMergeable)
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(platform_fixture());
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            num_pci_segments: MAX_NUM_PCI_SEGMENTS + 1,
            ..platform_fixture()
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidNumPciSegments(
                MAX_NUM_PCI_SEGMENTS + 1
            ))
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([
                MAX_NUM_PCI_SEGMENTS + 1,
                MAX_NUM_PCI_SEGMENTS + 2,
            ])),
            ..platform_fixture()
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciSegment(MAX_NUM_PCI_SEGMENTS + 1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_address_width_bits: MAX_IOMMU_ADDRESS_WIDTH_BITS + 1,
            ..platform_fixture()
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidIommuAddressWidthBits(
                MAX_IOMMU_ADDRESS_WIDTH_BITS + 1
            ))
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                pci_segment: 1,
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.net = Some(vec![NetConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                pci_segment: 1,
                ..Default::default()
            },
            ..net_fixture()
        }]);
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.pmem = Some(vec![PmemConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                pci_segment: 1,
                ..Default::default()
            },
            ..pmem_fixture()
        }]);
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.devices = Some(vec![DeviceConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                pci_segment: 1,
                ..Default::default()
            },
            ..device_fixture()
        }]);
        still_valid_config.validate().unwrap();

        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        still_valid_config.vsock = Some(VsockConfig {
            socket_type: SocketType::Stream,
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                pci_segment: 1,
                ..Default::default()
            },
            cid: 3,
            socket: PathBuf::new(),
        });
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Off,
                pci_segment: 1,
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.net = Some(vec![NetConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Off,
                pci_segment: 1,
                ..Default::default()
            },
            ..net_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            num_pci_segments: MAX_NUM_PCI_SEGMENTS,
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.pmem = Some(vec![PmemConfig {
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            ..pmem_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            num_pci_segments: MAX_NUM_PCI_SEGMENTS,
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.devices = Some(vec![DeviceConfig {
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            ..device_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.vsock = Some(VsockConfig {
            socket_type: SocketType::Stream,
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            cid: 3,
            socket: PathBuf::new(),
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.user_devices = Some(vec![UserDeviceConfig {
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            socket: PathBuf::new(),
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.vdpa = Some(vec![VdpaConfig {
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            ..vdpa_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.memory.shared = true;
        invalid_config.platform = Some(PlatformConfig {
            iommu_segments: Some(Box::new([1, 2, 3])),
            ..platform_fixture()
        });
        invalid_config.fs = Some(vec![FsConfig {
            pci_common: PciDeviceCommonConfig {
                pci_segment: 1,
                ..Default::default()
            },
            ..fs_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::OnIommuSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            num_pci_segments: 2,
            ..platform_fixture()
        });
        invalid_config.numa = Some(Box::new([
            NumaConfig {
                guest_numa_id: 0,
                cpus: Some(Box::new([0])),
                pci_segments: Some(Box::new([1])),
                ..numa_fixture()
            },
            NumaConfig {
                guest_numa_id: 1,
                cpus: Some(Box::new([1])),
                pci_segments: Some(Box::new([1])),
                ..numa_fixture()
            },
        ]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::PciSegmentReused(1, 0, 1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.pci_segments = Some(Box::new([PciSegmentConfig {
            pci_segment: 0,
            mmio32_aperture_weight: 1,
            mmio64_aperture_weight: 0,
        }]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciSegmentApertureWeight(0))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.pci_segments = Some(Box::new([PciSegmentConfig {
            pci_segment: 0,
            mmio32_aperture_weight: 0,
            mmio64_aperture_weight: 1,
        }]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciSegmentApertureWeight(0))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.numa = Some(Box::new([
            NumaConfig {
                guest_numa_id: 0,
                cpus: Some(Box::new([0])),
                ..numa_fixture()
            },
            NumaConfig {
                guest_numa_id: 1,
                cpus: Some(Box::new([1])),
                pci_segments: Some(Box::new([0])),
                ..numa_fixture()
            },
        ]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::DefaultPciSegmentInvalidNode(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.numa = Some(Box::new([
            NumaConfig {
                guest_numa_id: 0,
                cpus: Some(Box::new([0])),
                pci_segments: Some(Box::new([0])),
                ..numa_fixture()
            },
            NumaConfig {
                guest_numa_id: 1,
                cpus: Some(Box::new([1])),
                pci_segments: Some(Box::new([1])),
                ..numa_fixture()
            },
        ]));
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciSegment(1))
        );

        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            rate_limit_group: Some("foo".into()),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidRateLimiterGroup)
        );

        // Test serial length validation
        let mut valid_serial_config = valid_config.clone();
        valid_serial_config.disks = Some(vec![DiskConfig {
            serial: Some("valid_serial".to_string()),
            ..raw_disk_fixture()
        }]);
        valid_serial_config.validate().unwrap();

        // Test empty string serial (should be valid)
        let mut empty_serial_config = valid_config.clone();
        empty_serial_config.disks = Some(vec![DiskConfig {
            serial: Some(String::new()),
            ..raw_disk_fixture()
        }]);
        empty_serial_config.validate().unwrap();

        // Test None serial (should be valid)
        let mut none_serial_config = valid_config.clone();
        none_serial_config.disks = Some(vec![DiskConfig {
            serial: None,
            ..raw_disk_fixture()
        }]);
        none_serial_config.validate().unwrap();

        // Test maximum length serial (exactly VIRTIO_BLK_ID_BYTES)
        let max_serial = "a".repeat(VIRTIO_BLK_ID_BYTES as usize);
        let mut max_serial_config = valid_config.clone();
        max_serial_config.disks = Some(vec![DiskConfig {
            serial: Some(max_serial),
            ..raw_disk_fixture()
        }]);
        max_serial_config.validate().unwrap();

        // Test serial length exceeding VIRTIO_BLK_ID_BYTES
        let long_serial = "a".repeat(VIRTIO_BLK_ID_BYTES as usize + 1);
        let mut invalid_serial_config = valid_config.clone();
        invalid_serial_config.disks = Some(vec![DiskConfig {
            serial: Some(long_serial.clone()),
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_serial_config.validate(),
            Err(ValidationError::InvalidSerialLength(
                long_serial.len(),
                VIRTIO_BLK_ID_BYTES as usize
            ))
        );

        let mut still_valid_config = valid_config.clone();
        still_valid_config.devices = Some(vec![
            DeviceConfig {
                path: Some("/device1".into()),
                ..device_fixture()
            },
            DeviceConfig {
                path: Some("/device2".into()),
                ..device_fixture()
            },
        ]);
        still_valid_config.validate().unwrap();

        let mut invalid_config = valid_config.clone();
        invalid_config.devices = Some(vec![
            DeviceConfig {
                path: Some("/device1".into()),
                ..device_fixture()
            },
            DeviceConfig {
                path: Some("/device1".into()),
                ..device_fixture()
            },
        ]);
        invalid_config.validate().unwrap_err();

        // An fd-backed DeviceConfig is only valid with
        // externally-supplied fd is provided for iommufd too
        let mut fd_valid_config = valid_config.clone();
        fd_valid_config.platform = Some(PlatformConfig {
            iommufd: true,
            iommufd_fd: fd.clone(),
            ..platform_fixture()
        });
        fd_valid_config.devices = Some(vec![DeviceConfig {
            path: None,
            fd: fd.clone(),
            ..device_fixture()
        }]);
        fd_valid_config.validate().unwrap();

        let mut fd_without_iommufd_fd = fd_valid_config.clone();
        fd_without_iommufd_fd.platform = Some(PlatformConfig {
            iommufd: true,
            iommufd_fd: Default::default(),
            ..platform_fixture()
        });
        assert!(matches!(
            fd_without_iommufd_fd.validate(),
            Err(ValidationError::VfioFdRequiresIommufdFd),
        ));

        // iommufd_fd without iommufd=on is rejected at PlatformConfig::validate.
        let mut iommufd_fd_without_iommufd = valid_config.clone();
        iommufd_fd_without_iommufd.platform = Some(PlatformConfig {
            iommufd: false,
            iommufd_fd: fd.clone(),
            ..platform_fixture()
        });
        assert!(matches!(
            iommufd_fd_without_iommufd.validate(),
            Err(ValidationError::IommufdFdRequiresIommufd),
        ));

        // Exactly one of path and fd must be set.
        let mut both_path_and_fd = fd_valid_config.clone();
        both_path_and_fd.devices = Some(vec![DeviceConfig {
            path: Some("/device1".into()),
            fd: fd.clone(),
            ..device_fixture()
        }]);
        assert!(matches!(
            both_path_and_fd.validate(),
            Err(ValidationError::VfioDeviceBothPathAndFd),
        ));

        let mut neither_path_nor_fd = fd_valid_config.clone();
        neither_path_nor_fd.devices = Some(vec![DeviceConfig {
            path: None,
            fd: Default::default(),
            ..device_fixture()
        }]);
        assert!(matches!(
            neither_path_nor_fd.validate(),
            Err(ValidationError::VfioDeviceNeitherPathNorFd),
        ));
        #[cfg(all(feature = "sev_snp", any(not(feature = "kvm"), feature = "fw_cfg")))]
        {
            let mut sev_snp_config = valid_config.clone();
            sev_snp_config.platform = Some(PlatformConfig {
                sev_snp: true,
                ..platform_fixture()
            });

            #[cfg(all(feature = "kvm", feature = "fw_cfg"))]
            {
                sev_snp_config.payload.as_mut().unwrap().fw_cfg_config = Some(FwCfgConfig {
                    kernel: false,
                    cmdline: false,
                    initramfs: false,
                    ..Default::default()
                });
            }

            // Payload with empty host data
            let mut config_with_no_host_data = sev_snp_config.clone();
            config_with_no_host_data.payload = Some(PayloadConfig {
                kernel: Some(PathBuf::from("/path/to/kernel")),
                firmware: None,
                cmdline: None,
                initramfs: None,
                #[cfg(feature = "igvm")]
                igvm: Some(PathBuf::from("/path/to/igvm")),
                #[cfg(feature = "sev_snp")]
                host_data: Some(String::new()),
                #[cfg(feature = "fw_cfg")]
                fw_cfg_config: None,
            });
            config_with_no_host_data.validate().unwrap_err();

            // Payload with no host data provided
            let mut valid_config_with_no_host_data = sev_snp_config.clone();
            let payload = valid_config_with_no_host_data.payload.as_mut().unwrap();
            payload.igvm = Some(PathBuf::from("/path/to/igvm"));
            payload.host_data = None;
            valid_config_with_no_host_data.validate().unwrap();

            // Payload with invalid host data length i.e less than 64
            let mut config_with_invalid_host_data = sev_snp_config.clone();
            config_with_invalid_host_data.payload = Some(PayloadConfig {
                kernel: Some(PathBuf::from("/path/to/kernel")),
                firmware: None,
                cmdline: None,
                initramfs: None,
                #[cfg(feature = "igvm")]
                igvm: Some(PathBuf::from("/path/to/igvm")),
                #[cfg(feature = "sev_snp")]
                host_data: Some(
                    "243eb7dc1a21129caa91dcbb794922b933baecb5823a377eb43118867328".to_string(),
                ),
                #[cfg(feature = "fw_cfg")]
                fw_cfg_config: None,
            });
            config_with_invalid_host_data.validate().unwrap_err();

            let payload = sev_snp_config.payload.as_mut().unwrap();
            payload.kernel = None;
            payload.igvm = Some(PathBuf::from("/path/to/igvm"));
            sev_snp_config.validate().unwrap();

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.memory.hotplug_size = Some(1);
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoMemoryHotplug)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.memory.hotplugged_size = Some(1);
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoMemoryHotplug)
            );

            let mut cpu_config = sev_snp_config.clone();
            cpu_config.cpus.max_vcpus = 2;
            #[cfg(feature = "kvm")]
            cpu_config.validate().unwrap();
            #[cfg(not(feature = "kvm"))]
            assert_eq!(
                cpu_config.validate(),
                Err(ValidationError::SevSnpNoCpuHotplug)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.memory.hugepages = true;
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoHugePages)
            );

            let iommu_pci_common = PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                ..Default::default()
            };

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.disks = Some(vec![DiskConfig {
                pci_common: iommu_pci_common.clone(),
                ..raw_disk_fixture()
            }]);
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoViommu)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.devices = Some(vec![DeviceConfig {
                pci_common: iommu_pci_common.clone(),
                ..device_fixture()
            }]);
            invalid_config.platform = Some(PlatformConfig {
                sev_snp: true,
                iommufd: true,
                ..platform_fixture()
            });
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoViommu)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.platform = Some(PlatformConfig {
                sev_snp: true,
                iommu_segments: Some(Box::new([1])),
                ..platform_fixture()
            });
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoViommu)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.vdpa = Some(vec![VdpaConfig {
                path: PathBuf::from("/path/to/vdpa"),
                ..vdpa_fixture()
            }]);
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpNoVdpa)
            );

            let mut invalid_config = sev_snp_config.clone();
            invalid_config.devices = Some(vec![device_fixture()]);
            assert_eq!(
                invalid_config.validate(),
                Err(ValidationError::SevSnpRequiresIommufd)
            );

            let mut valid = sev_snp_config.clone();
            valid.devices = Some(vec![device_fixture()]);
            valid.platform = Some(PlatformConfig {
                sev_snp: true,
                iommufd: true,
                ..platform_fixture()
            });
            valid.validate().unwrap();
        }

        // Devices cannot ask for different types of virtual IOMMU.
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Virtio,
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert!(invalid_config.virtio_iommu_attached());
        assert!(!invalid_config.smmuv3_attached());

        invalid_config.devices = Some(vec![DeviceConfig {
            pci_common: PciDeviceCommonConfig {
                iommu: IommuType::Smmuv3,
                ..Default::default()
            },
            ..device_fixture()
        }]);
        assert!(invalid_config.smmuv3_attached());
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::MixedIommuTypes)
        );

        invalid_config.disks = None;
        assert_ne!(
            invalid_config.validate(),
            Err(ValidationError::MixedIommuTypes)
        );

        // x_nv_gpudirect_clique with vfio_p2p_dma=off should fail
        let mut invalid_config = valid_config.clone();
        invalid_config.platform = Some(PlatformConfig {
            vfio_p2p_dma: false,
            ..platform_fixture()
        });
        invalid_config.devices = Some(vec![DeviceConfig {
            x_nv_gpudirect_clique: Some(0),
            ..device_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::GpuDirectCliqueRequiresP2pDma)
        );

        // x_nv_gpudirect_clique with vfio_p2p_dma=on should pass
        let mut still_valid_config = valid_config.clone();
        still_valid_config.platform = Some(PlatformConfig {
            vfio_p2p_dma: true,
            ..platform_fixture()
        });
        still_valid_config.devices = Some(vec![DeviceConfig {
            x_nv_gpudirect_clique: Some(0),
            ..device_fixture()
        }]);
        still_valid_config.validate().unwrap();

        // x_nv_gpudirect_clique with no platform config (default p2p_dma=on) should pass
        let mut still_valid_config = valid_config.clone();
        still_valid_config.devices = Some(vec![DeviceConfig {
            x_nv_gpudirect_clique: Some(0),
            ..device_fixture()
        }]);
        still_valid_config.validate().unwrap();

        // x_exclude_mmap_bars only accepts PCI BAR indices 0 through 5
        let mut invalid_config = valid_config.clone();
        invalid_config.devices = Some(vec![DeviceConfig {
            x_exclude_mmap_bars: vec![6],
            ..device_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidDeviceExcludeMmapBar(6))
        );

        // Valid BDF test
        let mut still_valid_config = valid_config.clone();
        still_valid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                pci_device_id: Some(8),
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        still_valid_config.validate().unwrap();
        // Invalid BDF - Same ID as Root device
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                pci_device_id: Some(pci::PCI_ROOT_DEVICE_ID),
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::ReservedPciDeviceId(
                pci::PCI_ROOT_DEVICE_ID
            ))
        );
        // Invalid BDF - Out of range
        let mut invalid_config = valid_config.clone();
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                pci_device_id: Some(pci::NUM_DEVICE_IDS + 1),
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciDeviceId(pci::NUM_DEVICE_IDS + 1))
        );

        // Invalid balloon BDF - Same ID as Root device
        let mut invalid_config = valid_config.clone();
        invalid_config.balloon = Some(BalloonConfig {
            pci_common: PciDeviceCommonConfig {
                pci_device_id: Some(pci::PCI_ROOT_DEVICE_ID),
                ..Default::default()
            },
            size: 0,
            deflate_on_oom: false,
            free_page_reporting: false,
        });
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::ReservedPciDeviceId(
                pci::PCI_ROOT_DEVICE_ID
            ))
        );

        // Invalid balloon ID - Duplicate identifier
        let mut invalid_config = valid_config.clone();
        invalid_config.balloon = Some(BalloonConfig {
            pci_common: PciDeviceCommonConfig {
                id: Some("test0".to_string()),
                ..Default::default()
            },
            size: 0,
            deflate_on_oom: false,
            free_page_reporting: false,
        });
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                id: Some("test0".to_string()),
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::IdentifierNotUnique("test0".to_string()))
        );

        // Invalid console BDF - Same ID as Root device
        let mut invalid_config = valid_config.clone();
        invalid_config.console.pci_common.pci_device_id = Some(pci::PCI_ROOT_DEVICE_ID);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::ReservedPciDeviceId(
                pci::PCI_ROOT_DEVICE_ID
            ))
        );
        // Invalid console BDF - Out of range
        let mut invalid_config = valid_config.clone();
        invalid_config.console.pci_common.pci_device_id = Some(pci::NUM_DEVICE_IDS + 1);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::InvalidPciDeviceId(pci::NUM_DEVICE_IDS + 1))
        );
        // Invalid console ID - Duplicate identifier
        let mut invalid_config = valid_config.clone();
        invalid_config.console.pci_common.id = Some("test0".to_string());
        invalid_config.disks = Some(vec![DiskConfig {
            pci_common: PciDeviceCommonConfig {
                id: Some("test0".to_string()),
                ..Default::default()
            },
            ..raw_disk_fixture()
        }]);
        assert_eq!(
            invalid_config.validate(),
            Err(ValidationError::IdentifierNotUnique("test0".to_string()))
        );
    }
    #[test]
    fn test_landlock_parsing() -> Result<()> {
        // should not be empty
        LandlockConfig::parse("").unwrap_err();
        // access should not be empty
        LandlockConfig::parse("path=/dir/path1").unwrap_err();
        LandlockConfig::parse("path=/dir/path1,access=rwr").unwrap_err();
        assert_eq!(
            LandlockConfig::parse("path=/dir/path1,access=rw")?,
            LandlockConfig {
                path: PathBuf::from("/dir/path1"),
                access: "rw".to_string(),
            }
        );
        Ok(())
    }
    #[test]
    #[cfg(feature = "fw_cfg")]
    fn test_fw_cfg_config_item_list_parsing() -> Result<()> {
        // Empty list
        FwCfgConfig::parse("items=[]").unwrap_err();
        // Missing closing bracket
        FwCfgConfig::parse("items=[name=opt/org.test/fw_cfg_test_item,file=/tmp/fw_cfg_test_item")
            .unwrap_err();
        // Single file Item
        assert_eq!(
            FwCfgConfig::parse(
                "items=[name=opt/org.test/fw_cfg_test_item,file=/tmp/fw_cfg_test_item]"
            )?,
            FwCfgConfig {
                items: Some(FwCfgItemList {
                    item_list: vec![FwCfgItem {
                        name: "opt/org.test/fw_cfg_test_item".to_string(),
                        file: Some(PathBuf::from("/tmp/fw_cfg_test_item")),
                        string: None,
                    }]
                }),
                ..Default::default()
            },
        );
        // Multiple file Items
        assert_eq!(
            FwCfgConfig::parse(
                "items=[name=opt/org.test/fw_cfg_test_item,file=/tmp/fw_cfg_test_item:name=opt/org.test/fw_cfg_test_item2,file=/tmp/fw_cfg_test_item2]"
            )?,
            FwCfgConfig {
                items: Some(FwCfgItemList {
                    item_list: vec![
                        FwCfgItem {
                            name: "opt/org.test/fw_cfg_test_item".to_string(),
                            file: Some(PathBuf::from("/tmp/fw_cfg_test_item")),
                            string: None,
                        },
                        FwCfgItem {
                            name: "opt/org.test/fw_cfg_test_item2".to_string(),
                            file: Some(PathBuf::from("/tmp/fw_cfg_test_item2")),
                            string: None,
                        }
                    ]
                }),
                ..Default::default()
            },
        );
        // Single string Item (for OVMF MMIO64 config, GPU CC passthrough, etc.)
        assert_eq!(
            FwCfgConfig::parse("items=[name=opt/ovmf/X-PciMmio64Mb,string=262144]")?,
            FwCfgConfig {
                items: Some(FwCfgItemList {
                    item_list: vec![FwCfgItem {
                        name: "opt/ovmf/X-PciMmio64Mb".to_string(),
                        file: None,
                        string: Some("262144".to_string()),
                    }]
                }),
                ..Default::default()
            },
        );
        // Mixed file and string Items
        assert_eq!(
            FwCfgConfig::parse(
                "items=[name=opt/org.test/fw_cfg_test_item,file=/tmp/fw_cfg_test_item:name=opt/ovmf/X-PciMmio64Mb,string=262144]"
            )?,
            FwCfgConfig {
                items: Some(FwCfgItemList {
                    item_list: vec![
                        FwCfgItem {
                            name: "opt/org.test/fw_cfg_test_item".to_string(),
                            file: Some(PathBuf::from("/tmp/fw_cfg_test_item")),
                            string: None,
                        },
                        FwCfgItem {
                            name: "opt/ovmf/X-PciMmio64Mb".to_string(),
                            file: None,
                            string: Some("262144".to_string()),
                        }
                    ]
                }),
                ..Default::default()
            },
        );
        // Missing both file and string parses OK but fails validation
        let missing_content =
            FwCfgConfig::parse("items=[name=opt/org.test/missing_content]").unwrap();
        assert_eq!(
            missing_content.items.as_ref().unwrap().item_list[0].file,
            None
        );
        assert_eq!(
            missing_content.items.as_ref().unwrap().item_list[0].string,
            None
        );
        // Both file and string parses OK but fails validation
        let both = FwCfgConfig::parse("items=[name=opt/org.test/both,file=/tmp/test,string=test]")
            .unwrap();
        assert!(both.items.as_ref().unwrap().item_list[0].file.is_some());
        assert!(both.items.as_ref().unwrap().item_list[0].string.is_some());
        Ok(())
    }
}
