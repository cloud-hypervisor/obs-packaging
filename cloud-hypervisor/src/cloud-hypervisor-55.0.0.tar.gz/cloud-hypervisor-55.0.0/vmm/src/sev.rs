// Copyright (c) Meta Platforms, Inc. and affiliates.
//
// SPDX-License-Identifier: Apache-2.0
//

use std::ffi::CString;
use std::fs::File;
use std::io::{self, Cursor, Read, Seek, SeekFrom};
use std::os::unix::fs::FileExt;
use std::result;
use std::sync::{Arc, Mutex, Weak};

use hypervisor::MemoryConversionHandler;
use linux_loader::bootparam::boot_params;
use log::error;
use sha2::{Digest, Sha256};
use uuid::{Uuid, uuid};
use vm_device::dma_mapping::{ExternalDmaMapping, ExternalDmaMappingError};
use vm_memory::ByteValued;
use vmm_sys_util::errno;
use zerocopy::{Immutable, IntoBytes};

use crate::util::flatten_error_chain_to_string;

pub(crate) type Result<T> = result::Result<T, errno::Error>;

// https://github.com/tianocore/edk2/blob/f98662c5e35b6ab60f46ee4350fa0e6eab0497cf/OvmfPkg/Include/Fdf/MemFd.fdf.inc#L89-L93
pub(crate) const SEV_HASH_BLOCK_ADDRESS: u64 = 0x10c00;
pub(crate) const SEV_HASH_BLOCK_SIZE: usize = 0x400;
const SHA256_HASH_SIZE: usize = 32;

// Measured hashes table definitions. These match the definitions found in
// QEMU's implementation: https://gitlab.com/qemu-project/qemu/-/blob/master/target/i386/sev.c#L68
#[repr(C, packed)]
#[derive(IntoBytes, Immutable)]
struct SevHashTableEntry {
    pub guid: [u8; 16],
    pub len: u16,
    pub hash: [u8; SHA256_HASH_SIZE],
}

#[repr(C, packed)]
#[derive(IntoBytes, Immutable)]
struct SevHashTable {
    pub guid: [u8; 16],
    pub len: u16,
    pub cmdline: SevHashTableEntry,
    pub initrd: SevHashTableEntry,
    pub kernel: SevHashTableEntry,
}

const SEV_HASH_TABLE_PADDING: usize =
    size_of::<SevHashTable>().next_multiple_of(16) - size_of::<SevHashTable>();

#[derive(IntoBytes, Immutable)]
struct PaddedSevHashTable {
    #[expect(dead_code)]
    hash_table: SevHashTable,
    #[expect(dead_code)]
    padding: [u8; SEV_HASH_TABLE_PADDING],
}

// These GUIDs are defined in both EDK2 and QEMU:
// https://github.com/tianocore/edk2/blob/master/OvmfPkg/AmdSev/BlobVerifierLibSevHashes/BlobVerifierSevHashes.c#L36-L43
// https://gitlab.com/qemu-project/qemu/-/blob/master/target/i386/sev.c#L2344-2360
const SEV_HASH_TABLE_GUID: Uuid = uuid!("9438d606-4f22-4cc9-b479-a793d411fd21");
const SEV_KERNEL_HASH_GUID: Uuid = uuid!("4de79437-abd2-427f-b835-d5b172d2045b");
const SEV_INITRD_HASH_GUID: Uuid = uuid!("44baf731-3a2f-4bd7-9af1-41e29169781d");
const SEV_CMDLINE_HASH_GUID: Uuid = uuid!("97d02dd8-bd20-4c94-aa78-e7714d36ab2a");

pub(crate) struct MeasuredBootInfo {
    pub kernel: File,
    // QEMU also makes initrd optional in the hash table
    pub initramfs: Option<File>,
    pub cmdline: CString,
}

impl MeasuredBootInfo {
    fn measured_boot_io(err: &io::Error) -> errno::Error {
        errno::Error::new(err.raw_os_error().unwrap_or(libc::EINVAL))
    }

    fn sha256_reader<R: Read>(mut reader: R) -> Result<[u8; 32]> {
        let mut hasher = Sha256::new();
        let mut chunk = [0u8; 8192];
        loop {
            let bytes_read = reader
                .read(&mut chunk)
                .map_err(|e| Self::measured_boot_io(&e))?;
            if bytes_read == 0 {
                break;
            }
            hasher.update(&chunk[..bytes_read]);
        }

        Ok(hasher.finalize().into())
    }

    pub(crate) fn build_hash_block(&self) -> Result<[u8; SEV_HASH_BLOCK_SIZE]> {
        // Current tooling appends a NUL byte at the end of cmdlines:
        // https://github.com/virtee/sev-snp-measure/blob/main/sevsnpmeasure/sev_hashes.py#L71-L74
        let cmdline_digest: [u8; 32] = Sha256::digest(self.cmdline.as_bytes_with_nul()).into();

        // If no initrd is provided, we will simply hash over an empty buffer, mimicking
        // QEMU's behavior: https://gitlab.com/qemu-project/qemu/-/blob/master/target/i386/sev.c#L2387
        let initrd_digest: [u8; 32] = if let Some(initramfs) = &self.initramfs {
            let mut initramfs = initramfs
                .try_clone()
                .map_err(|e| Self::measured_boot_io(&e))?;
            initramfs
                .seek(SeekFrom::Start(0))
                .map_err(|e| Self::measured_boot_io(&e))?;
            Self::sha256_reader(initramfs)?
        } else {
            Self::sha256_reader(Cursor::new([]))?
        };

        // The kernel components are split up into a setup section and the actual kernel data,
        // so split them up to avoid double counting, assuming this is a bzImage Linux kernel
        let mut setup_header = vec![0u8; size_of::<boot_params>()];
        self.kernel
            .read_exact_at(&mut setup_header, 0)
            .map_err(|e| Self::measured_boot_io(&e))?;

        let kernel_start = {
            // Matches QEMU's way of finding the kernel start/setup start
            // https://gitlab.com/qemu-project/qemu/-/blob/master/hw/i386/x86-common.c#L903
            let bp = boot_params::from_mut_slice(&mut setup_header).unwrap();
            let setup_sects = if bp.hdr.setup_sects == 0 {
                4
            } else {
                bp.hdr.setup_sects
            };
            (u64::from(setup_sects) + 1) * 512
        };
        let setup_len = kernel_start as usize;
        let mut setup_data = vec![0u8; setup_len];
        if setup_len <= setup_header.len() {
            setup_data.copy_from_slice(&setup_header[..setup_len]);
        } else {
            setup_data[..setup_header.len()].copy_from_slice(&setup_header);
            self.kernel
                .read_exact_at(
                    &mut setup_data[setup_header.len()..],
                    setup_header.len() as u64,
                )
                .map_err(|e| Self::measured_boot_io(&e))?;
        }

        let mut kernel = self
            .kernel
            .try_clone()
            .map_err(|e| Self::measured_boot_io(&e))?;
        kernel
            .seek(SeekFrom::Start(kernel_start))
            .map_err(|e| Self::measured_boot_io(&e))?;
        let kernel_digest = Self::sha256_reader(Cursor::new(setup_data).chain(kernel))?;

        let table = PaddedSevHashTable {
            hash_table: SevHashTable {
                guid: SEV_HASH_TABLE_GUID.to_bytes_le(),
                len: size_of::<SevHashTable>() as u16,
                cmdline: SevHashTableEntry {
                    guid: SEV_CMDLINE_HASH_GUID.to_bytes_le(),
                    len: size_of::<SevHashTableEntry>() as u16,
                    hash: cmdline_digest,
                },
                initrd: SevHashTableEntry {
                    guid: SEV_INITRD_HASH_GUID.to_bytes_le(),
                    len: size_of::<SevHashTableEntry>() as u16,
                    hash: initrd_digest,
                },
                kernel: SevHashTableEntry {
                    guid: SEV_KERNEL_HASH_GUID.to_bytes_le(),
                    len: size_of::<SevHashTableEntry>() as u16,
                    hash: kernel_digest,
                },
            },
            padding: [0; SEV_HASH_TABLE_PADDING],
        };

        let mut hash_block = [0u8; SEV_HASH_BLOCK_SIZE];
        // The remainder of the page is zeroed to ensure measurements are reliably calculated
        hash_block[..size_of::<PaddedSevHashTable>()].copy_from_slice(table.as_bytes());
        Ok(hash_block)
    }
}

/// SEV-SNP RMP/PSC minimum conversion granule.
pub(crate) const PAGE_SIZE_4K: u64 = 4096;

const BITS_PER_U64: usize = u64::BITS as usize;

struct TrackedRegion {
    base: u64,
    /// One bit per 4KiB page, bits past num_pages are just padding
    shared: Vec<u64>,
    /// Number of 4KiB tracked pages
    num_pages: usize,
}

impl TrackedRegion {
    fn new(base: u64, size: u64) -> Self {
        let num_pages = size.div_ceil(PAGE_SIZE_4K) as usize;
        Self {
            base,
            shared: vec![0; num_pages.div_ceil(BITS_PER_U64)],
            num_pages,
        }
    }

    fn end(&self) -> u64 {
        self.base + self.num_pages as u64 * PAGE_SIZE_4K
    }

    fn is_shared(&self, page: usize) -> bool {
        self.shared[page / BITS_PER_U64] & (1 << (page % BITS_PER_U64)) != 0
    }

    fn shared_gpas(&self) -> impl Iterator<Item = u64> + '_ {
        (0..self.num_pages)
            .filter(|&i| self.is_shared(i))
            .map(|i| self.base + i as u64 * PAGE_SIZE_4K)
    }
}

#[derive(Default)]
struct Inner {
    regions: Vec<TrackedRegion>,
    handler: Option<Weak<dyn ExternalDmaMapping>>,
}

/// Tracks which confidential guest pages are shared and keeps the device
/// IOMMU mapping exactly those pages.
#[derive(Default)]
pub(crate) struct SevSnpSharedPageTracker {
    inner: Mutex<Inner>,
}

impl SevSnpSharedPageTracker {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    /// Register a confidential RAM region `[base, base + size)`.
    pub(crate) fn register_region(&self, base: u64, size: u64) {
        self.inner
            .lock()
            .unwrap()
            .regions
            .push(TrackedRegion::new(base, size));
    }

    /// Register a weak reference to a VFIO DMA handler and replay shared pages.
    /// The caller must retain the handler while DMA mapping is needed.
    /// A partial replay is rolled back, so a failed registration leaves nothing
    /// mapped in the IOMMU.
    pub(crate) fn add_dma_mapping_handler(
        &self,
        handler: &Arc<dyn ExternalDmaMapping>,
    ) -> result::Result<(), ExternalDmaMappingError> {
        let mut inner = self.inner.lock().unwrap();
        let shared = inner.regions.iter().flat_map(TrackedRegion::shared_gpas);
        for (mapped, gpa) in shared.enumerate() {
            if let Err(e) = handler.map(gpa, gpa, PAGE_SIZE_4K) {
                // The handler stays unregistered, so no later conversion would
                // ever unmap what the replay already mapped.
                Self::undo_replay(handler.as_ref(), &inner.regions, mapped);
                return Err(e);
            }
        }

        inner.handler = Some(Arc::downgrade(handler));
        Ok(())
    }

    fn undo_replay(handler: &dyn ExternalDmaMapping, regions: &[TrackedRegion], count: usize) {
        let shared = regions.iter().flat_map(TrackedRegion::shared_gpas);
        for gpa in shared.take(count) {
            if let Err(e) = handler.unmap(gpa, PAGE_SIZE_4K) {
                error!(
                    "VFIO replay rollback failed gpa={gpa:#x}: {}",
                    flatten_error_chain_to_string(&e)
                );
            }
        }
    }

    /// Flip `[gpa, gpa + size)` shared/private in the tracker, driving the
    /// handler so the device IOMMU maps the shared pages only.
    fn set_shared(
        &self,
        gpa: u64,
        size: u64,
        shared: bool,
    ) -> result::Result<(), ExternalDmaMappingError> {
        let mut inner = self.inner.lock().unwrap();
        let Inner { regions, handler } = &mut *inner;
        let handler = handler.as_ref().and_then(Weak::upgrade);
        let req_end = gpa.saturating_add(size);

        for region in regions.iter_mut() {
            let start = gpa.max(region.base);
            let end = req_end.min(region.end());
            if start >= end {
                continue;
            }
            let first_page = ((start - region.base) / PAGE_SIZE_4K) as usize;
            let end_page = (end - region.base).div_ceil(PAGE_SIZE_4K) as usize;

            if shared {
                Self::map_pages(handler.as_deref(), region, first_page, end_page)?;
            } else {
                Self::unmap_pages(handler.as_deref(), region, first_page, end_page)?;
            }
        }
        Ok(())
    }

    /// Map each newly shared page one at a time. We map one page per call,
    /// not one big mapping for the whole range. A  mapping can only be removed
    /// as a whole, never split, so the size we map here is the smallest unit we
    /// can later unmap. This lets `unmap_pages()` remove any single page.
    fn map_pages(
        handler: Option<&dyn ExternalDmaMapping>,
        region: &mut TrackedRegion,
        first_page: usize,
        end_page: usize,
    ) -> result::Result<(), ExternalDmaMappingError> {
        assert!(end_page <= region.num_pages);
        for i in first_page..end_page {
            if region.is_shared(i) {
                continue;
            }
            let gpa = region.base + i as u64 * PAGE_SIZE_4K;
            if let Some(handler) = handler {
                handler.map(gpa, gpa, PAGE_SIZE_4K)?;
            }
            region.shared[i / BITS_PER_U64] |= 1 << (i % BITS_PER_U64);
        }
        Ok(())
    }

    /// Clear each shared page in `[first_page, end_page)`, coalescing contiguous runs
    /// into a single unmap.
    fn unmap_pages(
        handler: Option<&dyn ExternalDmaMapping>,
        region: &mut TrackedRegion,
        first_page: usize,
        end_page: usize,
    ) -> result::Result<(), ExternalDmaMappingError> {
        assert!(end_page <= region.num_pages);
        let mut i = first_page;
        while i < end_page {
            if !region.is_shared(i) {
                i += 1;
                continue;
            }
            let run = i;
            while i < end_page && region.is_shared(i) {
                i += 1;
            }
            let gpa = region.base + run as u64 * PAGE_SIZE_4K;
            let len = (i - run) as u64 * PAGE_SIZE_4K;
            if let Some(handler) = handler {
                handler.unmap(gpa, len)?;
            }
            for page in run..i {
                region.shared[page / BITS_PER_U64] &= !(1 << (page % BITS_PER_U64));
            }
        }
        Ok(())
    }
}

impl MemoryConversionHandler for SevSnpSharedPageTracker {
    fn handle_conversion(&self, gpa: u64, size: u64, to_shared: bool) -> anyhow::Result<()> {
        self.set_shared(gpa, size, to_shared)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use std::cmp;
    use std::io::Write;

    use super::*;

    fn make_tempfile(data: &[u8]) -> File {
        let mut f = tempfile::tempfile().unwrap();
        f.write_all(data).unwrap();
        f
    }

    fn make_fake_kernel(setup_sects: u8, kernel_payload: &[u8]) -> File {
        let effective_sects = if setup_sects == 0 { 4 } else { setup_sects };
        let setup_len = (usize::from(effective_sects) + 1) * 512;
        let header_size = size_of::<boot_params>();
        let file_len = cmp::max(setup_len, header_size) + kernel_payload.len();

        let mut buf = vec![0u8; file_len];
        let bp = boot_params::from_mut_slice(&mut buf[..header_size]).unwrap();
        bp.hdr.setup_sects = setup_sects;
        buf[setup_len..setup_len + kernel_payload.len()].copy_from_slice(kernel_payload);

        make_tempfile(&buf)
    }

    #[test]
    fn hash_block_cmdline_includes_nul() {
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, b"K"),
            initramfs: None,
            cmdline: CString::new("test").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected: [u8; 32] = Sha256::digest(b"test\0").into();
        let cmdline_hash_offset = 2 * (size_of::<[u8; 16]>() + size_of::<u16>());
        assert_eq!(
            &block[cmdline_hash_offset..cmdline_hash_offset + 32],
            &expected
        );
    }

    #[test]
    fn hash_block_no_initrd_hashes_empty() {
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, b"K"),
            initramfs: None,
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected: [u8; 32] = Sha256::digest([]).into();

        let initrd_hash_offset =
            2 * (size_of::<[u8; 16]>() + size_of::<u16>()) + size_of::<SevHashTableEntry>();
        assert_eq!(
            &block[initrd_hash_offset..initrd_hash_offset + 32],
            &expected
        );
    }

    #[test]
    fn hash_block_with_initrd() {
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, b"K"),
            initramfs: Some(make_tempfile(b"INITRD_CONTENTS")),
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected: [u8; 32] = Sha256::digest(b"INITRD_CONTENTS").into();
        let initrd_hash_offset =
            2 * (size_of::<[u8; 16]>() + size_of::<u16>()) + size_of::<SevHashTableEntry>();
        assert_eq!(
            &block[initrd_hash_offset..initrd_hash_offset + 32],
            &expected
        );
    }

    #[test]
    fn hash_block_guid_placement() {
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, b"K"),
            initramfs: None,
            cmdline: CString::new("x").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        assert_eq!(&block[0..16], SEV_HASH_TABLE_GUID.to_bytes_le());
        assert_eq!(&block[18..34], SEV_CMDLINE_HASH_GUID.to_bytes_le());
        let initrd_guid_offset =
            size_of::<[u8; 16]>() + size_of::<u16>() + size_of::<SevHashTableEntry>();
        assert_eq!(
            &block[initrd_guid_offset..initrd_guid_offset + 16],
            SEV_INITRD_HASH_GUID.to_bytes_le()
        );
        let kernel_guid_offset = initrd_guid_offset + size_of::<SevHashTableEntry>();
        assert_eq!(
            &block[kernel_guid_offset..kernel_guid_offset + 16],
            SEV_KERNEL_HASH_GUID.to_bytes_le()
        );
    }

    #[test]
    fn hash_block_struct_sizes() {
        assert_eq!(size_of::<SevHashTableEntry>(), 16 + 2 + 32);
        assert_eq!(
            size_of::<SevHashTable>(),
            16 + 2 + 3 * size_of::<SevHashTableEntry>()
        );
        assert_eq!(size_of::<PaddedSevHashTable>() % 16, 0);
        assert!(size_of::<PaddedSevHashTable>() <= SEV_HASH_BLOCK_SIZE);
    }

    #[test]
    fn hash_block_remainder_is_zeroed() {
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, b"K"),
            initramfs: None,
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let table_end = size_of::<PaddedSevHashTable>();
        assert!(block[table_end..].iter().all(|&b| b == 0));
    }

    fn expected_kernel_digest(setup_sects: u8, kernel_payload: &[u8]) -> [u8; 32] {
        let effective_sects = if setup_sects == 0 { 4 } else { setup_sects };
        let setup_len = (usize::from(effective_sects) + 1) * 512;
        let header_size = size_of::<boot_params>();
        let file_len = cmp::max(setup_len, header_size) + kernel_payload.len();

        let mut buf = vec![0u8; file_len];
        let bp = boot_params::from_mut_slice(&mut buf[..header_size]).unwrap();
        bp.hdr.setup_sects = setup_sects;
        buf[setup_len..setup_len + kernel_payload.len()].copy_from_slice(kernel_payload);

        Sha256::digest(&buf).into()
    }

    fn kernel_hash_offset() -> usize {
        size_of::<[u8; 16]>()
            + size_of::<u16>()
            + 2 * size_of::<SevHashTableEntry>()
            + size_of::<[u8; 16]>()
            + size_of::<u16>()
    }

    #[test]
    fn hash_block_kernel_digest_setup_sects_1() {
        let payload = b"KERNEL_DATA";
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(1, payload),
            initramfs: None,
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected = expected_kernel_digest(1, payload);
        let offset = kernel_hash_offset();
        assert_eq!(&block[offset..offset + 32], &expected);
    }

    #[test]
    fn hash_block_kernel_digest_setup_sects_0() {
        let payload = b"KERNEL_DATA";
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(0, payload),
            initramfs: None,
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected = expected_kernel_digest(0, payload);
        let offset = kernel_hash_offset();
        assert_eq!(&block[offset..offset + 32], &expected);
    }

    #[test]
    fn hash_block_kernel_digest_large_setup_sects() {
        let payload = b"KERNEL_PAYLOAD_LARGE_SETUP";
        let info = MeasuredBootInfo {
            kernel: make_fake_kernel(8, payload),
            initramfs: None,
            cmdline: CString::new("").unwrap(),
        };
        let block = info.build_hash_block().unwrap();
        let expected = expected_kernel_digest(8, payload);
        let offset = kernel_hash_offset();
        assert_eq!(&block[offset..offset + 32], &expected);
    }

    #[derive(Default)]
    struct Recorder {
        maps: Mutex<Vec<(u64, u64)>>,
        unmaps: Mutex<Vec<(u64, u64)>>,
        fail_map_gpa: Option<u64>,
    }

    impl ExternalDmaMapping for Recorder {
        fn map(
            &self,
            iova: u64,
            gpa: u64,
            size: u64,
        ) -> result::Result<(), ExternalDmaMappingError> {
            assert_eq!(iova, gpa, "tracker must identity-map (iova == gpa)");
            if self.fail_map_gpa == Some(gpa) {
                return Err(ExternalDmaMappingError::Map {
                    iova,
                    gpa,
                    size,
                    source: io::Error::from_raw_os_error(libc::EIO).into(),
                });
            }
            self.maps.lock().unwrap().push((gpa, size));
            Ok(())
        }
        fn unmap(&self, iova: u64, size: u64) -> result::Result<(), ExternalDmaMappingError> {
            self.unmaps.lock().unwrap().push((iova, size));
            Ok(())
        }
    }

    fn page(n: u64) -> u64 {
        n * PAGE_SIZE_4K
    }

    fn tracker_with_region(base: u64, size: u64) -> (SevSnpSharedPageTracker, Arc<Recorder>) {
        let t = SevSnpSharedPageTracker::new();
        t.register_region(base, size);
        let rec = Arc::new(Recorder::default());
        t.add_dma_mapping_handler(&(Arc::clone(&rec) as Arc<dyn ExternalDmaMapping>))
            .unwrap();
        (t, rec)
    }

    #[test]
    fn shared_maps_each_page_individually() {
        let (t, rec) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(0), 3 * PAGE_SIZE_4K, true).unwrap();
        assert_eq!(
            *rec.maps.lock().unwrap(),
            vec![
                (page(0), PAGE_SIZE_4K),
                (page(1), PAGE_SIZE_4K),
                (page(2), PAGE_SIZE_4K),
            ]
        );
    }

    #[test]
    fn shared_is_idempotent() {
        let (t, rec) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(0), 2 * PAGE_SIZE_4K, true).unwrap();
        t.set_shared(page(0), 2 * PAGE_SIZE_4K, true).unwrap();
        assert_eq!(rec.maps.lock().unwrap().len(), 2);
    }

    #[test]
    fn private_coalesces_contiguous_runs() {
        let (t, rec) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(0), 4 * PAGE_SIZE_4K, true).unwrap();
        rec.unmaps.lock().unwrap().clear();
        t.set_shared(page(0), 4 * PAGE_SIZE_4K, false).unwrap();
        assert_eq!(
            *rec.unmaps.lock().unwrap(),
            vec![(page(0), 4 * PAGE_SIZE_4K)]
        );
    }

    #[test]
    fn private_splits_runs_around_holes() {
        let (t, rec) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(0), 2 * PAGE_SIZE_4K, true).unwrap();
        t.set_shared(page(3), PAGE_SIZE_4K, true).unwrap();
        rec.unmaps.lock().unwrap().clear();
        t.set_shared(page(0), 4 * PAGE_SIZE_4K, false).unwrap();
        assert_eq!(
            *rec.unmaps.lock().unwrap(),
            vec![(page(0), 2 * PAGE_SIZE_4K), (page(3), PAGE_SIZE_4K)]
        );
    }

    #[test]
    fn add_handler_replays_shared_set() {
        let (t, first) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(1), PAGE_SIZE_4K, true).unwrap();
        let weak = Arc::downgrade(&first);
        drop(first);
        assert!(weak.upgrade().is_none());
        t.set_shared(page(2), PAGE_SIZE_4K, true).unwrap();
        let late = Arc::new(Recorder::default());
        t.add_dma_mapping_handler(&(Arc::clone(&late) as Arc<dyn ExternalDmaMapping>))
            .unwrap();
        assert_eq!(
            *late.maps.lock().unwrap(),
            vec![(page(1), PAGE_SIZE_4K), (page(2), PAGE_SIZE_4K)]
        );
    }

    #[test]
    fn replacing_handler_replays_shared_pages() {
        let (t, previous) = tracker_with_region(page(0), 4 * PAGE_SIZE_4K);
        t.set_shared(page(1), PAGE_SIZE_4K, true).unwrap();

        // An operation on another memory device can still hold the old handler.
        let next = Arc::new(Recorder::default());
        t.add_dma_mapping_handler(&(Arc::clone(&next) as Arc<dyn ExternalDmaMapping>))
            .unwrap();
        t.set_shared(page(2), PAGE_SIZE_4K, true).unwrap();
        assert_eq!(
            *previous.maps.lock().unwrap(),
            vec![(page(1), PAGE_SIZE_4K)]
        );
        assert_eq!(
            *next.maps.lock().unwrap(),
            vec![(page(1), PAGE_SIZE_4K), (page(2), PAGE_SIZE_4K)]
        );
    }

    #[test]
    fn replay_failure_rolls_back_partial_maps() {
        // Pages shared before any attach, as a guest converts them.
        let t = SevSnpSharedPageTracker::new();
        t.register_region(page(0), 2 * PAGE_SIZE_4K);
        t.register_region(page(8), 2 * PAGE_SIZE_4K);
        t.set_shared(page(0), 2 * PAGE_SIZE_4K, true).unwrap();
        t.set_shared(page(8), 2 * PAGE_SIZE_4K, true).unwrap();

        // The first page of the second region fails, so the rollback has to
        // reach back into the first one.
        let failed = Arc::new(Recorder {
            fail_map_gpa: Some(page(8)),
            ..Default::default()
        });
        assert!(
            t.add_dma_mapping_handler(&(Arc::clone(&failed) as Arc<dyn ExternalDmaMapping>))
                .is_err()
        );
        assert_eq!(
            *failed.unmaps.lock().unwrap(),
            vec![(page(0), PAGE_SIZE_4K), (page(1), PAGE_SIZE_4K)]
        );

        // The shared set is untouched, so a later attach replays all of it.
        let late = Arc::new(Recorder::default());
        t.add_dma_mapping_handler(&(Arc::clone(&late) as Arc<dyn ExternalDmaMapping>))
            .unwrap();
        assert_eq!(late.maps.lock().unwrap().len(), 4);
    }

    #[test]
    fn conversion_outside_any_region_is_ignored() {
        let (t, rec) = tracker_with_region(page(0), 2 * PAGE_SIZE_4K);
        t.set_shared(page(100), 4 * PAGE_SIZE_4K, true).unwrap();
        assert!(rec.maps.lock().unwrap().is_empty());
    }
}
