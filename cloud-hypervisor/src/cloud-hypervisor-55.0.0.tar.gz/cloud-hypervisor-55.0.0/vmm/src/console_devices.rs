// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// Copyright © 2019 Intel Corporation
// Copyright © 2024 Microsoft Corporation
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause
//

use std::fs::{File, OpenOptions, read_link};
use std::mem::zeroed;
use std::net::{SocketAddr, TcpListener};
use std::os::fd::{AsRawFd, FromRawFd, RawFd};
use std::os::unix::fs::OpenOptionsExt;
use std::path::PathBuf;
use std::sync::Arc;
use std::{io, result};

use libc::{TCSANOW, cfmakeraw, isatty, tcgetattr, tcsetattr, termios};
use thiserror::Error;
use vmm_sys_util::errno;

use crate::Vmm;
use crate::locked_unix_listener::{LockedUnixListener, LockedUnixListenerError};
use crate::sigwinch_listener::listen_for_sigwinch_on_tty;
use crate::vm_config::{ConsoleOutput, TcpConsoleConfig};

const TIOCSPTLCK: libc::c_int = 0x4004_5431;
const TIOCGPTPEER: libc::c_int = 0x5441;

/// Errors associated with console devices
#[derive(Debug, Error)]
pub enum ConsoleDeviceError {
    /// Error creating console device
    #[error("Error creating console device")]
    CreateConsoleDevice(#[source] io::Error),

    /// No socket option support for console device
    #[error("No socket option support for console device")]
    NoSocketOptionSupportForConsoleDevice,

    /// The serial socket is already in use by another running instance
    #[error("Serial socket {0:?} is already in use by another running instance")]
    SerialSocketInUse(PathBuf),

    /// The console socket is already in use by another running instance
    #[error("Console socket {0:?} is already in use by another running instance")]
    ConsoleSocketInUse(PathBuf),

    #[error("TCP console address {0} is not loopback")]
    TcpAddressNotLoopback(SocketAddr),

    /// Cannot bind the TCP console listener
    #[error("Cannot bind TCP console listener")]
    BindTcpListener(#[source] io::Error),

    #[error("Cannot set TCP console listener nonblocking")]
    SetTcpListenerNonblocking(#[source] io::Error),

    /// Error setting pty raw mode
    #[error("Error setting pty raw mode")]
    SetPtyRaw(#[source] errno::Error),

    /// Cannot duplicate file descriptor
    #[error("Cannot duplicate file descriptor")]
    DupFd(#[source] errno::Error),

    /// Error starting sigwinch listener
    #[error("Error starting sigwinch listener")]
    StartSigwinchListener(#[source] io::Error),
}

type ConsoleDeviceResult<T> = result::Result<T, ConsoleDeviceError>;

#[derive(Clone)]
pub enum ConsoleTransport {
    File(Arc<File>),
    Pty(Arc<File>),
    Tty(Arc<File>),
    Null,
    Socket(Arc<LockedUnixListener>),
    TcpListen(Arc<TcpListener>),
    Off,
}

fn tcp_console_transport(
    tcp: &TcpConsoleConfig,
    stored: Option<&Arc<TcpListener>>,
) -> ConsoleDeviceResult<ConsoleTransport> {
    let addr = tcp.address;
    if !addr.ip().is_loopback() {
        return Err(ConsoleDeviceError::TcpAddressNotLoopback(addr));
    }
    // Reuse across reboot to avoid binding while sandboxed.
    if let Some(listener) = stored
        && listener.local_addr().is_ok_and(|bound| bound == addr)
    {
        return Ok(ConsoleTransport::TcpListen(Arc::clone(listener)));
    }
    let listener = TcpListener::bind(addr).map_err(ConsoleDeviceError::BindTcpListener)?;
    listener
        .set_nonblocking(true)
        .map_err(ConsoleDeviceError::SetTcpListenerNonblocking)?;
    Ok(ConsoleTransport::TcpListen(Arc::new(listener)))
}

#[derive(Clone)]
pub struct ConsoleInfo {
    pub console: ConsoleTransport,
    pub serial: ConsoleTransport,
    #[cfg(target_arch = "x86_64")]
    pub debug: ConsoleTransport,
}

fn modify_mode<F: FnOnce(&mut termios)>(
    fd: RawFd,
    f: F,
    original_termios_opt: &mut Option<termios>,
) -> errno::Result<()> {
    // SAFETY: safe because we check the return value of isatty.
    if unsafe { isatty(fd) } != 1 {
        return Ok(());
    }

    // SAFETY: The following pair are safe because termios gets totally overwritten by tcgetattr
    // and we check the return result.
    let mut termios: termios = unsafe { zeroed() };
    // SAFETY: see above
    let ret = unsafe { tcgetattr(fd, &raw mut termios) };
    if ret < 0 {
        return errno::errno_result();
    }
    if original_termios_opt.is_none() {
        original_termios_opt.replace(termios);
    }

    f(&mut termios);
    // SAFETY: Safe because the syscall will only read the extent of termios and we check
    // the return result.
    let ret = unsafe { tcsetattr(fd, TCSANOW, &raw const termios) };
    if ret < 0 {
        return errno::errno_result();
    }

    Ok(())
}

fn set_raw_mode(
    f: &dyn AsRawFd,
    original_termios_opt: &mut Option<termios>,
) -> ConsoleDeviceResult<()> {
    modify_mode(
        f.as_raw_fd(),
        // SAFETY: FFI call. Variable t is guaranteed to be a valid termios from modify_mode.
        |t| unsafe { cfmakeraw(t) },
        original_termios_opt,
    )
    .map_err(ConsoleDeviceError::SetPtyRaw)
}

fn create_pty() -> io::Result<(File, File, PathBuf)> {
    // Try to use /dev/pts/ptmx first then fall back to /dev/ptmx
    // This is done to try and use the devpts filesystem that
    // could be available for use in the process's namespace first.
    // Ideally these are all the same file though but different
    // kernels could have things setup differently.
    // See https://www.kernel.org/doc/Documentation/filesystems/devpts.txt
    // for further details.

    let custom_flags = libc::O_NONBLOCK;
    let main = match OpenOptions::new()
        .read(true)
        .write(true)
        .custom_flags(custom_flags)
        .open("/dev/pts/ptmx")
    {
        Ok(f) => f,
        _ => OpenOptions::new()
            .read(true)
            .write(true)
            .custom_flags(custom_flags)
            .open("/dev/ptmx")?,
    };
    let mut unlock: libc::c_ulong = 0;
    // SAFETY: FFI call into libc, trivially safe
    unsafe { libc::ioctl(main.as_raw_fd(), TIOCSPTLCK as _, &mut unlock) };

    // SAFETY: FFI call into libc, trivially safe
    let sub_fd = unsafe {
        libc::ioctl(
            main.as_raw_fd(),
            TIOCGPTPEER as _,
            libc::O_NOCTTY | libc::O_RDWR,
        )
    };
    if sub_fd == -1 {
        return errno::errno_result().map_err(|e| e.into());
    }

    let proc_path = PathBuf::from(format!("/proc/self/fd/{sub_fd}"));
    let path = read_link(proc_path)?;

    // SAFETY: sub_fd is checked to be valid before being wrapped in File
    Ok((main, unsafe { File::from_raw_fd(sub_fd) }, path))
}

fn dup_stdout() -> errno::Result<File> {
    // SAFETY: FFI call to dup. Trivially safe.
    let stdout = unsafe { libc::dup(libc::STDOUT_FILENO) };
    if stdout == -1 {
        return errno::errno_result();
    }
    // SAFETY: stdout is valid and owned solely by us.
    Ok(unsafe { File::from_raw_fd(stdout) })
}

pub(crate) fn pre_create_console_devices(vmm: &mut Vmm) -> ConsoleDeviceResult<ConsoleInfo> {
    // Drop the previous VM's console handles. The VMM serial socket listener
    // remains available for reuse across reboot and shutdown followed by boot.
    vmm.console_info = None;

    let vm_config = Arc::clone(vmm.vm_config.as_mut().unwrap());
    let mut vmconfig = vm_config.lock().unwrap();
    let mut original_termios_opt = vmm.original_termios_opt.lock().unwrap();

    let console_info = ConsoleInfo {
        console: match &mut vmconfig.console.output {
            ConsoleOutput::File { file: path } => {
                let file = File::create(path).map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                ConsoleTransport::File(Arc::new(file))
            }
            ConsoleOutput::Pty { file } => {
                let (main_fd, sub_fd, path) =
                    create_pty().map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                set_raw_mode(&sub_fd.as_raw_fd(), &mut original_termios_opt)?;
                *file = Some(path.clone());
                vmm.console_resize_pipe = Some(Arc::new(
                    listen_for_sigwinch_on_tty(sub_fd, &vmm.seccomp_action)
                        .map_err(ConsoleDeviceError::StartSigwinchListener)?,
                ));
                ConsoleTransport::Pty(Arc::new(main_fd))
            }
            ConsoleOutput::Tty => {
                // Duplicating the file descriptors like this is needed as otherwise
                // they will be closed on a reboot and the numbers reused

                let stdout = dup_stdout().map_err(ConsoleDeviceError::DupFd)?;

                // SAFETY: FFI call. Trivially safe.
                if unsafe { libc::isatty(stdout.as_raw_fd()) } == 1 {
                    vmm.console_resize_pipe = Some(Arc::new(
                        listen_for_sigwinch_on_tty(
                            stdout.try_clone().unwrap(),
                            &vmm.seccomp_action,
                        )
                        .map_err(ConsoleDeviceError::StartSigwinchListener)?,
                    ));
                }

                // Make sure stdout is in raw mode, if it's a terminal.
                set_raw_mode(&stdout, &mut original_termios_opt)?;
                ConsoleTransport::Tty(Arc::new(stdout))
            }
            ConsoleOutput::Socket {
                socket: socket_path,
            } => {
                if let Some(listener) = vmm.console_socket_listener.as_ref()
                    && listener.path() == socket_path.as_path()
                {
                    ConsoleTransport::Socket(Arc::clone(listener))
                } else {
                    let listener = LockedUnixListener::bind(socket_path).map_err(|e| match e {
                        LockedUnixListenerError::InUse(path) => {
                            ConsoleDeviceError::ConsoleSocketInUse(path)
                        }
                        LockedUnixListenerError::Io(e) => {
                            ConsoleDeviceError::CreateConsoleDevice(e)
                        }
                    })?;
                    ConsoleTransport::Socket(Arc::new(listener))
                }
            }
            ConsoleOutput::Tcp { tcp } => {
                tcp_console_transport(tcp, vmm.console_tcp_listener.as_ref())?
            }
            ConsoleOutput::Null => ConsoleTransport::Null,
            ConsoleOutput::Off => ConsoleTransport::Off,
        },
        serial: match &mut vmconfig.serial.output {
            ConsoleOutput::File { file: path } => {
                let file = File::create(path).map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                ConsoleTransport::File(Arc::new(file))
            }
            ConsoleOutput::Pty { file } => {
                let (main_fd, sub_fd, path) =
                    create_pty().map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                set_raw_mode(&sub_fd.as_raw_fd(), &mut original_termios_opt)?;
                *file = Some(path.clone());
                ConsoleTransport::Pty(Arc::new(main_fd))
            }
            ConsoleOutput::Tty => {
                // During vm_shutdown, when serial device is closed, FD#2(STDOUT)
                // will be closed and FD#2 could be reused in a future boot of the
                // guest by a different file.
                //
                // To ensure FD#2 always points to STANDARD OUT, a `dup` of STDOUT
                // is passed to serial device. Doing so, even if the serial device
                // were to be closed, FD#2 will continue to point to STANDARD OUT.

                let stdout = dup_stdout().map_err(ConsoleDeviceError::DupFd)?;

                // Make sure stdout is in raw mode, if it's a terminal.
                set_raw_mode(&stdout, &mut original_termios_opt)?;

                ConsoleTransport::Tty(Arc::new(stdout))
            }
            ConsoleOutput::Socket {
                socket: socket_path,
            } => {
                if let Some(listener) = vmm.serial_socket_listener.as_ref()
                    && listener.path() == socket_path.as_path()
                {
                    ConsoleTransport::Socket(Arc::clone(listener))
                } else {
                    let listener = LockedUnixListener::bind(socket_path).map_err(|e| match e {
                        LockedUnixListenerError::InUse(path) => {
                            ConsoleDeviceError::SerialSocketInUse(path)
                        }
                        LockedUnixListenerError::Io(e) => {
                            ConsoleDeviceError::CreateConsoleDevice(e)
                        }
                    })?;
                    ConsoleTransport::Socket(Arc::new(listener))
                }
            }
            ConsoleOutput::Tcp { tcp } => {
                tcp_console_transport(tcp, vmm.serial_tcp_listener.as_ref())?
            }
            ConsoleOutput::Null => ConsoleTransport::Null,
            ConsoleOutput::Off => ConsoleTransport::Off,
        },
        #[cfg(target_arch = "x86_64")]
        debug: match &mut vmconfig.debug_console.output {
            ConsoleOutput::File { file: path } => {
                let file = File::create(path).map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                ConsoleTransport::File(Arc::new(file))
            }
            ConsoleOutput::Pty { file } => {
                let (main_fd, sub_fd, path) =
                    create_pty().map_err(ConsoleDeviceError::CreateConsoleDevice)?;
                set_raw_mode(&sub_fd.as_raw_fd(), &mut original_termios_opt)?;
                *file = Some(path.clone());
                ConsoleTransport::Pty(Arc::new(main_fd))
            }
            ConsoleOutput::Tty => {
                let out =
                    dup_stdout().map_err(|e| ConsoleDeviceError::CreateConsoleDevice(e.into()))?;
                set_raw_mode(&out, &mut original_termios_opt)?;
                ConsoleTransport::Tty(Arc::new(out))
            }
            ConsoleOutput::Socket { .. } | ConsoleOutput::Tcp { .. } => {
                return Err(ConsoleDeviceError::NoSocketOptionSupportForConsoleDevice);
            }
            ConsoleOutput::Null => ConsoleTransport::Null,
            ConsoleOutput::Off => ConsoleTransport::Off,
        },
    };

    vmm.serial_socket_listener = match &console_info.serial {
        ConsoleTransport::Socket(listener) => Some(Arc::clone(listener)),
        _ => None,
    };

    vmm.console_socket_listener = match &console_info.console {
        ConsoleTransport::Socket(listener) => Some(Arc::clone(listener)),
        _ => None,
    };

    vmm.serial_tcp_listener = match &console_info.serial {
        ConsoleTransport::TcpListen(listener) => Some(Arc::clone(listener)),
        _ => None,
    };

    vmm.console_tcp_listener = match &console_info.console {
        ConsoleTransport::TcpListen(listener) => Some(Arc::clone(listener)),
        _ => None,
    };

    Ok(console_info)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::vm_config::parse_tcp_address;

    #[test]
    fn test_tcp_console_loopback_addresses() {
        for address in ["127.0.0.1:0", "127.0.0.2:0", "[::1]:0"] {
            assert!(parse_tcp_address(address).unwrap().ip().is_loopback());
        }
        for address in [
            "0.0.0.0:0",
            "[::]:0",
            "192.0.2.1:0",
            "[2001:db8::1]:0",
            "[::ffff:192.0.2.1]:0",
        ] {
            let tcp = TcpConsoleConfig {
                address: address.parse().unwrap(),
                server: true,
            };
            assert!(matches!(
                tcp_console_transport(&tcp, None),
                Err(ConsoleDeviceError::TcpAddressNotLoopback(_))
            ));
        }
        parse_tcp_address("not-an-endpoint").unwrap_err();
        parse_tcp_address("localhost:0").unwrap_err();
    }

    #[test]
    fn test_tcp_console_listener_reuse() {
        let mut tcp = TcpConsoleConfig {
            address: "127.0.0.1:0".parse().unwrap(),
            server: true,
        };
        let ConsoleTransport::TcpListen(listener) = tcp_console_transport(&tcp, None).unwrap()
        else {
            panic!("Expected TCP listener");
        };
        tcp.address = listener.local_addr().unwrap();
        let ConsoleTransport::TcpListen(reused) =
            tcp_console_transport(&tcp, Some(&listener)).unwrap()
        else {
            panic!("Expected TCP listener");
        };
        assert!(Arc::ptr_eq(&listener, &reused));
    }
}
