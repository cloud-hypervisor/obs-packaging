// SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause
//
// Copyright © 2024, Microsoft Corporation
//

use std::cmp;

use anyhow::anyhow;
use iced_x86::Register;
use log::debug;
use mshv_bindings::*;

use crate::arch::emulator::{PlatformEmulator, PlatformError};
use crate::arch::x86::emulator::{CpuStateManager, EmulatorCpuState};
use crate::cpu::Vcpu;
use crate::mshv::MshvVcpu;

/// Returns how many bytes of an access at `gva` are in the first page.
fn first_page_len(gva: u64, len: usize) -> usize {
    let page_size = HV_HYP_PAGE_SIZE as usize;
    let page_offset = gva as usize % page_size;
    let bytes_left_in_page = page_size - page_offset;
    let first_len = cmp::min(len, bytes_left_in_page);
    // We only handle one page cross-page access
    assert!(len - first_len <= page_size);
    first_len
}

/// Returns the `HV_TRANSLATE_GVA_VALIDATE_*` checks the guest access behind a
/// memory intercept of `access_type` has already passed. A write implies the
/// page is readable as well.
pub fn intercept_translate_flags(access_type: u8) -> u32 {
    match u32::from(access_type) {
        HV_INTERCEPT_ACCESS_READ => HV_TRANSLATE_GVA_VALIDATE_READ,
        HV_INTERCEPT_ACCESS_WRITE => {
            HV_TRANSLATE_GVA_VALIDATE_READ | HV_TRANSLATE_GVA_VALIDATE_WRITE
        }
        _ => 0,
    }
}

/// Returns the GPA for `gva` from the cached intercept `mapping` if it covers
/// the same page and the intercepted access already passed every check in
/// `flags`, so the access does not need a translate hypercall.
fn cached_gpa(
    mapping: Option<(u64, u64)>,
    mapping_flags: u32,
    gva: u64,
    flags: u32,
) -> Option<u64> {
    let page_offset_mask = (HV_HYP_PAGE_SIZE as u64) - 1;
    let page_base = !page_offset_mask;

    let (cached_gva, cached_gpa) = mapping?;
    if (cached_gva & page_base) != (gva & page_base) || flags & !mapping_flags != 0 {
        return None;
    }

    Some((cached_gpa & page_base) | (gva & page_offset_mask))
}

pub struct MshvEmulatorContext<'a> {
    pub vcpu: &'a MshvVcpu,
    /// Initial (GVA, GPA) mapping provided by the hypervisor if the hypervisor provided a
    /// valid mapping. Used as a fast path in [`MshvEmulatorContext::translate`] to avoid a
    /// translate hypercall. `None` when the hypervisor did not provide a valid mapping.
    pub mapping: Option<(u64, u64)>,
    /// `HV_TRANSLATE_GVA_VALIDATE_*` checks the intercepted access passed for `mapping`,
    /// see [`intercept_translate_flags`]. Accesses needing any other check, such as a
    /// write through a mapping obtained from a read, are translated by the hypervisor.
    pub mapping_flags: u32,
}

impl MshvEmulatorContext<'_> {
    // Do the actual gva -> gpa translation
    #[expect(non_upper_case_globals)]
    fn translate(&self, gva: u64, flags: u32) -> Result<u64, PlatformError> {
        // MSHV can return a page-aligned GPA; splice gva's page offset
        // in so byte-sized MMIO (e.g. virtio device_status) is precise.
        let page_offset_mask = (HV_HYP_PAGE_SIZE as u64) - 1;
        let page_offset = gva & page_offset_mask;
        let page_base = !page_offset_mask;

        if let Some(gpa) = cached_gpa(self.mapping, self.mapping_flags, gva, flags) {
            return Ok(gpa);
        }

        let (gpa, result_code) = self
            .vcpu
            .translate_gva(gva, flags.into())
            .map_err(|e| PlatformError::TranslateVirtualAddress(anyhow!(e)))?;

        match result_code {
            hv_translate_gva_result_code_HV_TRANSLATE_GVA_SUCCESS => {
                Ok((gpa & page_base) | page_offset)
            }
            _ => Err(PlatformError::TranslateVirtualAddress(anyhow!(result_code))),
        }
    }

    fn r(&self, gva: u64, data: &mut [u8], flags: u32) -> Result<(), PlatformError> {
        let gpa = self.translate(gva, flags)?;
        debug!(
            "mshv emulator: memory read {} bytes from [{:#x} -> {:#x}]",
            data.len(),
            gva,
            gpa
        );

        if let Some(vm_ops) = &self.vcpu.vm_ops
            && vm_ops.guest_mem_read(gpa, data).is_err()
        {
            vm_ops
                .mmio_read(gpa, data)
                .map_err(|e| PlatformError::MemoryReadFailure(e.into()))?;
        }

        Ok(())
    }

    fn read_memory_flags(
        &self,
        gva: u64,
        data: &mut [u8],
        flags: u32,
    ) -> Result<(), PlatformError> {
        let len = first_page_len(gva, data.len());

        self.r(gva, &mut data[..len], flags)?;

        if len < data.len() {
            self.r(gva + len as u64, &mut data[len..], flags)?;
        }

        Ok(())
    }

    fn w(&mut self, gva: u64, data: &[u8]) -> Result<(), PlatformError> {
        let gpa = self.translate(gva, HV_TRANSLATE_GVA_VALIDATE_WRITE)?;
        debug!(
            "mshv emulator: memory write {} bytes at [{:#x} -> {:#x}]",
            data.len(),
            gva,
            gpa
        );

        if let Some(vm_ops) = &self.vcpu.vm_ops
            && vm_ops.guest_mem_write(gpa, data).is_err()
        {
            vm_ops
                .mmio_write(gpa, data)
                .map_err(|e| PlatformError::MemoryWriteFailure(e.into()))?;
        }

        Ok(())
    }

    pub fn update_cpu_state(
        &self,
        cpu_id: usize,
        old_state: &<Self as PlatformEmulator>::CpuState,
        new_state: &<Self as PlatformEmulator>::CpuState,
    ) -> Result<(), PlatformError> {
        if cpu_id != self.vcpu.vp_index as usize {
            return Err(PlatformError::SetCpuStateFailure(anyhow!(
                "CPU id mismatch {:?} {:?}",
                cpu_id,
                self.vcpu.vp_index
            )));
        }

        debug!("mshv emulator: Updating CPU state");
        debug!("mshv emulator: {:#x?}", new_state.regs);

        self.vcpu
            .set_regs(&new_state.regs)
            .map_err(|e| PlatformError::SetCpuStateFailure(e.into()))?;

        if old_state.sregs != new_state.sregs {
            debug!("mshv emulator: Updating CPU segment registers");
            // Emulation only modifies segment registers among special
            // registers. Use the VP register page to write only segments,
            // avoiding IOCTLs for other special registers (tr, ldt, gdt,
            // idt, cr*, efer, etc.) that emulation never modifies.
            if let Some(reg_page) = self.vcpu.fd.get_vp_reg_page() {
                let vp_reg_page = reg_page.0;
                let sregs: SpecialRegisters = new_state.sregs.into();
                // SAFETY: vp_reg_page is a valid mapped pointer
                unsafe {
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.cs = sregs.cs.into();
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.ds = sregs.ds.into();
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.es = sregs.es.into();
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.fs = sregs.fs.into();
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.gs = sregs.gs.into();
                    (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.ss = sregs.ss.into();
                    (*vp_reg_page).dirty |= 1 << HV_X64_REGISTER_CLASS_SEGMENT;
                }
            } else {
                debug!("mshv emulator: {:#x?}", new_state.sregs);
                self.vcpu
                    .set_sregs(&new_state.sregs)
                    .map_err(|e| PlatformError::SetCpuStateFailure(e.into()))?;
            }
        }

        Ok(())
    }
}

/// Platform emulation for Hyper-V
impl PlatformEmulator for MshvEmulatorContext<'_> {
    type CpuState = EmulatorCpuState;

    fn read_memory(&self, gva: u64, data: &mut [u8]) -> Result<(), PlatformError> {
        self.read_memory_flags(gva, data, HV_TRANSLATE_GVA_VALIDATE_READ)
    }

    fn write_memory(&mut self, gva: u64, data: &[u8]) -> Result<(), PlatformError> {
        let len = first_page_len(gva, data.len());

        self.w(gva, &data[..len])?;

        if len < data.len() {
            self.w(gva + len as u64, &data[len..])?;
        }

        Ok(())
    }

    fn cpu_state(&self, cpu_id: usize) -> Result<Self::CpuState, PlatformError> {
        if cpu_id != self.vcpu.vp_index as usize {
            return Err(PlatformError::GetCpuStateFailure(anyhow!(
                "CPU id mismatch {:?} {:?}",
                cpu_id,
                self.vcpu.vp_index
            )));
        }

        let regs = self
            .vcpu
            .get_regs()
            .map_err(|e| PlatformError::GetCpuStateFailure(e.into()))?;

        // For emulation, we only need segment registers, cr0, and efer
        // from special registers. Read them directly from the VP register
        // page to avoid IOCTLs for other special registers (tr, ldt, gdt,
        // idt, cr2, apic_base, etc.) that emulation doesn't use.
        let sregs = if let Some(reg_page) = self.vcpu.fd.get_vp_reg_page() {
            let vp_reg_page = reg_page.0;
            let mut mshv_sregs = SpecialRegisters::default();
            // SAFETY: vp_reg_page is a valid mapped pointer
            unsafe {
                mshv_sregs.cs = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.cs.into();
                mshv_sregs.ds = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.ds.into();
                mshv_sregs.es = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.es.into();
                mshv_sregs.fs = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.fs.into();
                mshv_sregs.gs = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.gs.into();
                mshv_sregs.ss = (*vp_reg_page).__bindgen_anon_3.__bindgen_anon_1.ss.into();
                mshv_sregs.cr0 = (*vp_reg_page).cr0;
                mshv_sregs.efer = (*vp_reg_page).efer;
            }
            mshv_sregs.into()
        } else {
            self.vcpu
                .get_sregs()
                .map_err(|e| PlatformError::GetCpuStateFailure(e.into()))?
        };

        debug!("mshv emulator: Getting new CPU state");
        debug!("mshv emulator: {regs:#x?}");

        Ok(EmulatorCpuState { regs, sregs })
    }

    fn set_cpu_state(&self, cpu_id: usize, state: Self::CpuState) -> Result<(), PlatformError> {
        if cpu_id != self.vcpu.vp_index as usize {
            return Err(PlatformError::SetCpuStateFailure(anyhow!(
                "CPU id mismatch {:?} {:?}",
                cpu_id,
                self.vcpu.vp_index
            )));
        }

        debug!("mshv emulator: Setting new CPU state");
        debug!("mshv emulator: {:#x?}", state.regs);

        self.vcpu
            .set_regs(&state.regs)
            .map_err(|e| PlatformError::SetCpuStateFailure(e.into()))?;
        self.vcpu
            .set_sregs(&state.sregs)
            .map_err(|e| PlatformError::SetCpuStateFailure(e.into()))
    }

    fn fetch(&self, ip: u64, instruction_bytes: &mut [u8]) -> Result<(), PlatformError> {
        let rip =
            self.cpu_state(self.vcpu.vp_index as usize)?
                .linearize(Register::CS, ip, false)?;
        self.read_memory_flags(
            rip,
            instruction_bytes,
            HV_TRANSLATE_GVA_VALIDATE_READ | HV_TRANSLATE_GVA_VALIDATE_EXECUTE,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_first_page_len() {
        assert_eq!(first_page_len(0x1000, 8), 8);
        assert_eq!(first_page_len(0x1ff8, 8), 8);
        assert_eq!(first_page_len(0x1ff8, 16), 8);
        assert_eq!(first_page_len(0x1fff, 2), 1);
    }

    #[test]
    fn test_cached_gpa_requires_intercept_validation() {
        let mapping = Some((0x7000_1010, 0xd000_0010));
        let read = intercept_translate_flags(HV_INTERCEPT_ACCESS_READ as u8);
        let write = intercept_translate_flags(HV_INTERCEPT_ACCESS_WRITE as u8);
        let fetch = HV_TRANSLATE_GVA_VALIDATE_READ | HV_TRANSLATE_GVA_VALIDATE_EXECUTE;

        // A read intercept only vouches for reads of that page.
        assert_eq!(
            cached_gpa(mapping, read, 0x7000_1020, HV_TRANSLATE_GVA_VALIDATE_READ),
            Some(0xd000_0020)
        );
        assert_eq!(
            cached_gpa(mapping, read, 0x7000_1020, HV_TRANSLATE_GVA_VALIDATE_WRITE),
            None
        );
        assert_eq!(cached_gpa(mapping, read, 0x7000_1020, fetch), None);

        // A write intercept vouches for reads and writes of that page.
        assert_eq!(
            cached_gpa(mapping, write, 0x7000_1020, HV_TRANSLATE_GVA_VALIDATE_READ),
            Some(0xd000_0020)
        );
        assert_eq!(
            cached_gpa(mapping, write, 0x7000_1020, HV_TRANSLATE_GVA_VALIDATE_WRITE),
            Some(0xd000_0020)
        );

        // Other pages, other intercept types and missing mappings are never cached.
        assert_eq!(
            cached_gpa(mapping, write, 0x7000_2000, HV_TRANSLATE_GVA_VALIDATE_READ),
            None
        );
        assert_eq!(
            cached_gpa(
                mapping,
                intercept_translate_flags(HV_INTERCEPT_ACCESS_EXECUTE as u8),
                0x7000_1020,
                HV_TRANSLATE_GVA_VALIDATE_READ
            ),
            None
        );
        assert_eq!(
            cached_gpa(None, write, 0x7000_1020, HV_TRANSLATE_GVA_VALIDATE_READ),
            None
        );
    }
}
